var recordData = [
 {
  "length": 4588714,
  "seq_id": "NZ_CP083638.1",
  "regions": [
   {
    "start": 293204,
    "end": 348217,
    "idx": 1,
    "orfs": [
     {
      "start": 293687,
      "end": 294340,
      "strand": -1,
      "locus_tag": "ctg1_281",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_281</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_281</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 293,687 - 294,340,\n (total: 654 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF00881<br>\n \n  biosynthetic-additional (smcogs) SMCOG1159:dihydropteridine reductase (Score: 317.4; E-value: 6.3e-97)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_281\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_281\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_281\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_281\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGATATCATTTCTGTCGCCTTAAAGCGTCATTCCACTAAGGCATTTGATGCCAGCAAAAAACTTACCCCAGAACAGGCCGAGCAGATCAAAACTCTTCTGCAATACAGCCCATCCAGCACCAACTCCCAGCCGTGGCATTTTATTGTTGCCAGCACGGAAGAAGGCAAAGCGCGTGTTGCCAAATCCGCCGCCGATAATTACGTGTTCAACGAGCGCAAAATGCTTGATGCCTCGCACGTCGTGGTGTTCTGCGCGAAAACCGCGATGGACGATGCCTGGCTGAAACAGGTTGTTGACCAGGAAGATGCCGATGGCCGCTTTGCCACGCCGGAAGCGAAAGCCGCGAACGATAAAGGTCGCAAATTCTTCGCCGATATGCACCGTAAAGATCTGCATGATGATGCTGAGTGGATGGCAAAACAGGTTTACCTCAACGTCGGTAACTTCCTGCTGGGCGTTGCGGCGCTGGGTCTGGACGCGGTGCCAATCGAAGGTTTTGACGCCGCAATCCTCGATGAAGAATTTGGTCTGAAAGAGAAAGGCTACACCAGCCTGGTGGTTGTTCCGGTAGGTCATCACAGCGTCGAAGATTTCAACGCTACACTGCCGAAATCCCGTCTGCCGCAAAACATCACCATAACTGAAGTGTAA",
      "translation": "MDIISVALKRHSTKAFDASKKLTPEQAEQIKTLLQYSPSSTNSQPWHFIVASTEEGKARVAKSAADNYVFNERKMLDASHVVVFCAKTAMDDAWLKQVVDQEDADGRFATPEAKAANDKGRKFFADMHRKDLHDDAEWMAKQVYLNVGNFLLGVAALGLDAVPIEGFDAAILDEEFGLKEKGYTSLVVVPVGHHSVEDFNATLPKSRLPQNITITEV",
      "product": ""
     },
     {
      "start": 294435,
      "end": 294803,
      "strand": -1,
      "locus_tag": "ctg1_282",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_282</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_282</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 294,435 - 294,803,\n (total: 369 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1198:hypothetical protein (Score: 203.4; E-value: 1.5e-62)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_282\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_282\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_282\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_282\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGATAAGCAATCACTGCACGAAACGGCGAAACGCCTGGCCCTTGAGTTACCCTTTGTCGAGCTTTGCTGGCCTTTTGGCCCGGAGTTCGATGTCTTTAAAATTGGCGGCAAGATTTTTATGCTGTCGTCGGAGCTGCGCGGCGTCCCCTTTATCAATTTGAAGTCCGATCCACAAAAATCCCTGTTAAATCAGCAGATATATCCGAGCATTAAGCCAGGGTATCACATGAATAAGAAGCACTGGATTTCAGTGTATCCAGGCGATGAGATCTCCGAAGCGTTACTGCGCGATCTTATCGATGATTCATGGAATTTAGTGGTTGATGGCTTATCTAAACGCGATCAAAAAAGAGTGCGCCCAGACTAA",
      "translation": "MDKQSLHETAKRLALELPFVELCWPFGPEFDVFKIGGKIFMLSSELRGVPFINLKSDPQKSLLNQQIYPSIKPGYHMNKKHWISVYPGDEISEALLRDLIDDSWNLVVDGLSKRDQKRVRPD",
      "product": ""
     },
     {
      "start": 294868,
      "end": 295068,
      "strand": -1,
      "locus_tag": "ctg1_283",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_283</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_283</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 294,868 - 295,068,\n (total: 201 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1253:putative lipoprotein (Score: 139.7; E-value: 5e-43)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_283\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_283\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_283\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_283\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTTTCCTCTCTTGCCTGCTGCTGCCCGCCCCCGCACTGGGGCTGACGCTGGCACAAAAACTGGTGAGCACGTTCCATCTGATGGATCTTAGCCAGCTTTACACTTTATTGTTTTGCCTGTGGTTTTTAGTGCTGGGCGCAATTGAGTATTTTGTTCTGCGCTTTATCTGGCAACGCTGGTTCTCACTGGCGGATTAA",
      "translation": "MAFLSCLLLPAPALGLTLAQKLVSTFHLMDLSQLYTLLFCLWFLVLGAIEYFVLRFIWQRWFSLAD",
      "product": ""
     },
     {
      "start": 295182,
      "end": 296300,
      "strand": -1,
      "locus_tag": "ctg1_284",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_284</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_284</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 295,182 - 296,300,\n (total: 1119 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1165:carboxylate-amine ligase (Score: 540.2; E-value: 3.1e-164)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_284\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_284\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_284\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_284\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCAATGCCCGATTTTCAAGTCTCTGAACCTTTTACCCTCGGTATTGAACTGGAAATGCAGGTGGTTAATCCGCCGGGCTATGACTTAAGCCAGGACTCTTCAACGCTGATTGACGCGGTTAAAAATCAGATCACTGCCGGGGAAGTAAAGCACGATATCACCGAAAGCATGCTGGAGCTGGCGACGGATGTTTGCCGTGATATCAACCAGGCTGCCGGGCAATTTTCAGCGATGCAGAAAGTCGTATTGCAGGCAGCCGCAGACCATCATCTGGAAATTTGCGGCGGGGGCACGCACCCGTTTCAGAAATGGCAGCGTCAGGAGGTATGCGATAACGAACGCTATCAACGAACGCTGGAAAACTTTGGTTATCTCATTCAGCAGGCGACCGTTTTTGGTCAGCATGTCCATGTTGGCTGCGCCAGTGGCGATGACGCCATTTATTTGCTGCACGGCTTGTCGCGGTTTGTGCCGCACTTTATCGCCCTTTCTGCCGCATCGCCGTATATGCAGGGAACGGATACACGCTTTGCTTCCTCAAGACCGAATATTTTTTCCGCCTTTCCCGACAATGGCCCAATGCCGTGGGTCAGTAACTGGCAACAATTTGAAACCCTGTTTCGTTGTCTGAGTTACACCAAGATGATCGACAGCATTAAAGATCTGCACTGGGATATTCGCCCCAGCCCCCATTTTGGCACGGTGGAAGTTCGGGTGATGGATACCCCATTAACCCTTAGCCACGCGGTAAATATGGCGGGATTAATTCAGGCCACCGCCCACTGGTTACTGACGGAACGCCCGTTCAAACATCAGGAGAAAGATTACCTGCTGTATAAATTCAACCGCTTCCAGGCCTGCCGTTATGGGCTGGAAGGTGTCATTACCGATCCGCACACTGGCGATCGTCGACCATTGACGGAAGACACCTTGCGATTGCTGGAAAAAATCGCCCCTTCCGCAGATAAAATTGGCGCATCGAGCGCGATTGAAGCCCTGCATCGCCAGGTCGTTAGCGGTCTGAATGAAGCGCAGCTGATGCGTGATTTCGTCGCCGATGGCGGCTCGCTGATTGGACTGGTGAAAAAGCATTGTGAAATCTGGGCCGGAGAATAA",
      "translation": "MPMPDFQVSEPFTLGIELEMQVVNPPGYDLSQDSSTLIDAVKNQITAGEVKHDITESMLELATDVCRDINQAAGQFSAMQKVVLQAAADHHLEICGGGTHPFQKWQRQEVCDNERYQRTLENFGYLIQQATVFGQHVHVGCASGDDAIYLLHGLSRFVPHFIALSAASPYMQGTDTRFASSRPNIFSAFPDNGPMPWVSNWQQFETLFRCLSYTKMIDSIKDLHWDIRPSPHFGTVEVRVMDTPLTLSHAVNMAGLIQATAHWLLTERPFKHQEKDYLLYKFNRFQACRYGLEGVITDPHTGDRRPLTEDTLRLLEKIAPSADKIGASSAIEALHRQVVSGLNEAQLMRDFVADGGSLIGLVKKHCEIWAGE",
      "product": ""
     },
     {
      "start": 296653,
      "end": 296904,
      "strand": 1,
      "locus_tag": "ctg1_285",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_285</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_285</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 296,653 - 296,904,\n (total: 252 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_285\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_285\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_285\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_285\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGCCCCAGGAGATATTTCTATCAACCCTGGGGCTGCCACTCCAAACCCGAACAATTTGGATGGTAGCCCCTTCTTCGCATGGAGGCAATATAAACATGCTGACGAAATATGCCCTTGTGGCAGTCATAGTGCTGTGTTTGACGGTGCTGGGATTTACGCTTCTGGTCGGCGACTCGCTGTGTGAGTTTACGGTGAAGGAACGTAATATTGAGTTTAAGGCTGTTCTCGCTTACGAACCGAAGAAGTAG",
      "translation": "MKPQEIFLSTLGLPLQTRTIWMVAPSSHGGNINMLTKYALVAVIVLCLTVLGFTLLVGDSLCEFTVKERNIEFKAVLAYEPKK",
      "product": ""
     },
     {
      "start": 297255,
      "end": 297407,
      "strand": 1,
      "locus_tag": "ctg1_286",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_286</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_286</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 297,255 - 297,407,\n (total: 153 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_286\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_286\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_286\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_286\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTGACGAAATATTCCCTTGTGGCGGTCATAGTGCTGTGTTTGACAGTGCTGGGATTTACGCTTCTGGTCGGCGACTCGCTGTGTGAGTTCACCGTAAAGGAACGTAATATTGAGTTCAGGGCTGTTCTCGCTTACGAACCGAAGAAGTAG",
      "translation": "MLTKYSLVAVIVLCLTVLGFTLLVGDSLCEFTVKERNIEFRAVLAYEPKK",
      "product": ""
     },
     {
      "start": 297517,
      "end": 298302,
      "strand": -1,
      "locus_tag": "ctg1_287",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_287</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_287</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 297,517 - 298,302,\n (total: 786 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short_C2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 231.8; E-value: 1.5e-70)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_287\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_287\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_287_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_287\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_287\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCGCAAAAGATTTTGCTCAACAATTGTTTGATCTCCACGATCGCGTCGCCTTTGTCACTGGCGCAGGTAGCGGTATCGGACAAATGATCGCTCTGGCTTTTGCCAGCGCAGGCGCACGAGTGGTGTGTTTTGATCTACGGGAAGATGGCGGACTTAAAGAGACGGTTAATCATATCGAAGCACTTGGTGGACAAGCCTTGTATTACACGGGCGATGTTCGGGAGTTGAGAGATCTTCGCTCAGCAGTCGCTCTGGCAAAAACACATTTTGGTCGTCTGGATATTGCCGTAAACGCCGCTGGAATCGCTAACGCGAACCCGGCGCTGGAAATGGAAAGCGAGCAATGGCAACGCGTTATAGATATCAACCTGACTGGTGTGTGGAATTCCTGTAAGGCGGAAGCCGAGTTAATGGTAGAGAACGGAGGCGGTTCGATTATAAATATTGCGTCAATGTCCGGGATTATCGTCAATCGCGGTCTGGAACAGGCCCACTACAACAGCTCCAAAGCAGGCGTGATTCATTTATCTAAAAGTCTTGCGATGGAATGGGTGAGTAATGGGATCCGCGTGAACTCAATCAGCCCAGGATATACCGCGACACCAATGAATACCCGACCTGAAATGGTGCATCAGACACGGGAGTTTGAAAGCCAGACGCCGATTCAACGGATGGCGAAAGTGGAAGAGATGGCGGGCCCAGCGCTGTTCCTTGCCAGCGATGCGGCGTCATTCTGCACTGGTGTTGATCTGGTGGTCGATGGTGGTTTTATCTGCTGGTAA",
      "translation": "MIAKDFAQQLFDLHDRVAFVTGAGSGIGQMIALAFASAGARVVCFDLREDGGLKETVNHIEALGGQALYYTGDVRELRDLRSAVALAKTHFGRLDIAVNAAGIANANPALEMESEQWQRVIDINLTGVWNSCKAEAELMVENGGGSIINIASMSGIIVNRGLEQAHYNSSKAGVIHLSKSLAMEWVSNGIRVNSISPGYTATPMNTRPEMVHQTREFESQTPIQRMAKVEEMAGPALFLASDAASFCTGVDLVVDGGFICW",
      "product": ""
     },
     {
      "start": 298335,
      "end": 299132,
      "strand": -1,
      "locus_tag": "ctg1_288",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_288</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_288</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 298,335 - 299,132,\n (total: 798 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 238.1; E-value: 1.7e-72)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_288\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_288\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_288_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_288\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_288\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAACGTAATTTTCAGGGTAAGACTGTAGTTATTACCGGGGCATGCCGGGGAATTGGGGCCGGGATCGCTGAACGCTTCGCCCGCGATGGCGCAAATCTGGTGATGGTTTCTAACGCTGCACGCGTTCATGAAACTGCTGAGCAACTGCGCCAACGTTATCAGGCTGACATTTTGTCATTAGAAGTCGATGTGACAGATGAAGCACAAGTACAGGCACTCTATGAACAAGCGGCTGCACGTTTTGGCAGCATCGATGTTTCCATCCAGAATGCGGGCATTATCACCATCGATTATTTTGATCGGATGCCGACTGCTGATTTCGAAAAAGTGCTGGCGGTGAACACGACGGCAGTCTGGCTCTGCTGCCGGGAAGCAGCCAAATATATGGTGAAACAGAATCACGGCTGCCTGATCAACACCTCTTCCGGCCAGGGACGTCAGGGGTTTATCTATACCCCACACTATGCAGCCAGCAAAATGGGGGTGATCGGCATTACGCAAAGCCTGGCCCACGAGTTGGCGCAATGGAATATCACTGTTAACGCCTTCTGCCCGGGTATTATCGAAAGCGAAATGTGGGACTACAACGACCGTGTATGGGGAGAAATTCTCAGTACCGATGACAAGCGTTATGGCAAAGGCGAGCTTATGGCGGAATGGGTGGAAGGTATTCCGATGAAGCGTGCCGGTAAACCTGAAGATGTTGCCGGACTGGTTGCCTTCCTCGCCTCTGACGATGCGCGTTATCTCACCGGTCAAACCATCAACATCGACGGCGGCCTGATTATGTCGTAA",
      "translation": "MQRNFQGKTVVITGACRGIGAGIAERFARDGANLVMVSNAARVHETAEQLRQRYQADILSLEVDVTDEAQVQALYEQAAARFGSIDVSIQNAGIITIDYFDRMPTADFEKVLAVNTTAVWLCCREAAKYMVKQNHGCLINTSSGQGRQGFIYTPHYAASKMGVIGITQSLAHELAQWNITVNAFCPGIIESEMWDYNDRVWGEILSTDDKRYGKGELMAEWVEGIPMKRAGKPEDVAGLVAFLASDDARYLTGQTINIDGGLIMS",
      "product": ""
     },
     {
      "start": 299186,
      "end": 300253,
      "strand": -1,
      "locus_tag": "ctg1_289",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_289</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_289</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 299,186 - 300,253,\n (total: 1068 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1113:inner-membrane translocator (Score: 333.2; E-value: 2.4e-101)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_289\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_289\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_289_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMNQKYMIYMYLLKARTFIALLLVIAFFSVMVPNFLTASNLLIMTQHVAITGLLAIGMTLVILTGGIDLSVGAVAGICGMVAGALLTNGLPLWSGNIIFFNVPEVILCVAVFGILVGLVNGAVITRFGVAPFICTLGMMYVARGSALLFNDGSTYPNLNGIETLGNTGFATLGSGTFLGVYLPIWLMIGFLVLGYWITTKTPLGRYIYAIGGNESAARLAGVPIVKVKVFVYAFSGLCAAFVGLIVASQLQTAHPMTGNMFEMDAIGATVLGGTALAGGRGRVSGSIIGAFVIVFLADGMVMMGVSDFWQMVIKGLVIVTAVVVDQFQQKLQNKVILMRRHEEKMAASPAVKPLSS\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_289\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_289\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAATCAGAAATATATGATCTATATGTACCTGTTGAAGGCCAGAACGTTTATCGCTCTGCTGTTAGTGATCGCCTTCTTTAGTGTGATGGTGCCTAACTTCCTGACGGCCTCTAACCTGCTGATTATGACTCAACACGTTGCGATTACCGGGCTGCTGGCAATCGGAATGACGCTGGTGATCCTGACCGGCGGCATCGATCTTTCCGTCGGCGCGGTAGCGGGGATCTGCGGAATGGTTGCCGGGGCTCTGTTGACAAACGGCCTGCCATTGTGGAGCGGCAATATTATTTTCTTCAACGTGCCGGAAGTGATCCTCTGCGTGGCGGTATTTGGCATTTTAGTGGGACTGGTGAATGGCGCGGTAATCACCCGCTTTGGTGTCGCGCCCTTTATATGCACCCTCGGTATGATGTACGTCGCCCGTGGCTCTGCCCTGCTGTTTAATGACGGCAGCACTTACCCTAATCTCAACGGCATAGAAACGCTGGGCAACACGGGTTTCGCCACCCTTGGTTCTGGCACGTTTTTAGGCGTTTATCTGCCAATCTGGCTGATGATTGGCTTTTTGGTTTTAGGCTACTGGATCACGACTAAAACGCCGCTCGGTCGTTATATCTATGCCATTGGTGGCAATGAATCTGCCGCGCGACTGGCAGGCGTCCCCATCGTAAAAGTCAAAGTGTTCGTCTATGCGTTCTCTGGGTTATGCGCCGCATTTGTCGGTTTGATTGTTGCCTCGCAGCTGCAAACTGCTCACCCAATGACCGGCAATATGTTCGAAATGGATGCTATTGGTGCCACGGTTCTTGGTGGAACTGCGCTGGCGGGTGGTCGGGGACGTGTCTCTGGCTCGATTATCGGTGCCTTTGTCATTGTCTTCCTCGCCGATGGCATGGTGATGATGGGTGTCAGTGATTTCTGGCAAATGGTCATTAAAGGCCTCGTTATCGTCACCGCCGTGGTGGTCGATCAGTTCCAGCAAAAATTGCAAAACAAAGTCATTTTGATGCGTCGCCATGAAGAAAAGATGGCCGCCTCACCTGCCGTAAAACCGCTTTCCAGTTAA",
      "translation": "MNQKYMIYMYLLKARTFIALLLVIAFFSVMVPNFLTASNLLIMTQHVAITGLLAIGMTLVILTGGIDLSVGAVAGICGMVAGALLTNGLPLWSGNIIFFNVPEVILCVAVFGILVGLVNGAVITRFGVAPFICTLGMMYVARGSALLFNDGSTYPNLNGIETLGNTGFATLGSGTFLGVYLPIWLMIGFLVLGYWITTKTPLGRYIYAIGGNESAARLAGVPIVKVKVFVYAFSGLCAAFVGLIVASQLQTAHPMTGNMFEMDAIGATVLGGTALAGGRGRVSGSIIGAFVIVFLADGMVMMGVSDFWQMVIKGLVIVTAVVVDQFQQKLQNKVILMRRHEEKMAASPAVKPLSS",
      "product": ""
     },
     {
      "start": 300271,
      "end": 301815,
      "strand": -1,
      "locus_tag": "ctg1_290",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_290</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_290</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 300,271 - 301,815,\n (total: 1545 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 138.7; E-value: 4.1e-42)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_290\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_290\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_290_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMLPQEIDTPKTHESPVIIETHDLSRIYPGVVALDNVNYRVYRNKVNVLIGENGAGKSTMMKMLAGVETPSSGKIILDGKEVTLNSTHQAEKHGISIIFQELNLFPNMNVMDNIFMANEFFQKGKINEKYQYELAKSLLERLELDVDPYTQLGELGIGHQQLVEIARALSKDTRVLIMDEPTSALSQSEVKVLFNVIAQLKRRGVTIIYISHRLEELMEIGDFITIFRDGRFISERAVSDASIPWIIAQMVGDKKKHFDYQPATQGNTVLAVQGLTALHPSGGYKLNDVTFSLRKGEVIGIYGLLGAGRTELFKGLVGLMPCQSGKIQLNGETIDKCHFQARLKKGLALVPEDRQGEGVVQMMSIQSNMTLSDFSLQGFRRAWKWLNPQKESASVKEMIQQLAIKVSDAELPITSLSGGNQQKVVLGKALMTQPQVVFLDEPTRGIDVGAKTDVYQLVGKMAQQGLAVMFSSSELDEVMALADRILVMADGRITADLPRGEVTREKLIAASTPQD\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_290\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_290\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTGCCGCAAGAAATTGACACTCCCAAGACTCATGAATCACCTGTAATCATAGAAACTCATGACTTATCGCGCATTTATCCTGGTGTGGTGGCGTTAGATAACGTGAATTACCGTGTCTATCGCAATAAAGTGAATGTGCTTATTGGTGAAAACGGTGCGGGTAAATCCACAATGATGAAAATGCTGGCGGGGGTTGAAACACCTTCCTCAGGCAAGATCATTCTTGATGGTAAAGAAGTTACCCTAAATTCTACCCATCAGGCCGAAAAACATGGAATTAGTATCATTTTTCAGGAGCTGAATTTATTCCCGAATATGAATGTCATGGATAACATTTTCATGGCTAATGAATTTTTTCAGAAAGGGAAGATTAACGAAAAATATCAATATGAATTAGCCAAATCTTTACTAGAGAGACTGGAACTGGATGTTGATCCCTATACCCAACTGGGAGAACTTGGTATTGGTCATCAACAACTGGTGGAGATTGCCCGTGCCCTTTCTAAAGATACCCGGGTACTGATTATGGATGAACCGACGTCGGCCCTCAGCCAGTCGGAAGTCAAAGTCCTTTTCAATGTGATCGCACAACTGAAGCGCCGTGGTGTCACCATCATTTATATCTCCCACCGACTGGAAGAGTTGATGGAGATTGGCGATTTCATCACCATCTTCCGTGATGGTCGCTTTATTAGTGAACGCGCCGTGAGCGATGCCAGTATTCCGTGGATCATCGCGCAAATGGTCGGTGATAAGAAAAAACATTTTGATTATCAACCAGCTACACAAGGTAACACTGTACTGGCGGTACAGGGGTTAACGGCGCTACATCCCAGCGGTGGTTACAAACTCAATGATGTGACATTCAGCCTGCGTAAAGGCGAAGTTATCGGCATTTACGGCTTGCTGGGCGCAGGACGTACTGAGCTATTTAAGGGGCTGGTGGGCCTGATGCCCTGTCAGAGTGGGAAGATCCAGCTTAATGGTGAAACCATCGACAAATGCCATTTCCAGGCGCGGCTCAAAAAGGGGCTGGCGTTGGTGCCAGAAGATCGCCAGGGCGAAGGCGTCGTTCAGATGATGTCGATTCAGTCCAATATGACGCTATCCGATTTCAGCCTGCAAGGTTTTCGCCGTGCCTGGAAATGGCTGAATCCGCAAAAAGAGAGCGCCAGTGTGAAAGAGATGATCCAGCAACTGGCGATCAAAGTCAGCGATGCCGAACTCCCTATTACCTCACTCAGCGGCGGTAACCAGCAAAAAGTGGTGCTTGGCAAAGCGTTGATGACCCAGCCACAGGTGGTGTTTCTTGATGAACCCACACGCGGCATTGATGTTGGCGCAAAAACCGATGTCTATCAGCTGGTGGGAAAAATGGCACAACAGGGGCTGGCAGTCATGTTCTCTTCTTCAGAACTCGATGAAGTCATGGCACTGGCAGATCGCATTCTGGTGATGGCTGATGGCCGTATTACCGCTGATCTCCCCCGGGGCGAAGTCACCCGAGAGAAACTGATCGCGGCTTCAACACCTCAAGATTAA",
      "translation": "MLPQEIDTPKTHESPVIIETHDLSRIYPGVVALDNVNYRVYRNKVNVLIGENGAGKSTMMKMLAGVETPSSGKIILDGKEVTLNSTHQAEKHGISIIFQELNLFPNMNVMDNIFMANEFFQKGKINEKYQYELAKSLLERLELDVDPYTQLGELGIGHQQLVEIARALSKDTRVLIMDEPTSALSQSEVKVLFNVIAQLKRRGVTIIYISHRLEELMEIGDFITIFRDGRFISERAVSDASIPWIIAQMVGDKKKHFDYQPATQGNTVLAVQGLTALHPSGGYKLNDVTFSLRKGEVIGIYGLLGAGRTELFKGLVGLMPCQSGKIQLNGETIDKCHFQARLKKGLALVPEDRQGEGVVQMMSIQSNMTLSDFSLQGFRRAWKWLNPQKESASVKEMIQQLAIKVSDAELPITSLSGGNQQKVVLGKALMTQPQVVFLDEPTRGIDVGAKTDVYQLVGKMAQQGLAVMFSSSELDEVMALADRILVMADGRITADLPRGEVTREKLIAASTPQD",
      "product": ""
     },
     {
      "start": 301817,
      "end": 302437,
      "strand": -1,
      "locus_tag": "ctg1_291",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_291</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_291</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 301,817 - 302,437,\n (total: 621 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_291\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_291\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_291\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_291\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGATAAAAAAGTCTGGCTGGCGCTGGCAATTCTGAGCCTGGGTGGATGTCGCATCGTCTCGCAGCAGGAACTTGCCGATCTCAAATCCCCGCCTAATCCTCATATGGCAAATATCGACCAGACCTGGCAGAAAAATATCGTGCCGCAGGTGGTAGAAAATGCGCGTCCGGTTGCGGAATTAATGGCGGCGCTACAGGCAGAAAAAGATGTCGATGCTGCCTGTAAAACGCTGGGCTATCGTTCTCAAGAAGAAAACCCGTGTATTTTCTACGTTAAAGTCGAAGGAGGCATCACCAATATCGATGCAAAATCCCGTAGCGGAAAAATGACCATCGCAGATATCAGCGGCATGAATATTGTCGTGCAGACGGGGCCAACTCTTCGCGGCACGCTTCTGCGAGATGCATATAAAGGCGCGAGCTATGAGCATTTTAACGATCAGGTTTTATTTGGTGAATATGGTCGTGCTATCAATGAGCAAGCCATCAATATGATTCAGTCGGCAAGGCTTAAAACCGGGGAAACGGTTCAGGTTTATGGCATATTTTCTGCATGGGATATTCCGCAAACTATCCCGGATATAACGCCTGCGAAAATAGCCAGGGCGGGAGGCGAGTAA",
      "translation": "MDKKVWLALAILSLGGCRIVSQQELADLKSPPNPHMANIDQTWQKNIVPQVVENARPVAELMAALQAEKDVDAACKTLGYRSQEENPCIFYVKVEGGITNIDAKSRSGKMTIADISGMNIVVQTGPTLRGTLLRDAYKGASYEHFNDQVLFGEYGRAINEQAINMIQSARLKTGETVQVYGIFSAWDIPQTIPDITPAKIARAGGE",
      "product": ""
     },
     {
      "start": 302484,
      "end": 303419,
      "strand": -1,
      "locus_tag": "ctg1_292",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_292</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_292</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 302,484 - 303,419,\n (total: 936 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1205:ABC transporter, carbohydrate uptake (Score: 238.2; E-value: 1.6e-72)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_292\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_292\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_292_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMKLRLTLLTAATLTALSFSAHAVEKGTIMIMVNSLDNPYYASEAKGASEKAQQLGYKTTILSHGEDVKKQNELIDTAIGKKVQGIILDNADSTASVAAIEKAKKAGIPVILINREIPVDDVALVQITHNNFQAGSEVANVFVEKMGEKGKYAELTCNLADNNCVTRSKSFHQVIDQFPEMVSVAKQDAKGTLIDGKRIMDSILQAHPDVKGVICGNGPVALGAIAALKAANRNDVIVVGIDGSNDERDAVKAESLQATVMLQAQAIAAQGVTDLDNYLQKGVKPAKQRVMFRGILITKDNADKVQDFNIKS\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_292\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_292\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAATTACGTTTAACACTGTTAACCGCTGCGACCCTGACTGCTCTTTCTTTTTCTGCCCATGCGGTAGAAAAAGGAACCATTATGATTATGGTCAATTCACTGGATAATCCTTATTACGCCTCGGAAGCGAAAGGTGCCAGTGAAAAAGCCCAGCAACTGGGATATAAAACGACCATTCTTTCTCATGGTGAAGATGTCAAAAAACAGAATGAACTGATCGATACTGCAATTGGTAAAAAAGTTCAGGGTATTATTTTAGATAATGCTGACTCTACTGCCAGTGTTGCAGCCATTGAAAAAGCAAAAAAAGCAGGTATTCCCGTTATATTAATTAATCGCGAAATACCTGTGGATGATGTTGCACTGGTGCAAATTACCCATAATAACTTCCAGGCTGGCTCGGAAGTTGCCAACGTATTTGTCGAGAAAATGGGAGAGAAAGGAAAATATGCCGAACTCACCTGTAATCTTGCTGATAATAATTGCGTAACTCGCTCGAAATCTTTCCACCAGGTCATTGACCAGTTCCCTGAAATGGTCAGTGTGGCGAAGCAAGATGCCAAAGGCACGTTAATTGATGGCAAACGAATAATGGACAGTATTCTGCAAGCCCATCCCGATGTTAAAGGGGTGATTTGTGGTAATGGTCCGGTTGCACTGGGAGCTATCGCAGCATTGAAAGCAGCCAATCGCAATGACGTTATTGTTGTCGGCATTGATGGCAGTAACGATGAACGCGATGCCGTGAAAGCCGAATCATTGCAGGCTACCGTGATGTTACAAGCACAAGCCATTGCCGCGCAGGGTGTTACCGATCTGGATAATTACCTGCAAAAAGGAGTTAAACCAGCCAAACAGCGGGTGATGTTCCGCGGCATTCTGATAACCAAAGATAACGCAGATAAAGTCCAGGATTTCAATATCAAATCCTGA",
      "translation": "MKLRLTLLTAATLTALSFSAHAVEKGTIMIMVNSLDNPYYASEAKGASEKAQQLGYKTTILSHGEDVKKQNELIDTAIGKKVQGIILDNADSTASVAAIEKAKKAGIPVILINREIPVDDVALVQITHNNFQAGSEVANVFVEKMGEKGKYAELTCNLADNNCVTRSKSFHQVIDQFPEMVSVAKQDAKGTLIDGKRIMDSILQAHPDVKGVICGNGPVALGAIAALKAANRNDVIVVGIDGSNDERDAVKAESLQATVMLQAQAIAAQGVTDLDNYLQKGVKPAKQRVMFRGILITKDNADKVQDFNIKS",
      "product": ""
     },
     {
      "start": 303523,
      "end": 305043,
      "strand": -1,
      "locus_tag": "ctg1_293",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_293</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_293</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 303,523 - 305,043,\n (total: 1521 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1210:glycerol kinase (Score: 534.9; E-value: 2.7e-162)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_293\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_293\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_293_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_293\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_293\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTTGCAGGAAATAAAGAGTTCGTTATTGCGTTGGATGAGGGTACCACCAATGCAAAAGCCATCGCACTTGATGGTTTCGGTAACGTGGTGGCGAAGTTTTCTCAACCACTTGCTATTCAGACGCCACGTGAAGGCTGGGTTGAGCAATCCGGGGAAGCGTTAATCTCTGCCTCGCTTGACGTTATTGCCCAGGCCATCAGCCACGTGGGGGCAGAAAATGTAGCGGCTCTGGCTATCAGTAATCAGCGTGAAACGGCTATCGGCTGGTATCGTCAGAGTGGAAAACCACTCAATGCGGCGATTACCTGGCAATGCACGCGCAGTGCAGAGTTTTGTGAAACACTTCGTCGCGAGGGCAAAGAGCAGCAAATTAAAACGACTACAGGCCTGCCTATCGCCCCGCTATTTTCCGCTTTCAAGATGCGTTGGCTACTGGAATCTACATCTGAGGGTGTGCAACTTGCCGACCAGGGTGAAATTTGTCTCGGCACCATTGATGCCTGGTTACTATGGAACTTGACTGCTGGCGATTCATTTTGCTGCGACCACTCTAACGCCGCGCGAACTCAATTACTTAACCTGAAAACAGGCGAGTGGGATGAGGAAATGCTGGCATTGTTTCATATTCCACGCGCTGCATTGCCAGAAATTAAACCATCCAGTGGCCTGTTCGGTTATACCCGAGGGCTTAAAACAATTCCGGATGGTATTCCCGTCATGGCGATGGTGGGCGATTCTCACGCCGCTCTTTTTGGTCATGCGTTGGGAGAAGCGGGATGTGTGAAAGCGACCTATGGGACCGGTTCTTCCGTCATGGCCCCCGTCAACTCTGCTCAGTGTGATATCGCCACACTTGCCACAACCATTGCCTGGCATGACGGCGAAAATATTGTTTACGGTCTGGAAGGAAATATCCCCCACACCGGGGATGCCGTGGCATGGATGGCTGATAGCACCGGTTTAAGTGAACTGACAGACGCTGAGCTGGCCCACGAACTGAATACCCTGCCAGCCTCAGTGGATTCGACTATGGGCGTTTATTTTGTTCCTGCTCTCACTGGCCTGGGCGCACCATGGTGGGATGACAGTGCTCGCGGCGTGGTGTGTGGCTTAAGCCGTGGCGTAAAGCGCGCGCATTTGATTCGCGCCGCACTGGAATCAATCACTTACCAAATTGCAGATGTAGTAGAAGCCATGCAACAGCATGATAATTTTCACTTATCGGCGTTAATGGTGGATGGCGGCCCGACCAAAAATGACTGGTTGATGCAATATCAGGCGGATCTGCTGGGTTGCCCGGTGATGCGCAGTGATGTGCCAGAGCTTTCGGCCATTGGTGCGGGTCTGCTCGCCCGCAAAGCGCTTACCCCCGGCACCGTTGCAGATTTAAAAACGTTATTAACTGAACACAGTGAATTTAAACCGGACATGGCGCGTCATCAGCGACTGCAAAAGAGATGGCAGGAGTGGCGTCATGCGGTAAACAGAACATTATGGAAACCGGCATCGTCAATTTGA",
      "translation": "MFAGNKEFVIALDEGTTNAKAIALDGFGNVVAKFSQPLAIQTPREGWVEQSGEALISASLDVIAQAISHVGAENVAALAISNQRETAIGWYRQSGKPLNAAITWQCTRSAEFCETLRREGKEQQIKTTTGLPIAPLFSAFKMRWLLESTSEGVQLADQGEICLGTIDAWLLWNLTAGDSFCCDHSNAARTQLLNLKTGEWDEEMLALFHIPRAALPEIKPSSGLFGYTRGLKTIPDGIPVMAMVGDSHAALFGHALGEAGCVKATYGTGSSVMAPVNSAQCDIATLATTIAWHDGENIVYGLEGNIPHTGDAVAWMADSTGLSELTDAELAHELNTLPASVDSTMGVYFVPALTGLGAPWWDDSARGVVCGLSRGVKRAHLIRAALESITYQIADVVEAMQQHDNFHLSALMVDGGPTKNDWLMQYQADLLGCPVMRSDVPELSAIGAGLLARKALTPGTVADLKTLLTEHSEFKPDMARHQRLQKRWQEWRHAVNRTLWKPASSI",
      "product": ""
     },
     {
      "start": 305394,
      "end": 306344,
      "strand": -1,
      "locus_tag": "ctg1_294",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_294</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_294</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 305,394 - 306,344,\n (total: 951 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_294\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_294\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_294\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_294\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTAAGCAGGATGAACAGCGGCTACTGGTGAAGATCGCCACTCTTTACTATCTTGAGGGGCGAAAACAGTCTGACATCGCCCAACTTCTCTCGCTTTCTCAGTCATTTATCTCCAGAGCGCTAACCCGTTGCCAGAAAGAAGGCGTGGTTAAAATCAGCGTTGTCCAGCCGTCAAATATCTTTCTCAATCTGGAAAAAGGCATTGAAGAGCGTTACGGCATTAAACAAGCGATTGTTGTCGATACCGAAGATGATGCCACTGACCATACCATTAAACGTGCTATCGGCTCTGCCGCCGCGCACTATCTGGAAACGCGTTTAAGACCAAAAGATTTCATTGGCGTCTCTTCCTGGAGTTCTACGATTCGCGCGATGGTCGATGAAGTTCACGCCCAAAACTTAAAAGCCAGCGGCGTTATTCAGCTGCTGGGCGGCGTGGGGCCAAACGGCAATGTGCAGGCAACTATTTTGACACAGACCCTGGCCCAGCATCTGAATTGCGAAGCCTGGTTACTTCCTTCTCAAAGCATTGAAGGTTCGGTAGAAGAGAAAAAACGCCTGGTGGCAAGCCAGGATGTGGCTGACGTTATCGCCAGATTTGACGACGTCGATATCGCCATTGTCGGCATCGGTATCCTTGAACCCTCGCAGTTACTAAAAACCTCGGGCAACTATTATCACGAGGATATGTTACAGGTACTGGCGGATCGCGGTGCTGTGGGCGATATCTGCCTGCATTACTACGATAAACATGGTCAGCCAGTGTTGCAGGACGATGAAGATCCAGTGATTGGTATGGCACTGGATAAAATCAAAAAATGCCCGAATGTGGTGGCGCTGGCGGGCGGCAAAGACAAAGTTGCCGCCATCAAAGGCGCCATGCAGGGTGGTTATATCGATGTTTTGATCACTGATTACCCCACCGCCAGAATGCTGATTGCGGATTAA",
      "translation": "MAKQDEQRLLVKIATLYYLEGRKQSDIAQLLSLSQSFISRALTRCQKEGVVKISVVQPSNIFLNLEKGIEERYGIKQAIVVDTEDDATDHTIKRAIGSAAAHYLETRLRPKDFIGVSSWSSTIRAMVDEVHAQNLKASGVIQLLGGVGPNGNVQATILTQTLAQHLNCEAWLLPSQSIEGSVEEKKRLVASQDVADVIARFDDVDIAIVGIGILEPSQLLKTSGNYYHEDMLQVLADRGAVGDICLHYYDKHGQPVLQDDEDPVIGMALDKIKKCPNVVALAGGKDKVAAIKGAMQGGYIDVLITDYPTARMLIAD",
      "product": ""
     },
     {
      "start": 306707,
      "end": 307537,
      "strand": 1,
      "locus_tag": "ctg1_295",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_295</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_295</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 306,707 - 307,537,\n (total: 831 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) DXP_synthase_N<br>\n \n  biosynthetic-additional (rule-based-clusters) TPP_enzyme_C<br>\n \n  biosynthetic-additional (smcogs) SMCOG1204:transketolase (Score: 353.3; E-value: 4.8e-107)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_295\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_295\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_295_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_295\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_295\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAATCCCTATAGCTATGATATCCAGACCCTTGAGCGAAAAGCGCGGGCGGTACGCCGCCATATCGTGCGCTTAAATGCCAATAGCCCGGCAGGTGGACACACCGGGGCCGATCTCTCTCAGGTTGAATTACTGACCGCACTCTATTTTCGTATACTCAATGTCGCCCCGGATCGCCTTCACGACGATGACCGGGATATATACATTCAGTCAAAAGGCCATGCTGTTGGATGTTACTACTGCGTGCTGGCGGAAGCAGGATTCTTCCCACTGGAATGGCTTTCCACTTATCAGCAGCCAAATTCACACTTACCCGGCCATCCGGTTCGGCAAAAAACGCCAGGTATTGAACTGAATACCGGAGCACTGGGGCATGGTTTCCCTGTGGCTGTAGGACTTGCGCTGGCGGCGAAAAAAAGTCAAAGCCGTCGTCGTATCTTCTTAATTACTGGCGATGGTGAGCTGGCTGAGGGCAGTAACTGGGAAGCTGCACTGGCGGCGGCGCATTACGGGCTTGATAACCTGGTCATTATTAATGACAAAAATAATCTGCAATTAGCCGGGCCAACGCGCGAAATCATGAACACCGATCCTCTGGCAGAGAAATGGCTGGCATTCGGTATGCAGGTTACTGAATGTCAGGGCAATGATATGGCTTCGGTTGTCGCGACGCTTGAAGAGCTTAAACAGGAAGGCAAACCGAATGTGGTGATTGCCCACACCACTAAAGGGGCAGGCATTTCCTTTATACAAGGGCGTGCGGAATGGCATCACCGGGTGCCGAAAGGCGATGAAATTGAACAGGCACTGGAGGAACTCAAAGATGCGTAA",
      "translation": "MNPYSYDIQTLERKARAVRRHIVRLNANSPAGGHTGADLSQVELLTALYFRILNVAPDRLHDDDRDIYIQSKGHAVGCYYCVLAEAGFFPLEWLSTYQQPNSHLPGHPVRQKTPGIELNTGALGHGFPVAVGLALAAKKSQSRRRIFLITGDGELAEGSNWEAALAAAHYGLDNLVIINDKNNLQLAGPTREIMNTDPLAEKWLAFGMQVTECQGNDMASVVATLEELKQEGKPNVVIAHTTKGAGISFIQGRAEWHHRVPKGDEIEQALEELKDA",
      "product": ""
     },
     {
      "start": 307530,
      "end": 308465,
      "strand": 1,
      "locus_tag": "ctg1_296",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_296</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_296</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 307,530 - 308,465,\n (total: 936 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1110:1-deoxy-D-xylulose-5-phosphate synthase (Score: 292.7; E-value: 3.8e-89)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_296\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_296\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_296_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_296\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_296\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGTAACAGTGAACATCTGGCAAATGTGATGGTTCAGGCGTTTATCGATGCCGTAAATGAGGGGATCGATTTGGTGCCTGTGGTGGCTGATTCAACGTCTACGGCAAAAATTGCTCCCTTTATTAAGCAATTTCCTGACCGACTGGTGAATGTGGGTATTGCCGAACAGAGTATGGTTGGTACAGCTGCCGGGCTGGCGCTGGGCGGCAAGGTGGCTGTTACTTGCAATGCCGCGCCGTTTCTTATCGCTCGCGCTAACGAGCAAATCAAGGTTGATGTCTGCTACAACTTTACCAACGTAAAATTGTTCGGTCTGAATGCCGGGGCGAGTTATGGACCGCTAGCGAGCACGCATCATGCGATTGATGACATTGCGGTTATGCGTGGTTTCGGCAATATCCAGATCTTTGCCCCGTCTTCACCGCTGGAGTGCCGTCAGGTGATTGATTATGCCCTTCGCTATCAGGGACCTGTTTATATCCGTATGGACGGTAAAGCCCTGCCGGAAATCCACGATGAGGACTACCGATTTGTGCCTGGTGCCGTGGTGACTTTACGCGAGGGCAGCGAACTGGCGCTGGTAGCCACAGGTTCTACCGTTCATGAAGTGGTCGATGCCGCAGAACTTTTAGCGCAATCTGGTATCGCGGCTACAGTTGTCAGCGTACCGTCGATTCGCCCATGCGACACCAAAGCATTGCTGGCAGTGTTAAAAGGATGCAAAGCAGTGATGACGGTTGAAGAGCATAACGTCAATGGCGGCCTTGGTAGCCTGGTCGCGGAAGTGTTGGCAGAGGCCGGAACGGGGATCAAATTAAAACGCGCGGGCATTATGGATGGAGAATATGCCGCAGCGGCGGATCGTGGGTGGTTGCGTCAGCATCATGGCTTTGATGCTGCCGGAATTGCAGCTCAGGCACGGGAAATGCTTTGA",
      "translation": "MRNSEHLANVMVQAFIDAVNEGIDLVPVVADSTSTAKIAPFIKQFPDRLVNVGIAEQSMVGTAAGLALGGKVAVTCNAAPFLIARANEQIKVDVCYNFTNVKLFGLNAGASYGPLASTHHAIDDIAVMRGFGNIQIFAPSSPLECRQVIDYALRYQGPVYIRMDGKALPEIHDEDYRFVPGAVVTLREGSELALVATGSTVHEVVDAAELLAQSGIAATVVSVPSIRPCDTKALLAVLKGCKAVMTVEEHNVNGGLGSLVAEVLAEAGTGIKLKRAGIMDGEYAAAADRGWLRQHHGFDAAGIAAQAREML",
      "product": ""
     },
     {
      "start": 308467,
      "end": 309249,
      "strand": -1,
      "locus_tag": "ctg1_297",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_297</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_297</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 308,467 - 309,249,\n (total: 783 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1060:4&#39;-phosphopantetheinyl transferase (Score: 190.7; E-value: 3.9e-58)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_297\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_297\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_297_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_297\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_297\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAACGCCTTATCCGGCCTACAAAAATCTTGCCAATTCAATATATTGCAGGATAGTGTAGGCCTGATAAGCGTAGCGCATCAGGCAGTTTTGCGTTTGTCATCAGTCTCTAATATGGTCGACATGAAAACTACGCATACCTCCCTCCCCTTTGCCGGACATACGCTGCATTTTGTTGAGTTCGATCCAGTAAGTTTTCGCGAGCAGGATTTACTCTGGCTGCCACACTACGCACAACTGCAACACGCTGGACGTAAACGTAAAACAGAGCATTTAGCCGGACGGATCGCTGCTGTTTACGCCTTGCGGGAATATGGCTATAAATGTGTGCCCGCAATCGGCGAGCTACGCCAACCTGTGTGGCCTGCGGAGGTATACGGCAGTATTAGCCACTGCGGGACTACGGCATTGGCAGTGGTATCCCGTCAACAGATTGGCATTGATATCGAAGAGATTTTCTCTGTACAAACCGCAAGAGAATTGACAGACAACATTATTACACCAGCAGAACACGAGCGACTCGCAGAATGCGGTTTAACCTTTTCTCTGGCGCTGACACTGGCATTTTCCGCCAAAGAGAGCGCATTTAAGACAGGCGAGATCCAAACTGATGCCGGTTTTCAGCACTACCAAATTGGAAATTGTCAGCATCAACAGATGAAGATAAGTGGGCCGAATGGCGACCATATTGTGCAGTGGTTAGTAAGGGGTAATAACGTTATTACCTTGTGCCGGGCAGATAAACACCCGCACACTGCCGCATGCGGGTTGTCTGGCGGATAA",
      "translation": "MNALSGLQKSCQFNILQDSVGLISVAHQAVLRLSSVSNMVDMKTTHTSLPFAGHTLHFVEFDPVSFREQDLLWLPHYAQLQHAGRKRKTEHLAGRIAAVYALREYGYKCVPAIGELRQPVWPAEVYGSISHCGTTALAVVSRQQIGIDIEEIFSVQTARELTDNIITPAEHERLAECGLTFSLALTLAFSAKESAFKTGEIQTDAGFQHYQIGNCQHQQMKISGPNGDHIVQWLVRGNNVITLCRADKHPHTAACGLSGG",
      "product": ""
     },
     {
      "start": 309301,
      "end": 311541,
      "strand": -1,
      "locus_tag": "ctg1_298",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_298</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_298</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 309,301 - 311,541,\n (total: 2241 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1082:TonB-dependent siderophore receptor family (Score: 1043.1; E-value: 0.0)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_298\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_298\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_298_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMNKKIHSLALLVNLGIYGVAQAQEPTDTPVSHDDTIVVTAAEQNLQAPGVSTITADEIRKNPVARDVSEIIRTMPGVNLTGNSTSGQRGNNRQIDIRGMGPENTLILIDGKPVSSRNSVRQGWRGERDTRGDTSWVPPEMIERIEVLRGPAAARYGNGAAGGVVNIITKKGSGEWHGSWDAYFNAPEHKEEGATKRTNFSLTGPLGDQFSFRLYGNLDKTQADAWDINQGHQSARAGTYATTLPAGREGVINKDINGVVRWDFAPMQSLELEAGYSRQGNLYAGDTQNTNSDAYTRSKYGDETNRLYRQNYSLTWNGGWDNGVTTSNWVQYEHTRNSRIPEGLAGGTEGKFNEKATQDFVDIDLDDVMLHSEVNLPIDFLVNQTLTLGTEWNQQRMKDLSSNTQALTGTNTGGAIDGVSATDRSPYSKAEIFSLFAENNMELTDSTIVTPGLRFDHHSIVGNNWSPALNISQGLGDDFTLKMGIARAYKAPSLYQTNPNYILYSKGQGCYASAGGCYLQGNDDLKAETSINKEIGLEFKRDGWLAGVTWFRNDYRNKIEAGYVAVGQNAVGTDLYQWDNVPKAVVEGLEGSLNVPVSETVMWTNNITYMLKSENKTTGDRLSIIPEYTLNSTLSWQAREDLSMQTTFTWYGKQQPKKYNYKGQPAVGPETKEISPYSIVGLSATWDVTKNVSLTGGVDNLFDKRLWRAGNAQTTGDLAGANYIAGAGAYTYNEPGRTWYMSVNTHF\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_298\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_298\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACAAGAAGATTCATTCCCTGGCCTTGTTGGTCAATCTGGGGATTTATGGGGTAGCGCAGGCACAAGAGCCAACCGATACTCCTGTTTCACATGACGATACTATTGTCGTTACCGCCGCCGAGCAGAACTTGCAGGCGCCTGGCGTTTCGACCATCACCGCAGATGAAATCCGCAAAAACCCGGTTGCCCGCGATGTGTCGGAGATCATTCGTACCATGCCTGGCGTTAACCTGACCGGTAACTCCACCAGTGGTCAGCGTGGTAATAACCGCCAGATTGATATTCGCGGCATGGGTCCGGAAAACACGCTGATTTTGATTGACGGTAAGCCTGTCAGCAGCCGTAACTCGGTGCGTCAGGGCTGGCGTGGCGAGCGTGATACCCGTGGTGATACCTCCTGGGTGCCGCCTGAAATGATTGAACGTATTGAAGTTCTGCGTGGTCCGGCAGCTGCGCGTTATGGCAACGGCGCGGCGGGCGGCGTGGTTAACATCATTACCAAAAAAGGCAGCGGCGAGTGGCACGGCTCCTGGGATGCTTATTTCAATGCGCCAGAACATAAAGAGGAAGGTGCCACCAAACGCACCAACTTTAGCTTGACCGGTCCGCTGGGCGACCAATTCAGCTTTCGTTTATATGGCAACCTCGACAAAACTCAGGCTGATGCGTGGGATATTAACCAGGGCCATCAGTCCGCGCGTGCCGGAACCTATGCCACGACGTTACCAGCCGGGCGCGAAGGGGTGATCAACAAAGATATCAATGGCGTGGTGCGTTGGGACTTCGCCCCTATGCAGTCACTCGAACTTGAAGCGGGCTACAGCCGCCAGGGTAACCTGTATGCGGGTGACACCCAGAACACCAACTCTGACGCTTACACTCGCTCTAAATATGGCGATGAAACCAACCGCCTGTATCGCCAGAACTACTCGCTGACCTGGAACGGTGGCTGGGATAACGGCGTGACCACCAGCAATTGGGTGCAGTACGAACACACCCGTAACTCGCGTATACCGGAAGGTTTGGCGGGCGGCACCGAAGGGAAATTTAACGAAAAAGCGACACAAGATTTCGTCGATATCGATCTTGATGACGTGATGTTGCACAGCGAAGTTAACCTGCCGATTGATTTCCTCGTTAACCAGACGCTGACGCTGGGGACTGAGTGGAATCAGCAGCGGATGAAGGACTTAAGTTCCAACACCCAGGCCCTGACCGGAACGAATACCGGCGGTGCTATTGATGGTGTAAGTGCTACTGACCGTAGCCCATATTCAAAGGCAGAAATTTTCTCGCTGTTTGCCGAAAACAATATGGAGCTGACTGACAGCACCATCGTAACGCCGGGGCTGCGTTTCGATCATCACAGCATTGTCGGCAATAACTGGAGTCCGGCGCTGAATATATCGCAAGGTTTAGGCGATGACTTCACGCTGAAAATGGGCATCGCCCGTGCTTATAAAGCGCCGAGCCTGTACCAGACTAACCCGAACTACATTCTCTACAGTAAAGGTCAGGGCTGCTATGCCAGCGCGGGCGGCTGCTATTTGCAAGGTAATGATGACCTGAAAGCGGAAACCAGCATCAACAAAGAGATTGGTCTGGAGTTCAAACGCGACGGCTGGCTGGCGGGTGTCACCTGGTTCCGTAACGATTATCGCAATAAGATTGAAGCGGGCTATGTGGCTGTCGGGCAAAACGCAGTCGGCACCGATCTCTATCAGTGGGATAACGTTCCAAAAGCGGTGGTTGAAGGTCTGGAAGGATCGTTAAATGTGCCGGTTAGCGAAACGGTGATGTGGACCAATAACATCACTTATATGCTGAAGAGTGAAAACAAAACCACGGGCGACCGTTTATCGATCATCCCGGAATATACGTTGAACTCAACGCTGAGCTGGCAGGCACGGGAAGATTTGTCGATGCAAACGACCTTCACCTGGTACGGCAAGCAGCAGCCGAAGAAGTACAACTATAAAGGTCAGCCAGCGGTTGGACCGGAAACCAAAGAAATCAGTCCGTACAGCATTGTGGGCCTGAGCGCGACCTGGGATGTGACGAAGAATGTCAGTCTGACCGGCGGCGTGGACAACCTGTTCGACAAGCGTTTGTGGCGTGCGGGTAATGCCCAGACCACGGGCGATTTGGCAGGAGCCAACTATATCGCGGGTGCCGGGGCGTATACCTATAACGAGCCGGGACGTACATGGTATATGAGCGTAAACACTCACTTCTGA",
      "translation": "MNKKIHSLALLVNLGIYGVAQAQEPTDTPVSHDDTIVVTAAEQNLQAPGVSTITADEIRKNPVARDVSEIIRTMPGVNLTGNSTSGQRGNNRQIDIRGMGPENTLILIDGKPVSSRNSVRQGWRGERDTRGDTSWVPPEMIERIEVLRGPAAARYGNGAAGGVVNIITKKGSGEWHGSWDAYFNAPEHKEEGATKRTNFSLTGPLGDQFSFRLYGNLDKTQADAWDINQGHQSARAGTYATTLPAGREGVINKDINGVVRWDFAPMQSLELEAGYSRQGNLYAGDTQNTNSDAYTRSKYGDETNRLYRQNYSLTWNGGWDNGVTTSNWVQYEHTRNSRIPEGLAGGTEGKFNEKATQDFVDIDLDDVMLHSEVNLPIDFLVNQTLTLGTEWNQQRMKDLSSNTQALTGTNTGGAIDGVSATDRSPYSKAEIFSLFAENNMELTDSTIVTPGLRFDHHSIVGNNWSPALNISQGLGDDFTLKMGIARAYKAPSLYQTNPNYILYSKGQGCYASAGGCYLQGNDDLKAETSINKEIGLEFKRDGWLAGVTWFRNDYRNKIEAGYVAVGQNAVGTDLYQWDNVPKAVVEGLEGSLNVPVSETVMWTNNITYMLKSENKTTGDRLSIIPEYTLNSTLSWQAREDLSMQTTFTWYGKQQPKKYNYKGQPAVGPETKEISPYSIVGLSATWDVTKNVSLTGGVDNLFDKRLWRAGNAQTTGDLAGANYIAGAGAYTYNEPGRTWYMSVNTHF",
      "product": ""
     },
     {
      "start": 311784,
      "end": 312986,
      "strand": 1,
      "locus_tag": "ctg1_299",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_299</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_299</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 311,784 - 312,986,\n (total: 1203 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1098:enterobactin/ferric enterobactin esterase (Score: 585; E-value: 1.5e-177)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_299\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_299\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_299_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_299\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_299\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGACAGCGTTAAAAGTAGGAAGTGAGAGCTGGTGGCAGTCGAAACATGGCCCGGAATGTCAGCGTCTGAATGACAAAATGTATCAGGTCACTTTCTGGTGGCGTGATCCACAAGGTGCTGAAGACCACTCGACGATAAAGCGCGTATGGGTCTATATCACTGGCGTGACCGATCACCATCAGAACAGCCAACCCCAGTCGATGCAGCGAATTGCAGGGACCGATGTCTGGCAGTGGACGACACAACTCAATGCCAACTGGCGCGGCAGCTACTGTTTTATTCCTACCGAACGTGATGACATTTTTTCTGCACCATCCCCTGATCGCCTTGAATTGCGCGAAGGCTGGCGAAAACTATTACCCCAGGCGATAGCCGATCCGCTGAATCCACAAAGCTGGAAAGGTGGGCGAGGGCACGCTGTTTCTGCACTTGAAATGCCGCAAGCGCCCCTGCAACCTGGATGGGATTGTCCGCAAGCGCCAGAAACGCCTGCCAAAGAAATTATCTGGAAAAGTGAACGGTTGAAAAATTCACGCCGTGTATGGATTTTTACCACCGGCGATGCAACAGCAGAAGAACGTCCGCTGGCAGTTTTACTTGATGGCGAATTTTGGGCGCAGAGTATGCCCGTCTGGCCTGCGCTGACTTCTCTGACCCATCGTCAGCAACTTCCTCCCGCCGTGTACGTGTTGATCGACTCTATCGACACCACGCAACGTGCCCACGAACTGCCATGTAATGCGGATTTCTGGCTGGCAGCACAGCAAGAGTTATTACCCCAGGTGAAAACTATCGCCCCCTTTAGCGATCGCGCCGATCTTACTGTGGTCGCCGGGCAGAGTTTTGGTGGGCTTTCCGCGCTGTATGCCGGACTGCGCTGGCCTGAACGCTTTGGCTGTGTATTAAGCCAGTCGGGATCGTACTGGTGGCCGCATCGGGGCGGGCAGCAAGAGGGCGTGTTACTTGAACAGCTCAAAGCTGGTGAAGTTAGCGCCGAAGGTCTGCGCATTGTGCTGGAAGCGGGTATTCGCGAGCCGATGATCATGCGGGCCAATCAGGCGCTGTATGCGCAATTAACCCCCCTAAAAGAATCCATTTTCTGGCGTCAGGTTGACGGCGGACATGATGCGCTTTGTTGGCGCGGTGGCTTGATGCAGGGGCTAATCGACCTCTGGCAACCACTTTTCCATGACAGGAGTTGA",
      "translation": "MTALKVGSESWWQSKHGPECQRLNDKMYQVTFWWRDPQGAEDHSTIKRVWVYITGVTDHHQNSQPQSMQRIAGTDVWQWTTQLNANWRGSYCFIPTERDDIFSAPSPDRLELREGWRKLLPQAIADPLNPQSWKGGRGHAVSALEMPQAPLQPGWDCPQAPETPAKEIIWKSERLKNSRRVWIFTTGDATAEERPLAVLLDGEFWAQSMPVWPALTSLTHRQQLPPAVYVLIDSIDTTQRAHELPCNADFWLAAQQELLPQVKTIAPFSDRADLTVVAGQSFGGLSALYAGLRWPERFGCVLSQSGSYWWPHRGGQQEGVLLEQLKAGEVSAEGLRIVLEAGIREPMIMRANQALYAQLTPLKESIFWRQVDGGHDALCWRGGLMQGLIDLWQPLFHDRS",
      "product": ""
     },
     {
      "start": 312989,
      "end": 313207,
      "strand": 1,
      "locus_tag": "ctg1_300",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_300</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_300</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 312,989 - 313,207,\n (total: 219 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1009:mbtH-like protein (Score: 95.3; E-value: 2.3e-29)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_300\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_300\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_300_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_300\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_300\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCATTCAGTAATCCCTTCGATGATCCGCAGGGCGTGTTTTACATTTTACGCAATGCGCAGGGGCAATTCAGTCTGTGGCCGCAACAGTGCGCCTTACCGGCAGGCTGGGATGTTGTGTGTCAGCCGCAGTCACAGGCGTCCTGCCAGCACTGGCTGGACGCCCACTGGCGTACTCTGACACCGGCGAATTTCATCCAGCAGCAGGAGGCGCAATGA",
      "translation": "MAFSNPFDDPQGVFYILRNAQGQFSLWPQQCALPAGWDVVCQPQSQASCQHWLDAHWRTLTPANFIQQQEAQ",
      "product": ""
     },
     {
      "start": 313204,
      "end": 317085,
      "strand": 1,
      "locus_tag": "ctg1_301",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_301</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_301</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 313,204 - 317,085,\n (total: 3882 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS: Condensation<br>\n \n  biosynthetic (rule-based-clusters) NRP-metallophore: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRP-metallophore: Condensation<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1127:condensation domain-containing protein (Score: 253.4; E-value: 8.1e-77)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-ctg1_301 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>Thioesterase</strong> (1066..1276)</dt>\n   <dd>\n   \n    active site serine present: True<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_301\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_301\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_301_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_301\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_301\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCCAGCATTTACCTTTAGTTGCCGCACAGCCCGGCATCTGGATGGCAGAAAAACTGTCGGATTTACCCTCCGCCTGGAGCGTGGCGCATTACGTTGAGTTAACCGGAGATGTTGATGCGCCATTACTGGCTCGCGCGGTGGTTGCCGGATTAGCGCAAGCAGATACGCTGCGGATGCGTTTTACGGAAGATAACGGCGAAGTCTGGCAATGGGTCGATGATGCGCTGACGTTCGAACTGCCAGAAATTATCGACCTGCGAACCAACATTGATCCGCACGGTACTGCGCAGGCATTAATGCAGGCGGATTTGCAACAAGATCTGCGCGTCGATAGCGGTAAACCTCTGGTTTTTCATCAACTGATACAGGTGGCAGATAACCGCTGGTACTGGTATCAGCGTTACCACCATTTGCTGGTCGATGGCTTCAGTTTCCCGGTCATTACCCGCCAGATCGCCAACATTTACTGTGCATGGATGCGTGGCGAACCAACACCGGCTTCGCCGTTTACGCCTTTCGCTGACGTGGTGGAAGAGTACCAGCAGTATCGCGAAAGCGAAGCCTGGCAGCGTGATGCGGCATTCTGGGCGGAGCAACGTCGTCAACTACCACCGCCCGCGTCACTTTCTCCAGTCCCTTTACCGGGGCGCAGCGCCTCGGCAGATATTTTGCGTCTGAAACTGGAATTTAACGGCGGGGAATTCCGCCAGTTGGCTACGCAACTTTCAGGTTTACAACGTACCGATATAGCCCTTGCGCTGGCGGCTTTGTGGCTGGGGCGATTGTGCAACCACATGGACTATGCCGCCGGATTTATCTTTATGCGTCGACTGGGCTCAGCTGCGCTGACGGCTACCGGACCTGTGCTCAACGTGTTGCCGTTGGGTATTCACATTGAGGCACAAGAAACGTTGCCGCAACTGGCAGCCCGACTAGCGGCACAACTGAAAAAAATGCGTCGTCATCAACGTTACGATGCCGAACAAATTGTCCGTGACAGTGGGCGAGTCGCAGGAGAGGAACCGTTGTTCGGTCCGGTACTCAATATCAAGGTGTTTGATTACCAACTGGATATTCCTGATGTACAGGCGCAAACCCATACCCTGGCAACCGGTCCGGTTAATGACCTTGAACTGGCGCTGTTCCCGGATGAACACGGTGATTTGAGTATTGAGATCCTCGCCAATAAACAGCGTTACGATGAGCCAACGTTAATCCAGCATGCTGAACGGCTGAAAATGCTGACGGCGCAGTTTGCCGCGGATCCGGCGCGGTTGTGCGGCGATGTCGATATTATGCTGCCAGAAGAGTATGCACAGCTGGCGCAGATCAACGCCACTCAGGTTGAGATTCCAGAAACCACACTGAGCGCGCTGGTGGCAGAACAGGCGGCAAAAACGCCGGATGCTCCGGCACTGGCAGATGTGCGTTACCAGTTCAGTTATCGGGAAATGCGCGAGCAGGTGGTGGCGCTGGCGAATCTGCTGCGTGAGCGCGGCGTCAAACCTGGCGACAGCGTAGCGGTGGCACTACCGCGCTCGGTCTTTTTGACTATGGCGCTACATGCGATAGTTGAAGCAGGTGCGGCCTGGCTACCGCTGGATACGGGCTATCCGGACGATCGCCTGAAAATGATGCTGGAAGATGCGTGTCCGTCACTGTTAATCACCACCGATGATCAACTGCCGCGCTTTAGCGATATCCCCAATTTAACCAGTCTTTGCTATAACGCCCCGCTTACACCGCAGGGCAGTGCGCCGCTGCAACTTTCACAACCGCACCACACGGCTTATATCATCTTTACCTCCGGTTCCACCGGCAGGCCGAAAGGGGTGATGGTCGGGCAGACGGCTATCGTTAACCGCCTGTTATGGATGCAAAACCACTACACGCTCACAGGCGAAGATGTTGTTGCCCAAAAAACGCCGTGCAGTTTTGATGTCTCGGTGTGGGAGTTTTTCTGGCCGTTTATTGCTGGGGCGAAACTGGTGATGGCTGAACCGGAAGCGCACCGCGATCCGCTCGCTATGCAACAATTCTTTGCCGAATATGGCGTAACGACCACGCATTTTGTGCCGTCGATGCTGGCGGCGTTTGTTGCTTCGCTGACGTCGGAAACCGCTCGCCAGAGTTGCGCGACGTTGAAACAGGTTTTCTGTAGTGGAGAAGCCTTACCAGCCGATTTATGTCGCGAATGGCAGCAGTTAACTGGCGCGCCGTTACATAATCTTTATGGCCCGACGGAAGCGGCGGTGGATGTGAGCTGGTATCCAGCCTTTGGTGCTGAACTTGCAGCGGTACGCGGCAGCAGTGTGCCGATTGGCTACCCGGTGTGGAACACGGGCCTGCGCATTCTCGATGCGATGATGCATCCGGTGCCGCCGGGTGTGGCAGGCGATCTCTATCTCACCGGTATTCAACTGGCGCAGGGGTATCTTGGACGACCCGATCTGACAGCCAGCCGCTTTATTGCCGATCCTTTCGCGCCAGGTGAACGGATGTACCGTACCGGAGATGTTGCCCGCTGGCTGGATAACGGCGCGGTGGAGTATCTCGGGCGTAGTGATGATCAGCTAAAAATTCGTGGTCAGCGGATTGAACTGGGCGAAATCGATCGTGTGATGCAGGCGCTGCCGGATGTCGAGCAAGCAGTTACCCACGCTTGTGTGATTAATCAGGCGGCAGCCACCGGAGGGGATGCGCGTCAACTGGTGGGCTATCTGGTGTCGCAATCGGGCCTGCCACTGGATACCAGCACATTGCAGGCGCAGCTTCGCGAAAAATTGCCACCGCATATGGTGCCCGTGGTTCTGCTGCAACTGCCACAGTTACCACTTAGCGCCAACGGTAAGCTGGATCGCAAAGCCTTACCGTTGCCGGAACTGAAGGCACAAGCGCCGGGGCGTGCGCCGAAAGCGGGCAGTGAAACGATTATCGCCGCGGCGTTCTCGTCATTGCTGGGTTGTGACGTGCAGGATGCCGATGCTGATTTCTTTGCGCTTGGCGGTCATTCACTACTGGCAATGAAACTGGCTGCGCAGTTAAGTCGACAGTTTGCCCGTCAGATGACGCCGGGGCAGGTGATGGTCGCGTCAACCGTCGCCAAACTGGCAACGGTTATTGATGGTGAAGAAGACAGCTCCCGGCGCATGGGATTTGAAACCATCCTGCCGTTGCGTGAAGGTAATGGCCCGACGCTGTTTTGTTTCCATCCAGCATCTGGTTTTGCCTGGCAGTTTAGCGTGCTCTCGCGTTATCTAGATCCTCAATGGTCGATTATTGGCATCCAGTCTCCGCGCCCTCATGGCCCCATGCAGACGGCGGCAAACCTGGATGAAGTCTGCGAAGCGCATCTGGCAACGTTACTTGAACAACAACCGCACGGTCCTTATTACCTGCTGGGGTATTCGCTGGGCGGTACGCTGGCGCAGGGAATAGCGGCAAGGCTGCGTGCCCGTGGCGAACAGGTAGCATTTCTTGGCTTGCTGGATACCTGGCCGCCAGAAACGCAGAACTGGCAGGAAAAAGAAGCTAATGGTCTGGACCCGGAAGTGTTGGCGGAGATTAACCGCGAACGTGAAGCCTTCCTGGCGGCACAGCAGGGGAGTACTTCAACGGAGCTGTTTACCACCATTGAAGGCAACTACGCTGATGCAGTGCGCTTGTTGACCACTGCTCATAGTGTACCGTTTGACGGCAAAGCGACGCTGTTTGTTGCCGAACGTACTCTTCAGGAAGGAATGAGTCCCGAACGGGCCTGGTCGCCGTGGATAGCCGAGCTGGATATTTATCGTTTAGATTGTGCGCATGTGGATATTATTTCCCCTGGTTATTTTAAACAAATAGGACCATTAATAAGGACATCAATTAATAACTAA",
      "translation": "MSQHLPLVAAQPGIWMAEKLSDLPSAWSVAHYVELTGDVDAPLLARAVVAGLAQADTLRMRFTEDNGEVWQWVDDALTFELPEIIDLRTNIDPHGTAQALMQADLQQDLRVDSGKPLVFHQLIQVADNRWYWYQRYHHLLVDGFSFPVITRQIANIYCAWMRGEPTPASPFTPFADVVEEYQQYRESEAWQRDAAFWAEQRRQLPPPASLSPVPLPGRSASADILRLKLEFNGGEFRQLATQLSGLQRTDIALALAALWLGRLCNHMDYAAGFIFMRRLGSAALTATGPVLNVLPLGIHIEAQETLPQLAARLAAQLKKMRRHQRYDAEQIVRDSGRVAGEEPLFGPVLNIKVFDYQLDIPDVQAQTHTLATGPVNDLELALFPDEHGDLSIEILANKQRYDEPTLIQHAERLKMLTAQFAADPARLCGDVDIMLPEEYAQLAQINATQVEIPETTLSALVAEQAAKTPDAPALADVRYQFSYREMREQVVALANLLRERGVKPGDSVAVALPRSVFLTMALHAIVEAGAAWLPLDTGYPDDRLKMMLEDACPSLLITTDDQLPRFSDIPNLTSLCYNAPLTPQGSAPLQLSQPHHTAYIIFTSGSTGRPKGVMVGQTAIVNRLLWMQNHYTLTGEDVVAQKTPCSFDVSVWEFFWPFIAGAKLVMAEPEAHRDPLAMQQFFAEYGVTTTHFVPSMLAAFVASLTSETARQSCATLKQVFCSGEALPADLCREWQQLTGAPLHNLYGPTEAAVDVSWYPAFGAELAAVRGSSVPIGYPVWNTGLRILDAMMHPVPPGVAGDLYLTGIQLAQGYLGRPDLTASRFIADPFAPGERMYRTGDVARWLDNGAVEYLGRSDDQLKIRGQRIELGEIDRVMQALPDVEQAVTHACVINQAAATGGDARQLVGYLVSQSGLPLDTSTLQAQLREKLPPHMVPVVLLQLPQLPLSANGKLDRKALPLPELKAQAPGRAPKAGSETIIAAAFSSLLGCDVQDADADFFALGGHSLLAMKLAAQLSRQFARQMTPGQVMVASTVAKLATVIDGEEDSSRRMGFETILPLREGNGPTLFCFHPASGFAWQFSVLSRYLDPQWSIIGIQSPRPHGPMQTAANLDEVCEAHLATLLEQQPHGPYYLLGYSLGGTLAQGIAARLRARGEQVAFLGLLDTWPPETQNWQEKEANGLDPEVLAEINREREAFLAAQQGSTSTELFTTIEGNYADAVRLLTTAHSVPFDGKATLFVAERTLQEGMSPERAWSPWIAELDIYRLDCAHVDIISPGYFKQIGPLIRTSINN",
      "product": ""
     },
     {
      "start": 317331,
      "end": 318470,
      "strand": 1,
      "locus_tag": "ctg1_302",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_302</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_302</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 317,331 - 318,470,\n (total: 1140 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1254:ferric enterobactin transport protein FepE (Score: 708; E-value: 4.1e-215)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_302\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_302\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSSLNVNREKDSDFVGYALPSPDRNEIDLLHLIDVLWRAKKQIIAISFAFACAGILISFLLPQKWTSAAVVTPAEAVQWQELERTFTKLRVLDVDAGIDRSSVFNLFIKKFQSPTLLEDYLRSSPYVMDQLKGAEIDELELHRAIVALSEKMKAVDENSSKKKDETALYTAWRLSFTAPTKEEAQQVLAGYIQYISNLVVTESLENIRNKLEIKTRFEQEKLAQDRVKIRNQLDANIQRLNYSLDIANAAGIKKPVYSNGQAVKDDPEFSISLGADGIQRKLEIEKGVTDVAELNGDLRNRQYYVEQLKKLNVSDVKFSPFKYQMKPSLPVKKDGPGRAIIAILAALVGGMVACGSVLMRNAMLSRKMEKAITVDEQLV\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_302\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_302\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCATCATTAAATGTAAATCGAGAAAAAGACTCGGATTTCGTCGGCTATGCATTACCTTCGCCTGACAGAAATGAAATAGATTTATTACATCTTATTGACGTTCTTTGGCGGGCAAAGAAGCAAATTATTGCCATTAGTTTTGCATTTGCTTGTGCCGGAATATTAATTTCCTTTTTGTTGCCACAAAAATGGACCAGTGCAGCGGTAGTCACTCCTGCAGAAGCCGTGCAGTGGCAGGAACTGGAAAGAACATTTACCAAATTACGTGTACTGGATGTCGACGCTGGTATTGATCGTAGCAGCGTATTTAACCTTTTTATTAAGAAGTTTCAATCTCCTACACTGCTGGAAGATTATCTCCGCTCCTCACCTTATGTTATGGATCAACTGAAAGGAGCTGAAATTGATGAACTGGAGTTACACCGGGCTATTGTTGCGCTCAGCGAGAAAATGAAAGCGGTGGATGAGAACTCCAGCAAGAAGAAAGATGAAACTGCGCTCTATACTGCCTGGCGTTTAAGCTTTACTGCACCGACAAAAGAAGAAGCACAGCAGGTTCTGGCAGGTTATATCCAGTATATTTCCAATCTGGTGGTTACAGAATCACTGGAGAATATCCGTAATAAACTGGAAATTAAAACCCGTTTTGAGCAAGAAAAACTGGCTCAGGATCGTGTGAAAATACGTAATCAGTTGGATGCAAATATTCAACGACTGAATTATTCGCTCGACATTGCCAACGCTGCCGGGATTAAAAAACCAGTTTATAGCAACGGACAGGCAGTAAAAGACGATCCAGAATTTTCAATTTCTCTCGGTGCCGATGGTATTCAGCGTAAACTGGAAATCGAAAAAGGCGTTACAGACGTAGCCGAACTGAATGGCGATTTGCGTAATCGACAGTATTACGTAGAGCAACTCAAAAAGCTGAATGTTAGCGATGTCAAATTTTCACCGTTTAAATATCAGATGAAACCATCATTGCCGGTGAAGAAAGATGGTCCGGGGAGAGCGATTATTGCCATTCTGGCAGCGCTTGTGGGTGGAATGGTTGCTTGTGGTAGTGTACTGATGCGTAACGCCATGCTTTCTCGCAAGATGGAGAAAGCCATTACGGTAGATGAACAGTTAGTGTGA",
      "translation": "MSSLNVNREKDSDFVGYALPSPDRNEIDLLHLIDVLWRAKKQIIAISFAFACAGILISFLLPQKWTSAAVVTPAEAVQWQELERTFTKLRVLDVDAGIDRSSVFNLFIKKFQSPTLLEDYLRSSPYVMDQLKGAEIDELELHRAIVALSEKMKAVDENSSKKKDETALYTAWRLSFTAPTKEEAQQVLAGYIQYISNLVVTESLENIRNKLEIKTRFEQEKLAQDRVKIRNQLDANIQRLNYSLDIANAAGIKKPVYSNGQAVKDDPEFSISLGADGIQRKLEIEKGVTDVAELNGDLRNRQYYVEQLKKLNVSDVKFSPFKYQMKPSLPVKKDGPGRAIIAILAALVGGMVACGSVLMRNAMLSRKMEKAITVDEQLV",
      "product": ""
     },
     {
      "start": 318505,
      "end": 319305,
      "strand": -1,
      "locus_tag": "ctg1_303",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_303</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_303</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 318,505 - 319,305,\n (total: 801 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 223.9; E-value: 3.7e-68)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_303\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_303\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_303_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMTESVARLRGEQLTLGYGKYTVAENLTVEIPDGHFTAIIGPNGCGKSTLLRTLSRLMTPAHGHVWLDGEHIQHYASKEVARRIGLLAQNATTPGDITVQELVARGRYPHQPLFTRWRKEDEEAVTKAMQATGITHLANQSVDTLSGGQRQRAWIAMVLAQETAIMLLDEPTTWLDISHQIDLLELLSELNREKGYTLAAVLHDLNQACRYASHLIALREGKIVAQGAPKEIVTAELIERIYGLRCMIIDDPVAGTPLVVPLGRNKK\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_303\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_303\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGAATCAGTAGCCCGTTTGCGTGGCGAACAGTTAACCCTAGGATATGGCAAATATACCGTTGCGGAAAATCTGACTGTAGAAATTCCTGATGGTCACTTCACGGCAATTATCGGGCCAAATGGCTGCGGTAAATCCACGTTACTGCGTACCTTAAGCCGCCTGATGACGCCTGCTCACGGGCATGTCTGGCTGGATGGCGAGCACATTCAACATTACGCCAGTAAAGAGGTCGCACGCCGGATTGGTTTACTGGCGCAAAACGCCACCACGCCGGGAGATATCACCGTGCAGGAGTTAGTAGCGCGCGGGCGTTACCCGCATCAACCGCTGTTTACCCGCTGGCGTAAAGAAGATGAAGAAGCGGTAACGAAAGCGATGCAGGCCACAGGAATAACTCATCTGGCAAATCAAAGCGTTGATACCCTCTCCGGTGGACAACGTCAGCGAGCGTGGATCGCGATGGTGCTGGCCCAGGAAACGGCAATTATGCTGCTCGATGAACCAACGACCTGGCTGGATATCAGTCATCAGATTGATCTACTGGAACTGCTAAGCGAACTGAACCGCGAGAAAGGCTATACTCTGGCGGCGGTACTGCACGATCTTAATCAGGCCTGTCGTTACGCCAGCCATTTGATTGCATTGCGGGAAGGGAAAATTGTCGCTCAGGGAGCACCGAAAGAGATTGTCACTGCTGAATTGATCGAGCGTATTTATGGTTTGCGTTGCATGATAATTGACGATCCGGTAGCCGGAACACCGCTTGTAGTGCCGCTCGGGAGAAATAAAAAATGA",
      "translation": "MTESVARLRGEQLTLGYGKYTVAENLTVEIPDGHFTAIIGPNGCGKSTLLRTLSRLMTPAHGHVWLDGEHIQHYASKEVARRIGLLAQNATTPGDITVQELVARGRYPHQPLFTRWRKEDEEAVTKAMQATGITHLANQSVDTLSGGQRQRAWIAMVLAQETAIMLLDEPTTWLDISHQIDLLELLSELNREKGYTLAAVLHDLNQACRYASHLIALREGKIVAQGAPKEIVTAELIERIYGLRCMIIDDPVAGTPLVVPLGRNKK",
      "product": ""
     },
     {
      "start": 319302,
      "end": 320294,
      "strand": -1,
      "locus_tag": "ctg1_304",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_304</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_304</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 319,302 - 320,294,\n (total: 993 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1011:transport system permease protein (Score: 353.1; E-value: 2.1e-107)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_304\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_304\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_304_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMIYVSRRLIITCLLLLIACVMASVWGLRSGAVTLETSQVFAALMGDAPRSMTMVVTEWRLPRVLMALLIGAALGVSGAIFQSLMRNPLGSPDVMGFNTGAWSGVLVAMVLFGQDLTAIALAAMAGGIITSLLVWLLAWRNGIDTFRLIIIGIGVRAMLVAFNTWLLLKASLETALTAGLWNAGSLNGLTWAKTSPSAPIIILMLIAAALLVRRMRLLEMGDDTACALGVSVERSRLLMMLVAVVLTAAATALAGPISFIALVAPHIARRISGTARWGLTQAALCGALLLLAADLCAQQLFMPYQLPVGVVTVSLGGIYLIVLLIQESRKK\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_304\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_304\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTTACGTCTCTCGTCGATTAATTATCACCTGTCTGCTGTTGCTAATAGCCTGTGTGATGGCAAGCGTGTGGGGATTACGCAGCGGTGCCGTCACGCTGGAAACCTCGCAGGTATTTGCCGCGCTGATGGGTGACGCACCGCGCAGTATGACAATGGTGGTCACCGAATGGCGTTTACCGCGGGTACTAATGGCGCTGTTGATTGGTGCGGCACTGGGCGTCAGCGGCGCGATTTTTCAGTCGTTGATGCGTAACCCACTCGGCAGCCCTGACGTAATGGGCTTTAACACCGGAGCGTGGAGCGGCGTGCTGGTGGCGATGGTGCTGTTTGGTCAGGACCTGACGGCTATCGCGCTGGCAGCAATGGCGGGCGGCATTATCACTTCGCTGCTGGTCTGGTTGCTTGCCTGGCGTAACGGTATCGACACCTTTCGGTTGATTATTATCGGCATCGGCGTTCGCGCCATGCTGGTGGCCTTTAATACCTGGCTGTTGCTGAAAGCGTCTTTAGAAACGGCGTTAACAGCGGGTTTGTGGAATGCCGGATCGCTCAATGGCCTGACGTGGGCAAAAACCTCGCCCTCCGCGCCCATCATTATATTGATGCTAATTGCCGCCGCCTTACTGGTAAGGCGGATGCGCTTGCTGGAGATGGGTGATGACACCGCGTGTGCGTTAGGCGTCAGCGTCGAACGTTCGCGTCTATTAATGATGCTGGTCGCCGTAGTACTTACCGCAGCTGCCACTGCCCTGGCGGGGCCGATTTCCTTTATTGCTTTAGTCGCGCCACACATTGCCCGCCGCATCAGCGGCACCGCTCGCTGGGGGCTAACCCAGGCGGCGCTGTGCGGTGCGCTGTTACTGCTGGCAGCCGATCTCTGTGCTCAGCAACTGTTTATGCCGTATCAACTTCCGGTTGGCGTCGTTACCGTCAGCCTCGGCGGTATTTACCTTATCGTCTTGTTAATTCAGGAGTCTCGCAAAAAATGA",
      "translation": "MIYVSRRLIITCLLLLIACVMASVWGLRSGAVTLETSQVFAALMGDAPRSMTMVVTEWRLPRVLMALLIGAALGVSGAIFQSLMRNPLGSPDVMGFNTGAWSGVLVAMVLFGQDLTAIALAAMAGGIITSLLVWLLAWRNGIDTFRLIIIGIGVRAMLVAFNTWLLLKASLETALTAGLWNAGSLNGLTWAKTSPSAPIIILMLIAAALLVRRMRLLEMGDDTACALGVSVERSRLLMMLVAVVLTAAATALAGPISFIALVAPHIARRISGTARWGLTQAALCGALLLLAADLCAQQLFMPYQLPVGVVTVSLGGIYLIVLLIQESRKK",
      "product": ""
     },
     {
      "start": 320291,
      "end": 321295,
      "strand": -1,
      "locus_tag": "ctg1_305",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_305</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_305</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 320,291 - 321,295,\n (total: 1005 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1011:transport system permease protein (Score: 339.7; E-value: 2.5e-103)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_305\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_305\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_305_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSGSVAVTRAIAVPGLLLLLIIATALSLLIGAKSLPASVVLEALSGTCQSADCTIVLDARLPRTLAGLLAGGALGLAGALMQTLTRNPLADPGLLGVNAGASFAIVLGAALFGYSSAQEQLAMAFAGALVASLIVAFTGSQGGGQLSPVRLTLAGVALAAVLEGLTSGIALLNPDVYDQLRFWQAGSLDIRNLHTLKVVLIPVLIAGATALLLSRALNSLSLGSDTATALGSRVARTQLIGLLTITVLCGSATAVVGPIAFIGLMMPHMARWLVGADHRWSLPVTLLATPALLLFADIIGRVIVPGELRVSVVSAFIGAPVLIFLVRRKTRGGA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_305\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_305\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCTGGTTCTGTTGCCGTGACACGCGCCATTGCCGTGCCCGGATTGCTGTTATTACTGATTATCGCGACGGCATTAAGCCTGCTCATTGGGGCAAAATCACTCCCCGCTTCCGTAGTGCTGGAGGCCCTCTCCGGCACCTGCCAGAGCGCCGACTGCACCATCGTGCTCGACGCGCGACTGCCGCGTACCCTTGCCGGTTTACTGGCAGGCGGCGCGCTTGGCCTTGCCGGGGCGTTAATGCAAACCCTCACCCGAAACCCACTTGCCGACCCCGGCTTGCTTGGCGTGAACGCCGGGGCCAGCTTTGCCATTGTGCTGGGCGCGGCGCTGTTTGGTTACTCATCCGCGCAGGAACAACTAGCGATGGCCTTCGCCGGGGCGCTGGTGGCCTCGTTGATTGTTGCCTTTACTGGCAGCCAGGGCGGTGGGCAGTTAAGTCCGGTGCGTTTAACTCTGGCGGGCGTGGCGCTGGCGGCAGTGCTGGAAGGGCTGACCAGCGGCATCGCCCTGCTTAATCCCGACGTCTACGATCAACTGCGTTTCTGGCAAGCCGGTTCGCTGGATATTCGTAATTTACACACCTTAAAAGTAGTGCTGATCCCGGTGCTGATCGCTGGAGCAACTGCACTATTACTGAGCCGCGCGCTGAACAGTTTAAGCCTTGGCAGTGACACCGCGACGGCGCTGGGCAGTCGCGTGGCGCGCACACAGTTGATTGGTCTGCTGACGATTACCGTGCTTTGTGGTAGTGCGACGGCGGTAGTTGGCCCGATTGCTTTTATTGGCCTGATGATGCCGCACATGGCACGTTGGTTGGTTGGAGCCGATCATCGCTGGTCGCTGCCCGTCACGCTGCTCGCCACACCAGCCCTGCTGCTGTTTGCCGATATTATCGGGCGTGTGATTGTTCCCGGCGAACTGCGCGTTTCTGTAGTCAGTGCCTTTATTGGCGCACCAGTGCTGATCTTCCTTGTACGACGTAAAACGCGAGGTGGCGCATGA",
      "translation": "MSGSVAVTRAIAVPGLLLLLIIATALSLLIGAKSLPASVVLEALSGTCQSADCTIVLDARLPRTLAGLLAGGALGLAGALMQTLTRNPLADPGLLGVNAGASFAIVLGAALFGYSSAQEQLAMAFAGALVASLIVAFTGSQGGGQLSPVRLTLAGVALAAVLEGLTSGIALLNPDVYDQLRFWQAGSLDIRNLHTLKVVLIPVLIAGATALLLSRALNSLSLGSDTATALGSRVARTQLIGLLTITVLCGSATAVVGPIAFIGLMMPHMARWLVGADHRWSLPVTLLATPALLLFADIIGRVIVPGELRVSVVSAFIGAPVLIFLVRRKTRGGA",
      "product": ""
     },
     {
      "start": 321406,
      "end": 322656,
      "strand": 1,
      "locus_tag": "ctg1_306",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_306</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_306</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 321,406 - 322,656,\n (total: 1251 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1020:major facilitator transporter (Score: 394.9; E-value: 6.5e-120)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_306\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_306\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_306_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMNKQSWLLNLSLLKTHPAFRAVFLARFISIVSLGLLGVAVPVQIQMMTHSTWQVGLSVTLTGGAMFVGLMVGGVLADRYERKKVILLARGTCGIGFIGLCLNALLPEPSLLAIYLLGLWDGFFASLGVTALLAATPALVGRENLMQAGAITMLTVRLGSVISPMIGGLLLATGGVAWNYGLAAAGTFITLLPLLSLPALPPPPQPREHPLKSLLAGFRFLLASPLVGGIALLGGLLTMASAVRVLYPALADNWQMSAAQIGFLYAAIPLGAAIGALTSGKLAHSARPGLLMLLSTLGSFLAIGLFGLMPMWILGVVCLALFGWLSAVSSLLQYTMLQTQTPEAMLGRINGLWTAQNVTGDAIGAALLGGLGAMMTPVASASASGFGLLIIGVLLLLVLVELRRFRQTPPQVTASDS\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_306\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_306\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAATAAACAATCCTGGCTGCTTAACCTCAGCCTGTTGAAAACGCACCCGGCGTTTCGCGCAGTATTCCTCGCTCGTTTTATCTCTATTGTTTCTCTGGGTTTGCTCGGCGTCGCGGTGCCAGTGCAGATCCAGATGATGACGCATTCTACCTGGCAGGTGGGGCTTTCGGTGACGCTGACCGGCGGCGCGATGTTTGTTGGCCTGATGGTCGGCGGTGTGCTGGCGGATCGCTATGAACGCAAAAAAGTGATTTTGCTGGCGCGCGGCACCTGTGGCATTGGCTTCATTGGACTGTGCCTTAATGCACTGCTGCCGGAGCCGTCATTGCTGGCAATCTATTTACTTGGTTTATGGGATGGTTTTTTCGCATCACTTGGCGTTACGGCGCTACTGGCGGCGACACCAGCACTGGTAGGGCGTGAAAACCTAATGCAGGCCGGGGCGATCACCATGTTGACCGTGCGGCTGGGATCGGTAATTTCGCCCATGATTGGCGGCTTACTGCTGGCGACTGGCGGCGTAGCCTGGAACTACGGGCTGGCGGCGGCGGGCACGTTTATTACCTTGCTACCATTGTTAAGCCTTCCGGCGCTACCTCCGCCACCGCAACCGCGTGAGCATCCGTTGAAATCATTACTGGCAGGATTTCGTTTTCTGCTCGCCAGCCCGCTGGTGGGAGGGATTGCACTGCTGGGGGGATTATTGACGATGGCGAGCGCGGTACGGGTACTGTATCCGGCGCTGGCTGACAACTGGCAGATGTCGGCGGCACAGATTGGTTTTCTCTATGCGGCGATCCCGCTCGGTGCAGCTATTGGCGCGTTAACCAGCGGGAAGCTGGCACATAGCGCGCGACCAGGGTTATTGATGCTGCTCTCCACGCTGGGATCGTTCCTCGCCATTGGTTTGTTTGGCCTGATGCCGATGTGGATTTTAGGCGTGGTTTGCCTGGCGCTGTTCGGCTGGCTGAGCGCGGTTAGTTCATTGCTGCAATACACAATGCTGCAAACGCAAACCCCGGAAGCGATGTTAGGGCGGATTAACGGTTTGTGGACGGCACAAAACGTGACGGGCGATGCTATAGGCGCAGCGCTGTTGGGTGGTCTGGGAGCGATGATGACGCCGGTGGCCTCCGCAAGCGCGAGTGGTTTTGGTTTGTTGATTATCGGCGTGTTGTTGTTGCTGGTACTGGTGGAGTTGCGTCGTTTTCGCCAGACGCCGCCGCAGGTGACAGCGTCTGACAGTTAA",
      "translation": "MNKQSWLLNLSLLKTHPAFRAVFLARFISIVSLGLLGVAVPVQIQMMTHSTWQVGLSVTLTGGAMFVGLMVGGVLADRYERKKVILLARGTCGIGFIGLCLNALLPEPSLLAIYLLGLWDGFFASLGVTALLAATPALVGRENLMQAGAITMLTVRLGSVISPMIGGLLLATGGVAWNYGLAAAGTFITLLPLLSLPALPPPPQPREHPLKSLLAGFRFLLASPLVGGIALLGGLLTMASAVRVLYPALADNWQMSAAQIGFLYAAIPLGAAIGALTSGKLAHSARPGLLMLLSTLGSFLAIGLFGLMPMWILGVVCLALFGWLSAVSSLLQYTMLQTQTPEAMLGRINGLWTAQNVTGDAIGAALLGGLGAMMTPVASASASGFGLLIIGVLLLLVLVELRRFRQTPPQVTASDS",
      "product": ""
     },
     {
      "start": 322660,
      "end": 323616,
      "strand": -1,
      "locus_tag": "ctg1_307",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_307</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_307</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 322,660 - 323,616,\n (total: 957 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1033:iron compound ABC transporter, periplasmic (Score: 339.1; E-value: 3.3e-103)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_307\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_307\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_307_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMRLAPLYHNALLLAGLLLSGISAVQAADWPRQITDSRGTHTLESPPQRIVSTSVTLTGSLLAIDAPVIASGATTPNNRVADDQGFLRQWSKVAKERKLQRLYIGEPNAEAVAAQMPDLILISATGGDSALALYDQLSTIAPTLIINYDDKSWQSLLTQLGEITGHEKQAAERIAQFDKQLAAAKEQIKLPPQPVTAIVYTAAAHSANLWTAESAQGQMLEQLGFTLARLPAGLNASQSQGKRHDIIQLGGENLAAGLNGESLFLFAGDQKDADAIYANPLLAHLPAVQNKQVYALGTETFRLDYYSAMQVLDRLKALF\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_307\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_307\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGACTCGCCCCGCTCTACCACAACGCCCTTCTTTTAGCAGGACTTTTGCTTTCAGGAATATCCGCAGTTCAGGCTGCCGACTGGCCGCGTCAGATTACTGACAGTCGTGGTACTCATACCCTGGAAAGCCCGCCGCAGCGTATTGTTTCCACCAGCGTCACCCTGACCGGCTCACTGCTGGCGATTGATGCACCAGTGATCGCCAGCGGCGCGACCACGCCGAATAACCGCGTAGCGGATGACCAGGGCTTTTTACGCCAGTGGAGCAAGGTGGCGAAAGAACGCAAACTGCAACGTCTCTATATCGGCGAACCGAACGCCGAAGCGGTGGCCGCGCAAATGCCGGATCTGATTTTAATTAGCGCAACCGGCGGCGATTCGGCGCTGGCGCTGTACGATCAGCTTTCCACCATCGCCCCGACGTTAATCATCAATTACGACGACAAAAGCTGGCAGTCGCTGTTAACGCAGCTTGGCGAAATTACCGGGCATGAGAAACAAGCGGCAGAGCGGATTGCGCAGTTTGATAAGCAACTGGCGGCGGCGAAAGAGCAAATCAAATTACCGCCGCAGCCGGTCACTGCCATTGTCTATACCGCCGCCGCGCACAGTGCCAATCTCTGGACAGCTGAATCAGCACAAGGGCAGATGCTGGAACAACTCGGCTTTACGCTGGCCAGGTTGCCCGCAGGCTTAAACGCCAGCCAAAGCCAGGGCAAACGCCATGACATCATTCAGCTTGGTGGGGAAAATCTGGCGGCAGGGTTAAATGGCGAGTCGCTATTCCTGTTCGCCGGTGATCAGAAAGACGCCGATGCGATTTATGCCAATCCACTGCTCGCACACCTGCCTGCAGTACAAAACAAGCAGGTTTATGCGCTGGGAACCGAGACGTTCCGACTGGATTACTACAGCGCCATGCAAGTGCTGGATCGGCTTAAGGCGCTGTTCTAA",
      "translation": "MRLAPLYHNALLLAGLLLSGISAVQAADWPRQITDSRGTHTLESPPQRIVSTSVTLTGSLLAIDAPVIASGATTPNNRVADDQGFLRQWSKVAKERKLQRLYIGEPNAEAVAAQMPDLILISATGGDSALALYDQLSTIAPTLIINYDDKSWQSLLTQLGEITGHEKQAAERIAQFDKQLAAAKEQIKLPPQPVTAIVYTAAAHSANLWTAESAQGQMLEQLGFTLARLPAGLNASQSQGKRHDIIQLGGENLAAGLNGESLFLFAGDQKDADAIYANPLLAHLPAVQNKQVYALGTETFRLDYYSAMQVLDRLKALF",
      "product": ""
     },
     {
      "start": 323805,
      "end": 324980,
      "strand": 1,
      "locus_tag": "ctg1_308",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_308</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_308</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 323,805 - 324,980,\n (total: 1176 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRP-metallophore: EntC<br>\n \n  biosynthetic-additional (smcogs) SMCOG1018:isochorismate synthase (Score: 408.9; E-value: 5.5e-124)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_308\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_308\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_308_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_308\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_308\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGATACGTCACTGGCTGAGGAAGTACAGCAGACCATGGCAACACTTGCGCCCAATCGCTTTTTCTTTATGTCGCCGTACCGCAGTTTTACGACGTCAGGATGTTTCGCCCGCTTTGATGAACCGGCTGTGAACGGGGATTCGCCCGACAGTCCCTTCCAGCAAAAACTCACCGCGCTGTTTGCCGATGCCAAAGCGCAGGGCATTAAAAATCCGGTGATGGTTGGGGCGATTCCCTTCGATCCACGTCAGCCTTCGTCGCTGTATATTCCCGAATCCTGGCAGTCGTTCTCCCGGCTGGAAAAACAGACTTCAGCCCGCCGTTTCACCCGCAGCCAGTCGCTGAACGTGGTGGAACGTCAGGCAATTCCTGAACAAGCTACGTTTGAACAGATGGTTGCCCGCGCCGCCGCACTTACCGCCACGCCGCAAGTCGACAAAGTGGTGTTGTCACGGTTGATTGATATCACCACTGACGCCGTCATTGATAGTGGCGTATTGCTGGAACGGTTGATTGTGCAAAACCCGGTTAGTTACAACTTCCATGTGCCGTTAGCTGATGGTGGCGTCCTGCTGGGAGCCAGCCCGGAACTGCTGCTACGTAAAGACGGCGAGCGTTTTAGCTCCATTCCGTTAGCCGGTTCCGCGCGCCGTCAGCCGGATGACGTGCTCGATCGCGAAGCGGGTAATCGTCTGCTGGCGTCAGAAAAAGATCGCCATGAACATGAACTTGTCACTCAGGCGATGAAAGAGGTACTGCGCGAACGCAGTAGTGAGTTACACGTTCCATCCTCCCCACAATTGCTCACCACACCGACGCTGTGGCATCTCGCAACACCCTTTGAAGGCAAAGCGAATTCGCAAGAAAACGCATTGACTCTGGCCTGTCTGCTGCATCCGACCCCCGCGCTGAGCGGTTTCCCGCATCAGGCCGCGACCCAGGTGATTGCTGAGCTGGAACCGTTCGACCGCGAACTGTTTGGCGGCATTGTGGGTTGGTGTGACAGCGAAGGTAACGGCGAGTGGGTGGTGACCATCCGCTGCGCGAAGCTGCGGGAAAATCAGGTACGTCTGTTTGCCGGAGCGGGGATTGTGCCTGCGTCCTCACCGTTGGGTGAATGGCGCGAAACGGGCGTCAAACTTTCTACCATGTTGAACGTTTTTGGATTGCATTAA",
      "translation": "MDTSLAEEVQQTMATLAPNRFFFMSPYRSFTTSGCFARFDEPAVNGDSPDSPFQQKLTALFADAKAQGIKNPVMVGAIPFDPRQPSSLYIPESWQSFSRLEKQTSARRFTRSQSLNVVERQAIPEQATFEQMVARAAALTATPQVDKVVLSRLIDITTDAVIDSGVLLERLIVQNPVSYNFHVPLADGGVLLGASPELLLRKDGERFSSIPLAGSARRQPDDVLDREAGNRLLASEKDRHEHELVTQAMKEVLRERSSELHVPSSPQLLTTPTLWHLATPFEGKANSQENALTLACLLHPTPALSGFPHQAATQVIAELEPFDRELFGGIVGWCDSEGNGEWVVTIRCAKLRENQVRLFAGAGIVPASSPLGEWRETGVKLSTMLNVFGLH",
      "product": ""
     },
     {
      "start": 324990,
      "end": 326600,
      "strand": 1,
      "locus_tag": "ctg1_309",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_309</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_309</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 324,990 - 326,600,\n (total: 1611 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 451.9; E-value: 3.7e-137)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_309\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_309\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_309_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_309\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_309\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCATTCCATTCACCCGCTGGCCGGAAGAGTTTGCCCGTCGCTATCGGGAAAAAGGCTACTGGCAGGATTTGCCACTGACCGACATTCTGACTCGCCACGCTGCGAGTGACAGCATCGCGGTTATCGACGGCGAGCGGCAGTTGAGTTACCGGGAGCTGAATCAGGCGGCGGATAACCTCGCCTGTAGTTTGCGCCGTCAGGGCATTAAACCCGGTGAAACCGCGCTGGTACAACTGGGTAACGTCGCTGAATTGTATATTACCTTTTTCGCGCTGCTGAAACTGGGCGTTGCGCCGGTGCTGGCGCTGTTCAGTCATCAGCGTAGTGAACTGAACGCCTATGCCAGCCAGATTGAACCGGCGTTACTGATTGCCGATCGCCAACATGCGCTATTTAGCGGGGATGATTTCCTCAACACATTTGTTGCAGAGCATTCTTCCATTCGCGTGGTGCAACTGCTGAACGACAGCGGTGAGCATAACTTGCAGGATGCGATTAACCATCCGGCTGAGGATTTTACTGCCACGCCATCTCCTGCTGATGAAGTGGCCTATTTCCAGCTTTCCGGCGGCACCACCGGCACACCGAAACTGATCCCGCGCACTCATAACGACTACTACTACAGCGTGCGTCGTAGCGTCGAGATTTGTCAGTTCACACAACAGACGCGCTACCTGTGCGCGATCCCGGCGGCTCATAACTACGCCATGAGTTCGCCGGGATCGTTGGGGGTATTTCTCGCTGGCGGCACTGTCGTTCTGGCTGCCGACCCCAGCGCCACGCTTTGTTTCCCATTGATTGAAAAACATCAGGTGAACGTCACCGCGCTGGTGCCGCCAGCAGTCAGCCTGTGGTTACAGGCGCTGACCGAAGGTGAAAGCCGGGCGCAGCTTGCCTCGCTGAAACTGTTACAGGTCGGTGGCGCACGTCTTTCTGCCACGCTTGCGGCGCGTATTCCCGCAGAGATTGGCTGCCAGTTACAGCAGGTATTCGGCATGGCGGAAGGGCTGGTGAACTACACCCGTCTTGATGATAGCGCGGAGAAAATTATCCATACCCAGGGCTATCCAATGTGTCCGGATGATGAAGTGTGGGTTGCCGATGCTGACGGAAATCCACTGCCGCAAGGGGAGGTTGGACGCCTGATGACGCGCGGGCCGTACACCTTCCGCGGCTATTACAAAAGTCCACAGCACAATGCCAGCGCCTTTGATGCCAACGGTTTTTACTGTTCCGGCGATCTGATCTCTATTGATCCAGAGGGGTACATCACCGTGCAGGGGCGCGAGAAAGATCAGATCAACCGTGGCGGCGAGAAGATCGCTGCCGAAGAGATCGAAAACCTGTTACTGCGCCATCCGGCGGTGATCTACGCCGCCCTGGTGAGTATGGAAGATGAGCTGATGGGCGAAAAAAGCTGTGCTTATCTGGTGGTAAAAGAACCACTGCGTGCGGTACAGGTGCGTCGTTTCCTGCGTGAACAGGGTATTGCCGAATTTAAATTACCGGATCGCGTGGAGTGTGTAGATTCACTTCCGCTGACGGCGGTCGGGAAAGTCGATAAAAAACAATTACGTCAGTGGCTGGCGTCACGCGCATCAGCCTGA",
      "translation": "MSIPFTRWPEEFARRYREKGYWQDLPLTDILTRHAASDSIAVIDGERQLSYRELNQAADNLACSLRRQGIKPGETALVQLGNVAELYITFFALLKLGVAPVLALFSHQRSELNAYASQIEPALLIADRQHALFSGDDFLNTFVAEHSSIRVVQLLNDSGEHNLQDAINHPAEDFTATPSPADEVAYFQLSGGTTGTPKLIPRTHNDYYYSVRRSVEICQFTQQTRYLCAIPAAHNYAMSSPGSLGVFLAGGTVVLAADPSATLCFPLIEKHQVNVTALVPPAVSLWLQALTEGESRAQLASLKLLQVGGARLSATLAARIPAEIGCQLQQVFGMAEGLVNYTRLDDSAEKIIHTQGYPMCPDDEVWVADADGNPLPQGEVGRLMTRGPYTFRGYYKSPQHNASAFDANGFYCSGDLISIDPEGYITVQGREKDQINRGGEKIAAEEIENLLLRHPAVIYAALVSMEDELMGEKSCAYLVVKEPLRAVQVRRFLREQGIAEFKLPDRVECVDSLPLTAVGKVDKKQLRQWLASRASA",
      "product": ""
     },
     {
      "start": 326614,
      "end": 327471,
      "strand": 1,
      "locus_tag": "ctg1_310",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_310</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_310</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 326,614 - 327,471,\n (total: 858 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1027:isochorismatase (Score: 416; E-value: 8.1e-127)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_310\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_310\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_310_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_310\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_310\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTATTCCAAAATTACAGGCTTACGCACTGCCGGAGTCTCACGATATTCCGCACAATAAAGTCAACTGGACCTTTGAGCCGCAACGTGCCGCGTTGTTAATCCATGATATGCAGGACTATTTTGTTAGCTTCTGGGGCGAGAACTGCCCGATGATGGAGCAGGTGATCGCGAATATTGCGGCACTACGCAACTACTGCAAACAGCACAATATCCCGGTTTATTACACCGCCCAGCCGAAAGAGCAGAGCGATGAAGATCGGGCGCTGTTGAATGATATGTGGGGGCCGGGCCTGACCCGTTCGCCGGAACAGCAAAAGGTGGTGGATCGCCTGACGCCAGATGCCGACGACACGGTGCTGGTGAAGTGGCGCTACAGCGCGTTTCATCGTTCTCCGCTGGAACAAATGCTCAAAGAGAGTGGACGTAACCAACTGATTATAACCGGGGTGTACGCCCACATTGGCTGTATGACCACCGCAACCGACGCATTTATGCGCGATATTAAACCGTTTATGGTGGCAGATGCGCTGGCCGATTTCAGCCGTGACGAGCATTTGATGTCTCTGAAATATGTGGCCGGACGGTCTGGCCGGGTGGTGATGACCGAAGAACTATTGCCTGCACCGATCCCTTCAACCAAAGCGGCGCTGCGAGAGGTGATCCTGCCGTTGCTGGACGAGTCCGATGAACCCTTCGATGACGACAACCTGATCGATTACGGTCTGGATTCGGTGCGCATGATGGCGCTGGCGGCGCGCTGGCGCAAAGTGCATGGCGATATCGATTTTGTCATGCTGGCGAAAAATCCGACCATCGATGCCTGGTGGAAGCTACTCTCCCGCGAGGTGAAATGA",
      "translation": "MAIPKLQAYALPESHDIPHNKVNWTFEPQRAALLIHDMQDYFVSFWGENCPMMEQVIANIAALRNYCKQHNIPVYYTAQPKEQSDEDRALLNDMWGPGLTRSPEQQKVVDRLTPDADDTVLVKWRYSAFHRSPLEQMLKESGRNQLIITGVYAHIGCMTTATDAFMRDIKPFMVADALADFSRDEHLMSLKYVAGRSGRVVMTEELLPAPIPSTKAALREVILPLLDESDEPFDDDNLIDYGLDSVRMMALAARWRKVHGDIDFVMLAKNPTIDAWWKLLSREVK",
      "product": ""
     },
     {
      "start": 327471,
      "end": 328217,
      "strand": 1,
      "locus_tag": "ctg1_311",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_311</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_311</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 327,471 - 328,217,\n (total: 747 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRP-metallophore: EntA<br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short_C2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 238.4; E-value: 1.4e-72)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_311\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_311\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_311_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_311\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_311\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGATTTCAGCGGCAAAAATGTCTGGGTAACCGGTGCGGGGAAAGGTATTGGCTACGCCACGGCGCTGGCATTTGTTGAGGCCGGAGCGAAAGTTACAGGTTTTGATCAAGCGTTCACTCTGGAGCAATATCCCTTTGCGACCGAAGTAATGGATGTAGCCGACGCTGCGCAGGTGGCGCAAGTGTGTCAGCGACTGTTAGCGCAAACGGAGCGACTGGACGTGCTGGTCAATGCGGCGGGAATTTTGCGCATGGGCGCGACCGATCAGCTCAGCAAGGAGGACTGGCAGCAGACTTTTTCGGTTAACGTCGGCGGTGCGTTTAACCTGTTCCAGCAAACCATGAACCAGTTTCGCCGTCAGCGGGGCGGGGCGATTGTCACTGTGGCGTCCGACGCCGCACACACGCCGCGTATTGGTATGAGTGCTTATGGCGCGTCGAAAGCGGCGCTGAAAAGCCTGGCGTTGAGCGTCGGGCTGGAACTGGCGGGTAGCGGTGTGCGCTGTAATGTGGTTTCCCCGGGGTCCACCGACACCGATATGCAACGCACGCTGTGGGTGAGTGATGACGCCGAAGAGCAGCGTATTCGCGGCTTTGGCGAGCAGTTTAAACTCGGCATTCCGCTGGGGAAAATCGCCCGTCCACAAGAGATCGCCAACACGATTTTGTTCCTCGCCTCTGACCTCGCCAGCCATATCACCCTACAGGATATTGTGGTAGATGGCGGCTCAACACTGGGGGCATAA",
      "translation": "MDFSGKNVWVTGAGKGIGYATALAFVEAGAKVTGFDQAFTLEQYPFATEVMDVADAAQVAQVCQRLLAQTERLDVLVNAAGILRMGATDQLSKEDWQQTFSVNVGGAFNLFQQTMNQFRRQRGGAIVTVASDAAHTPRIGMSAYGASKAALKSLALSVGLELAGSGVRCNVVSPGSTDTDMQRTLWVSDDAEEQRIRGFGEQFKLGIPLGKIARPQEIANTILFLASDLASHITLQDIVVDGGSTLGA",
      "product": ""
     },
     {
      "start": 328220,
      "end": 328633,
      "strand": 1,
      "locus_tag": "ctg1_312",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_312</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_312</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 328,220 - 328,633,\n (total: 414 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1144:thioesterase superfamily protein (Score: 208.5; E-value: 4.3e-64)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_312\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_312\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_312_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_312\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_312\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCTGGAAACGCCATTTAACGCTCGACGAACTGAACGCCACCAGCGATAACACAATGGTGGCGCATCTGGGAATTGTTTATACCCGTCTGGGCGATGATGTGCTGGAAGCCGAAATGCCGGTTGATACCCGTACTCATCAACCGTTCGGTTTACTACATGGCGGCGCATCGGCGGCGCTGGCGGAAACCCTGGGATCGATGGCCGGATTTATGATGACTCGCGACGGACAGTGCGTGGTGGGCACGGAGCTTAACGCCACACATCATCGCCCAGTGTCTGAGGGAAAGGTACGCGGCGTCTGCCAGCCGCTGCATCTTGGGCGGCAAAATCAGAGCTGGGAAATCGTTGTTTTCGATGAACAGGGGCGGCGTTGCTGCACTTGCCGGCTGGGTACGGCAGTTTTGGGATGA",
      "translation": "MIWKRHLTLDELNATSDNTMVAHLGIVYTRLGDDVLEAEMPVDTRTHQPFGLLHGGASAALAETLGSMAGFMMTRDGQCVVGTELNATHHRPVSEGKVRGVCQPLHLGRQNQSWEIVVFDEQGRRCCTCRLGTAVLG",
      "product": ""
     },
     {
      "start": 328814,
      "end": 330919,
      "strand": 1,
      "locus_tag": "ctg1_313",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_313</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_313</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 328,814 - 330,919,\n (total: 2106 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1185:carbon starvation protein A (Score: 1372.6; E-value: 0.0)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_313\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_313\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_313\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_313\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACAAATCAGGGAAATACCTCGTCTGGACAGTGCTCTCTGTAATGGGAGCATTTGCTCTGGGATACATTGCTTTAAATCGTGGGGAACAGATCAACGCGCTGTGGATTGTGGTGGCGTCGGTCTGTATCTATCTGATCGCTTACCGTTTTTATGGTCTTTATATCGCCAAAAATGTATTGGCGGTTGACCCGACGCGTATGACGCCAGCGGTGCGCCATAACGACGGGCTGGACTATGTGCCGACGGACAAGAAAGTGCTGTTCGGTCACCATTTTGCGGCTATTGCCGGAGCAGGCCCGTTGGTGGGGCCGGTACTGGCGGCGCAAATGGGCTACCTACCGGGGATGATCTGGCTACTTGCCGGGGTGGTTCTCGCCGGTGCAGTGCAGGATTTCATGGTGCTGTTTGTTTCCACGCGCCGTGACGGTCGCTCGCTGGGCGAGCTGGTTAAAGAAGAGATGGGGCCAACTGCCGGGGTGATTGCGCTGGTGGCCTGCTTTATGATCATGGTCATTATCCTTGCAGTACTGGCGATGATCGTGGTGAAAGCCCTGACTCATAGCCCGTGGGGAACGTATACCGTTGCGTTCACCATTCCGCTGGCGCTGTTCATGGGGATTTACCTGCGCTATCTGCGTCCGGGCCGCATTGGGGAAGTGTCGGTGATTGGCCTGGTATTCCTTATTTTCGCCATTATCTCTGGCGGCTGGGTGGCAGAAAGCCCGACCTGGGCACCGTACTTTGACTTTACCGGCGTGCAGCTGACCTGGATGCTGGTGGGTTACGGTTTTGTGGCGGCGGTTCTGCCGGTGTGGTTGCTGCTGGCTCCGCGTGACTACCTCTCTACCTTCCTGAAAATCGGGACTATCGTCGGTCTGGCGGTAGGCATTTTGATTATGCGTCCGACGCTGACCATGCCTGCGCTGACCAAATTTGTAGATGGCACTGGTCCGGTATGGACCGGTAATCTGTTCCCGTTCCTGTTTATTACTATCGCCTGTGGCGCGGTGTCTGGCTTCCATGCGCTGATCTCTTCCGGCACCACACCGAAGATGCTGGCGAACGAAGGTCAGGCGTGCTTTATCGGCTACGGTGGAATGTTGATGGAATCCTTCGTGGCGATTATGGCACTGGTTTCTGCCTGTATCATCGATCCGGGCGTGTACTTCGCGATGAACAGCCCGATGGCGGTGCTGGCTCCGGCGGGGACGGCGGATGTAGTGGCATCTGCTGCGCAGGTAGTGAGTAGCTGGGGCTTTAGCATTACGCCAGATACGTTAAATCAGATTGCCAGCGAAGTGGGCGAACAGTCGATCATTTCCCGTGCGGGCGGTGCGCCGACCCTGGCGGTGGGGATGGCCTACATTCTGCACGGCGCGCTGGGTGGCATGATGGATGTGGCGTTCTGGTATCACTTCGCCATTCTGTTTGAAGCACTGTTTATTCTGACGGCGGTGGATGCGGGTACGCGTGCTGCGCGCTTTATGTTGCAGGATCTGCTGGGCGTGGTTTCTCCGGGCCTGAAACGGACCGATTCACTGCCTGCTAACCTGCTGGCAACGGCGCTGTGCGTGCTGGCGTGGGGTTACTTTCTGCATCAGGGCGTGGTCGATCCGCTGGGCGGTATTAACACTCTGTGGCCGCTGTTTGGTATTGCCAACCAGATGCTGGCAGGGATGGCGCTGATGCTCTGTGCCGTGGTGTTGTTCAAGATGAAACGTCAACGTTACGCCTGGGTGGCGCTGGTACCAACGGCCTGGCTGCTGATTTGTACCCTGACCGCAGGCTGGCAGAAAGCGTTTAGCCCGGATGCGAAAGTCGGTTTCCTGGCGATTGCTAACAAGTTCCAGGCAATGATCGACAGCGGCAATATTCCGTCGCAGTATACTGAGTCACAACTGGCGCAACTGGTGTTCAACAACCGTCTGGATGCCGGATTAACCATCTTCTTTATGGTGGTTGTGGTGGTTCTGGCGCTGTTCTCGATTAAGACGGCACTGGCGGCATTGAAAGAGCCGAAGCCAACGGCGAAAGAAACGCCGTATGAGCCAATGCCGGAAAATGTCGAGGAGATCGTGGCGCAGGCGAAAGGCGCGCACTAA",
      "translation": "MNKSGKYLVWTVLSVMGAFALGYIALNRGEQINALWIVVASVCIYLIAYRFYGLYIAKNVLAVDPTRMTPAVRHNDGLDYVPTDKKVLFGHHFAAIAGAGPLVGPVLAAQMGYLPGMIWLLAGVVLAGAVQDFMVLFVSTRRDGRSLGELVKEEMGPTAGVIALVACFMIMVIILAVLAMIVVKALTHSPWGTYTVAFTIPLALFMGIYLRYLRPGRIGEVSVIGLVFLIFAIISGGWVAESPTWAPYFDFTGVQLTWMLVGYGFVAAVLPVWLLLAPRDYLSTFLKIGTIVGLAVGILIMRPTLTMPALTKFVDGTGPVWTGNLFPFLFITIACGAVSGFHALISSGTTPKMLANEGQACFIGYGGMLMESFVAIMALVSACIIDPGVYFAMNSPMAVLAPAGTADVVASAAQVVSSWGFSITPDTLNQIASEVGEQSIISRAGGAPTLAVGMAYILHGALGGMMDVAFWYHFAILFEALFILTAVDAGTRAARFMLQDLLGVVSPGLKRTDSLPANLLATALCVLAWGYFLHQGVVDPLGGINTLWPLFGIANQMLAGMALMLCAVVLFKMKRQRYAWVALVPTAWLLICTLTAGWQKAFSPDAKVGFLAIANKFQAMIDSGNIPSQYTESQLAQLVFNNRLDAGLTIFFMVVVVVLALFSIKTALAALKEPKPTAKETPYEPMPENVEEIVAQAKGAH",
      "product": ""
     },
     {
      "start": 331047,
      "end": 331244,
      "strand": 1,
      "locus_tag": "ctg1_314",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_314</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_314</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 331,047 - 331,244,\n (total: 198 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1211:hypothetical protein (Score: 157.8; E-value: 9e-49)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_314\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_314\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_314\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_314\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTTGATTCACTGGCAAAAGCTGGAAAATATTTAGGTCAGGCGGCGAAACTGATGATTGGTATGCCCGATTACGACAACTATGTCGAACATATGCGGGTTAACCATCCTGATCAAACGCCGATGACCTACGAAGAGTTTTTCCGGGAGCGGCAGGACGCGCGCTACGGTGGAAAAGGCGGCGCGCGTTGCTGCTAA",
      "translation": "MFDSLAKAGKYLGQAAKLMIGMPDYDNYVEHMRVNHPDQTPMTYEEFFRERQDARYGGKGGARCC",
      "product": ""
     },
     {
      "start": 331254,
      "end": 332342,
      "strand": -1,
      "locus_tag": "ctg1_315",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_315</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_315</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 331,254 - 332,342,\n (total: 1089 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Fe-ADH<br>\n \n  biosynthetic-additional (smcogs) SMCOG1181:dehydrogenase (Score: 636.2; E-value: 2.4e-193)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_315\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_315\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_315\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_315\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCTCACAATCCTATCCGCGTCGTCGTCGGCCCGGCTAACTACTTTTCACATCCCGGAAGTTTCAATCACCTGCAAGATTTTTTTACTGATGAACAGCTTTCTCGCGCAGCGTGGATCTACGGCGAACGCGCCATTGCGGCTGCGCAATGCAAACTTCCGCCAGCGTTTGAACTGCCAGGGGCAAAGCATATTTTGTTTCGCGGTCATTGCAGTGAAAGCGATGTGCAACAACTGGCGGCTGAGTCCGGTGACGATCGCAGCGTAGTGATTGGCGTCGGCGGCGGCGCACTGCTCGACACCGCGAAAGCCCTCGCCCGCCGTCTCGGTCTGCCGTTTGTTGCCGTTCCAACGATTGCCGCTACTTGCGCTGCCTGGACACCGCTCTCCGTCTGGTATAACGATGCCGGACAGGCGCTACATTATGAGATTTTCGACGACGCCAATTTTATGGTGCTGGTGGAACCGGAGATTATCCTCAATGCGCCGCAAGAATATCTGCTGGCGGGAATCGGTGACACGCTGGCGAAATGGTATGAAGCGGTGGTGCTGGCCCCACAACCAGAAACGTTGCCGCTAACCGTACGGCTGGGGATTAATAATGCGCAGGCCATTCGTGACGTCTTGTTAAGCAGTAGCGAGCAGGCGCTTGCCGATCAGCAAAATCAGCAGTTAACGCGATCATTTTGCGATGTGGTGGATGCGATTATCGCCGGAGGCGGAATGGTCGGTGGTCTGGGCGATCGTTTTACGCGTGTGGCGGCGGCCCATGCCGTGCATAACGGTCTGACTGTACTGCCACAAACCGAGAAGTTTCTCCACGGCACCAAAGTCGCCTACGGAATTCTGGTGCAAAGCGCCTTGCTGGGTCAGGATGCTGTGCTGGCACAATTAACCGGGGCGTATCAGCGTTTTCATCTGCCGACCACGCTGGCGGAGCTGGAAGTGGATATCAATGATCAGGCGGAGATCGACAAAGTGATTGCCCACACCTTGCGTCCGGCGGAATCCATTCATTACCTGCCGGTCACGCTGACACCAGATACGTTGCGTGCAGCGTTCGAAAAAGTGGAATCGTTTAAAGTCTGA",
      "translation": "MPHNPIRVVVGPANYFSHPGSFNHLQDFFTDEQLSRAAWIYGERAIAAAQCKLPPAFELPGAKHILFRGHCSESDVQQLAAESGDDRSVVIGVGGGALLDTAKALARRLGLPFVAVPTIAATCAAWTPLSVWYNDAGQALHYEIFDDANFMVLVEPEIILNAPQEYLLAGIGDTLAKWYEAVVLAPQPETLPLTVRLGINNAQAIRDVLLSSSEQALADQQNQQLTRSFCDVVDAIIAGGGMVGGLGDRFTRVAAAHAVHNGLTVLPQTEKFLHGTKVAYGILVQSALLGQDAVLAQLTGAYQRFHLPTTLAELEVDINDQAEIDKVIAHTLRPAESIHYLPVTLTPDTLRAAFEKVESFKV",
      "product": ""
     },
     {
      "start": 332451,
      "end": 333611,
      "strand": 1,
      "locus_tag": "ctg1_316",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_316</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_316</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 332,451 - 333,611,\n (total: 1161 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_1_2<br>\n \n  biosynthetic-additional (rule-based-clusters) DegT_DnrJ_EryC1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1019:aminotransferase (Score: 389.3; E-value: 3.4e-118)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_316\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_316\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_316_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_316\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_316\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACAAATAACCCTCTGATTCCAAAAAGTAAACTTCCACAACTTGGCACCACTATTTTCACCCAGATGAGCGCACTGGCGCAGCAACACCAGGCGATTAACCTGTCGCAAGGCTTTCCTGATTTTGATGGTCCGCGCTATTTGCAGGAGCGGCTGGCATACCATGTTGACCAGGGGGCAAACCAATACGCGCCTATGACTGGCGTGCAGGCCTTGCGCGAGGCGATTGCTCAGAAAACGGAACGTCTGTATGGCTATCAACCGGATGCCGATAGTGATATCACCGTAACGGCAGGGGCGACGGAAGCGTTATATGCAGCGATTACCGCATTGGTGCGCAATGGTGATGAAGTGATCTGCTTTGATCCCAGCTATGACAGTTACGCGCCCGCCATCGCGCTTTCGGGGGGAATAGTGAAACGTATTGCACTGCAACCACCGCATTTTCGCGTGGACTGGCAGGAATTTGCCGCATTGTTAAGCGAGCGCACCCGACTGGTGATCCTTAACACCCCGCATAACCCCAGTGCTACTGTCTGGCAGCAGACTGATTTTTCTGCTTTGTGGCAGGCAATTGCCGGGCACGAGATTTTTGTTATTAGCGATGAAGTTTACGAGCATATCAACTTTTCACAGCAGGGCCATGCCAGTGTGCTGGCGCATCCGCAACTGCGTGAGCGGGCGGTGGCGGTGTCATCGTTTGGTAAGACTTATCATATGACCGGCTGGAAAGTGGGCTATTGTGTTGCGCCTGCGCCCATCAGCGCCGAGATCCGCAAAGTGCATCAGTATCTGACTTTTTCGGTGAATACCCCGGCGCAGCTGGCCCTTGCCGATATGCTGCGAACAGAACCCGAACACTACCTTGCGTTACCGGACTTTTATCGCCAGAAGCGCGATATTCTGGTGAACGCCTTAAGTGAGAGTCGGCTGGAGATTTTACCGTGCGAAGGCACTTACTTTTTGCTGGTGGATTACAGCGCGGTTTCTTCGCTGGATGACGTTGAGTTTTGCCAGTGGCTGACGCGGGAGCATGGCGTGGCGGCGATCCCGCTGTCGGTATTTTGCGCCGATCCATTCCCCCATAAGCTCATTCGTCTCTGTTTTGCCAAGAAGGAATCGACGTTGCTGGCGGCAGCTGAACGCCTGCGCCAGCTGTAA",
      "translation": "MTNNPLIPKSKLPQLGTTIFTQMSALAQQHQAINLSQGFPDFDGPRYLQERLAYHVDQGANQYAPMTGVQALREAIAQKTERLYGYQPDADSDITVTAGATEALYAAITALVRNGDEVICFDPSYDSYAPAIALSGGIVKRIALQPPHFRVDWQEFAALLSERTRLVILNTPHNPSATVWQQTDFSALWQAIAGHEIFVISDEVYEHINFSQQGHASVLAHPQLRERAVAVSSFGKTYHMTGWKVGYCVAPAPISAEIRKVHQYLTFSVNTPAQLALADMLRTEPEHYLALPDFYRQKRDILVNALSESRLEILPCEGTYFLLVDYSAVSSLDDVEFCQWLTREHGVAAIPLSVFCADPFPHKLIRLCFAKKESTLLAAAERLRQL",
      "product": ""
     },
     {
      "start": 333612,
      "end": 334229,
      "strand": -1,
      "locus_tag": "ctg1_317",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_317</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_317</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 333,612 - 334,229,\n (total: 618 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1232:hypothetical protein (Score: 406.7; E-value: 2.6e-124)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_317\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_317\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_317\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_317\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAACAACATTTAAAGCAGGAGTTAACCCATTTTCTTGCCAGTTTGCCAGAAGACGAAAGAGTAGAGGCAATCAACGAGTTTCGCCAGGCGATCCATAAAGTCAGCCCTTTCCGTGAGGAGCCGGTGGACTGCGTGCTCTGGGTAAAAAAAGAACAGCTCAAGCCAAACAATTACAACCCCAATAATGTTGCACCACCAGAGAAAAGACTGTTACAGGTCTCTATAGAGACTGACGGCTTTACCCAACCCATTGTCGTTTCGCCATCCAGCCAAAATGAGTATGAGATTGTCGATGGTTTCCACCGTCACCTGGTGGGTAAAGAGAACGGTACACTAGGTGTAAGGCTAAAAGGTTATCTGCCAGTGACCTGTCTGGATGGCAATCGCCACGAACGCATCGCCGCAACTATTCGTCATAACCGCGCTCGTGGCCGCCACCAAATCACAGCCATGTCAGAAATCGTTCGTGAACTCAGCCAGTTGGGATGGGACGACAATAAAATCGGCAAAGAGCTGGGTATGGACAGCGACGAAGTGTTGCGCCTGAAACAAATTAACGGCCTGCAAGAGTTATTTGCTGACCGTCAATATTCCCGTGCCTGGACAGTAAAATAA",
      "translation": "MKQHLKQELTHFLASLPEDERVEAINEFRQAIHKVSPFREEPVDCVLWVKKEQLKPNNYNPNNVAPPEKRLLQVSIETDGFTQPIVVSPSSQNEYEIVDGFHRHLVGKENGTLGVRLKGYLPVTCLDGNRHERIAATIRHNRARGRHQITAMSEIVRELSQLGWDDNKIGKELGMDSDEVLRLKQINGLQELFADRQYSRAWTVK",
      "product": ""
     },
     {
      "start": 334226,
      "end": 335437,
      "strand": -1,
      "locus_tag": "ctg1_318",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_318</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_318</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 334,226 - 335,437,\n (total: 1212 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1221:hypothetical protein (Score: 820; E-value: 4.7e-249)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_318\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_318\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_318\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_318\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCTATTCATAAAATTCCTCTTTTCATTAATGTCCTCGACGCTGCGAGGGAGCGCATTCATTGGACGCTAAAAAATTTAGATCGCGTTTGCGTATCCTTTTCCGGTGGTAAAGACTCTGGAGTGATGTTACACCTCACCGCCCAGCTTGCTCGTCAGTTGAACAAAAAAATATTCGTTTTATTTATTGATTGGGAAGCTCAATTCAATCACACCATTAATTATGTCCAGGCCATAAATGATCAATATGCTGACGTCATCGATACCATTTACTGGATCGCTTTACCGCTCACCACGCAAAATGCTCTATCACAGTACCAACCACAATGGCAGTGCTGGGAGCCCGACACAGAATGGGTTCGCCAGCCTCCTACGACAGCCATAACATCCCCTGATTACTTTCCTTTTTACCAGGAAGGTATGACTTTCGAGCACTTTGTTCGCGAATTTGCCGACTGGTTTTCACAGCAACGTCCGGCAGCAATGCTAATCGGTATACGGGCCGATGAATCCTATAACCGCTTTGTTGCAATCGCCACTGAGCACAAGAAACGTTTTGCCGACGACAAACCCTGGACGACATTAGCCCCCGGAGGTCACACCTGGTACATTTACCCGATTTATGACTGGAAAACAGCCGATATCTGGACATGGTATGCAAAAACCAATTCGCTCTGTAATCCTCTGTACAATGTAATGTACCAGGCGGGCGTTCCCTTACGCTATATGAGGATTTGTGAACCTTTTGGCCCGGAACAGAGACAAGGATTGTGGTTATACCACGTCATTGAACCAGAGCAATGGGCAAAGATGTGCGCCCGAGTCAGTGGCGTAAAAAGCGGGGGAATTTACGCCGGACAGGACAACAAGTTTTATGGTCACCGAAAACTGCTTAAACCCGATCACCTTAGCTGGCAGGAGTATGCCCTGCTATTACTCAACAGTATGCCAGAACATACCGCAGAGCATTATCGTAATAAGATCGCCGTTTACCTGAAATGGTACAAGAAGAAAGGAATGGACGAAATTCCCCAGACCCAACAAGGTGATATCGGTGCAAAGGATATTCCATCCTGGAGGCGCATTTGTAAGGTGCTGCTTAATAACGATTACTGGTGCCGGGCACTGTCATTCAGCCCAACAAAATCTCAACATTATCAACGGTATAGCGAACGAATTAAAGCCAAACGCAAACTCTGGGGAATATTATGA",
      "translation": "MSIHKIPLFINVLDAARERIHWTLKNLDRVCVSFSGGKDSGVMLHLTAQLARQLNKKIFVLFIDWEAQFNHTINYVQAINDQYADVIDTIYWIALPLTTQNALSQYQPQWQCWEPDTEWVRQPPTTAITSPDYFPFYQEGMTFEHFVREFADWFSQQRPAAMLIGIRADESYNRFVAIATEHKKRFADDKPWTTLAPGGHTWYIYPIYDWKTADIWTWYAKTNSLCNPLYNVMYQAGVPLRYMRICEPFGPEQRQGLWLYHVIEPEQWAKMCARVSGVKSGGIYAGQDNKFYGHRKLLKPDHLSWQEYALLLLNSMPEHTAEHYRNKIAVYLKWYKKKGMDEIPQTQQGDIGAKDIPSWRRICKVLLNNDYWCRALSFSPTKSQHYQRYSERIKAKRKLWGIL",
      "product": ""
     },
     {
      "start": 335545,
      "end": 336483,
      "strand": -1,
      "locus_tag": "ctg1_319",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_319</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_319</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 335,545 - 336,483,\n (total: 939 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1125:LysR family transcriptional regulator (Score: 351.8; E-value: 5.2e-107)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_319\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_319\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_319\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_319\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCCAATTTGTACGATCTAAAAAAATTCGATTTAAATCTGCTGGTTATTTTTGAATGTATTTATGAAAATCTAAGTATCAGTAAAGCTGCGGAAACTCTTTATATCACGCCATCAGCAGTTAGCCAGTCACTTCAACGTTTACGACTGCAGTTTAATGATCCATTGTTTGTTCGTGCAGGCAAAGGTATATCGCCAACTATTGTCGGTATAAATTTGCATCACCACCTGGGAAAAAATTTGGATGGGCTTGAGCAAATCATCAATATTATGAATGCATCGGAGCTAAAAAATAAATTTGTTATTTACGGGCCGCAATTGATTTCAACGTTCAACGTCACCCGTTTAATTACCTGCCTGCGTGAGGAAGCATCAGTAGAGATCGAATATCATGATATTTTAACGTCAACCGAAACCGGAGAAGAGTTACTGGCTCATCGCAAAGCTGATCTGGTTGTGACAATGCTTCCTATGATCAATCGCTCCGTACTTTGCATGCCATTTCAGTCCATTAGCAATGTATTAGTTTGTCGTAATAATCATCCACGCATGAAAAATGAGTGCTCTCTTGATGATATTCTGAAAGAAGAATTTACTATGCTTATGTCTGAAGCACCTGGATTGGACGAATATCAGTCCCGCATGGATAAAATAATGGTAAATCGAAAGATTGCATTCCGCAGTCAGTCATTAACTTCTATTATTAATATTATTGCAGAAACTGATATTATTGGGATCATTCCACAAAAACTTTATAAAATATATCGTTCCATTCTGAATCTGAGAGAAATAAAGATAGATTATACTCTCCCTTTAATGCGTCTGTATATTTCGTACAATAAATCATCACTTTATAATAAAGCATTTTCAAATTTCATTACCAGGATTGCAGACGAGAAACAATCGAGCCAAAAAAGCATTCACTCGACAAATAATTAA",
      "translation": "MANLYDLKKFDLNLLVIFECIYENLSISKAAETLYITPSAVSQSLQRLRLQFNDPLFVRAGKGISPTIVGINLHHHLGKNLDGLEQIINIMNASELKNKFVIYGPQLISTFNVTRLITCLREEASVEIEYHDILTSTETGEELLAHRKADLVVTMLPMINRSVLCMPFQSISNVLVCRNNHPRMKNECSLDDILKEEFTMLMSEAPGLDEYQSRMDKIMVNRKIAFRSQSLTSIINIIAETDIIGIIPQKLYKIYRSILNLREIKIDYTLPLMRLYISYNKSSLYNKAFSNFITRIADEKQSSQKSIHSTNN",
      "product": ""
     },
     {
      "start": 336683,
      "end": 337429,
      "strand": -1,
      "locus_tag": "ctg1_320",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_320</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_320</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 336,683 - 337,429,\n (total: 747 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1233:disulfide isomerase/thiol-disulfide oxidase (Score: 454.8; E-value: 9.3e-139)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_320\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_320\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_320_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_320\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_320\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTAAAAAAGTCACTTTTAATGACAATGTTACCTGCCATCGCCTTCGCACAGGAGTTACCAGAAGCAGTTAAAGCAATTGAAAAACAAGGCATTACCATAATAAAACCTTTCGACGCCCCCGGCGGCATGAAAGGCTATCTGGGGAAATATCAGGATATGGGCGTCACCATCTATCTGACCCCCGATGGTAAGCATGCTATCTCCGGCTACATGTACAACGAAAAAGGTGAAAACCTGAGCAATACACTTATCGAAAAAGAAATTTATGCGCCAGCCGGACGCGAAATGTGGCAACGGATGGAACAATCGCACTGGCTCCTCGACGGTAAAAAAGACGCGCCAGTCATAGTCTACGTTTTCGCCGATCCGTTCTGTCCTTATTGCAAACAATTCTGGAAACAGACGCGCCCCTGGGTAGAGTCGGGTAAAGTACAACTAAGAACCTTACTGGTCGGCGTCATCAAACCAGAAAGTCCTGCTACAGCAGCAGCTATTCTCGCCAGTAAAGATCCCGCCAGCACCTGGAGTAAATACGAATCTTCAGAAGGTAAATTGCAACTGAATGTGACTGCTAATATTACGTCGGAGCAGATGAAAACTCTGAAAGATAATGAAAAGTTGATGGATGATCTAGGGGCCAATGTCACACCTGCAATCTATTACATGAGCAAAGACAACACTCTGCAACAAGCGGTAGGTTTGCCAGATAATAAAACGCTTAATACCATTATGGGCGAGGAATAA",
      "translation": "MLKKSLLMTMLPAIAFAQELPEAVKAIEKQGITIIKPFDAPGGMKGYLGKYQDMGVTIYLTPDGKHAISGYMYNEKGENLSNTLIEKEIYAPAGREMWQRMEQSHWLLDGKKDAPVIVYVFADPFCPYCKQFWKQTRPWVESGKVQLRTLLVGVIKPESPATAAAILASKDPASTWSKYESSEGKLQLNVTANITSEQMKTLKDNEKLMDDLGANVTPAIYYMSKDNTLQQAVGLPDNKTLNTIMGEE",
      "product": ""
     },
     {
      "start": 337802,
      "end": 338365,
      "strand": 1,
      "locus_tag": "ctg1_321",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_321</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_321</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 337,802 - 338,365,\n (total: 564 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1196:alkyl hydroperoxide reductase/ Thiol specific (Score: 179.4; E-value: 6.4e-55)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_321\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_321\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_321_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_321\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_321\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCTTGATTAACACCAAAATTAAACCTTTTAAAAACCAGGCATTCAAAAACGGCGAATTCATCGAAATCACCGAAAAAGATACCGAAGGCCGCTGGAGCGTCTTCTTCTTCTACCCGGCTGACTTTACTTTCGTATGCCCGACCGAACTGGGTGACGTTGCTGACCACTACGAAGAACTGCAGAAACTGGGCGTAGACGTATACGCAGTATCTACCGATACTCACTTCACCCACAAAGCATGGCACAGCAGCTCTGAAACTATCGCTAAAATCAAATATGCGATGATCGGCGACCCGACTGGCGCCCTGACCCGTAACTTCGAAAACATGCGTGAAGAAGAAGGTCTGGCTGACCGCGCAACCTTCGTTGTTGACCCGCAGGGTATCATCCAGGCTATCGAAGTTACCGCTGAAGGCATTGGCCGTGACGCGTCTGACCTGCTGCGTAAAATCAAAGCAGCACAGTACGTGGCTTCTCACCCAGGTGAAGTTTGCCCGGCTAAATGGAAAGAAGGTGAAGCAACTCTGGCTCCGTCTCTGGACCTGGTTGGTAAAATCTAA",
      "translation": "MSLINTKIKPFKNQAFKNGEFIEITEKDTEGRWSVFFFYPADFTFVCPTELGDVADHYEELQKLGVDVYAVSTDTHFTHKAWHSSSETIAKIKYAMIGDPTGALTRNFENMREEEGLADRATFVVDPQGIIQAIEVTAEGIGRDASDLLRKIKAAQYVASHPGEVCPAKWKEGEATLAPSLDLVGKI",
      "product": ""
     },
     {
      "start": 338506,
      "end": 340101,
      "strand": 1,
      "locus_tag": "ctg1_322",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_322</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_322</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 338,506 - 340,101,\n (total: 1596 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Pyr_redox_2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1176:alkyl hydroperoxide reductase subunit (Score: 674.9; E-value: 1.2e-204)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_322\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_322\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_322_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_322\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_322\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATGATGTTTAAAGCCCAGGAGATAAACATGCTCGACACAAATATGAAAACTCAACTCAAGGCTTACCTTGAGAAATTGACCAAGCCTGTTGAGTTAATTGCCACGCTGGATGACAGCGCTAAATCGGCAGAAATCAAGGAACTGTTGGCTGAAATCGCAGAACTGTCAGACAAAGTCACCTTTAAAGAAGATAACAGCTTGCCGGTGCGTAAGCCGTCTTTCCTGATCACTAACCCAGGTTCCAACCAGGGGCCACGTTTTGCAGGTTCCCCGCTGGGCCACGAGTTCACCTCGCTGGTACTGGCGTTGTTGTGGACCGGTGGTCATCCGTCGAAAGAAGCGCAGTCTCTGCTGGAGCAGATTCGCCATATTGACGGTGATTTTGAATTCGAAACCTATTACTCGCTCTCTTGCCACAACTGCCCGGACGTAGTGCAGGCGCTGAACCTGATGAGCGTACTGAATCCGCGTATTAAGCATACGGCAATTGACGGCGGCACCTTCCAGAACGAAATCACCGATCGCAACGTGATGGGCGTTCCGGCAGTGTTCGTAAATGGGAAAGAGTTTGGTCAGGGCCGCATGACTATTTCCGAAATCGTCGCCAAAATTGATACTGGCGCGGAAAAACGTGCGGCAGAAGAGCTGAACAAGCGTGATGCTTATGACGTATTAATCGTTGGTTCCGGCCCGGCGGGTGCAGCGGCAGCAATTTACTCCGCACGTAAAGGCATCCGTACCGGTCTGATGGGCGAACGTTTTGGTGGTCAGATCCTCGATACCGTTGATATCGAAAACTACATTTCTGTACCGAAGACCGAAGGGCAGAAGCTGGCAGGTGCGCTGAAAGTTCACGTTGATGAATACGACGTTGATGTGATCGACAGCCAGAGCGCCAGCAAACTGATTCCGGCAGCGGTTGAAGGTGGCCTGCATCAGATTGAAACAGCTTCTGGCGCGGTACTGAAAGCACGCAGCATTATCGTGGCGACCGGTGCAAAATGGCGCAACATGAATGTTCCGGGCGAAGATCAGTATCGCACCAAAGGCGTGACCTACTGCCCGCACTGCGACGGCCCGCTGTTTAAAGGCAAACGCGTAGCGGTTATCGGCGGTGGTAACTCCGGCGTGGAAGCGGCAATCGACCTGGCGGGTATCGTTGAACACGTAACTCTGCTGGAATTTGCGCCAGAAATGAAAGCAGACCAGGTTCTGCAGGACAAACTGCGCAGCCTGAAAAATGTCGACATTATTCTGAATGCGCAAACCACGGAAGTGAAAGGCGATGGTAGCAAAGTCGTAGGTCTGGAATATCGTGATCGTGTCAGCGGCGATATTCACAGCATCGAACTGGCCGGTATTTTCGTTCAGATTGGTCTGCTGCCGAACACCAACTGGCTGGAAGGCGCAGTCGAACGTAACCGCATGGGCGAGATAATCATTGATGCGAAATGCGAAACCAACGTCAAAGGCGTGTTCGCAGCGGGTGACTGTACGACGGTTCCGTACAAGCAGATCATCATCGCCACTGGCGAAGGTGCCAAAGCCTCTCTGAGTGCATTTGACTACCTGATTCGCACCAAAACTGCATAA",
      "translation": "MMMFKAQEINMLDTNMKTQLKAYLEKLTKPVELIATLDDSAKSAEIKELLAEIAELSDKVTFKEDNSLPVRKPSFLITNPGSNQGPRFAGSPLGHEFTSLVLALLWTGGHPSKEAQSLLEQIRHIDGDFEFETYYSLSCHNCPDVVQALNLMSVLNPRIKHTAIDGGTFQNEITDRNVMGVPAVFVNGKEFGQGRMTISEIVAKIDTGAEKRAAEELNKRDAYDVLIVGSGPAGAAAAIYSARKGIRTGLMGERFGGQILDTVDIENYISVPKTEGQKLAGALKVHVDEYDVDVIDSQSASKLIPAAVEGGLHQIETASGAVLKARSIIVATGAKWRNMNVPGEDQYRTKGVTYCPHCDGPLFKGKRVAVIGGGNSGVEAAIDLAGIVEHVTLLEFAPEMKADQVLQDKLRSLKNVDIILNAQTTEVKGDGSKVVGLEYRDRVSGDIHSIELAGIFVQIGLLPNTNWLEGAVERNRMGEIIIDAKCETNVKGVFAAGDCTTVPYKQIIIATGEGAKASLSAFDYLIRTKTA",
      "product": ""
     },
     {
      "start": 340223,
      "end": 340651,
      "strand": -1,
      "locus_tag": "ctg1_323",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_323</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_323</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 340,223 - 340,651,\n (total: 429 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_323\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_323\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_323\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_323\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTACAAAACAATCATTATGCCAGTTGATGTTTTTGAAATGGAGTTAAGTGACAAAGCTGTACGTCACGCTGAATTTCTCGCCCAGGATGACGGCGTAATTCATTTACTTCATGTATTACCGGGCGCTGCAAGCCTTAGTCTGCACCGTTTTGCTGCTGATGTGCGACGTTTTGAAGAGCATCTGCAACATGAAGCTGAAGAACGTCTGCAAACGATGGTCAGCCACTTCACCATCGATCCTTCCCGCATTAAACAACATGTCCGTTTTGGTAGCGTGCGAGATGAAGTCAACGAGTTAGCGAAAGAACTCGATGCAGATGTAGTGGTTATCGGTTCGCGTAATCCATCAATTTCAACCCATCTGTTAGGTTCTAACGCCTCCAGTGTGATCCGTCACGCTAATCTGCCTGTACTGGTCGTTCGCTAA",
      "translation": "MYKTIIMPVDVFEMELSDKAVRHAEFLAQDDGVIHLLHVLPGAASLSLHRFAADVRRFEEHLQHEAEERLQTMVSHFTIDPSRIKQHVRFGSVRDEVNELAKELDADVVVIGSRNPSISTHLLGSNASSVIRHANLPVLVVR",
      "product": ""
     },
     {
      "start": 340776,
      "end": 340865,
      "strand": -1,
      "locus_tag": "ctg1_324",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_324</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_324</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 340,776 - 340,865,\n (total: 90 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_324\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_324\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_324\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_324\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGTGAAGTGCTGGGTATCACTGCTTTTTTTATTTTAGTTGCAGCGATCATCGTTGCGGCAGTGTTATACCTTGAGCAACACTGGTAG",
      "translation": "MGEVLGITAFFILVAAIIVAAVLYLEQHW",
      "product": ""
     },
     {
      "start": 341010,
      "end": 341420,
      "strand": -1,
      "locus_tag": "ctg1_325",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_325</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_325</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 341,010 - 341,420,\n (total: 411 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_325\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_325\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_325\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_325\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCAGACCAACAATTATCATTAACGACCTTGATGCAGAACGCATCGATATGCTGCTGGAACAACCTGCATACGCTGGCCTGCCCATTGCCGATGCGTTAAATGCGGAACTTGACCGCGCACAGATGTGCTCGCCTGAAACCATGCCAAATGATGTGGTGACCATGAATAGTCGGGTTAAATTCCGTAATCTGAGCGATGGCGAAGTCCGTGTGCGCACGCTGGTTTATCCGGCCAAAATGACTGACAGCAACACACAACTTTCCGTAATGGCTCCTGTGGGAGCAGCCCTCCTGGGACTCCGTGTTGGTGATACCATCCACTGGGAACTGCCGGGCGGCACCTCCACGCACCTTGAAGTGCTGGAACTGGAATACCAGCCAGAAGCTGCTGGCGACTACCTGCTTTAA",
      "translation": "MSRPTIIINDLDAERIDMLLEQPAYAGLPIADALNAELDRAQMCSPETMPNDVVTMNSRVKFRNLSDGEVRVRTLVYPAKMTDSNTQLSVMAPVGAALLGLRVGDTIHWELPGGTSTHLEVLELEYQPEAAGDYLL",
      "product": ""
     },
     {
      "start": 341619,
      "end": 342425,
      "strand": -1,
      "locus_tag": "ctg1_326",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_326</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_326</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 341,619 - 342,425,\n (total: 807 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_326\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_326\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_326\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_326\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAATTACTCAGATATTCCTGCACATTATTGGCTATCTCACTGCTTCCCTTCACCTCTGCTCGTGCTGACGAACTACAGCCTAAGCAGTATGCTGATTTCGATCGCTATGTTCTGGCACTCTCCTGGCAAACAGGCTTTTGTCAAAGCCAGCATGACCGTGGGCGCAAAGAACCTGTCGAATGTCGTTTGCAAAAAGAAACCGAAGATAAATCCGCTTTCCTGACTGTTCACGGGCTTTGGCCTGGCTTGCCAAAATCAGTAGCGGCACGCGGAGTTGATGAGCGACGCTGGATGCGCTATGGCTGTGCCACTCGCCCTATTCCAAATTTTCCTGAAGTACGTGCCAGCCGGAAGTGTTCCTCTCCTGAAACTGGATTATCTCTGGAAACAGCAGCCAGACTTAGCGAAGTGATGCCCGGAGCAGGCGGGCGTTCATGCCTGGAACGCTATGAATACGCCAAACATGGGGCCTGTTTTGGCTTCGATCCGGATGCTTACTTCGAGACTATGGTACGCCTGAATAAAGAATTCAAAAGCAGTGCCGTTGGCGAGTTCCTTGTTGAAAATTACGGTAAAACCGTTTCGCGCAGTGATTTTGACGCTGCTATTGCCAAAAGCTGGGGAAGTGAAAACGTCAAAGCGGTAAAATTAAGCTGTCAGGGCAAACCGGCTTATCTGACAGAGATTCAAATCTCCCTGCGCGCCAACCAAATCAACGCCCCATTATCTGCCAGTTCCCTCCAACCGCAGCCACACCCGGGGAATTGCGGTAATCAATTTATCATTGATAAAGTGGGTTATTGA",
      "translation": "MKLLRYSCTLLAISLLPFTSARADELQPKQYADFDRYVLALSWQTGFCQSQHDRGRKEPVECRLQKETEDKSAFLTVHGLWPGLPKSVAARGVDERRWMRYGCATRPIPNFPEVRASRKCSSPETGLSLETAARLSEVMPGAGGRSCLERYEYAKHGACFGFDPDAYFETMVRLNKEFKSSAVGEFLVENYGKTVSRSDFDAAIAKSWGSENVKAVKLSCQGKPAYLTEIQISLRANQINAPLSASSLQPQPHPGNCGNQFIIDKVGY",
      "product": ""
     },
     {
      "start": 342660,
      "end": 344030,
      "strand": -1,
      "locus_tag": "ctg1_327",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_327</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_327</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 342,660 - 344,030,\n (total: 1371 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_327\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_327\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_327_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_327\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_327\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTAACTTTTATCGAACTCCTGATTGGGGTAATCGTTATAGTGGGTGTTGCCCGCTACATTATTAAGGGGTATTCCGCCACTGGCGTACTCTTTGTCGGCGGTCTGGCGTTATTGATTATTAGCGCTTTGATGGGCCACAAAGTACTGCCGTCCAGCGCCACCAGTACTGGTTACTCAGCGACTGATATCGTTGAATATATTAAGATATTACTGATGAGTCGTGGCGGCGACCTTGGCATGATGATTATGATGTTGTGCGGATTTGCTGCGTACATGACTCATATTGGTGCCAATGATATGGTTGTAAAGCTGGCTTCCAAACCATTGCAGTATATTAACTCGCCTTATTTGCTGATGATTGCAGCTTATTTTGTCGCTTGCCTGATGTCTCTTGCGGTTTCCTCTGCGACAGGGCTTGGTGTGTTGTTAATGGCGACCTTATTCCCGGTAATGGTTAACGTTGGTATCAGTCGTGGTGCGGCGGCCGCTATATGTGCCTCTCCTGCGGCAATCATTCTTTCTCCAACTTCTGGCGATGTGGTTCTGGCAGCAGAAGCCGCAGAAATGCCATTAATTGATTTTGCCTTTAAAACAACGCTGCCCATTTCTATAGCGGCAATCATTGGTATGGCGATTGCCCACTTTTTCTGGCAGCGCTATCTCGATAAGAAAGAACATATCTCCCATGAGATGCTGGACGTCAACGAAATCACCACTACGGCTCCGGCGTTTTACGCCATTCTGCCGTTTACCCCGATCATCGGTGTTCTGATTTTTGACGGCAAATGGGGGCCACAGCTGCACATCATTACCATTCTGGTTATTTGTATGTTGTTAGCTGCCGTACTGGAATTTGTTCGTGGTTTTGATACCCAGAAAGTCTTCTCCGGGCTGGAAGTGGCGTATCGCGGCATGGCAGATGCGTTTGCCAGTGTAGTAATGTTGTTGGTTGCTGCCGGGGTTTTTGCTCAAGGGTTGAGCACAATCGGCTTTATCCAGAGCTTGATTTCCATTGCCACCTCATTTGGCTCGGCAAGCATTATTCTGATGCTGGTTCTGGTAATTTTAACCATGCTGGCAGCGATGACCACCGGATCGGGTAATGCGCCGTTCTATGCTTTTGTTGAGATGATCCCCAAACTGGCCCATTCATCAGGAATCAATCCGGCTTATTTATCGATTCCTATGCTACAGGCATCCAACCTGGGACGTACCATCTCACCGGTTTCTGGCGTGGTTGTTGCAGTGGCAGGGATGGCAAAAATCTCCCCCTTCGAAGTAGTAAAACGCACTTCTGTACCGGTACTGGTGGGGTTATTGATTGTGATAATCGCCACTGAGATCCTGGTTCCTGGAGCTGCAGCCTAA",
      "translation": "MLTFIELLIGVIVIVGVARYIIKGYSATGVLFVGGLALLIISALMGHKVLPSSATSTGYSATDIVEYIKILLMSRGGDLGMMIMMLCGFAAYMTHIGANDMVVKLASKPLQYINSPYLLMIAAYFVACLMSLAVSSATGLGVLLMATLFPVMVNVGISRGAAAAICASPAAIILSPTSGDVVLAAEAAEMPLIDFAFKTTLPISIAAIIGMAIAHFFWQRYLDKKEHISHEMLDVNEITTTAPAFYAILPFTPIIGVLIFDGKWGPQLHIITILVICMLLAAVLEFVRGFDTQKVFSGLEVAYRGMADAFASVVMLLVAAGVFAQGLSTIGFIQSLISIATSFGSASIILMLVLVILTMLAAMTTGSGNAPFYAFVEMIPKLAHSSGINPAYLSIPMLQASNLGRTISPVSGVVVAVAGMAKISPFEVVKRTSVPVLVGLLIVIIATEILVPGAAA",
      "product": ""
     },
     {
      "start": 344471,
      "end": 345055,
      "strand": 1,
      "locus_tag": "ctg1_328",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_328</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_328</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 344,471 - 345,055,\n (total: 585 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_328\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_328\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_328\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_328\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTAATAACGATCTTGATAATTGCAAAAAAATATCTGACTTATCTGATAATTGTAATTGCAACACAATTATCTCTTGTTCATCAAGTTATTGCCGGAAGTCATTCTGGCTGGTGGCAAACGTTAGGTAACAACGTAGCGGAAACCTGGCAACAACCTGAACATTACGATTTATACATTCCAGCGATCACCTGGCATGCACGTTTTGCTTACGATAAAGAAAAAACGGATCGTTATAACGAACGTCCTTGGGGTGGTGGCTTTGGACAATCGCGTTGGGACGAAAAAGGTAACTGGCATGGCTTGTACATGATGGTCTTTAAAGATTCATGGAATGAATGGGAACCTATTGGCGGTTATGGCTGGGAAAGCACATGGCGTCCGTTTTCAGATGACAATTTCCATGTTGGATTGGGCTTTACCGCAGGTGTGACGATGCGGGATAACTGGAACTACATTCCACTCCCTGTGTTGTTACCTTTGGCGTCAATAGGCTATGGCCCTGCCACTTTTCAGATGACGTATATTCCCGGAACCTACAACAACGGTAATGTGTACTTTGCGTGGATGCGTTTTCAGTTCTGA",
      "translation": "MVITILIIAKKYLTYLIIVIATQLSLVHQVIAGSHSGWWQTLGNNVAETWQQPEHYDLYIPAITWHARFAYDKEKTDRYNERPWGGGFGQSRWDEKGNWHGLYMMVFKDSWNEWEPIGGYGWESTWRPFSDDNFHVGLGFTAGVTMRDNWNYIPLPVLLPLASIGYGPATFQMTYIPGTYNNGNVYFAWMRFQF",
      "product": ""
     },
     {
      "start": 345241,
      "end": 345450,
      "strand": 1,
      "locus_tag": "ctg1_329",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_329</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_329</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 345,241 - 345,450,\n (total: 210 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1255:cold-shock DNA-binding domain protein (Score: 99.5; E-value: 1.4e-30)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_329\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_329\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_329_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_329\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_329\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCTAAGATTAAAGGTAACGTTAAGTGGTTTAATGAATCCAAAGGATTCGGTTTCATTACTCCGGAAGATGGCAGCAAAGACGTGTTCGTACACTTCTCTGCAATCCAGACTAATGGTTTTAAAACTCTGGCTGAAGGTCAGCGCGTAGAGTTCGAAATCACTAACGGTGCCAAAGGCCCTTCCGCTGCAAACGTAATCGCGCTGTAA",
      "translation": "MSKIKGNVKWFNESKGFGFITPEDGSKDVFVHFSAIQTNGFKTLAEGQRVEFEITNGAKGPSAANVIAL",
      "product": ""
     },
     {
      "start": 345504,
      "end": 345887,
      "strand": -1,
      "locus_tag": "ctg1_330",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_330</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_330</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 345,504 - 345,887,\n (total: 384 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_330\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_330\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_330\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_330\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGTTACAACTTCTTTTAGCAGTTTTTATTGGCGGTGGAACAGGTAGCGTGGCGAGATGGATGTTGAGTATGCGCTTTAACCCCCTGCATCAGGCAATTCCATTAGGAACACTGGCGGCAAATTTACTTGGCGCATTCATCATCGGAATGGGCTTTGCCTGGTTCAGTCGCATGACAAATATCGATCCAGTTTGGAAGGTGCTGATCACTACGGGTTTTTGCGGTGGCCTGACAACATTCTCTACATTTTCTGCAGAGGTCGTGTTTTTGTTGCAGGAAGGGCGCTTTGGTTGGGCGATGTTAAATGTGCTGGTCAATCTGCTGGGATCGTTTGCCATGACCGCCCTGGCATTCTGGATTTTTTCTGCATCGACCGCGAATTAA",
      "translation": "MLQLLLAVFIGGGTGSVARWMLSMRFNPLHQAIPLGTLAANLLGAFIIGMGFAWFSRMTNIDPVWKVLITTGFCGGLTTFSTFSAEVVFLLQEGRFGWAMLNVLVNLLGSFAMTALAFWIFSASTAN",
      "product": ""
     },
     {
      "start": 345979,
      "end": 346767,
      "strand": 1,
      "locus_tag": "ctg1_331",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_331</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_331</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 345,979 - 346,767,\n (total: 789 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1294:Nitrilase/cyanide hydratase and apolipoprotein (Score: 178.5; E-value: 2.7e-54)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_331\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_331\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_331_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_331\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_331\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTGGTTGCCGCAGGGCAGTTTGCCGTTTCACCCGTATGGGAAAGGAACGCAGAAACATGTGTATCGTTGATGGAGCAGGCCGCCGAAAGCGATGTCTCTCTGCTAGTTTTGCCGGAGGCGTTGTTGGCTCGGGATGATCTTGATCCAGATTTGGCGGTGAAGTCCGCTCAACCTGTTGAAGGGGATTTTCTTGCACGGTTACTACGCGAGAGCAAACGTAACACGATGACTACTGTGCTGGCGATACATGTGCCTTCAGTTCCTGGCAGGGCGTTCAATATGCTGGTCGCGCTGCAAAGAGGAAAAATTATTGCCCGGTATGCCAAGTTGCATCTCTATGATGCTTTTGCCATCCAGGAATCACGCAATGTTGATGCAGGAAAATCACTACCACCATTACTGGATGTTGACGGAATGAAGGTTGGGCTGATGACGTGCTACGATTTACGCTTTCCTGAACTGGCGTTGGCCCATGCGTTGCAAGGAGCAGAAATATTGGTCCTGCCGGCAGCCTGGGTGCGTGGTGCGCTGAAAGAACATCACTGGTCCACACTGCTGGCGGCACGGGCGCTGGATACTACCTGTTACATGGTCGCTGCGGGGGAGTGTGGAACACGCAATATTGGGCAAAGCCGTATTATTGATCCTTTTGGCGTTACGCTTGCAGCCGCAGCAGAAATACCTGCATTGATTATTGCTGATATATCCGCTGAGCGCGTTCGCCAGGTCAGGGCACAATTGCCCGTTTTAGCCAACCGCCGATTTGCGCCACCGCAATTGCTGTGA",
      "translation": "MLVAAGQFAVSPVWERNAETCVSLMEQAAESDVSLLVLPEALLARDDLDPDLAVKSAQPVEGDFLARLLRESKRNTMTTVLAIHVPSVPGRAFNMLVALQRGKIIARYAKLHLYDAFAIQESRNVDAGKSLPPLLDVDGMKVGLMTCYDLRFPELALAHALQGAEILVLPAAWVRGALKEHHWSTLLAARALDTTCYMVAAGECGTRNIGQSRIIDPFGVTLAAAAEIPALIIADISAERVRQVRAQLPVLANRRFAPPQLL",
      "product": ""
     },
     {
      "start": 346896,
      "end": 347099,
      "strand": 1,
      "locus_tag": "ctg1_332",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_332</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_332</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 346,896 - 347,099,\n (total: 204 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_332\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_332\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_332\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_332\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGTGAGATTAGTATTACCAAGTTGCTGGTTGTTGCAGCACTGGTCGTCCTGTTGTTTGGTACGAAGAAGCTACGCACATTGGGCGGTGACCTCGGTGCTGCCATTAAAGGTTTCAAGAAAGCGATGAATGATGAAGACGCGGGTGCGAAGAAAGACGCAAACGGCGATCTTCCGGCAGAAAAATTAACTCATAAAGAGTAA",
      "translation": "MGEISITKLLVVAALVVLLFGTKKLRTLGGDLGAAIKGFKKAMNDEDAGAKKDANGDLPAEKLTHKE",
      "product": ""
     },
     {
      "start": 347213,
      "end": 348178,
      "strand": -1,
      "locus_tag": "ctg1_333",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_333</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_333</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 347,213 - 348,178,\n (total: 966 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF04055<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_333\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_333\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_333\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_333\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTAAACCCATTGTGATGGAACGCGGTGTTAAATACCGCGATGCCGATAAGATGGCCCTTATCCCGGTTAAAAACGTGGTAACAGAGCGCGAAGCCCTGCTACGTAAGCCGGAATGGATGAAAATCAAACTTCCAGCGGACTCCACCCGTATCCAGGGCATCAAAGCCGCAATGCGCAAAAATGGCCTGCATTCTGTCTGCGAGGAAGCTTCCTGCCCCAACCTGGCGGAATGTTTCAATCACGGAACAGCAACATTTATGATCCTCGGTGCGATTTGTACGCGCCGCTGCCCTTTCTGCGACGTAGCACATGGTCGCCCGGTTGCTCCTGATGCCAATGAACCTGTGAAACTGGCACAAACCATCGCAGATATGGCTCTACGCTATGTCGTGATTACTTCCGTGGATCGTGATGATCTGCGTGACGGCGGTGCGCAACACTTTGCCGATTGCATTACTGCTATCCGCGAAAAAAGCCCATCAATTAAAATTGAAACGCTGGTGCCTGACTTCCGTGGTCGCATGGATCGTGCGCTGGATATCCTCACCGCAACGCCACCAGACGTATTCAACCATAACCTGGAGAACGTACCACGTATCTACCGCCAGGTTCGTCCCGGGGCTGACTATAACTGGTCACTGAAGCTGCTGGAGCGCTTTAAAGAAGCACATCCTGAGATCCCAACCAAGTCTGGCTTGATGGTAGGTCTGGGTGAAACGAATGAAGAAATCATTGAAGTGATGCGTGACCTGCGTCGGCATGGTGTAACCATGTTGACTCTGGGGCAATATTTACAGCCAAGCCGTCATCACTTGCCGGTTCAGCGTTACGTTAGCCCGGACGAATTTGAAGAGATGAAAGCTGAAGCACTGGCGATGGGCTTCACCCATGCTGCTTGTGGGCCTTTTGTGCGATCTTCTTACCATGCAGATTTGCAGGCTAAAGGTATTGAAGTGAAGTAA",
      "translation": "MSKPIVMERGVKYRDADKMALIPVKNVVTEREALLRKPEWMKIKLPADSTRIQGIKAAMRKNGLHSVCEEASCPNLAECFNHGTATFMILGAICTRRCPFCDVAHGRPVAPDANEPVKLAQTIADMALRYVVITSVDRDDLRDGGAQHFADCITAIREKSPSIKIETLVPDFRGRMDRALDILTATPPDVFNHNLENVPRIYRQVRPGADYNWSLKLLERFKEAHPEIPTKSGLMVGLGETNEEIIEVMRDLRRHGVTMLTLGQYLQPSRHHLPVQRYVSPDEFEEMKAEALAMGFTHAACGPFVRSSYHADLQAKGIEVK",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 293204,
      "end": 348216,
      "tool": "",
      "neighbouring_start": 293203,
      "neighbouring_end": 348217,
      "product": "CC 1: chemical_hybrid",
      "kind": "candidatecluster",
      "prefix": "",
      "height": 0
     },
     {
      "start": 313203,
      "end": 328217,
      "tool": "rule-based-clusters",
      "neighbouring_start": 293203,
      "neighbouring_end": 348217,
      "product": "NRP-metallophore",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     },
     {
      "start": 313203,
      "end": 317085,
      "tool": "rule-based-clusters",
      "neighbouring_start": 293203,
      "neighbouring_end": 337085,
      "product": "NRPS",
      "category": "NRPS",
      "height": 4,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": [
      {
       "loc": 323646,
       "len": 15
      },
      {
       "loc": 323761,
       "len": 15
      },
      {
       "loc": 346019,
       "len": 12
      }
     ]
    },
    "type": "NRP-metallophore,NRPS",
    "products": [
     "NRP-metallophore",
     "NRPS"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS",
    "anchor": "r1c1"
   },
   {
    "start": 1788258,
    "end": 1814551,
    "idx": 2,
    "orfs": [
     {
      "start": 1789246,
      "end": 1791510,
      "strand": -1,
      "locus_tag": "ctg1_1696",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1696</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1696</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,789,246 - 1,791,510,\n (total: 2265 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1696\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1696\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1696\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1696\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAAAATTACATCTATTAGCATTTGCGTCTTATTCGGTATTTTCCCGCTAACCTTATTACCAACATTACCTGGCTTCCCTGTCATAGCGATTCTTTTTGTTACTGCATGCGTGCTGGCTTTAATTCCACGACAACCGCTGCGCTATTTGGCTCTGACTTTGCTCTTTTTTCTGTGGGGGATTCTGGCTGCCAAACAAATCACATGGCCTTCTGAAGTTTTACCGACTGCGATACAGGAAGCCCAGGTTCTTATTACTGGTACTGATCATATGACAACCCATTATGGTCAGATTACCCATCTGTCAGGGAAACGCGTATTCCCTGCGCCTGGCATTGTTTTGTATGGTCAATATCTGCCGGGTGAAGTCTGTGCAGGCCAACGCTGGTTGATGAAATTAAAAGTCCGTGCAGTGCATGGGCAACTAAATGATGGTGGTTTTGACAGCCAACGATATGCGCTGGCTCAACATCAACCTCTCACTGGGCGATTTCTTAACGCAACTGCGATAGATGCGCGTTGTAGCTTACGTGCTGAGTATCTGGCTTCGTTAACTCAGACTTTGGCTAATTATTTATGGAAACCGGTTATTTTAGGCCTGGGGATGGGAGAACGTTTATCAATCCCTCAGGAGATCAAGCGCATTATGCGTGATACCGGAACGGCCCATCTGATGGCTATTTCTGGATTGCATATTGCTTTTGCCGCAGTTCTCGCGGCAGGGATTATCCGGGGAATGCAGTTTTTATTGCCAGCCCAACGTATTTTCTGGCAAGTTCCTCTCATTGGCGGGGTAGGCTGTGCTATTTTTTATGCCTGGCTGACAGGTATGCAACCACCGGCCTTACGTACCGTTGTTGCTTTAACCGTCTGGGGAATGCTTAAAATAAGTGGCCGTCAATGGAGCGGATGGGACGTCTGGCTATGCTGCCTTGCAGCAATTTTAATAACCGATCCGATAGCGATACTTTCCGATAGTCTGTGGCTCTCCGCTTTTGCAGTTGCGGCGCTCATTTTTTGGTATCAATGGTGCCCATTGCCCTCGCTATCATTACCACGTTTACTTCGCCCTTTCGTTTCTCTGGTGCATTTGCAAATTGGTATCACGCTTTTATTGTTACCTGTTCAGATAGTTATTTTTCATGGTCTCAGTCTCAGTTCATTGATAGCCAATTTATTTGCTGTCCCGCTGGTTACTTTTATCTCTGTGCCCCTTATCCTGGCGGGTATGGTGATACACCTTACCGGACCACAAGTGCTTGAGCAGGGGCTCTGGTATTTAGCCGACTACTCACTGGCAATATTATTCCGGGCACTGGAGTTACTTCCTGGTGGTTGGGTAAATATCAGCGAGCAATGGCGATGGTTGGCATTTTCTCCGTGGCCTGGTTTGTTGATATGGCGGCTTAATGCCTGGAGAGCAGTTCCGTTTTTATGTTTATCAGGAATAATCCTTCTAAGTTGGCCGCTATGGAGAGCTCCACGTATTGATATATGGCAAGTGCATATGCTCGATGTAGGGCAGGGGCTGGCAATGGTGATTGAGCGAAACGGCAAAGCTATTCTCTATGATACGGGGCTTGCGTGGCCAGGAGGCGATAGTGGGCAACAACTCATCATTCCCTGGCTACGTTGGCATAACTTACAGCCTGAAGGCATCATTCTCAGCCACGAGCATCTTGATCATCGTGGAGGATTGGATTCTTTGTTAAAAATCTGGCCAGAAATGTGGGTCAGAAGTCCACTCGGATGGCAGAGTCATCTTCCCTGTATACGTGGTGAAACGTGGCAGTGGCAGGGACTTAATTTCTCCGCGCACTGGCCACTCAAGGTTGATTCGGAGCAGGGGAATAATCGCTCTTGTGTAGTCAAAATAGATGACGGCAAGCAGAGCATCTTGTTGACTGGCGATATCGAGGCTCCAGCTGAACAAAAAATGCTTAGTCACTATTGGCAGTACCTGGCGGCGACAATTATTCAGGTGCCCCATCATGGTAGTAATACATCCTCAACTCTGCCTTTGCTTCAACGGGTAAATGGCTCTGTCGCACTGGCATCAGCGTCGCGCTATAACGCGTGGCGTCTGCCTTCGTGGAAAGTAAAACAGCGATATCTGAAACAAGAATACCAATGGTTAGATACGCCCCATTCTGGGCAAATAACGGTCGATTTTTCTCCGCAAAGTTGGCAGATAAGCAGTATGAGGGAACAAATTTTACCGCGTTGGTATCATCAGTGGTTTGGCGTGTCAGAGGATAACGGGTAG",
      "translation": "MKITSISICVLFGIFPLTLLPTLPGFPVIAILFVTACVLALIPRQPLRYLALTLLFFLWGILAAKQITWPSEVLPTAIQEAQVLITGTDHMTTHYGQITHLSGKRVFPAPGIVLYGQYLPGEVCAGQRWLMKLKVRAVHGQLNDGGFDSQRYALAQHQPLTGRFLNATAIDARCSLRAEYLASLTQTLANYLWKPVILGLGMGERLSIPQEIKRIMRDTGTAHLMAISGLHIAFAAVLAAGIIRGMQFLLPAQRIFWQVPLIGGVGCAIFYAWLTGMQPPALRTVVALTVWGMLKISGRQWSGWDVWLCCLAAILITDPIAILSDSLWLSAFAVAALIFWYQWCPLPSLSLPRLLRPFVSLVHLQIGITLLLLPVQIVIFHGLSLSSLIANLFAVPLVTFISVPLILAGMVIHLTGPQVLEQGLWYLADYSLAILFRALELLPGGWVNISEQWRWLAFSPWPGLLIWRLNAWRAVPFLCLSGIILLSWPLWRAPRIDIWQVHMLDVGQGLAMVIERNGKAILYDTGLAWPGGDSGQQLIIPWLRWHNLQPEGIILSHEHLDHRGGLDSLLKIWPEMWVRSPLGWQSHLPCIRGETWQWQGLNFSAHWPLKVDSEQGNNRSCVVKIDDGKQSILLTGDIEAPAEQKMLSHYWQYLAATIIQVPHHGSNTSSTLPLLQRVNGSVALASASRYNAWRLPSWKVKQRYLKQEYQWLDTPHSGQITVDFSPQSWQISSMREQILPRWYHQWFGVSEDNG",
      "product": ""
     },
     {
      "start": 1791713,
      "end": 1791997,
      "strand": -1,
      "locus_tag": "ctg1_1697",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1697</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1697</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,791,713 - 1,791,997,\n (total: 285 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1132:DNA-binding protein HU 1 (Score: 105.9; E-value: 1.7e-32)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1697\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1697\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region2/ctg1_1697_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1697\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1697\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCAAGTCAGAATTGATTGAAAGACTTGCAACCCAGCAATCGCATATTCCTGCCAAAGTGGTTGAAGATGCCGTTAAAGAGATGCTGGAGCATATGGCCTCGACTCTTGCGCAGGGCGAGCGTATTGAAATCCGCGGTTTCGGCAGTTTCTCTTTGCACTACCGCGCACCTCGCACCGGACGTAACCCAAAAACTGGTGATAAAGTTGAACTTGAAGGCAAATATGTGCCGCACTTTAAGCCAGGTAAAGAACTGCGCGATCGCGCCAATATTTACGGTTGA",
      "translation": "MTKSELIERLATQQSHIPAKVVEDAVKEMLEHMASTLAQGERIEIRGFGSFSLHYRAPRTGRNPKTGDKVELEGKYVPHFKPGKELRDRANIYG",
      "product": ""
     },
     {
      "start": 1792157,
      "end": 1793830,
      "strand": -1,
      "locus_tag": "ctg1_1698",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1698</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1698</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,792,157 - 1,793,830,\n (total: 1674 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1698\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1698\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region2/ctg1_1698_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1698\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1698\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTGAATCTTTTGCTCAACTCTTTGAAGAGTCCTTAAAAGAAATCGAAACCCGCCCGGGTTCTATCGTTCGTGGTGTTGTTGTTGCTATCGACAAAGACGTAGTACTGGTTGACGCTGGTCTGAAATCTGAGTCTGCCATTCCGGCTGAGCAGTTCAAAAACGCCCAGGGCGAAATTGAAATCCAGGTTGGTGACGAAGTTGACGTTGCTCTGGATGCAGTAGAAGACGGTTTCGGTGAAACCCTGCTGTCTCGTGAGAAAGCAAAACGTCACGAAGCGTGGCTGATGCTGGAAAAAGCTTACGAAGAAGCAGCAACCGTTACTGGTGTAATCAATGGCAAAGTCAAGGGCGGCTTCACTGTTGAGCTGAACGGTATTCGTGCGTTCCTGCCAGGTTCTCTGGTAGACGTTCGTCCGGTTCGTGACACCCTGCACCTGGAAGGCAAAGAGCTTGAATTCAAAGTAATCAAGCTGGACCAGAAGCGTAACAACGTTGTTGTTTCTCGTCGTGCTGTTATTGAGTCTGAAAACAGTGCAGAACGCGATCAGCTGCTGGAAAACCTGCAGGAAGGCATGGAAGTTAAAGGTATCGTTAAGAACCTCACTGACTACGGTGCATTCGTTGATCTGGGTGGTGTTGACGGTCTGCTGCACATCACCGACATGGCGTGGAAACGCGTTAAACATCCGAGCGAAATCGTAAACGTTGGCGACGAAATCACTGTTAAAGTGCTGAAGTTCGACCGCGAACGTACCCGTGTATCTCTGGGCCTGAAACAACTGGGCGAAGATCCGTGGGTAGCTATCGCTAAACGTTATCCGGAAGGTACCAAACTGACCGGTCGCGTGACCAACCTGACCGACTACGGCTGCTTCGTTGAAATCGAAGAAGGCGTTGAAGGCCTGGTACACGTTTCCGAAATGGATTGGACCAACAAAAACATCCACCCGTCCAAAGTTGTTAACGTTGGCGATGTAGTGGAAGTGATGGTTCTGGATATCGACGAAGAACGTCGTCGTATCTCCCTGGGTCTGAAGCAGTGCAAATCTAACCCATGGCAGCAGTTCGCGGAAACCCACAACAAGGGCGACCGTGTTGAAGGTAAAATCAAGTCTATCACTGACTTCGGTATCTTCATCGGGCTGGACGGCGGTATCGACGGCCTGGTTCACCTGTCTGACATCTCCTGGAACGTTGCAGGCGAAGAAGCAGTTCGTGAATACAAAAAAGGCGACGAAATCGCAGCAGTTGTACTGCAGGTTGATGCAGAACGTGAACGTATCTCCCTGGGCGTTAAGCAGCTCGCAGAAGATCCGTTCAACAACTGGGTTGCTCTGAACAAGAAAGGCGCTATCGTGACCGGTAAAGTAACTGCAGTTGACGCTAAAGGCGCAACCGTAGAACTGGCTGACGGCGTTGAAGGTTACCTGCGTGCTTCTGAAGCATCCCGTGACCGCGTTGAAGACGCTACCCTGGTTCTGAGCGTTGGCGACGAAGTTGAAGCTAAATTCACCGGCGTTGATCGTAAAAACCGCGCAATCAGCCTGTCTGTTCGTGCGAAAGACGAAGCTGACGAGAAAGATGCAATCGCAACTGTTAACAAACAGGAAGATGCAAACTTCTCTAACAATGCAATGGCTGAAGCTTTCAAAGCAGCTAAAGGCGAGTAA",
      "translation": "MTESFAQLFEESLKEIETRPGSIVRGVVVAIDKDVVLVDAGLKSESAIPAEQFKNAQGEIEIQVGDEVDVALDAVEDGFGETLLSREKAKRHEAWLMLEKAYEEAATVTGVINGKVKGGFTVELNGIRAFLPGSLVDVRPVRDTLHLEGKELEFKVIKLDQKRNNVVVSRRAVIESENSAERDQLLENLQEGMEVKGIVKNLTDYGAFVDLGGVDGLLHITDMAWKRVKHPSEIVNVGDEITVKVLKFDRERTRVSLGLKQLGEDPWVAIAKRYPEGTKLTGRVTNLTDYGCFVEIEEGVEGLVHVSEMDWTNKNIHPSKVVNVGDVVEVMVLDIDEERRRISLGLKQCKSNPWQQFAETHNKGDRVEGKIKSITDFGIFIGLDGGIDGLVHLSDISWNVAGEEAVREYKKGDEIAAVVLQVDAERERISLGVKQLAEDPFNNWVALNKKGAIVTGKVTAVDAKGATVELADGVEGYLRASEASRDRVEDATLVLSVGDEVEAKFTGVDRKNRAISLSVRAKDEADEKDAIATVNKQEDANFSNNAMAEAFKAAKGE",
      "product": ""
     },
     {
      "start": 1793941,
      "end": 1794624,
      "strand": -1,
      "locus_tag": "ctg1_1699",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1699</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1699</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,793,941 - 1,794,624,\n (total: 684 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1699\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1699\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1699\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1699\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGGCAATTGCCCCGGTAATTACCATTGATGGCCCAAGCGGTGCAGGAAAAGGCACCTTGTGCAAGGCAATGGCGGAAGCATTGCAATGGCATCTGTTGGATTCAGGAGCGATCTATCGTGTACTGGCATTGGCTGCCTTACATCACCATGTCGATGTTGCATCGGAAGACGCACTGGTACCGCTGGCTTCCCATCTTGATGTGCGCTTTATTTCAACTAACGGCAATCTGGAAGTTATCCTCGAAGGAGAAGACGTCAGCGGAGAAATCAGAACACAAGAAGTGGCGAATGCAGCATCACAAGTTGCTGCTTTTCCTCGTGTTCGTGAAGCTTTATTGCGTCGTCAGCGCGCGTTTCGCGAACTGCCCGGACTGATTGCCGACGGGCGTGACATGGGAACGGTGGTTTTTCCTGATGCGCCAGTAAAAATATTCCTTGATGCCTCCTCTGAAGAACGCGCGCATCGTCGCATGCTACAGTTGCAGGAGAAAGGCTTTAGTGTTAACTTTGAACGCCTTTTGGCCGAGATCAAAGAGCGTGATGACCGTGATCGTAATCGAGCGGTAGCCCCTCTGGTTCCGGCGGCTGATGCTTTAGTGTTAGATTCAACCACCTTAAGCATTGAGCAAGTGATTGAAAAAGCGTTACAATACGCGCGCCAAAAACTGGCTCTCGCATAA",
      "translation": "MTAIAPVITIDGPSGAGKGTLCKAMAEALQWHLLDSGAIYRVLALAALHHHVDVASEDALVPLASHLDVRFISTNGNLEVILEGEDVSGEIRTQEVANAASQVAAFPRVREALLRRQRAFRELPGLIADGRDMGTVVFPDAPVKIFLDASSEERAHRRMLQLQEKGFSVNFERLLAEIKERDDRDRNRAVAPLVPAADALVLDSTTLSIEQVIEKALQYARQKLALA",
      "product": ""
     },
     {
      "start": 1794811,
      "end": 1796088,
      "strand": -1,
      "locus_tag": "ctg1_1700",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1700</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1700</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,794,811 - 1,796,088,\n (total: 1278 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1700\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1700\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region2/ctg1_1700_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1700\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1700\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAATCCCTGACGTTACAACCCATCGCCCGTGTCGATGGCACTATTAATCTGCCCGGTTCCAAGAGCGTTTCTAACCGCGCTTTATTGCTGGCGGCTTTGGCACACGGTAAAACAGTATTAACTAATCTGCTGGATAGCGATGATGTTCGCCATATGCTTAATGCGTTAAAGGCATTAGGGGTAAGCTATTCGCTTTCTACCGATCGTACACGTTGCGAGATCATCGGTAACGGAGGTCCATTACACGCAGAGAGTGCACTGGAGTTGTTCCTCGGTAATGCCGGAACGGCAATGCGTCCGCTGGCGGCAGCTCTTTGTCTGGGTAGCAATGATATTGTTCTGACCGGTGAACCGCGCATGAAAGAACGGCCGATTGGTCATCTTGTAGATGCGTTGCGCCAGGGCGGAGCGGGAATCACTTACCTGGAGCAAGAAAACTATCCACCGCTGCGTTTACAGGGCGGCTTTACTGGTGGCAACGTTGACGTTGATGGTTCCGTTTCCAGTCAATTCCTCACCGCACTATTAATGACTGCGCCGCTTGCGCCGGAAGATACAGTTATTCGTATTAAAGGTGATCTGGTTTCTAAACCTTATATCGATATCACCCTCAACCTGATGAAAACGTTTGGTGTTGAAGTTGAAAATCAGCGCTATCAACAATTTGTGGTGAAAGGTGGTCAATCTTATCAGTCACCGGGCAGCTATTTAGTGGAAGGGGATGCATCTTCGGCTTCTTACTTTCTTGCTGCGGCAGCGATCAAAGGTGGTACGGTAAAAGTGACGGGCATTGGACGCAATAGTATGCAAGGCGATATTCACTTTGCTGACGTACTGGAAAAAATGGGCGCGACCATTAGCTGGGGCGACGATTATATATCCTGCACACGCGGTGAACTGAACGGCATTGATATGGATATGAACCATATTCCCGATGCGGCGATGACCATTGCCACGACGGCGTTATTTGCAAAAGGCACCACCACGCTGCGCAATATCTATAACTGGCGTGTTAAAGAGACTGATCGCCTGTTTGCGATGGCAACAGAACTGCGTAAAGTCGGTGCGGAAGTAGAAGAGGGGCACGATTTTATTCGTATCACTCCACTGGAAAAACTGAAATTTGCCGAGATCGCGACTTATAACGATCACCGAATGGCGATGTGTTTTTCGCTTGTCGCCTTGTCAGATACGGCAGTGACAATTTTGGATCCTAAATGTACCGCCAAAACGTTCCCGGACTATTTTGAGCAGTTGGCTCGCATTAGTGCATAA",
      "translation": "MESLTLQPIARVDGTINLPGSKSVSNRALLLAALAHGKTVLTNLLDSDDVRHMLNALKALGVSYSLSTDRTRCEIIGNGGPLHAESALELFLGNAGTAMRPLAAALCLGSNDIVLTGEPRMKERPIGHLVDALRQGGAGITYLEQENYPPLRLQGGFTGGNVDVDGSVSSQFLTALLMTAPLAPEDTVIRIKGDLVSKPYIDITLNLMKTFGVEVENQRYQQFVVKGGQSYQSPGSYLVEGDASSASYFLAAAAIKGGTVKVTGIGRNSMQGDIHFADVLEKMGATISWGDDYISCTRGELNGIDMDMNHIPDAAMTIATTALFAKGTTTLRNIYNWRVKETDRLFAMATELRKVGAEVEEGHDFIRITPLEKLKFAEIATYNDHRMAMCFSLVALSDTAVTILDPKCTAKTFPDYFEQLARISA",
      "product": ""
     },
     {
      "start": 1796158,
      "end": 1797246,
      "strand": -1,
      "locus_tag": "ctg1_1701",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1701</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1701</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,796,158 - 1,797,246,\n (total: 1089 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_5<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1701\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1701\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1701\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1701\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTCAGGTATTCAATTTTAGTTCAGGCCCGGCAATGCTTCCGGCAGATGTGCTCAAGCAGGCGCAACAAGAGTTGTGTGACTGGAATGGTCTTGGTACATCCGTTATGGAAATTAGCCACCGTGGCAAAGAATTTATCAAAGTCGCAGAAGAAGCAGAGCACGATTTCCGCGAGCTGTTAAACGTTCCTTCAAACTATAAAGTACTCTTTTGCCATGGTGGTGGCCGTGGGCAATTTGCGGCGGTGCCACTGAATATACTTGGTGATAAGACTACCGCAGATTATGTTGATGCGGGCTACTGGGCGGCAAGCGCTATCAAAGAAGCGAAAAAATATTGCACGCCAAATGTGTTTGACGCCAAAGTAACCGTTGACGGTCTGCGCGCGGTGAAGCCAATGCGTGAATGGCAACTTTCTGATAACGCAGCTTACCTGCACTATTGCCCGAATGAAACTATTGATGGTATCGCCATTGACGAAACGCCAGACTTCGGTAACGAAGTGGTTGTCGCTGCCGATTTCTCATCAACCATTCTTTCTCGTCCAATCGATGTGAGCCGTTACGGCGTGATCTATGCTGGCGCGCAGAAAAATATCGGCCCAGCTGGTCTGACAATTGTCATTGTGCGTGAAGACTTGCTGGGTAAAGCGAATATCGCGTGTCCGTCGATTCTGGATTATTCCATCCTCAACGATAACGACTCTATGTTTAACACGCCGCCGACGTTTGCCTGGTACTTATCTGGCCTGGTCTTCAAATGGCTGAAAGCGAATGGTGGGGTGGCTGCAATGGATAAAATCAATCAGCAGAAAGCGGAGCTGCTTTACGGCGCCATTGATAACAGCGATTTTTACCGTAATGACGTAGCGAAAGCTAACCGTTCTCGGATGAACGTGCCGTTCCAGTTGGCGGACAATGCTCTCGATAAACTGTTCCTCGAAGAGTCTTTCGCTGCGGGGCTGCATGCGCTGAAAGGGCATCGCGTGGTCGGCGGTATGCGTGCGTCAATTTATAACGCAATGCCTCTGGAAGGTGTCATAGCCCTGACTGATTTTATGGCTGATTTCGAACGTCGCCACGGTTAA",
      "translation": "MAQVFNFSSGPAMLPADVLKQAQQELCDWNGLGTSVMEISHRGKEFIKVAEEAEHDFRELLNVPSNYKVLFCHGGGRGQFAAVPLNILGDKTTADYVDAGYWAASAIKEAKKYCTPNVFDAKVTVDGLRAVKPMREWQLSDNAAYLHYCPNETIDGIAIDETPDFGNEVVVAADFSSTILSRPIDVSRYGVIYAGAQKNIGPAGLTIVIVREDLLGKANIACPSILDYSILNDNDSMFNTPPTFAWYLSGLVFKWLKANGGVAAMDKINQQKAELLYGAIDNSDFYRNDVAKANRSRMNVPFQLADNALDKLFLEESFAAGLHALKGHRVVGGMRASIYNAMPLEGVIALTDFMADFERRHG",
      "product": ""
     },
     {
      "start": 1797436,
      "end": 1798128,
      "strand": -1,
      "locus_tag": "ctg1_1702",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1702</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1702</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,797,436 - 1,798,128,\n (total: 693 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1702\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1702\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1702\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1702\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGGCGTTCGATCTCCACCGTATGGCATTTGATAAAGTGCCTTTTGATTTCCTTGGCGAAGTTGCACTACGTAGTCTTTATACCTTTGTACTGGTCTTTTTATTCCTCAAAATGACCGGAAGACGCGGTGTGCGGCAGATGTCGCTTTTTGAAGTGTTAATCATTCTGACGCTGGGGTCAGCGGCGGGAGATGTGGCGTTTTATGATGATGTGCCGATGGTCCCGGTACTTATCGTCTTTATTACTCTGGCGTTGTTATACCGCCTGGTAATGTGGTTGATGGCGCACAGTGAGAAACTGGAAGATCTTCTGGAAGGCAAACCGGTTGTCATTATTGAAGATGGCGAACTGGCCTGGTCGAAACTCAATAACTCCAACATGACGGAATTTGAGTTTTTTATGGAACTGCGACTCCGGGGTGTGGAACAACTGGGGCAGGTCCGCCTGGCTATACTCGAAACCAACGGGCAAATCAGTGTCTATTTCTTTGAAGATGACAAGGTGAAACCGGGTTTACTTATTTTACCCAGTGATTGTACTCAGCGTTACAAAGTGGTACCGGAGTCGGCGGACTATGCCTGCATCCGTTGCAGTGAAATCATTCATATGAACGCGGGGGAAAAACAATTATGTCCGCGCTGTGCAAATCCAGAATGGACGAAGGCAAGCCGGGCGAAACGGGTGACCTGA",
      "translation": "MKAFDLHRMAFDKVPFDFLGEVALRSLYTFVLVFLFLKMTGRRGVRQMSLFEVLIILTLGSAAGDVAFYDDVPMVPVLIVFITLALLYRLVMWLMAHSEKLEDLLEGKPVVIIEDGELAWSKLNNSNMTEFEFFMELRLRGVEQLGQVRLAILETNGQISVYFFEDDKVKPGLLILPSDCTQRYKVVPESADYACIRCSEIIHMNAGEKQLCPRCANPEWTKASRAKRVT",
      "product": ""
     },
     {
      "start": 1798258,
      "end": 1800018,
      "strand": 1,
      "locus_tag": "ctg1_1703",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1703</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1703</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,798,258 - 1,800,018,\n (total: 1761 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) thiopeptide: YcaO<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1703\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1703\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region2/ctg1_1703_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1703\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1703\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGCAAACATTTATCCCCGGCAAAGATGCCGCTCTGGAAGATTCCATCGCTCGCTTCCAGCAAAAACTTTCAGACCTCGGTTTTCAGATTGAAGAGGCCTCCTGGCTGAATCCCGTGCCTAACGTCTGGTCTGTACATATTCGTGACAAAGAGTGCGCACTGTGTTTTACCAACGGTAAAGGCGCAACCAAAAAAGCGGCGCTGGCATCCGCCCTCGGTGAATATTTCGAGCGTCTCTCAACCAACTACTTTTTTGCTGACTTCTGGCTGGGCGAAACCATCGCCAACGGTCCGTTCGTGCATTATCCCAACGAAAAATGGTTCCCACTGACCGAAAACGACGATGTGCCGGAAGGACTGCTCGATGACCGTCTGCGCGCGTTTTACGACCCTGAAAATGAACTGACCGGCAGCATGCTGATTGACCTGCAATCCGGTAACGAAGATCGTGGTATTTGCGGTCTGCCATTTACGCGCCAGTCCGACAATCAGACCGTTTATATTCCGATGAATATCATTGGTAACTTGTACGTTTCTAACGGTATGTCCGCTGGCAATACCCGCAACGAAGCACGCGTTCAAGGGTTGTCCGAAGTTTTCGAACGCTACGTGAAAAACCGCATTATTGCTGAAAGCATCAGCTTGCCGGAAATCCCGGCAGACGTGCTGGCACGTTACCCTGCAGTAGTTGAAGCAATCGAAACACTGGAAGCGGAAGGTTTCCCAATCTTTGCTTATGATGGTTCGCTTGGCGGCCAGTATCCAGTGATTTGCGTGGTACTGTTCAATCCGGCTAACGGCACTTGCTTTGCCTCTTTCGGTGCGCATCCTGATTTTGGCGTAGCACTGGAACGTACCGTGACCGAGCTGCTGCAAGGTCGTGGCCTGAAAGATTTGGATGTGTTTACTCCGCCAACCTTCGATGATGAAGAAGTTGCTGAACATACCAACCTTGAAACGCACTTTATCGATTCCAGCGGTTTAATCTCCTGGGACCTGTTCAAGCAGGATGCCGATTATCCGTTTGTGGACTGGAATTTCTCCGGCACCACGGAAGAAGAGTTTGCCACGCTGATGGCTATCTTCAACAACGAAGATAAAGAAGTTTATATTGCCGATTACGAGCATCTGGGCGTTTATGCTTGTCGTATTATCGTGCCTGGCATGTCCGATATTTATCCGGCTGAAGATTTGTGGTTAGCGAATAACAGCATGGGCAGCCATTTACGTGAAACGATTCTTTCACTCCCAGGCAGCGAGTGGGAAAAAGAAGATTACCTGAACCTCATCGAGCAACTGGATGAAGAAGGTTTTGATGACTTTACCCGCGTGCGTGAGCTATTGGGTCTGGCAACCGGGCCGGATAACGGCTGGTACACTCTGCGTATCGGTGAATTAAAGGCTATGCTGGCGCTGGCTGGTGGCGATCTGGAACAGGCTCTGGTCTGGACCGAATGGACGATGGAGTTTAACTCATCGGTCTTCAGCCCGGAACGCGCAAACTATTATCGCTGCCTGCAAACCCTCCTGCTGCTGGCTCAGGAAGAAGATCGCCAGCCACTGCAATATCTGAATGCTTTTATCCGCATGTACGGCGCGGAGGCGGTAGAAGCCGCCAGTGCGGCAATGAGTGGCGAAGCGGCGTTTTACGGCCTGCAACCGGTAGATAGCGATCTGCACGCATTCGCCGCACATCAGTCGCTGCTGAAGGCCTATGAAAAGCTGCAACGCGCCAAAGCGACATTCTGGACAAAATGA",
      "translation": "MTQTFIPGKDAALEDSIARFQQKLSDLGFQIEEASWLNPVPNVWSVHIRDKECALCFTNGKGATKKAALASALGEYFERLSTNYFFADFWLGETIANGPFVHYPNEKWFPLTENDDVPEGLLDDRLRAFYDPENELTGSMLIDLQSGNEDRGICGLPFTRQSDNQTVYIPMNIIGNLYVSNGMSAGNTRNEARVQGLSEVFERYVKNRIIAESISLPEIPADVLARYPAVVEAIETLEAEGFPIFAYDGSLGGQYPVICVVLFNPANGTCFASFGAHPDFGVALERTVTELLQGRGLKDLDVFTPPTFDDEEVAEHTNLETHFIDSSGLISWDLFKQDADYPFVDWNFSGTTEEEFATLMAIFNNEDKEVYIADYEHLGVYACRIIVPGMSDIYPAEDLWLANNSMGSHLRETILSLPGSEWEKEDYLNLIEQLDEEGFDDFTRVRELLGLATGPDNGWYTLRIGELKAMLALAGGDLEQALVWTEWTMEFNSSVFSPERANYYRCLQTLLLLAQEEDRQPLQYLNAFIRMYGAEAVEAASAAMSGEAAFYGLQPVDSDLHAFAAHQSLLKAYEKLQRAKATFWTK",
      "product": ""
     },
     {
      "start": 1800423,
      "end": 1801280,
      "strand": 1,
      "locus_tag": "ctg1_1704",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1704</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1704</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,800,423 - 1,801,280,\n (total: 858 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1704\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1704\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1704\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1704\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAAAGCTGACAACCCTTTTGATCTTATTCTTCCTGCTGCGATGGCCAAAGTTGCCGAAGAAGCAGGTGTCTATAAAGCAACGAAACATCCGCTTAAGACTTTCTATCTGGCGATTACCGCTGGTGTATTCATCTCTATCGCTTTTGTTTTCTATATCACTGCAACAACAGGTGCTGGTGCGATGCCATATGGCATGGCAAAACTGGTTGGCGGTATCTGCTTCTCTCTGGGCCTCATTCTTTGTGTTGTTTGTGGTGCTGATCTCTTTACTTCAACAGTTCTGATTGTTGTTGCTAAAGCCAGTGGACGCATCACCTGGGGGCAACTGGCGAAGAACTGGCTTAATGTCTATTTTGGTAACCTGATCGGTGCATTACTGTTTGTTCTGCTGATGTGGCTTTCCGGCGAATATATGACTGCGAATGGTCAGTGGGGACTTAACGTCCTGCAAACAGCCGATCATAAAATGCACCATACTTTTATTGAAGCTGTTGCCCTCGGTATCCTGGCAAACCTGATGGTCTGTCTGGCTGTGTGGATGAGCTACTCTGGCCGTAGCCTGATGGACAAATCGTTTATCATGATTCTTCCTGTCGCCATGTTCGTAGCCAGTGGATTCGAACACAGCATCGCAAACATGTTTATGATCCCAATGGGTATCGTAATTCGTGACTTTGCATCACCGGAATTCTGGACCGCTATCGGTTCTTCTCCGGAAAATTTTTCTCACCTGACCGTGATGGGCTTCATCACTGATAACCTGATTCCGGTTACGATCGGTAACATTATTGGCGGTGGTTTGTTGGTTGGGTTGACATACTGGGTCATTTATCTGCGTGATAACGATCATCACTAA",
      "translation": "MKADNPFDLILPAAMAKVAEEAGVYKATKHPLKTFYLAITAGVFISIAFVFYITATTGAGAMPYGMAKLVGGICFSLGLILCVVCGADLFTSTVLIVVAKASGRITWGQLAKNWLNVYFGNLIGALLFVLLMWLSGEYMTANGQWGLNVLQTADHKMHHTFIEAVALGILANLMVCLAVWMSYSGRSLMDKSFIMILPVAMFVASGFEHSIANMFMIPMGIVIRDFASPEFWTAIGSSPENFSHLTVMGFITDNLIPVTIGNIIGGGLLVGLTYWVIYLRDNDHH",
      "product": ""
     },
     {
      "start": 1801336,
      "end": 1803618,
      "strand": 1,
      "locus_tag": "ctg1_1705",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1705</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1705</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,801,336 - 1,803,618,\n (total: 2283 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1705\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1705\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1705\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1705\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCGAGCTTAATGAAAAGTTAGCCACAGCCTGGGAAGGTTTTACCAAAGGTGACTGGCAGAATGAAGTAAACGTCCGTGACTTCATCCAGAAAAACTACACTCCGTACGAGGGTGACGAGTCCTTCCTGGCTGGCGCTACTGACGCGACCACTACCCTGTGGGACAAAGTAATGGAAGGCGTTAAACTGGAAAACCGCACTCACGCGCCAGTTGACTTTGACACCGCTGTTGCTTCCACCATCACTTCCCACGACGCTGGCTACATCAACAAAGCGCTGGAAAAAATTGTTGGTCTGCAGACTGAAGCTCCGCTGAAACGTGCTCTTATCCCGTTCGGTGGTATCAAAATGATCGAAGGTTCCTGCAAAGCGTACAACCGCGAACTGGACCCGATGATCAAAAAAATCTTCACTGAATACCGTAAAACTCACAACCAGGGCGTGTTCGACGTTTATACTCCGGACATCCTGCGTTGCCGTAAATCCGGGGTTCTGACCGGTTTGCCAGATGCTTATGGTCGTGGCCGTATCATTGGTGACTACCGTCGCGTTGCGCTGTACGGTATCGACTACCTGATGAAAGACAAATACGCTCAGTTCACCTCTCTGCAGGCAGATCTGGAAAATGGCGTAAATCTGGAAGCAACTATCCGTCTGCGTGAAGAAATTGCTGAACAGCACCGCGCTCTGGGTCAGATGAAAGAAATGGCTGCCAAATACGGCTACGACATTTCTGGTCCGGCAACCAACGCTCAGGAAGCTATCCAGTGGACTTACTTCGGCTACCTGGCTGCTGTTAAGTCTCAGAACGGTGCTGCAATGTCCTTCGGTCGTACCTCCACCTTCCTGGATGTGTACATCGAACGTGACCTGAAAGCTGGCAAGATCACCGAACAAGAAGCGCAGGAAATGGTTGACCACCTGGTCATGAAACTGCGTATGGTTCGCTTCCTGCGTACCCCGGAATACGATGAACTGTTCTCTGGCGACCCGATCTGGGCAACCGAATCTATCGGTGGTATGGGCCTCGACGGTCGTACCCTGGTTACCAAAAACAGCTTCCGTTTCCTGAACACCCTGTACACCATGGGTCCGTCTCCGGAACCGAACATGACCATTCTGTGGTCTGAAAAACTGCCGCTGAACTTCAAGAAATTCGCTGCTAAAGTGTCCATCGACACCTCTTCTCTGCAGTATGAGAACGATGACCTGATGCGTCCGGACTTCAACAACGATGACTACGCTATCGCTTGCTGCGTAAGCCCGATGATCGTTGGTAAACAAATGCAGTTCTTCGGTGCGCGTGCAAACCTGGCGAAAACCATGCTGTACGCAATCAACGGCGGCGTTGACGAAAAACTGAAAATGCAGGTTGGTCCGAAATCTGAACCGATCAAAGGCGACGTCCTGAACTACGATGAAGTGATGGAGCGCATGGATCACTTCATGGACTGGCTGGCTAAACAGTACATCACTGCACTGAACATCATCCACTACATGCACGACAAGTACAGCTACGAAGCCTCTCTGATGGCGCTGCACGACCGTGACGTTATCCGCACCATGGCGTGTGGTATCGCTGGTCTGTCCGTTGCTGCTGACTCCCTGTCTGCAATCAAATATGCGAAAGTTAAACCGATTCGTGACGAAGACGGTCTGGCTATCGACTTCGAAATCGAAGGCGAATACCCGCAGTTTGGTAACAACGATCCGCGTGTAGATGACCTGGCTGTTGACCTGGTAGAACGTTTCATGAAGAAAATTCAGAAACTGCACACCTACCGTGACGCAATCCCGACTCAGTCTGTTCTGACCATCACTTCTAACGTTGTGTATGGTAAGAAAACTGGTAACACCCCAGACGGTCGTCGTGCTGGCGCGCCGTTCGGACCGGGTGCTAACCCGATGCACGGTCGTGACCAGAAAGGTGCTGTAGCGTCTCTGACTTCCGTTGCTAAACTGCCGTTCGCTTACGCTAAAGATGGTATCTCCTACACCTTCTCTATCGTTCCGAACGCACTGGGTAAAGACGACGAAGTTCGTAAGACCAACCTGGCTGGTCTGATGGATGGTTACTTCCACCACGAAGCATCCATCGAAGGTGGTCAGCACCTGAACGTTAACGTGATGAACCGTGAAATGCTGCTCGACGCGATGGAAAATCCGGAAAAATATCCGCAGCTGACCATCCGTGTATCTGGCTACGCAGTACGTTTCAACTCGCTGACTAAAGAACAGCAGCAGGACGTAATTACCCGTACCTTCACTCAAACCATGTAA",
      "translation": "MSELNEKLATAWEGFTKGDWQNEVNVRDFIQKNYTPYEGDESFLAGATDATTTLWDKVMEGVKLENRTHAPVDFDTAVASTITSHDAGYINKALEKIVGLQTEAPLKRALIPFGGIKMIEGSCKAYNRELDPMIKKIFTEYRKTHNQGVFDVYTPDILRCRKSGVLTGLPDAYGRGRIIGDYRRVALYGIDYLMKDKYAQFTSLQADLENGVNLEATIRLREEIAEQHRALGQMKEMAAKYGYDISGPATNAQEAIQWTYFGYLAAVKSQNGAAMSFGRTSTFLDVYIERDLKAGKITEQEAQEMVDHLVMKLRMVRFLRTPEYDELFSGDPIWATESIGGMGLDGRTLVTKNSFRFLNTLYTMGPSPEPNMTILWSEKLPLNFKKFAAKVSIDTSSLQYENDDLMRPDFNNDDYAIACCVSPMIVGKQMQFFGARANLAKTMLYAINGGVDEKLKMQVGPKSEPIKGDVLNYDEVMERMDHFMDWLAKQYITALNIIHYMHDKYSYEASLMALHDRDVIRTMACGIAGLSVAADSLSAIKYAKVKPIRDEDGLAIDFEIEGEYPQFGNNDPRVDDLAVDLVERFMKKIQKLHTYRDAIPTQSVLTITSNVVYGKKTGNTPDGRRAGAPFGPGANPMHGRDQKGAVASLTSVAKLPFAYAKDGISYTFSIVPNALGKDDEVRKTNLAGLMDGYFHHEASIEGGQHLNVNVMNREMLLDAMENPEKYPQLTIRVSGYAVRFNSLTKEQQQDVITRTFTQTM",
      "product": ""
     },
     {
      "start": 1803811,
      "end": 1804551,
      "strand": 1,
      "locus_tag": "ctg1_1706",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1706</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1706</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,803,811 - 1,804,551,\n (total: 741 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) thiopeptide: PF04055<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1706\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1706\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1706\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1706\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCAGTTATTGGTCGCATTCACTCCTTTGAATCCTGTGGAACCGTAGACGGCCCAGGTATTCGCTTTATTACTTTTTTCCAGGGCTGCCTGATGCGCTGCCTGTATTGTCATAACCGCGACACTTGGGACACGCATGGTGGTAAAGAAGTTACCGTTGAAGATTTAATGAAAGAGGTGGTGACCTATCGCCACTTTATGAATGCATCTGGCGGTGGTGTTACCGCGTCCGGCGGCGAGGCAATCCTGCAAGCCGAGTTTGTTCGTGACTGGTTCCGCGCCTGCAAAAAAGAAGGTATTCATACCTGTCTGGACACTAACGGTTTTGTTCGTCGTTACGATCCGGTGATTGATGAACTGCTGGAAGTAACCGACCTGGTGATGCTCGATCTCAAACAGATGAACGACGAGATCCACCAAAATCTGGTTGGAGTTTCCAACCACCGCACGCTGGAGTTCGCCAAATATCTGGCGAACAAAAATGTGAAGGTTTGGATCCGCTACGTTGTTGTCCCAGGCTGGTCTGATGATGATGATTCTGCCCATCGTCTGGGTGAATTTACCCGCGATATGGGCAACGTCGAGAAAATCGAGCTTCTCCCCTACCACGAGCTGGGCAAACACAAATGGGTGGCAATGGGTGAAGAGTACAAACTCGACGGCGTGAAACCACCGAAAAAAGAGACCATGGAACGCGTGAAAGGCATTCTTGAGCAATATGGCCATAAGGTAATGTTCTAA",
      "translation": "MSVIGRIHSFESCGTVDGPGIRFITFFQGCLMRCLYCHNRDTWDTHGGKEVTVEDLMKEVVTYRHFMNASGGGVTASGGEAILQAEFVRDWFRACKKEGIHTCLDTNGFVRRYDPVIDELLEVTDLVMLDLKQMNDEIHQNLVGVSNHRTLEFAKYLANKNVKVWIRYVVVPGWSDDDDSAHRLGEFTRDMGNVEKIELLPYHELGKHKWVAMGEEYKLDGVKPPKKETMERVKGILEQYGHKVMF",
      "product": ""
     },
     {
      "start": 1804761,
      "end": 1806191,
      "strand": -1,
      "locus_tag": "ctg1_1707",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1707</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1707</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,804,761 - 1,806,191,\n (total: 1431 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1038:phenylalanine-specific permease (Score: 93.9; E-value: 1.2e-28)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1707\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1707\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1707\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1707\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCGCGTAATGGGCAGGAAAAACAGTTGCGATGGTACAATATTGCATTGATGTCATTTATTACAGTCTGGGGATTTGGCAATGTTGTTAATAATTATGCAAACCAGGGATTAGTGGTAGTTTTCTCATGGTTGTTTATATTTATCCTTTATTTTACTCCGTATGCTCTTATTGTCGGACAACTGGGTTCAACGTTTAAAGATGGGAAGGGCGGAGTTAGCACCTGGATTAAGCATACTATGGGGCCAGGACTGGCTTATCTTGCCGCATGGACCTATTGGGTGGTGCATATTCCTTACCTGGCACAAAAACCTCAAACAATTCTGATTGCTCTTGGTTGGGCCGTGAAAGGTGACGGTTCACTAATTAAAGAATACTCGGTGGTAGTATTACAGGGGCTAACATTAGTGTTGTTTGTCTTCTTTATGTGGGTCGCATCGCGCGGTATGAAATCGCTGAAAACCGTCGGTTCGATTGCGGGAATCGCGATGTTTGTAATGTCGCTGTTATATGTGGCGATGGCAGTAGCTGCACCGGCTATAACTGAAGTTCATATTGCGACCACTAATATTACCTCGGAAACGTTTATTCCTCATATAGATTTCACCTACATAACGACTATTTCGATGTTAGTTTTTGCAGTGGGCGGTGCTGAGAAGATTTCTCCTTACGTTAATCAAACGTGTAATCCGGGAAAAGAGTTTCCAAAAGGGATGCTATGTTTAGCAGCAATGGTTGCGGTGTGTGCAATTCTGGGATCGCTGGCGATGGGGATGATGTTTGACTCGCGGCATATTCCGGATGATTTAATGACCAATGGGCAATATTATGCCTTCCAGAAATTGGGAGAGTATTACAATATGGGTAATTCCTTAATGGTCATTTACGCCATTGCTAATACCCTTGGGCATGTTGCTGCACTGGTATTCTCAATTGATGCGCCACTGAAAGTCTTACTAGGGGATGCAGACAGGAAATATATTCCTGCAAGATTGTGCCGTACAAATGATTCAGGAACACCAGTTAACGGGTATATTTTGACGCTGGTGTTAGTGGCGATCCTGATAATGCTGCCAACGCTGGGTATTGGTGATATGAATAATCTCTACAAATGGTTGTTGAATCTTAACTCGGTAGTGATGCCACTGCGTTATTTGTGGGTGTTTGTTGCATTTATTGCAGTCGTTCGCCTGGCGCAGAAATATAAACCAGAGTATGTCTTTATTCGTAATAGATGGCTGGCGATGATCGTCGGGATTTGGTGTTTTGCCTTTACCGCTTTTGCCTGTTTGACGGGGATCTTCCCGAAAATGGAAGCCTTCACTACCGAGTGGACTTTCCAGCTGGCGCTGAACATTGCAACGCCGTTTGTGCTGGTAGGATTAGGGCTGATATTCCCGTTGTTGGCGCGTAAAGCGAATAGTGAATAA",
      "translation": "MARNGQEKQLRWYNIALMSFITVWGFGNVVNNYANQGLVVVFSWLFIFILYFTPYALIVGQLGSTFKDGKGGVSTWIKHTMGPGLAYLAAWTYWVVHIPYLAQKPQTILIALGWAVKGDGSLIKEYSVVVLQGLTLVLFVFFMWVASRGMKSLKTVGSIAGIAMFVMSLLYVAMAVAAPAITEVHIATTNITSETFIPHIDFTYITTISMLVFAVGGAEKISPYVNQTCNPGKEFPKGMLCLAAMVAVCAILGSLAMGMMFDSRHIPDDLMTNGQYYAFQKLGEYYNMGNSLMVIYAIANTLGHVAALVFSIDAPLKVLLGDADRKYIPARLCRTNDSGTPVNGYILTLVLVAILIMLPTLGIGDMNNLYKWLLNLNSVVMPLRYLWVFVAFIAVVRLAQKYKPEYVFIRNRWLAMIVGIWCFAFTAFACLTGIFPKMEAFTTEWTFQLALNIATPFVLVGLGLIFPLLARKANSE",
      "product": ""
     },
     {
      "start": 1806399,
      "end": 1807547,
      "strand": -1,
      "locus_tag": "ctg1_1708",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1708</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1708</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,806,399 - 1,807,547,\n (total: 1149 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1169:sugar transport protein (Score: 62.6; E-value: 5.6e-19)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1708\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1708\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSIYTRPVMLLLSGLLLLTLAIAVLNTLVPLWLAHEHLPTWQVGMVSSSYFTGNLVGTLLTGYLIKRLGFNRSYYLASLVFAAGCLGLGLMIGFWSWMAWRFVAGVGCAMIWVVVESALMCSGTSRNRGRLLAAYMMIYYVGTFLGQLLVSKVSTELMNVLPWVTALILAGILPLLFTRILSQQTESRKTTSITSMLKLRQARLGVNGCIISGIVLGSLYGLMPLYLNHQGISNSNIGFWMAVLVSAGIVGQWPIGRLADKFGRLLVLRVQIFVVILGSIAMLTHTAMAPALFILGAAGFTLYPVAMAWSCEKVSQDQLVAMNQALLLSYTIGSLLGPSFTAMLMQHYSDNLLFIMIASVSFIYLLMLLRNARHTSNPVAHV\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1708\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1708\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCTATCTATACCCGGCCTGTCATGCTTTTGCTGTCTGGCCTGCTTTTGTTGACCCTGGCGATAGCGGTATTGAACACGCTTGTACCGCTATGGCTTGCTCATGAACATCTACCGACATGGCAGGTTGGTATGGTCAGCTCATCTTATTTCACTGGTAATCTGGTGGGCACATTGTTGACAGGGTATTTGATCAAACGCCTCGGATTTAACCGTAGTTACTACCTTGCATCTTTGGTTTTTGCTGCGGGATGTCTGGGCCTGGGCTTAATGATTGGCTTCTGGAGTTGGATGGCCTGGCGTTTTGTTGCGGGCGTTGGTTGTGCCATGATTTGGGTGGTGGTTGAAAGCGCTCTGATGTGCAGTGGTACATCGCGCAATCGTGGCCGTCTGCTCGCTGCATATATGATGATCTATTATGTGGGAACGTTTCTGGGGCAGTTGCTGGTTAGTAAAGTTTCTACCGAACTAATGAATGTTTTGCCCTGGGTTACAGCTCTGATTCTGGCTGGAATTCTGCCTCTGTTATTTACTCGTATCCTGAGTCAGCAAACTGAATCTCGGAAAACAACATCTATTACCTCAATGCTGAAACTACGCCAGGCGCGATTAGGTGTTAATGGCTGTATTATTTCCGGCATAGTGCTTGGCTCTTTATACGGGTTGATGCCACTTTATCTGAACCATCAGGGAATTAGTAATTCCAACATTGGTTTTTGGATGGCGGTGTTAGTGAGTGCTGGAATTGTAGGACAGTGGCCAATTGGTCGCCTGGCTGATAAATTTGGCCGGTTGTTAGTTTTGCGTGTTCAGATTTTTGTGGTGATTTTGGGAAGCATTGCCATGCTTACACATACAGCAATGGCTCCTGCATTATTTATCCTCGGCGCTGCTGGGTTTACACTTTACCCTGTCGCTATGGCCTGGTCTTGCGAAAAAGTTTCGCAAGACCAATTAGTTGCTATGAATCAGGCATTGCTTTTGAGTTACACAATCGGCAGTTTGCTGGGGCCGTCATTTACCGCGATGTTAATGCAGCATTATTCCGATAATCTGTTATTTATTATGATTGCCAGCGTATCATTTATTTACCTGCTCATGTTACTTCGTAATGCCAGACATACCTCAAATCCTGTGGCACACGTGTAA",
      "translation": "MSIYTRPVMLLLSGLLLLTLAIAVLNTLVPLWLAHEHLPTWQVGMVSSSYFTGNLVGTLLTGYLIKRLGFNRSYYLASLVFAAGCLGLGLMIGFWSWMAWRFVAGVGCAMIWVVVESALMCSGTSRNRGRLLAAYMMIYYVGTFLGQLLVSKVSTELMNVLPWVTALILAGILPLLFTRILSQQTESRKTTSITSMLKLRQARLGVNGCIISGIVLGSLYGLMPLYLNHQGISNSNIGFWMAVLVSAGIVGQWPIGRLADKFGRLLVLRVQIFVVILGSIAMLTHTAMAPALFILGAAGFTLYPVAMAWSCEKVSQDQLVAMNQALLLSYTIGSLLGPSFTAMLMQHYSDNLLFIMIASVSFIYLLMLLRNARHTSNPVAHV",
      "product": ""
     },
     {
      "start": 1807860,
      "end": 1808486,
      "strand": 1,
      "locus_tag": "ctg1_1709",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1709</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1709</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,807,860 - 1,808,486,\n (total: 627 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1709\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1709\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region2/ctg1_1709_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1709\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1709\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCAGGCCCTATGTTCGTCTCGATAAAAATGACGCTGCGGTACTATTAGTTGATCATCAAGCTGGATTATTGTCACTTGTCAGGGATATTGAGCCTGACAAATTCAAAAATAATGTTCTGGCATTAGGCGATTTAGCAAAATATTTCAAACTCCCCACCATTCTCACTACCAGTTTCGAAACAGGTCCCAATGGTCCACTGGTTCCCGAACTTAAGGCACAGTTCCCGGATGCGCCTTATATTGCCCGTCCTGGCAATATCAATGCCTGGGATAATGAAGATTTTGTCAAAGCCGTAAAAGCTACGGGTAAAAAGCAGTTGATCATTGCAGGTGTAGTAACTGAAGTATGTGTTGCTTTCCCGGCACTTTCAGCCATAGAAGAAGGTTTTGATGTCTTCGTGGTGACTGATGCTTCAGGCACATTTAACGAGATCACACGCCATTCGGCATGGGATCGTATGTCGCAAGCAGGAGCGCAATTAATGACATGGTTTGGCGTCGCCTGCGAGTTGCACCGCGACTGGAGAAACGATATTGAGGGGCTGGCGACACTGTTCTCAAATCATATTCCTGACTATCGTAATCTGATGACGAGTTACGACACCTTAACGAAACAGAAATAA",
      "translation": "MTRPYVRLDKNDAAVLLVDHQAGLLSLVRDIEPDKFKNNVLALGDLAKYFKLPTILTTSFETGPNGPLVPELKAQFPDAPYIARPGNINAWDNEDFVKAVKATGKKQLIIAGVVTEVCVAFPALSAIEEGFDVFVVTDASGTFNEITRHSAWDRMSQAGAQLMTWFGVACELHRDWRNDIEGLATLFSNHIPDYRNLMTSYDTLTKQK",
      "product": ""
     },
     {
      "start": 1808544,
      "end": 1809836,
      "strand": -1,
      "locus_tag": "ctg1_1710",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1710</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1710</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,808,544 - 1,809,836,\n (total: 1293 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1710\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1710\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region2/ctg1_1710_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1710\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1710\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTCGATCCCAATCTGCTGCGTAATGAGCCAGACGCAGTCGCTGAAAAACTGGCACGCCGGGGCTTTAAGCTGGATGTAGATAAGTTGGGCGCTCTTGAGGAGCGTCGTAAAGTATTGCAGGTCAAAACGGAAAACCTGCAAGCGGAGCGTAACTCCCGATCGAAATCCATTGGCCAGGCGAAAGCGCGGGGGGAAGATATCGAGCCTTTACGTCTGGAAGTGAACAAACTGGGCGAAGAGCTGGATGCAGCAAAAGCCGAGCTGGATGCTTTACAGGCTGAAATTCGCGATATCGCGCTGACAATCCCTAACCTGCCTGCAGATGAAGTGCCGGTAGGTAAAGATGAAAATGACAACGTTGAAGTCAGCCGCTGGGGTACCCCGCGTGAGTTTGACTTCGAAGTTCGTGACCACGTGACGCTGGGTGAAATGCACTCTGGCCTGGACTTTGCAGCCGCAGTTAAGCTGACCGGTTCGCGCTTTGTGGTGATGAAAGGGCAGATTGCTCGTATGCACCGCGCACTGGCGCAGTTTATGCTAGATCTGCATACCGAACAGCACGGTTATAGTGAAAACTATGTTCCGTATCTGGTTAACCAGGACACGCTGTACGGTACAGGGCAGTTGCCGAAGTTTGCTGGCGATCTGTTCCATACTCGTCCGCTGGAAGAAGAAGCAGATACCAGTAACTACGCACTGATCCCAACGGCAGAAGTTCCGCTGACTAACCTGGTACGCGGTGAAATCATTGATGAAGATGATCTGCCAATTAAGATGACCGCCCACACCCCATGCTTCCGTTCTGAAGCCGGTTCATATGGTCGTGACACCCGTGGTCTGATCCGTATGCACCAGTTCGACAAAGTTGAAATGGTGCAGATCGTTCGCCCGGAAGACTCAATGGCGGCGCTGGAAGAGATGACCGGTCATGCGGAAAAAGTCCTGCAGTTGCTGGGCCTGCCGTACCGTAAAATCATTCTTTGCACCGGCGACATGGGCTTTGGCGCTTGCAAAACTTACGACCTGGAAGTATGGATCCCGGCACAGAACACCTACCGCGAGATCTCTTCCTGCTCCAACGTTTGGGATTTCCAGGCGCGTCGTATGCAGGCACGTTGCCGTAGCAAGTCGGACAAGAAAACCCGTCTGGTTCATACCCTGAACGGTTCTGGTCTGGCTGTTGGTCGTACGCTGGTTGCGGTAATGGAAAACTATCAGCAGGCTGATGGTCGTATCGAAGTACCGGAAGTTTTACGCCCGTACATGAACGGCCTTGAATATATCGGTTAA",
      "translation": "MLDPNLLRNEPDAVAEKLARRGFKLDVDKLGALEERRKVLQVKTENLQAERNSRSKSIGQAKARGEDIEPLRLEVNKLGEELDAAKAELDALQAEIRDIALTIPNLPADEVPVGKDENDNVEVSRWGTPREFDFEVRDHVTLGEMHSGLDFAAAVKLTGSRFVVMKGQIARMHRALAQFMLDLHTEQHGYSENYVPYLVNQDTLYGTGQLPKFAGDLFHTRPLEEEADTSNYALIPTAEVPLTNLVRGEIIDEDDLPIKMTAHTPCFRSEAGSYGRDTRGLIRMHQFDKVEMVQIVRPEDSMAALEEMTGHAEKVLQLLGLPYRKIILCTGDMGFGACKTYDLEVWIPAQNTYREISSCSNVWDFQARRMQARCRSKSDKKTRLVHTLNGSGLAVGRTLVAVMENYQQADGRIEVPEVLRPYMNGLEYIG",
      "product": ""
     },
     {
      "start": 1809927,
      "end": 1811270,
      "strand": -1,
      "locus_tag": "ctg1_1711",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1711</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1711</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,809,927 - 1,811,270,\n (total: 1344 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1711\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1711\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1711\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1711\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGCAATCTGTCGCTCGATTTTTCGGATAATACTTTTCAACCTCTGGCCGCGCGTATGCGGCCAGAAAATTTAGCACAGTATATCGGTCAGCAACATTTGCTGGCTGCGGGGAAGCCGTTGCCGCGTGCAATCGAAGCCGGGCATTTGCATTCGATGATTCTCTGGGGGCCACCGGGTACCGGCAAAACAACCCTCGCTGAAGTGATTGCCCGCTATGCGAACGCTGATGTGGAACGTATTTCTGCCGTCACCTCTGGCGTGAAAGAGATTCGCGAGGCGATCGAGCGCGCCCGGCAAAACCGCAATGCAGGTCGCCGCACTATTCTTTTTGTTGATGAAGTTCACCGTTTCAACAAAAGCCAGCAGGATGCATTTCTGCCACATATTGAAGACGGCACCATCACTTTTATTGGCGCAACCACTGAAAACCCGTCGTTTGAGCTTAATTCGGCACTGCTTTCCCGTGCCCGTGTCTATCTGTTGAAATCCCTGAGTACAGAGGATATTGAGCAAGTACTAACTCAGGCGATGGAAGACAAAACCCGTGGCTATGGTGGTCAGGATATTGTTCTGCCAGATGAAACACGACGCGCCATTGCTGAACTGGTGAATGGCGACGCGCGCCGGGCGTTAAATACGCTGGAAATGATGGCGGATATGGCCGAAGTCGATGATAGCGGTAAGCGGGTCCTGAAGCCTGAATTACTGACCGAAATCGCCGGTGAACGTAGCGCCCGTTTTGATAACAAAGGCGATCGCTTTTACGATCTCATTTCCGCGCTGCATAAATCGGTGCGGGGTAGCGCACCTGATGCAGCTCTCTACTGGTATGCACGCATTATTACCGCCGGGGGCGATCCGTTATATGTCGCGCGCCGTTGCCTGGCGATAGCGTCTGAAGATGTTGGCAATGCCGACCCACGCGCGATGCAGGTGGCAATAGCAGCCTGGGATTGCTTTACCCGCGTTGGCCCGGCAGAAGGTGAACGCGCCATTGCTCAGGCGATTGTTTACCTGGCCTGCGCGCCAAAAAGCAACGCTGTCTATACCGCGTTTAAAGCCGCGCTGGCCGATGCTCGCGAACGTCCGGATTATGACGTACCGGTTCATTTGCGCAATGCGCCGACCAAACTGATGAAGGAAATGGGCTACGGTCAGGAATATCGTTATGCTCATGATGAAGCAAACGCTTATGCTGCCGGTGAGGTTTACTTCCCGCCGGAAATAGCACAAACACGCTATTATTTCCCGACAAACAGGGGCCTTGAAGGCAAGATTGGCGAAAAGCTCGCCTGGCTGGCTGAACAGGATCAAAATAGCCCCATAAAACGCTACCGTTAA",
      "translation": "MSNLSLDFSDNTFQPLAARMRPENLAQYIGQQHLLAAGKPLPRAIEAGHLHSMILWGPPGTGKTTLAEVIARYANADVERISAVTSGVKEIREAIERARQNRNAGRRTILFVDEVHRFNKSQQDAFLPHIEDGTITFIGATTENPSFELNSALLSRARVYLLKSLSTEDIEQVLTQAMEDKTRGYGGQDIVLPDETRRAIAELVNGDARRALNTLEMMADMAEVDDSGKRVLKPELLTEIAGERSARFDNKGDRFYDLISALHKSVRGSAPDAALYWYARIITAGGDPLYVARRCLAIASEDVGNADPRAMQVAIAAWDCFTRVGPAEGERAIAQAIVYLACAPKSNAVYTAFKAALADARERPDYDVPVHLRNAPTKLMKEMGYGQEYRYAHDEANAYAAGEVYFPPEIAQTRYYFPTNRGLEGKIGEKLAWLAEQDQNSPIKRYR",
      "product": ""
     },
     {
      "start": 1811281,
      "end": 1811892,
      "strand": -1,
      "locus_tag": "ctg1_1712",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1712</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1712</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,811,281 - 1,811,892,\n (total: 612 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1712\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1712\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1712\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1712\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAAAAATTGCCATCACCTGTGCATTACTCTCAAGTTTAGTGGCGTCCAGTGTTTGGGCTGATGCCGCAAGCGATCTGAAAAGCCGTCTGGATAAAGTCAGCAGCTTCCACGCCAGTTTCACACAAAAAGTAACTGACGGTAGCGGCGCGGCGGTGCAGGAAGGTCAGGGCGATCTGTGGGTGAAACGTCCAAATTTATTCAACTGGCATATGACTCAACCTGATGAAAGCATTCTGGTTTCTGACGGTAAAACACTGTGGTTCTATAACCCGTTCGTTGAGCAAGCTACGGCAACCTGGCTGAAAGATGCCACCGGTAATACGCCGTTTATGCTGATTGCCCGCAACCAGTCCAGCGACTGGCAGCAGTACAATATCAAACAGAATGGCGATGACTTTGTCCTGACGCCGAAAGCCAGCAATGGCAATCTGAAGCAGTTCACCATTAACGTGGGACGTGATGGCACAATCCATCAGTTTAGCGCGGTGGAGCAGGACGATCAGCGCAGCAGTTATCAACTGAAATCTCAGCAAAATGGGGCTGTGGATGCAGCGAAATTTACCTTCACCCCGCCGCAAGGCGTCACGGTAGATGATCAACGTAAGTAG",
      "translation": "MKKIAITCALLSSLVASSVWADAASDLKSRLDKVSSFHASFTQKVTDGSGAAVQEGQGDLWVKRPNLFNWHMTQPDESILVSDGKTLWFYNPFVEQATATWLKDATGNTPFMLIARNQSSDWQQYNIKQNGDDFVLTPKASNGNLKQFTINVGRDGTIHQFSAVEQDDQRSSYQLKSQQNGAVDAAKFTFTPPQGVTVDDQRK",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 1798257,
      "end": 1804551,
      "tool": "rule-based-clusters",
      "neighbouring_start": 1788257,
      "neighbouring_end": 1814551,
      "product": "thiopeptide",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "thiopeptide",
    "products": [
     "thiopeptide"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP thiopeptide",
    "anchor": "r1c2"
   },
   {
    "start": 3924883,
    "end": 3968470,
    "idx": 3,
    "orfs": [
     {
      "start": 3930139,
      "end": 3931191,
      "strand": -1,
      "locus_tag": "ctg1_3629",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3629</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3629</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,930,139 - 3,931,191,\n (total: 1053 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3629\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3629\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3629\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3629\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACATATACATCGGATGGCTATTCAAGTTAATTCCTTTAGTTATGGGTATAATATGTATTGCGTTGGGTGACTTTGTATTATCAGGTTCCGGGCAAAGTGAATATTTTGTGGCGGGGCATGTTCTTATTTCACTTTCTGCAATATGTCTGGCATTATTCACTACTGCATTTATTATTATTTCGCAGCTAACGCATGGTGTGAATAAGCTCTACAATACCCTTTTTCCTGTTATCGGTTACGCTGGATCTGTTGCAACTATGATTTGGGGATGGTCACTGCTGGCAAGTGATAATGTCATGGCCGATGAATTTGTTGCCGGGCATGTTATTTTTGGTGTTGGAATGATTGCCGCTTGTGTATCGACTGTAGCCGCCTCCTCCGGTCATTTTCTGTTGATCCCGAAAAATGCTGCGGGCAGTAAGAGTGATGGTACGCCGTTGCAGGCTTATTCTTCACTCATTGGCAACTGTCTGATTGCCGTGCCGCTACTTCTGACCGTCTTTGGTTTTATATGGTCCGTTACTTTACTGCGAAGTGCTAATATCACACCACATTACGTTGCAGGCCATGTCCTATTGGGATTAACGGCAATTTGTGCCTGTCTCATTGGACTGGTTGCCACTATTGTTCATCAAACACGTAATACCTTCTCGGAAAAAGAGCATTGGTTGTGGTGCTATTGGGTTATTTTACTTGGCACACTGACGGTTATTCAGGGGATCTACGTTTTAGTCAGTTCTGATGAAAGTGCCAGACTGGCTCCCGGTATTATTCTTATTTGTCTGGGAATGATCTGCTACAGTATTTTCTCCAAAGTATGGTTATTGGCGCTGGTATGGCGACGCACATGCGCTTTAGCCAATAGAATACCCATGATTCCGGTATTTACCTGTCTGTTTTGCCTGTTCCTGGCTGCATTCCTTGCTGAAGTGGCGCAAGTCGATATGGCTTATTTTATTCCTTCGCGAGTACTGGTCGGCTTAGGTGCGGTATGTTTCACCCTGTTCTCTATTGTTTCGATATTAGAAGCAGGTTCTGCAAAAAAATAA",
      "translation": "MNIYIGWLFKLIPLVMGIICIALGDFVLSGSGQSEYFVAGHVLISLSAICLALFTTAFIIISQLTHGVNKLYNTLFPVIGYAGSVATMIWGWSLLASDNVMADEFVAGHVIFGVGMIAACVSTVAASSGHFLLIPKNAAGSKSDGTPLQAYSSLIGNCLIAVPLLLTVFGFIWSVTLLRSANITPHYVAGHVLLGLTAICACLIGLVATIVHQTRNTFSEKEHWLWCYWVILLGTLTVIQGIYVLVSSDESARLAPGIILICLGMICYSIFSKVWLLALVWRRTCALANRIPMIPVFTCLFCLFLAAFLAEVAQVDMAYFIPSRVLVGLGAVCFTLFSIVSILEAGSAKK",
      "product": ""
     },
     {
      "start": 3931924,
      "end": 3932991,
      "strand": 1,
      "locus_tag": "ctg1_3630",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3630</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3630</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,931,924 - 3,932,991,\n (total: 1068 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1029:RND family efflux transporter MFP subunit (Score: 146.4; E-value: 1.8e-44)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3630\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3630\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3630_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMDKSKRHLAWWVVGLLAVAAVVAWWLLRPAGVPEGFAVSNGRIEATEVDIASKIAGRIDTILVKEGQFVREGEVLAKMDTRVLQEQRLEAIAQIKEAQSAVAAAQALLEQRQSETRAAQSLVNQRQAELDSVAKRHTRSRSLAHRGAISAQQLDDDRAAAESARAALESAKAQVSASKAAIEAARTNIIQAQTRVEAAQATERRIAADIDDSELKAPRDGRVQYRVAEPGEVLAAGGRVLNMVDLSDVYMTFFLPTEQAGTLKLGGEARLILDAAPDLRIPATISFVASVAQFTPKTVETSDERLKLMFRVKARIPPELLQQHLEYVKTGLPGVAWVRVNEELPWPDDLAVRLPQ\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3630\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3630\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGATAAGAGTAAGCGCCATCTGGCGTGGTGGGTTGTCGGGTTACTGGCGGTGGCTGCTGTCGTGGCGTGGTGGCTGTTGCGCCCGGCGGGTGTGCCGGAAGGCTTTGCCGTCAGCAATGGGCGTATTGAAGCGACGGAAGTGGATATCGCCAGCAAAATTGCCGGGCGTATCGACACCATTCTGGTGAAAGAAGGCCAGTTTGTTCGTGAAGGTGAAGTATTGGCGAAGATGGATACTCGCGTGTTGCAGGAACAGCGACTGGAAGCTATCGCGCAAATCAAAGAGGCACAAAGTGCCGTTGCCGCCGCGCAGGCTTTGCTGGAGCAACGGCAAAGTGAAACTCGTGCCGCGCAGTCACTGGTTAATCAACGCCAGGCCGAACTGGACTCTGTGGCCAAACGTCATACGCGCTCTCGCTCACTGGCCCATCGAGGGGCTATTTCTGCGCAACAGCTGGACGACGACCGTGCCGCCGCCGAAAGCGCCCGTGCTGCGCTGGAATCGGCAAAAGCCCAGGTTTCGGCTTCTAAAGCGGCTATAGAAGCGGCACGTACCAATATCATTCAGGCGCAAACGCGCGTCGAAGCCGCGCAAGCCACTGAACGGCGCATTGCCGCAGATATCGATGACAGCGAACTGAAAGCCCCGCGTGACGGACGCGTGCAGTATCGGGTTGCCGAGCCAGGGGAAGTGCTGGCGGCAGGCGGTCGGGTGCTGAATATGGTCGATCTCAGCGACGTCTATATGACCTTCTTCCTGCCAACCGAACAGGCGGGTACGCTGAAACTGGGCGGCGAAGCCCGGCTGATCCTCGATGCCGCGCCAGATCTGCGTATTCCGGCGACCATCAGCTTTGTCGCCAGCGTCGCCCAGTTCACACCAAAAACCGTCGAAACCAGCGATGAGCGGCTGAAACTGATGTTCCGCGTCAAAGCGCGTATCCCACCGGAATTACTCCAGCAGCATCTGGAATATGTCAAAACCGGTTTGCCGGGCGTGGCGTGGGTGCGGGTGAATGAAGAACTTCCGTGGCCTGACGACCTTGCGGTGAGGTTGCCGCAATGA",
      "translation": "MDKSKRHLAWWVVGLLAVAAVVAWWLLRPAGVPEGFAVSNGRIEATEVDIASKIAGRIDTILVKEGQFVREGEVLAKMDTRVLQEQRLEAIAQIKEAQSAVAAAQALLEQRQSETRAAQSLVNQRQAELDSVAKRHTRSRSLAHRGAISAQQLDDDRAAAESARAALESAKAQVSASKAAIEAARTNIIQAQTRVEAAQATERRIAADIDDSELKAPRDGRVQYRVAEPGEVLAAGGRVLNMVDLSDVYMTFFLPTEQAGTLKLGGEARLILDAAPDLRIPATISFVASVAQFTPKTVETSDERLKLMFRVKARIPPELLQQHLEYVKTGLPGVAWVRVNEELPWPDDLAVRLPQ",
      "product": ""
     },
     {
      "start": 3932988,
      "end": 3935723,
      "strand": 1,
      "locus_tag": "ctg1_3631",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3631</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3631</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,932,988 - 3,935,723,\n (total: 2736 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 191.6; E-value: 2.7e-58)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3631\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3631\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3631_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMTHLELVPVPPVAQLAGVSQHYGKTVALNNITLDIPARCMVGLIGPDGVGKSSLLSLISGARVIEQGNVIVLGGDMRDPRHRRDVCPRIAWMPQGLGKNLYHTLSVYENVDFFARLFGHDKAEREVRINELLTSTGLAPFRDRPAGKLSGGMKQKLGLCCALIHDPELLILDEPTTGVDPLSRAQFWDLIDSIRQRQSNMSVLVATAYMEEAERFDWLVAMNAGEVLATGSAEELRQQTQSATLEEAFINLLPQAQRQAHQAVVIPPYQSEKADIAIEARDLTMRFGSFVAVDHVNFRIPRGEIFGFLGSNGCGKSTTMKMLTGLLPASEGEAWLFGQPVDPKDIDTRRRVGYMSQAFSLYNELTVRQNLELHARLFHIPEAEIPARVAEMSERFKLNDVEDVLPESLPLGIRQRLSLAVAVIHRPEMLILDEPTSGVDPVARDMFWQLMVDLSRQDKVTIFISTHFMNEAERCDRISLMHAGKVLASGTPQELVEKRGAASLEEAFIAYLQEAAGQSNEAEAPPVVHDTTHAPRQGFSLRRLFSYSRREALELRRDPVRSTLALMGTVILMLIMGYGISMDVENLRFAVLDRDQTVSSQAWTLNLSGSRYFIEQPPLTSYDELDRRMRAGDITVAIEIPPNFGRDIARGTPVELGVWIDGAMPSRAETVKGYVQAMHQSWLQDVASRQSTPASQSGLMNIETRYRYNPDVKSLPAIVPAVIPLLLMMIPSMLSALSVVREKELGSIINLYVTPTTRSEFLLGKQLPYIGLGMLNFFLLCALSVFVFGVPHKGSFLTLTLAALLYIIIATGMGLLISTFMKSQIAAIFGTAIITLIPATQFSGMIDPVASLEGPGRWIGEVYPTSHFLTIARGTFSKALDLTDLWQLFIPLLIAIPLVMGLSILLLKKQEG\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3631\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3631\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGCATCTGGAACTGGTTCCCGTCCCGCCTGTCGCGCAACTGGCGGGCGTGAGCCAGCATTATGGAAAAACTGTTGCGCTGAACAATATCACTCTCGATATTCCGGCCCGCTGCATGGTTGGGCTGATTGGCCCGGACGGCGTCGGGAAGTCGAGTTTGTTGTCACTGATTTCCGGTGCCCGCGTCATTGAGCAGGGCAACGTGATCGTGCTGGGCGGCGATATGCGCGACCCGAGGCATCGCCGTGACGTCTGCCCGCGCATTGCCTGGATGCCGCAGGGACTGGGCAAAAACCTCTACCACACCTTGTCGGTGTATGAAAACGTCGATTTTTTCGCCCGCCTGTTCGGTCACGACAAAGCAGAGCGGGAAGTACGAATTAATGAACTGCTGACCAGCACCGGTTTAGCACCGTTTCGCGATCGTCCGGCAGGGAAACTCTCCGGCGGGATGAAGCAAAAACTGGGGCTGTGCTGTGCGTTAATCCACGACCCGGAACTGTTGATTCTTGATGAGCCTACGACGGGGGTTGACCCGCTCTCCCGCGCCCAGTTCTGGGATCTGATCGATAGCATTCGCCAGCGGCAGAGCAATATGAGCGTGCTGGTTGCCACCGCCTATATGGAAGAGGCGGAACGCTTCGACTGGCTGGTAGCGATGAATGCCGGAGAAGTGCTGGCGACTGGCAGCGCCGAAGAACTGCGGCAGCAAACGCAAAGCGCCACGCTGGAAGAAGCATTTATAAATCTGTTACCGCAAGCGCAACGCCAGGCGCATCAGGCGGTAGTGATCCCACCGTATCAATCTGAAAAAGCAGACATTGCCATCGAAGCACGCGATCTGACCATGCGTTTTGGTTCCTTCGTTGCCGTTGATCACGTCAATTTCCGCATTCCACGTGGGGAGATTTTTGGATTCCTTGGTTCGAACGGCTGCGGTAAATCCACCACCATGAAAATGCTTACTGGACTGCTGCCTGCCAGCGAAGGTGAGGCGTGGCTGTTCGGGCAACCGGTTGATCCAAAAGATATCGATACCCGCCGTCGGGTGGGCTATATGTCGCAGGCGTTTTCGCTCTATAACGAGCTCACCGTGCGGCAAAACCTGGAGTTACATGCCCGTTTGTTTCACATCCCGGAAGCGGAAATTCCCGCGCGAGTGGCTGAAATGAGCGAGCGTTTTAAGCTCAACGACGTTGAGGATGTTCTGCCGGAGTCATTGCCGCTCGGCATTCGCCAGCGGCTTTCGCTGGCGGTGGCGGTGATTCATCGCCCGGAAATGTTAATCCTCGATGAGCCTACTTCTGGCGTCGATCCAGTGGCGAGGGATATGTTCTGGCAGTTAATGGTGGATCTTTCGCGCCAGGACAAAGTGACCATTTTCATCTCCACCCACTTTATGAACGAAGCGGAACGCTGCGACCGCATCTCACTGATGCACGCCGGAAAAGTGCTCGCCAGCGGTACACCGCAGGAACTGGTTGAGAAACGCGGAGCCGCCAGCCTGGAAGAGGCTTTTATCGCCTATTTGCAGGAAGCGGCAGGGCAGAGCAACGAAGCCGAAGCGCCGCCTGTGGTACATGATACCACCCACGCGCCGCGTCAGGGATTTAGCCTGCGACGTCTGTTTAGCTACAGCCGTCGCGAAGCACTGGAACTGCGCCGCGATCCGGTACGTTCGACGCTGGCGCTGATGGGAACGGTGATCCTGATGCTGATAATGGGTTACGGCATCAGTATGGATGTGGAAAACCTGCGCTTTGCGGTGCTTGATCGCGACCAGACCGTCAGTAGCCAGGCGTGGACGCTCAATCTCTCCGGTTCCCGTTACTTTATCGAGCAGCCGCCGCTCACCAGTTATGACGAGCTTGATCGCCGGATGCGTGCGGGCGATATCACCGTGGCGATTGAGATTCCACCCAATTTCGGGCGCGATATCGCGCGTGGTACGCCTGTGGAACTCGGTGTCTGGATCGACGGTGCGATGCCGAGTCGCGCCGAAACGGTAAAAGGTTACGTGCAGGCCATGCACCAGAGCTGGTTACAGGATGTGGCGAGTCGGCAATCCACGCCCGCGAGCCAAAGCGGGCTGATGAATATTGAGACACGCTATCGCTATAACCCGGACGTAAAAAGCCTGCCAGCGATTGTTCCGGCGGTGATCCCACTGTTGCTGATGATGATTCCGTCGATGTTAAGCGCCCTTAGCGTGGTACGGGAAAAAGAGTTGGGGTCGATTATCAACCTTTACGTTACCCCCACCACCCGCAGCGAATTTTTACTTGGCAAACAGCTACCGTACATCGGGCTGGGAATGCTGAACTTTTTCCTGCTCTGCGCCCTGTCGGTGTTTGTGTTTGGCGTGCCGCATAAAGGCAGTTTCCTGACGCTCACCCTGGCGGCGTTGCTGTATATCATCATTGCCACCGGAATGGGGCTGCTGATCTCTACTTTTATGAAAAGCCAGATTGCCGCCATTTTCGGTACGGCGATTATCACGTTGATTCCGGCGACGCAGTTTTCCGGGATGATCGATCCGGTAGCTTCGCTGGAAGGTCCAGGACGTTGGATCGGCGAGGTTTACCCGACCAGTCATTTTCTGACTATCGCCCGCGGAACGTTCTCGAAAGCGCTGGATCTGACGGATTTATGGCAACTTTTTATCCCGTTGCTGATAGCCATTCCACTGGTGATGGGCTTAAGCATCCTGCTGCTGAAAAAACAGGAGGGATGA",
      "translation": "MTHLELVPVPPVAQLAGVSQHYGKTVALNNITLDIPARCMVGLIGPDGVGKSSLLSLISGARVIEQGNVIVLGGDMRDPRHRRDVCPRIAWMPQGLGKNLYHTLSVYENVDFFARLFGHDKAEREVRINELLTSTGLAPFRDRPAGKLSGGMKQKLGLCCALIHDPELLILDEPTTGVDPLSRAQFWDLIDSIRQRQSNMSVLVATAYMEEAERFDWLVAMNAGEVLATGSAEELRQQTQSATLEEAFINLLPQAQRQAHQAVVIPPYQSEKADIAIEARDLTMRFGSFVAVDHVNFRIPRGEIFGFLGSNGCGKSTTMKMLTGLLPASEGEAWLFGQPVDPKDIDTRRRVGYMSQAFSLYNELTVRQNLELHARLFHIPEAEIPARVAEMSERFKLNDVEDVLPESLPLGIRQRLSLAVAVIHRPEMLILDEPTSGVDPVARDMFWQLMVDLSRQDKVTIFISTHFMNEAERCDRISLMHAGKVLASGTPQELVEKRGAASLEEAFIAYLQEAAGQSNEAEAPPVVHDTTHAPRQGFSLRRLFSYSRREALELRRDPVRSTLALMGTVILMLIMGYGISMDVENLRFAVLDRDQTVSSQAWTLNLSGSRYFIEQPPLTSYDELDRRMRAGDITVAIEIPPNFGRDIARGTPVELGVWIDGAMPSRAETVKGYVQAMHQSWLQDVASRQSTPASQSGLMNIETRYRYNPDVKSLPAIVPAVIPLLLMMIPSMLSALSVVREKELGSIINLYVTPTTRSEFLLGKQLPYIGLGMLNFFLLCALSVFVFGVPHKGSFLTLTLAALLYIIIATGMGLLISTFMKSQIAAIFGTAIITLIPATQFSGMIDPVASLEGPGRWIGEVYPTSHFLTIARGTFSKALDLTDLWQLFIPLLIAIPLVMGLSILLLKKQEG",
      "product": ""
     },
     {
      "start": 3935723,
      "end": 3936847,
      "strand": 1,
      "locus_tag": "ctg1_3632",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3632</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3632</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,935,723 - 3,936,847,\n (total: 1125 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1065:ABC-2 type transporter (Score: 60; E-value: 3.4e-18)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3632\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3632\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMRHLRNIFNLGIKELRSLLGDKAMLTLIIFSFTVSVYSSATVTPGSLNLAPIAIADMDQSQLSNRIVNSFYRPWFLPPEMITADEMDAGLDAGRYTFAINIPPNFQRDVLAGRQPDIQVNVDATRMSQAFTGNGYIQNIINGEVNSFVARYRDNSEPLVSLETRMRFNPNLDPAWFGGVMAIINNITMLAIVLTGSALIREREHGTVEHLLVMPIKPFEIMMAKVWSMGLVVLVVSGLSLVLMVKGVLGVPIEGSIPLFMLGVALSLFATTSIGIFMGTIARSMPQLGLLVILVLLPLQMLSGGSTPRESMPQMVQDIMLTMPTTHFVSLAQAILYRGAGFEIVWPQFLTLMAIGGAFFTIALLRFRKTIGTMA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3632\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3632\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGCCATTTACGCAATATTTTTAATCTGGGTATCAAAGAGTTGCGCAGTCTGCTTGGTGATAAAGCGATGCTGACGCTGATTATTTTCTCGTTTACGGTGTCGGTTTATTCATCAGCGACCGTCACGCCAGGATCGTTGAACCTGGCACCGATCGCTATTGCCGATATGGATCAATCGCAGTTATCGAACCGGATCGTTAACAGCTTCTACCGCCCGTGGTTTTTGCCCCCGGAGATGATCACCGCCGATGAGATGGATGCCGGGCTGGACGCCGGGCGCTATACCTTCGCGATAAATATTCCGCCTAATTTTCAGCGTGATGTCCTCGCAGGACGCCAGCCGGATATTCAGGTGAACGTCGATGCCACGCGCATGAGCCAGGCATTCACTGGCAACGGTTATATCCAGAATATTATCAACGGTGAAGTGAACAGCTTTGTCGCGCGCTACCGTGATAACAGCGAACCGTTGGTATCGCTGGAAACCCGCATGCGCTTTAATCCGAACCTCGATCCCGCGTGGTTTGGCGGGGTGATGGCGATCATCAACAACATTACCATGCTGGCGATTGTACTGACCGGATCGGCGCTGATCCGCGAGCGTGAACACGGCACGGTGGAACACTTACTGGTGATGCCGATAAAGCCGTTTGAGATCATGATGGCGAAGGTCTGGTCGATGGGGCTGGTGGTGCTGGTGGTATCGGGATTATCGCTGGTGCTGATGGTAAAAGGCGTGCTGGGCGTACCGATTGAAGGCTCGATCCCGCTGTTTATGCTTGGCGTGGCGCTCAGTCTGTTTGCCACCACGTCAATCGGCATTTTTATGGGGACGATAGCGCGTTCAATGCCGCAACTGGGGCTGCTTGTGATTCTGGTGCTGCTGCCGCTGCAAATGCTTTCCGGTGGCTCCACGCCGCGCGAAAGTATGCCGCAGATGGTGCAGGACATTATGCTGACCATGCCGACGACACACTTTGTTAGCCTTGCGCAGGCCATCCTCTACCGGGGTGCCGGATTCGAAATCGTCTGGCCGCAGTTCCTGACGTTGATGGCAATTGGCGGCGCGTTTTTCACCATCGCGTTGCTGCGATTCAGGAAGACGATTGGGACAATGGCGTAA",
      "translation": "MRHLRNIFNLGIKELRSLLGDKAMLTLIIFSFTVSVYSSATVTPGSLNLAPIAIADMDQSQLSNRIVNSFYRPWFLPPEMITADEMDAGLDAGRYTFAINIPPNFQRDVLAGRQPDIQVNVDATRMSQAFTGNGYIQNIINGEVNSFVARYRDNSEPLVSLETRMRFNPNLDPAWFGGVMAIINNITMLAIVLTGSALIREREHGTVEHLLVMPIKPFEIMMAKVWSMGLVVLVVSGLSLVLMVKGVLGVPIEGSIPLFMLGVALSLFATTSIGIFMGTIARSMPQLGLLVILVLLPLQMLSGGSTPRESMPQMVQDIMLTMPTTHFVSLAQAILYRGAGFEIVWPQFLTLMAIGGAFFTIALLRFRKTIGTMA",
      "product": ""
     },
     {
      "start": 3936938,
      "end": 3937789,
      "strand": -1,
      "locus_tag": "ctg1_3633",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3633</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3633</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,936,938 - 3,937,789,\n (total: 852 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3633\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3633\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3633_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3633\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3633\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCATTAGTTAATGGACGGATACTGCTCGACCGCATTCAGGAAAAACGGGTATTAGCGGGCGCGTTTAATACCACCAATCTGGAGACGACGATTTCAATTTTAAACGCCATTGAGCGTTCAGGATTACCCAACTTCATTCAGATTGCGCCCACCAATGCACAACTCTCGGGATACGATTACATTTATGAAATCGTGAAACGTCACGCCGATAAAATGGATGTTCCGGTCAGTCTTCATCTGGATCACGGGAAAACTCAGGAGGATGTTAAACAGGCGGTGCGCGCGGGCTTTACCTCGGTCATGATTGACGGTGCCGCATTCTCTTTTGAAGAGAATATCGCTTTCACCCAGGAAGCTGTCGATTTCTGTAAATCCTATGGCGTACCGGTTGAAGCGGAGCTGGGGGCGATTCTCGGCAAAGAAGATGATCACGTCAGCGAAGCCGATTGCAAAACGGAACCGGAAAAGGTGAAGACCTTTGTCGAGCGCACCGGTTGCGACATGCTGGCAGTTTCTATTGGCAACGTTCATGGCCTGGACGATATACCGCGTATCGATATCCCCCTGCTGAAGCGCATTGCCGAAGTCTGCCCGGTGCCGCTGGTTATTCACGGCGGCTCCGGTATCGCCCCGGAGATATTGCGCAGCTTTGTTAATTATCGCGTCGCTAAAGTAAATATCGCCAGCGATCTGCGCAAAGCGTTTATCACCGCCGTCGGCAAAGCGTATGTGAATAATCACAACGAGGCGAATCTGGCACGAGTGATGGCATCAGCAAAAAACGCCGTCGAGGAAGATGTGTATAGCAAAATCCTGATGATGAATGAGGGTCATCGGTTGGTTAAATAA",
      "translation": "MPLVNGRILLDRIQEKRVLAGAFNTTNLETTISILNAIERSGLPNFIQIAPTNAQLSGYDYIYEIVKRHADKMDVPVSLHLDHGKTQEDVKQAVRAGFTSVMIDGAAFSFEENIAFTQEAVDFCKSYGVPVEAELGAILGKEDDHVSEADCKTEPEKVKTFVERTGCDMLAVSIGNVHGLDDIPRIDIPLLKRIAEVCPVPLVIHGGSGIAPEILRSFVNYRVAKVNIASDLRKAFITAVGKAYVNNHNEANLARVMASAKNAVEEDVYSKILMMNEGHRLVK",
      "product": ""
     },
     {
      "start": 3937820,
      "end": 3938089,
      "strand": -1,
      "locus_tag": "ctg1_3634",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3634</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3634</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,937,820 - 3,938,089,\n (total: 270 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3634\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3634\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3634\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3634\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTGAGTAAAACCGTGGAGGTCAGAAACAGTACTGGCCTGCATGCACGTCCGGCGGCTTGTCTGGTGAAAGCCGCCAAAAAGTTTAGCTGTAAAGTGACGCTGCATTATGAGGGTAATGATATTAATGCCACCAGCATGATGAATATTATGCGCGCCGGAATAAAAGGCGGCAAAACGGTGGAAATACGCTGCGAAGGCGATGATGAAAATGAGGCAATACAAACTCTCACCGCCTTATTTCGTGACCGCTTCGGTGAAGCTGAATAA",
      "translation": "MLSKTVEVRNSTGLHARPAACLVKAAKKFSCKVTLHYEGNDINATSMMNIMRAGIKGGKTVEIRCEGDDENEAIQTLTALFRDRFGEAE",
      "product": ""
     },
     {
      "start": 3938079,
      "end": 3939587,
      "strand": -1,
      "locus_tag": "ctg1_3635",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3635</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3635</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,938,079 - 3,939,587,\n (total: 1509 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1210:glycerol kinase (Score: 257.6; E-value: 3.2e-78)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3635\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3635\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3635\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3635\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCTGATAACAGCGCAGCTATCGTTATCGATATTGGCACCACCAATTGCAAAGTCACCTGCTTTTCCTGCCTGGACGCAACGACGTTGGGCGCGCATAAATTCGTGACGGCAAAACAGATCTCCCCACAGGGCGATGTCGATTTCGATATCGACGCCCTCTGGCAGGAGGTCCGCCAGGCGATAGCACAACTGAACGCCGCTTCGCCGCTGCCAGTCAGGCGGATCAGCATTGCCAGTTTTGGCGAGTCAGGCGTGTTTCTTGACGAGCATGGCGAGATCCTGACGCCAATGCTGGCATGGTATGACCGTCGCGGTGAAGAGTTTCTGGCTACACTTAGCGAGGCAGACAGTGCGGCACTTTATGACATTTGCGGATTACCGCTGCACAGCAATTACTCTGCCTTCAAAATGCGTTGGTTGCTGGAACATTACCCACTGCGTAATCGCCGCGGCCTGCACTGGCTACATGCGCCGGAAGTACTGCTCTGGCGGCTGACCGGCGAACAGCGCACGGATATCACCTTAGCCAGCCGCACGCTGTGTCTGGACGTGCGCAAAGGCGAATGGTCAGCGAAAGCGGCGGCGTTGTTACACGTTCCCTGTTCGGCATTTGCGCCATTGGTGCAGCCAGGCGAACACGCCGGATGGGTCAGCGAGTCGCTCTGCAAAACGCTTGGGTTCTCGCAACCGGTCAGCGTGACGCTGGCCGGACATGACCATATGGTGGGTGCACGGGCGTTGCAGATGATGCCGGGCGATATCCTTAACTCGACGGGGACCACAGAAGGCATTCTGCAACTGGATACACAACCGACGCTGGATGAACAGGCCAAACGTGACAAGCTGGCAAACGGCTGTTATTCGCTTGCAAACCAGTTCACCCTGTTTGCGTCGCTGCCCGTGGGCGGTTTCGCTCTGGAGTGGCTGCGTAACACGTTCCGGCTAACCGATGAGGAGATCGCCGCATCACTTACTCGCGGACATGCGGATTACCTGGCGGGGAACTGGTCGCTCGATGACATTCCCCTCTTTATTCCACATCTTCGCGGTTCGGGTTCGCCCTATAAAAATCGCCATACCCGTGGATTATTTTATGGGCTTAGCGATACGTTAAATATTGACATGTTAATTGCCAGCGTCTCACTGGGATTAACCATGGAATTTGCCAACTGCTTCGCCTGTTTTAATGTGCCTGGCACCAGCGCGTTAAAAGTAATCGGCCCGGCAACCCATAATCCCCTTTGGCTGCAATTAAAGGCGGATATTTTACAGCGTCCGGTTGAGGCAATTGCATTTAACGAGGCGGTTTCTGTCGGAGCATTATTAACTGCCGCACCGGATATTCCACCGCCGCAAGTTACCATAGCCCAACGTTTGTTACCGAATCGGGCGAGATACCATCAATTACAGCGTTATCAGCACAAATGGAAAAGCTGGTATCAGTTGAAATTACAGCAAGAAGGCGTGATGCCATTACACCATCGGGAGGAGCACTATGTTGAGTAA",
      "translation": "MPDNSAAIVIDIGTTNCKVTCFSCLDATTLGAHKFVTAKQISPQGDVDFDIDALWQEVRQAIAQLNAASPLPVRRISIASFGESGVFLDEHGEILTPMLAWYDRRGEEFLATLSEADSAALYDICGLPLHSNYSAFKMRWLLEHYPLRNRRGLHWLHAPEVLLWRLTGEQRTDITLASRTLCLDVRKGEWSAKAAALLHVPCSAFAPLVQPGEHAGWVSESLCKTLGFSQPVSVTLAGHDHMVGARALQMMPGDILNSTGTTEGILQLDTQPTLDEQAKRDKLANGCYSLANQFTLFASLPVGGFALEWLRNTFRLTDEEIAASLTRGHADYLAGNWSLDDIPLFIPHLRGSGSPYKNRHTRGLFYGLSDTLNIDMLIASVSLGLTMEFANCFACFNVPGTSALKVIGPATHNPLWLQLKADILQRPVEAIAFNEAVSVGALLTAAPDIPPPQVTIAQRLLPNRARYHQLQRYQHKWKSWYQLKLQQEGVMPLHHREEHYVE",
      "product": ""
     },
     {
      "start": 3939580,
      "end": 3940938,
      "strand": -1,
      "locus_tag": "ctg1_3636",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3636</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3636</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,939,580 - 3,940,938,\n (total: 1359 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3636\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3636\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3636\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3636\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACGATATCGCGCATACCCTCTATAATATTGTGCAATATATATTGGGATTTGGCCCGACGGTAATGTTGCCGTTGGTGTTATTTATTCTTGCTCTCTGTTTTAAAGTAAAACCCGCTAAAGCCTTACGTTCGTCATTAACAGTCGGCATTGGTTTTGTCGGTATTTATGCCATTTTCGATATTCTTACCAGCAATGTCGGGCCTGCGGCCCAGGCGATGGTTGAACGCACCGGAATTAATTTACCGGTGGTGGATTTAGGCTGGCCGCCGCTTTCCGCTATTACATGGGGTTCCCCAATTGCCCCATTTGTTATTCCCCTGACCATTCTGATTAACGTGGCGATGCTGGCGTTAAATAAAACCCGCACCGTTGACGTAGATATGTGGAACTACTGGCATTTTGCCCTTGCTGGTACGCTGGTTTATTACAGCACCGGCAGCCTGTTCTTTGGTTTGCTGGCGGCGGCGATTGCCGCAGTGGTGGTGCTAAAACTCGCCGACTGGTCTGCGCCACTGGTACAAAAATACTTTGGCCTGGAAGGGATCTCATTGCCGACGCTCTCTTCGGTGGTGTTCTTCCCGGTCGGTCTGCTGGTCGACAAAATCATCGACCATATCCCTGGCCTCAATCGTATTCATATCGACCCGGAAACCGTACAGAAAAAGTTTGGCATCTTCGGCGAACCGATGATGGTTGGCACTATTCTGGGCATTCTGCTCGGCGTAATTGCCGGATACGATTTCAAAAAAGTCTTGCTGCTTGGCATCAGCATTGGCGGTGTGATGTTCATCCTGCCACGCATGGTACGCATTCTGATGGAAGGTTTATTACCGCTGTCTGAAGCCATTAAAAAGTATCTCAATGCCAAATACCCTGACCGTGACGATCTCTATATCGGCCTGGATATCGCCGTTGCCGTAGGTAACCCGGCGATTATCTCCACCGCCCTGCTGCTGACGCCAATCTCGGTCTTTATCGCGTTTGTCCTTCCGGGTAATGAAGTCCTGCCGCTTGGCGACCTTGCCAACCTGGCGGTAATGGCGTCGATGATCGCTTTAGCCAGCCGTGGCAATATTTTCCGCACCGTTCTGGCGGCGATTCCGGTGATTATTGCCGACCTGTGGATTGCTACCAAAATCGCGCCGTTTATTACCGGAATGGCGAAAGACGTTAACTTCAAATTTGCCGAAGGCTCCAGCGGCCAGGTTTCCAGTTTCCTTGATGGCGGTAACCCGTTCCGCTTCTGGCTGCTGGAAATCTTCAACGGCAATCTCATCGCCATTGGTCTGGTGCCGGTTATCGCCCTGGTACTGTATGGCATTTTCCGAATGACGCGGAGCACGGTTTATGCCTGA",
      "translation": "MNDIAHTLYNIVQYILGFGPTVMLPLVLFILALCFKVKPAKALRSSLTVGIGFVGIYAIFDILTSNVGPAAQAMVERTGINLPVVDLGWPPLSAITWGSPIAPFVIPLTILINVAMLALNKTRTVDVDMWNYWHFALAGTLVYYSTGSLFFGLLAAAIAAVVVLKLADWSAPLVQKYFGLEGISLPTLSSVVFFPVGLLVDKIIDHIPGLNRIHIDPETVQKKFGIFGEPMMVGTILGILLGVIAGYDFKKVLLLGISIGGVMFILPRMVRILMEGLLPLSEAIKKYLNAKYPDRDDLYIGLDIAVAVGNPAIISTALLLTPISVFIAFVLPGNEVLPLGDLANLAVMASMIALASRGNIFRTVLAAIPVIIADLWIATKIAPFITGMAKDVNFKFAEGSSGQVSSFLDGGNPFRFWLLEIFNGNLIAIGLVPVIALVLYGIFRMTRSTVYA",
      "product": ""
     },
     {
      "start": 3941015,
      "end": 3941296,
      "strand": -1,
      "locus_tag": "ctg1_3637",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3637</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3637</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,941,015 - 3,941,296,\n (total: 282 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3637\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3637\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3637\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3637\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTCAAACCATTTTATTTGTCTGCGCCACGGGTATTGCCACATCCACGGCGGTAACAGAAAAAGTCATGGAATATTGTAAAGAGCACGGTCTTAACGTCAATTATTCCCAAACCAACGTTGCCTCTTTACCTGGAAATACTGACGGCGTAGCACTGGTAGTCTCAACGACTAAAGTGCCTTATGAACTCGACGTCCCGGTGGTTAACGGCTTGCCGATTATTACCGGTATTGGCGAAGAGAAAGTACTGGCGCAAATTGTTTCGATCCTTAAAAAGTAA",
      "translation": "MSQTILFVCATGIATSTAVTEKVMEYCKEHGLNVNYSQTNVASLPGNTDGVALVVSTTKVPYELDVPVVNGLPIITGIGEEKVLAQIVSILKK",
      "product": ""
     },
     {
      "start": 3941293,
      "end": 3941766,
      "strand": -1,
      "locus_tag": "ctg1_3638",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3638</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3638</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,941,293 - 3,941,766,\n (total: 474 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3638\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3638\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3638\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3638\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAAGGCATACAGTTTCAGGAAAATTATATTCAACGACTTCCGGCAGGGTTAAGCGTTGAACAGATCATCCGTCAGTTAGCGCAACCGTTGGTTGCCGCCGAGCTGGTGGTCCCTGATTTTGCCGATCACGTACTGGAACGTGAGGCGACGTACCCAACGGGGCTGCCTACCGAACCACCGTGCGTCGCCATTCCGCACACGGACCATAAACATGTCCGGCACAATGCAATTGCCGTCGGTATTTTGCCAGAGCCGGTAGAGTTTGCCGATATGGGCGGCGACCCTGATCCCGTGCCTGTCAGGGTGATTTTTTTGCTCGCCTTAAGCGAAAGTAACAAACAATTAAATGCCCTGGGCTGGATTATGGAGATGATTCAGGATACGCCCTTTATGCGCGCCCTGCTTACGATGGAAACAACAGAAATACACACAGTAATCTTAAACAAAATGAAAGAACGAGGTGAAATATGA",
      "translation": "MQGIQFQENYIQRLPAGLSVEQIIRQLAQPLVAAELVVPDFADHVLEREATYPTGLPTEPPCVAIPHTDHKHVRHNAIAVGILPEPVEFADMGGDPDPVPVRVIFLLALSESNKQLNALGWIMEMIQDTPFMRALLTMETTEIHTVILNKMKERGEI",
      "product": ""
     },
     {
      "start": 3941791,
      "end": 3942537,
      "strand": -1,
      "locus_tag": "ctg1_3639",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3639</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3639</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,941,791 - 3,942,537,\n (total: 747 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1136:GntR family transcriptional regulator (Score: 163.3; E-value: 1.2e-49)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3639\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3639\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3639_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3639\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3639\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAATCATTAAGTAAGTCGTCACAAATACCGCTCTATCAACAAGTGGTGGAGTGGATAAGAGAAAGTATTTATACCGGGGATCTGGTGGAAGACGATCGCATTCCTTCGGAATACCAGATTATGGATATGCTGGAAGTGAGTCGGGGAACCGTTAAAAAAGCAGTCGCCCAACTGGTAAAAGAAGGCGTGTTGATACAGGTCCAGGGGAAGGGAACATTTGTCAAAAAAGAGAACGTGGCATATCCGTTAGGTGAAGGATTATTGTCATTCGCGGAATCGCTGGAAAGCCAGAAAATACATTTTACCACTGAAGTTATTACGTCACGGATTGAACCGGCTAATCGTTATGTGGCAGAGAAATTAAGAATAACGCCCGGTCAGGATATTCTTTACCTTGAACGTTTACGTTCGATTGGTGATGAAAAAGCGATGCTGATAGAGAACCGTATCAATATTGAGCTATGCCCCGGCATCGTGGAAATCGATTTTAATCAACACAATTTATTTCCAACAATAGAAAGTTTGTCGCAAAGAAAAATTCGTTACTCGGAAAGTCGCTATGCCGCGCGATTAATTGGTAATGAACGCGGTCATTTTTTAGATATCAGTGAAGATGCACCCGTTTTGCATCTGGAGCAGTTAGTCTTTTTCTCCCGAGAGTTACCCGTTGAGTTTGGCAACGTCTGGTTAAAAGGCAATAAATATTATCTTGGCACCGTGCTGCAACGGCGGGAAGTGAGTTAA",
      "translation": "MKSLSKSSQIPLYQQVVEWIRESIYTGDLVEDDRIPSEYQIMDMLEVSRGTVKKAVAQLVKEGVLIQVQGKGTFVKKENVAYPLGEGLLSFAESLESQKIHFTTEVITSRIEPANRYVAEKLRITPGQDILYLERLRSIGDEKAMLIENRINIELCPGIVEIDFNQHNLFPTIESLSQRKIRYSESRYAARLIGNERGHFLDISEDAPVLHLEQLVFFSRELPVEFGNVWLKGNKYYLGTVLQRREVS",
      "product": ""
     },
     {
      "start": 3942886,
      "end": 3943752,
      "strand": -1,
      "locus_tag": "ctg1_3640",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3640</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3640</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,942,886 - 3,943,752,\n (total: 867 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3640\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3640\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3640\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3640\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAAATAATCGATAAAAATAAAAAAAGAAGAGAGAACAGAGAAACTTTTTTGTATGCAAAATATAAAGCCTATACCCTTAATCAACTGATTCCTCTTTTATTTAAAAAAAATAGTCTTACACGGCAGGCTGCCATTTTTCGATTACAAATAATTGGAACAGATGAGGTTTTTACCTTTGCTGTTAATCTTTGTCAGTCAGAAGGTAAACAGGAAAGAAAGACAGGAATATCCATTCTAAGTCAACTTTCGATGTCTCCCGAGCACCTGACTCAATCTTTTAATTTAGTCGAAGCGTTATTAGAAAAGGAAACGTCCGCTAACGTAAGAGCTGCTGCGGTTAATGCAATAGGCCATTTTTGCAGAAGAAACCCATCATTCAACAGCCGGGCACCAGAACTACTGACTCGAACAACATATGATAAATCGGTCAATACACGTTGCGCGACTGCGGCAGCGCTATCTGAAATAAATAACATAAAAGCCATTCCGCTGCTCTTATCGTTACTTAACGACAGCAACGGAGATGTGAGAAATTGGGCTGCATTCTCTGTTAATACAAACGAATATGATTCGAAAGAGATACGAGAGGCATTCGTCAAAATGCTTTCAGATGATCATGAACATGCCAGGCTAGAGGCTATTTTTGGATTAGCTGAAAGAAAAGATAGTCGTGTGGTAAAAACAATAATTAATGAGTTAGAGAAAGATATAATTTTTGACGAACTTATTGTTGTCGCGGGAGATTTAGGGAGTAAAAGATTCCTTCCTGTTCTTAAAAAATTATTGTCTGAATTTAATGATGAAAAAACCATTGGGAAAATAAAAATAGCAATACAAAAAATTACAAGTCCCTATGAATTTTAA",
      "translation": "MEIIDKNKKRRENRETFLYAKYKAYTLNQLIPLLFKKNSLTRQAAIFRLQIIGTDEVFTFAVNLCQSEGKQERKTGISILSQLSMSPEHLTQSFNLVEALLEKETSANVRAAAVNAIGHFCRRNPSFNSRAPELLTRTTYDKSVNTRCATAAALSEINNIKAIPLLLSLLNDSNGDVRNWAAFSVNTNEYDSKEIREAFVKMLSDDHEHARLEAIFGLAERKDSRVVKTIINELEKDIIFDELIVVAGDLGSKRFLPVLKKLLSEFNDEKTIGKIKIAIQKITSPYEF",
      "product": ""
     },
     {
      "start": 3943856,
      "end": 3944257,
      "strand": -1,
      "locus_tag": "ctg1_3641",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3641</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3641</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,943,856 - 3,944,257,\n (total: 402 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3641\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3641\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3641\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3641\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAACGTGTCACCATTACTCTCGATGACGATTTACTGGAAACGCTGGATAACCTGAGTCAGCGCCGTGGTTACAACAACCGCTCGGAAGCCATCCGCGATATTTTGCGCGGCGCCCTGGCGCAAGAAAGCACTCAACAGCACGGTACTGAGGGTTTTGCGGTTCTCTCTTATGTGTATGAGCATGAGAAGCGTGATTTAGCCAGCCGTATCGTCTCGACCCAGCACCATCACCACGATCTCTCTGTTGCCACGCTGCATGTACATATCAATCACGACGATTGCCTGGAAATCGCCGTGCTGAAAGGTGACATGGGCGACGTACAACATTTTGCCGATGACGTTATTTCCCAGCGCGGCGTACGGCACGGGCATTTGCAGTGCTTACCGAAGGAAGATTGA",
      "translation": "MQRVTITLDDDLLETLDNLSQRRGYNNRSEAIRDILRGALAQESTQQHGTEGFAVLSYVYEHEKRDLASRIVSTQHHHHDLSVATLHVHINHDDCLEIAVLKGDMGDVQHFADDVISQRGVRHGHLQCLPKED",
      "product": ""
     },
     {
      "start": 3944297,
      "end": 3944881,
      "strand": -1,
      "locus_tag": "ctg1_3642",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3642</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3642</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,944,297 - 3,944,881,\n (total: 585 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1012:4&#39;-phosphopantetheinyl transferase (Score: 103.8; E-value: 1.3e-31)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3642\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3642\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3642_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3642\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3642\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTATCGAATCGTTCTGGGAAAAGTATCGACCTTAAGCGCAGCGGCACTGCCATCCGCGCTTATCGAGCAGGCACCGCAGGGTGCCCGCCGTGCACGCTGGCTTGCTGGCCGTGCACTGCTTTCCCATGCGCTTTCGCCACTGCCAGAAATTGTCTATGGCGAACAGGGCAAACCCGCCTTTTCCCCGGAGACTGCACTCTGGTTTAACCTCAGTCATAGCGGCGACGATATCGTGTTGTTGTTAAGCGATGAAGGCGAAGTCGGTTGCGATATCGAAGTCATCCGTCCGCGTGCACAATGGCGTTCGCTGGCGAATGCGGTGTTCAGCCAGGGCGAACATGAGGAACTGGAAGCAGAACATCCCGATCACCAACTCATGGCGTTCTGGCGTATCTGGACGCGAAAAGAAGCCATCGTTAAACAGCGTGGCGGCAGCGCCTGGCAAATTGTCAGCATCGACAGTACACAACAATCGGCGCTCTCAGTCAGCCATTGTCAGTTTGGTTCATTGATCCTCGCAGTCTGCACGCCCACACCATTTGCTCTTACTCATAACGTTCTACAGCAGGTAGAATCACTGTAA",
      "translation": "MYRIVLGKVSTLSAAALPSALIEQAPQGARRARWLAGRALLSHALSPLPEIVYGEQGKPAFSPETALWFNLSHSGDDIVLLLSDEGEVGCDIEVIRPRAQWRSLANAVFSQGEHEELEAEHPDHQLMAFWRIWTRKEAIVKQRGGSAWQIVSIDSTQQSALSVSHCQFGSLILAVCTPTPFALTHNVLQQVESL",
      "product": ""
     },
     {
      "start": 3944883,
      "end": 3946112,
      "strand": -1,
      "locus_tag": "ctg1_3643",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3643</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3643</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,944,883 - 3,946,112,\n (total: 1230 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) arylpolyene: APE_KS1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 295.9; E-value: 8.3e-90)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-ctg1_3643 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>PKS_KS</strong> (83..408)</dt>\n   <dd>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3643\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3643\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3643_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3643\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3643\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACACGTCGCGTAGTGATTACAGGAATGGGCGGCGTGACTGCCTTTGGTGAAAACTGGCAGGACGTTTCTGCACGCTTACTGGCGTATGAAAATGCGGTGCGCAAAATGCCGGAGTGGCAGGTCTATGATGGTCTGCATACCCTGCTTGGCGCGCCTGTTGATGATTTCACGCTGCCGGAGCACTACACCCGCAAGCGTATCCGTGCGATGGGCCGCGTGTCGCAAATGTCGACCCGTGCCAGCGAGCTGGCGTTAGAGCAGGCAGGGTTGATTGGCGATCCGATATTAACCAGCGGTGAAACGGGCATTGCGTACGGTTCATCGACCGGCAGTACCGGTCCGGTGAGCGAGTTCGCCACCATGCTGACGGAAAAGCACACCAATAACATCACTGGCACCACCTATGTGCAGATGATGCCGCACACCACCGCCGTTAATACCGGGCTATTTTTTGGCCTGCGCGGACGGGTGATCCCAACCTCCAGCGCCTGTACCTCCGGCAGCCAGGCGATCGGCTACGCGTGGGAAGCCATTCGTCACGGTTATCAAACGGTAATGGTTGCTGGTGGCGCCGAAGAGTTATGCCCTTCAGAAGCGGCGGTGTTTGATACGCTTTTCGCCACCAGCCAGCACAATGACGCGCCGAAAACCACGCCGTCGCCGTTCGATGAAAACCGCGACGGGCTGGTGATTGGCGAAGGCGCAGGCACGCTCATTCTCGAAGAACTGGAGCACGCCAAAGCGCGCGGCGCGACCATTTACGGTGAAATCGTTGGCTTTGCCACCAACTGCGACGCGGCACATATTACCCAGCCTCAGCGTGAGACCATGCAATATTGTATGGAAAAATCGTTAAAAATCGCCGGGTTAAGTGCAAGTGATATCGGCTATATTTCGGCGCATGGTACGGCGACTGATCGTGGTGATGTAGCAGAAAGCCAGGCGACGGTAGCAATTTATGGCGATAACGTACCGATCTCCTCGCTTAAAAGTTATTTTGGGCATACCCTTGGTGCCTGCGGAGCACTCGAAGCCTGGATGAGCTTACAAATGATGCGTGAAGGCTGGTTTGCGCCTACGCTAAATTTGAGCCAGCCAGATGCGAACTGCGGTGCGCTGGATTACATCATGGGTGAAGCCCGCAAGATTGATTGTGAGTTTTTGCAGAGTAACAACTTTGCCTTTGGTGGCATTAATACCTCCATCATCATAAAACGTTGGCCCTGA",
      "translation": "MTRRVVITGMGGVTAFGENWQDVSARLLAYENAVRKMPEWQVYDGLHTLLGAPVDDFTLPEHYTRKRIRAMGRVSQMSTRASELALEQAGLIGDPILTSGETGIAYGSSTGSTGPVSEFATMLTEKHTNNITGTTYVQMMPHTTAVNTGLFFGLRGRVIPTSSACTSGSQAIGYAWEAIRHGYQTVMVAGGAEELCPSEAAVFDTLFATSQHNDAPKTTPSPFDENRDGLVIGEGAGTLILEELEHAKARGATIYGEIVGFATNCDAAHITQPQRETMQYCMEKSLKIAGLSASDIGYISAHGTATDRGDVAESQATVAIYGDNVPISSLKSYFGHTLGACGALEAWMSLQMMREGWFAPTLNLSQPDANCGALDYIMGEARKIDCEFLQSNNFAFGGINTSIIIKRWP",
      "product": ""
     },
     {
      "start": 3946109,
      "end": 3946840,
      "strand": -1,
      "locus_tag": "ctg1_3644",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3644</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3644</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,946,109 - 3,946,840,\n (total: 732 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 214.2; E-value: 3.4e-65)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3644\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3644\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3644_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3644\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3644\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTCGTTCAGTTCTGGTTACTGGTGCCAGCAAAGGCATTGGTCGCGCCATCGCCTGCCAACTGGCGGCAGACGGCTTTAATATTGGCGTTCACTATCACCGTGACGCCGCAGGCGCTCAGGAAACGCTGAATACCATTGTCGCCAACGGTGGTAACGGGCGTTTGCTCAGTTTCGACGTCGCAAACCGCGAACAGTGTCGGGAAGTGCTGGAGCACGAGATCGCGCAACACGGTGCCTGGTACGGCGTGGTTAGTAACGCCGGGATCGCCCGCGATGCCGCTTTTCCGGCTTTAAGCGATGACGACTGGGATGCGGTGATCCACACCAACCTCGACAGTTTCTACAACGTCATTCAGCCGTGCATTATGCCGATGATCGGCGCACGCCAGGGTGGACGCATCATCACGCTGTCCTCGGTTTCCGGCGTAATGGGCAATCGCGGCCAGGTGAACTACAGCGCTGCCAAAGCCGGAATTATCGGCGCAACAAAAGCACTGGCTATCGAACTCGCGAAGCGCAAAATCACCGTCAACTGCATCGCGCCGGGGCTTATTGATACCGGGATGATCGAAATGGAAGAGAGCGCTCTGAAAGAGGCAATGTCGATGATCCCCATGAAACGCATGGGCCAGGCGGAAGAAGTTGCCGGGCTTGCCAGCTATTTAATGTCTGATATTGCGGGTTACGTCACCCGCCAGGTTATTTCCATCAACGGAGGGATGTTATGA",
      "translation": "MSRSVLVTGASKGIGRAIACQLAADGFNIGVHYHRDAAGAQETLNTIVANGGNGRLLSFDVANREQCREVLEHEIAQHGAWYGVVSNAGIARDAAFPALSDDDWDAVIHTNLDSFYNVIQPCIMPMIGARQGGRIITLSSVSGVMGNRGQVNYSAAKAGIIGATKALAIELAKRKITVNCIAPGLIDTGMIEMEESALKEAMSMIPMKRMGQAEEVAGLASYLMSDIAGYVTRQVISINGGML",
      "product": ""
     },
     {
      "start": 3946855,
      "end": 3947304,
      "strand": -1,
      "locus_tag": "ctg1_3645",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3645</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3645</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,946,855 - 3,947,304,\n (total: 450 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3645\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3645\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3645_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3645\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3645\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGCCACTATTTATCACCCGGCGCTTATCTGCCCCACGATGCGCCCATGTTGCTGCTGGAAGAAGTGGTGAGCGTCAGCGATGACAGCGCCGTGTGCCGCGTGACGGTTTCGCCCAGTGGTGTACTGGAACCGTTTCTCGACCCGGACGGCAATCTCCCTGGCTGGTTTGCCCTTGAACTGATGGCGCAAACCGTCGGCGTCTGGTCTGGCTGGCATCGCCACCAGCAGGGCAAAAACAGTATTGAGTTAGGGATGGTACTGGGCGCGCGTGAATTGCTTTGCGCCGCTGGCATTCTGCCCGCAGGCCAGACGCTGACCATTACCGTCAAACTGCTGATGCAAGATGAACGCTTCGGTAGTTTTGAGTGCAGCATCAACGACGGCGAGGCAACGGGCCGCATTAACACCTTCCAGCCGACCGCGGAAGAACTTACCACCCTGTTTTAA",
      "translation": "MSHYLSPGAYLPHDAPMLLLEEVVSVSDDSAVCRVTVSPSGVLEPFLDPDGNLPGWFALELMAQTVGVWSGWHRHQQGKNSIELGMVLGARELLCAAGILPAGQTLTITVKLLMQDERFGSFECSINDGEATGRINTFQPTAEELTTLF",
      "product": ""
     },
     {
      "start": 3947301,
      "end": 3948470,
      "strand": -1,
      "locus_tag": "ctg1_3646",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3646</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3646</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,947,301 - 3,948,470,\n (total: 1170 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) arylpolyene: APE_KS2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 206.2; E-value: 1.5e-62)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-ctg1_3646 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>PKS_KS</strong> (138..386)</dt>\n   <dd>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3646\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3646\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3646_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3646\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3646\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTTATATTTCCGCCGTCGGCATGATCAACGCCCTGGGAAATAACCTTGATGAGATCGCAGCCAACCTGACTCGTGGTTCCGCTCCCGGCATGCGCCCACGCGCAGGCTGGTTGCAGGGGCATCCGCAGACGGTCCTGGCTGGCGTGGATGGCGAGCTTCCGCTTATCCCGGAAAAATTCGCTGCGCACCGCTCGCGCAACAATCAGGTCCTGCTGGCGGCGCTGGCGCAGATCCAGCCGCAGGTTGATGACGCTATCGCGAAATATGGCCGCGAGCGCATCGCGATTGTGCTTGGCACCAGCACCTCCGGCCTGCATGAAGGTGACACGCACGTTAACCTGCGCACCCACGGGCAGCCAAGCACCACATGGCACTATGCACAACAAGAACTCGGCGATCCGTCGCGTTTTCTCAGCCACTGGCTGGCGCTCGACGGCCCGGCATATACCCTTTCAACCGCCTGCTCTTCCAGCGCCAGAGCGATGATCAGCGGGCGCAGGCTTATCGAAGCGGGGCTGGTCGATGCTGCCATTGTGGGTGGCGCAGACACCCTGAGCCGGATGCCGATTAACGGTTTTCACAGTCTCGAATCGCTGTCGCCAACCTTATGTCAGCCGTTCGGCCGTGACCGTGCGGGCATCACCATTGGCGAAGGCGCGGGGCTAATGCTGCTGACCCGTGAACCGCAGCCCATCGCGTTGCTGGGCGTTGGTGAATCGAGCGACGCTTACCATATTTCGGCCCCGCATCCGCAGGGCGAAGGGGCAATCCGCGCTATTAACCAGGCGCTGACCGATGCGCAGCTTACGCCAGATGACGTCGGCTATATCAACCTGCACGGCACCGCCACACAACTCAACGATCAGATTGAATCAATAGTGGTTAACGCCCTGTTTGGCGAACGCGTACCGTGCAGCTCCACCAAACATTTGACCGGACACACGCTGGGCGCGGCGGGCATTACCGAGGCGGCAATCAGTATGTTGATCTTACAGCGTGATTTACCGCTGCCCGCTCAGGACTTCAGCCTGTCGCCACGCGATCCCACGCTACCACCGTGCGGCATTATCGAAAAACCACAGCCGCTGGCACGTCCGGTGATCCTGTCCAATTCTTTCGCCTTTGGCGGCAATAACGCCAGCATTCTGCTCGGGAGGGTTTCGTGA",
      "translation": "MIYISAVGMINALGNNLDEIAANLTRGSAPGMRPRAGWLQGHPQTVLAGVDGELPLIPEKFAAHRSRNNQVLLAALAQIQPQVDDAIAKYGRERIAIVLGTSTSGLHEGDTHVNLRTHGQPSTTWHYAQQELGDPSRFLSHWLALDGPAYTLSTACSSSARAMISGRRLIEAGLVDAAIVGGADTLSRMPINGFHSLESLSPTLCQPFGRDRAGITIGEGAGLMLLTREPQPIALLGVGESSDAYHISAPHPQGEGAIRAINQALTDAQLTPDDVGYINLHGTATQLNDQIESIVVNALFGERVPCSSTKHLTGHTLGAAGITEAAISMLILQRDLPLPAQDFSLSPRDPTLPPCGIIEKPQPLARPVILSNSFAFGGNNASILLGRVS",
      "product": ""
     },
     {
      "start": 3948472,
      "end": 3949056,
      "strand": -1,
      "locus_tag": "ctg1_3647",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3647</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3647</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,948,472 - 3,949,056,\n (total: 585 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3647\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3647\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3647_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3647\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3647\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCAAATCCACCTTCTGGCGAGCGTTCGCCCTGACCGCTACGCTTATCCTCACCGGCTGTAGCCACTCGCAATCGGAACAGGAAGGCCGCCCGCAGGCGTGGCTGCAACCTGGCACACGCATCACGCTGCCTGCGCCGGGGATATCGCCCGCCGTCAATTCCCAACAACTGTTGACTGGCAGCTTCAACGGCAAAACCCAGTCGCTGTTGGTGATGCTTAATGCCGACGACCAGAAAATCACCCTTGCCGGACTGTCATCAGTCGGCATTCGTCTGTTTCTGGTGACCTACGATGCGCAAGGGCTACGCGCCGAGCAATCCATCGTCGTCCCGCAACTGCCGCCCGCAAGTCAGGTGCTGGCTGACGTAATGCTCAGCCACTGGCCGATTAGCGCCTGGCAACCGCAACTCCCCGCTGGATGGACGCTTCGCGACAACGGTGACAAACGCGAACTGCGTAACGCCAGTGGCAAACTGGTCACGGAAATCACTTATTTGAATCGCAAAGGAAAACGCGTGCCAATCAGCATTGAGCAGCATGTCTTTAAATACCACATCACCATTCAATACTTAGGTGACTGA",
      "translation": "MIKSTFWRAFALTATLILTGCSHSQSEQEGRPQAWLQPGTRITLPAPGISPAVNSQQLLTGSFNGKTQSLLVMLNADDQKITLAGLSSVGIRLFLVTYDAQGLRAEQSIVVPQLPPASQVLADVMLSHWPISAWQPQLPAGWTLRDNGDKRELRNASGKLVTEITYLNRKGKRVPISIEQHVFKYHITIQYLGD",
      "product": ""
     },
     {
      "start": 3949053,
      "end": 3951371,
      "strand": -1,
      "locus_tag": "ctg1_3648",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3648</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3648</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,949,053 - 3,951,371,\n (total: 2319 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3648\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3648\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3648_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3648\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3648\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGAACGCCAACGTTTTGCCGCCCAGTAAACGCCCCGCGCTGTTATGGGGGCTAGTCTGCCTGGTCATGGCGGCGGCGTTGCTGATCCTGCTGCCGCAATCACGGCTGAACAGTAGCGTGCTGGCTATGTTACCCAAACAGGCGATGGGCGATATTCCCCCAGCGCTGAATGACGGCTTTATGCAGCGTCTGGACCGCCAACTGGTGTGGCTGGTCAGCCCCGGTAAAGAGGCTAATCCCAGGGTCGCTCAGGAGTGGCTGACGCTGCTGCAAAAATCCGCTGCGCTCGGCGACGTTAAAGGACCAATGGATGCCGCCAGCCAGCAAGCGTGGGGAGCGTTTTTCTGGCAGCACCGCAACGGCCTGATTGACCCCGACACCCGCGCCCGCCTGCAAAACGGCGGCGAAGCGCAGGCGCAGTGGATCCTCTCCCAGCTTTATTCCGCATTCTCCGGGGTAAGCGGCAAGGAGCTGCAAAACGATCCGCTGATGTTAATGCGCGGCTCGCAGCTGGCGATGGCGAAAAACGGCCAGCGTTTGCGGCTGATGGACGGCTGGCTGGTGACGCAGGATCCCCAGGGCAACTACTGGTATCTGCTGCACGGTGAACTGGCGGGATCGTCGTTTGATATGCAGCAAACCCACCAGCTCATCACGACCCTGAATACGCTGGAAAAGGATCTGAAAACGCGTTACCCACAGGCGCAGTTGCTCTCGCGCGGCACGGTATTTTACAGCGATTACGCCAGTCAACAGGCGAAGCAGGATATCTCAACCCTGGGCGTGGCAACGCTGCTGGGGGTGATATTACTGATTGTGGCGGTGTTCCGCTCTTTGCGCCCATTGTTGCTTTGCGTGATTTCCATCGGCATCGGCGCGCTGGCGGGAACGGTCGCCACTTTATTGATTTTCGGTGAATTACACCTGATGACGCTGGTGATGAGCATGAGCGTTATCGGCATTTCCGCTGACTACACGCTCTATTACCTCACCGAACGAATGGTGCACGGCAACGACGTTTCGCCGTGGCAAAGCCTGGCGAAAGTACGCAATGCCCTGCTGCTGGCGCTGCTCACAACCGTGGCGGCATATCTGATTATGATGCTCGCCCCCTTCCCCGGCATTCGCCAGATGGCGATTTTTGCCGCCGTCGGGTTGAGCGCCTCCTGTCTGACCGTCCTGTTCTGGCATCCGTGGCTGTGCCGTGGTCTGCCGGTGCGCCCGGTTCCGGCGATGGCGCTGATGCTACGCTGGCTGGCAGCGTGGCGGCGCAATAAAAAACTGTCGCGGGGTCTGCCCGTTGCGCTGGCGCTGTTTTCGCTGGCGGGGATGTCAATGCTGCGCGTCGATGACGATATCTCGCAGTTACAGGCGCTACCGCAGCATATTCTGGCGCAGGAAAAAGCCATTACCGCCCTGACCGGGCAGAGCGTCGATCAAAAATGGTTTGTGGTTTACGGCGACTCCCCACAGCAAACATTGCGGCGACTGGAGAAATATACCGCCTCACTTGAGTATGCGAAAAAAGAGGGGCTTATCAGCAACTACCGCACTATTCCGCTGAACTCCCTGGCGCGGCAGGAGGAAGACTTAGACCTGCTGAAAACGGCTGCCCCGACGGTAACAAAAGCACTGCAAAATGCAGGGCTGACGGCGGTGAAACCAGATCTCAACGCCATGCCGGTGAAGGTCGATGAATGGCTGGCAAGCCCCGCCAGTGAAGGCTGGCGTCTGCTGTGGCTGACGCTGGAAAACGGCGAAAGCGGTGTACTGGTGCCGGTTGAAGGGGTTAAAAGTAGCGCATTGTTGCAGGAAATCGCCAGCTATTACCCTTGCGGCATTGCCTGGGTTGATCGCAAAAGCTCCTTTGATGAATTGTTCGCACTTTACCGCTACGTCTTAACCGGCTTGTTGCTGGTGGCGCTGGCAGTGATTGCCTGCGGCGCAGTGGCCCGTCTCAGCTGGCGCAAAGGGATTATCAGCCTGGTGCCTTCGGTGCTTTCGCTGGGCTGTGGTCTGGCGGTGCTGGCGATGAGCGGGCAGGCGGTGAATCTCTTTTCGCTGCTGGCGCTGGTGCTGGTGCTTGGCATCGGTATCAACTACACGCTGTTTTTCAGTAATCCGCGCGGTACACCGTTAACTTCGCTACTGGCGATAGCGCTGGCAATGCTCACCACCTTGCTGACGCTGGGAATGTTGGTATTCAGCGCCACCCAGGCCATCAGCAGTTTTGGCATTGTGCTGGTGAGCGGTATTTTCACCGCCTTCCTGCTTTCGCCGCTGGCTATGCCCGATAAAAAGAGAACAAAAAAATGA",
      "translation": "MTNANVLPPSKRPALLWGLVCLVMAAALLILLPQSRLNSSVLAMLPKQAMGDIPPALNDGFMQRLDRQLVWLVSPGKEANPRVAQEWLTLLQKSAALGDVKGPMDAASQQAWGAFFWQHRNGLIDPDTRARLQNGGEAQAQWILSQLYSAFSGVSGKELQNDPLMLMRGSQLAMAKNGQRLRLMDGWLVTQDPQGNYWYLLHGELAGSSFDMQQTHQLITTLNTLEKDLKTRYPQAQLLSRGTVFYSDYASQQAKQDISTLGVATLLGVILLIVAVFRSLRPLLLCVISIGIGALAGTVATLLIFGELHLMTLVMSMSVIGISADYTLYYLTERMVHGNDVSPWQSLAKVRNALLLALLTTVAAYLIMMLAPFPGIRQMAIFAAVGLSASCLTVLFWHPWLCRGLPVRPVPAMALMLRWLAAWRRNKKLSRGLPVALALFSLAGMSMLRVDDDISQLQALPQHILAQEKAITALTGQSVDQKWFVVYGDSPQQTLRRLEKYTASLEYAKKEGLISNYRTIPLNSLARQEEDLDLLKTAAPTVTKALQNAGLTAVKPDLNAMPVKVDEWLASPASEGWRLLWLTLENGESGVLVPVEGVKSSALLQEIASYYPCGIAWVDRKSSFDELFALYRYVLTGLLLVALAVIACGAVARLSWRKGIISLVPSVLSLGCGLAVLAMSGQAVNLFSLLALVLVLGIGINYTLFFSNPRGTPLTSLLAIALAMLTTLLTLGMLVFSATQAISSFGIVLVSGIFTAFLLSPLAMPDKKRTKK",
      "product": ""
     },
     {
      "start": 3951340,
      "end": 3951945,
      "strand": -1,
      "locus_tag": "ctg1_3649",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3649</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3649</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,951,340 - 3,951,945,\n (total: 606 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3649\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3649\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3649_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3649\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3649\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAATTTTTACCGCTGCTGGCGCTGCTGATTAGCCCGTTTGTGAGCGCCCTGACCCTGGACGATCTTCAGCAACGCTTTACCGAACAACCGGTGATCCGCGCCCATTTTGATCAAACCCGGACGATTAAAGATCTGCCGCAGCCGCTGCGATCTCAGGGTCAGATGTTGATCGCCCGCGACCAGGGGTTATTGTGGGATCAAACCTCACCGTTCCCCATGCAGCTATTGCTGGATGATAAACGCATGGTGCAGGTGATCAACGGTCAGCCGCCGCAAATCATCACGGCAGAAAACAACCCGCAGATGTTCCAGTTTAACCACCTGCTGCGCGCGCTGTTCCAGGCCGATCGCAAAGTGCTGGAACAAAACTTCCGCGTCGAATTTGCTGACAAAGGCGAAGGCCGCTGGACGCTGCGCCTGACGCCGACCACCACGCCGCTGGATAAAATTTTCAACACCATCGATCTCGCCGGGAAAACCTATCTGGAGAGCATTCAACTTAATGATAAACAGGGCGATCGCACCGATATTGCTCTTACCCAACATCAACTGACGCCAGCGCAACTGACCGATGACGAACGCCAACGTTTTGCCGCCCAGTAA",
      "translation": "MKFLPLLALLISPFVSALTLDDLQQRFTEQPVIRAHFDQTRTIKDLPQPLRSQGQMLIARDQGLLWDQTSPFPMQLLLDDKRMVQVINGQPPQIITAENNPQMFQFNHLLRALFQADRKVLEQNFRVEFADKGEGRWTLRLTPTTTPLDKIFNTIDLAGKTYLESIQLNDKQGDRTDIALTQHQLTPAQLTDDERQRFAAQ",
      "product": ""
     },
     {
      "start": 3951942,
      "end": 3952364,
      "strand": -1,
      "locus_tag": "ctg1_3650",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3650</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3650</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,951,942 - 3,952,364,\n (total: 423 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3650\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3650\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3650_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3650\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3650\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCTTAACGATCCCCGATTTACCGCTGAAGTCGAGCTGATCATTCCATTTCACGACGTCGATATGATGGGCGTGGCCTGGCACGGTAACTATTTTCGCTACTTTGAAGTGGCCCGCGAGGCGCTGCTCAACCAGTTCAATTACGGCTATCGGCAGATGAAAGAGTCCGGTTATTTGTGGCCAGTGGTCGATGCGCGGGTGAAATATCGCCACGCCCTCACCTTTGAGCAACGCATCCGCGTGCGTGCGCATATCGAAGAGTTCGAAAACCGTCTGCGGATTGGCTATCAGATTTTCGATGCCGAAACGGGCAAACGCGCCACCACCGGATACACCATTCAGGTCGCGGTCGACGAGCAAAGTCGCGAACTGTGCTTTGTCAGCCCCGATATTCTGTTTGAACGCATGGGAGTCAAACCATGA",
      "translation": "MLNDPRFTAEVELIIPFHDVDMMGVAWHGNYFRYFEVAREALLNQFNYGYRQMKESGYLWPVVDARVKYRHALTFEQRIRVRAHIEEFENRLRIGYQIFDAETGKRATTGYTIQVAVDEQSRELCFVSPDILFERMGVKP",
      "product": ""
     },
     {
      "start": 3952368,
      "end": 3954044,
      "strand": -1,
      "locus_tag": "ctg1_3651",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3651</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3651</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,952,368 - 3,954,044,\n (total: 1677 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1123:polyprenol-monophosphomannose synthase ppm1 (Score: 85.3; E-value: 8.7e-26)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3651\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3651\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3651_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3651\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3651\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCGGTAAACTTTTCTCCCTGCGTGTTGATCCCCTGCTACAACCACGGCGCAATGATGCCGGGCGTGCTGGCGCGTCTTAAGCCATTTAATCTGCCCTGTATTGTGGTGGATGACGGCAGCGATGCCGCCACGCAACAGCAACTGGATAATCTGGTTGCCGAACAGCCTGGCGTGACCTTAATTCGCCTGGCAGAAAACGCAGGCAAAGGCGCGGCGGTAATGCGCGGCTTACAGGCGGCTGCAGACGCGGGGTTCAGCCATGCGGTACAGGTAGATGCCGACGGTCAGCACGCGATTGAAGATATCCCCAAACTGCTGGCACTCGCTGAACAACACCCTGCGGCACTGATCTCCGGCCAGCCGATTTACGATGACTCCATCCCCCGCTCACGGCTGTACGGGCGCTGGGTCACCCACGTCTGGGTGTGGATCGAAACGCTCTCCCTGCAACTGAAAGACAGCATGTGCGGCTTTCGCGTTTATCCAGTCGTGCCAACGCTGCAACTGGCAAAACACGCCACCATCGGCAAGCGGATGGATTTCGACACCGAAGTGATGGTGCGCCTCTACTGGCAGGGAAACACCAGTTATTTCGTGCCGACCCGCGTCACCTATCCGCTGGACGGGCTTTCGCATTTTGATGCCCTGAAAGATAACGTCCGCATCTCGCTGATGCACACACGTCTGTTTTTCGGCATGTTGCCGCGTATTCCTTCACTGCTGATGCGCCACTCTTCCAGCCACTGGGCGCGGCAGAGCGAAGTGAAAGGATTATGGGGAATGCGCCTGATGCTGCTGGTCTGGCGTCTGCTGGGAAAAACAGCGTTTAGCGCGCTGCTTTACCCGGTGGTGGGCGTCTACTGGCTCACCGCCAGCCGGGCGCGCAAAGCATCGCAAGACTGGCTCGCCCGTGTGCGCCAGCATCAACCACAGGCAGCAAAACTCAACAGCTATCAGCACTTTCTACGTTTCGGCAACGCCATGCTCGACAAAATCGCCAGCTGGCGCGGCGAGCTACAACTCGGGCGTGATGTGCTGTTTGCACCAGGCGCAGAAGCGGCACTTAACGTCAGCGATCCGCGAGGCAAATTGCTGCTGGCCTCGCATCTTGGCGATGTGGAAGTGTGCCGGGCGCTGGCAAAAATTCAGGGCTACAAAACCATTAACGCGCTGGTGTTTAGCGAAAACGCCCAACGTTTTAAACAGATAATGCAGGAGATGGCCCCGCAGGCAGGCATCAACCTGCTCCCGGTGACGGATATCGGCCCGGACACCGCCATCCTGCTAAAAGAGAAGCTGGATAACGGCGAATGGGTGGCGATTGTTGGTGACCGCATCGCCATCAACCCGCAACGCGGCGGCGACTGGCGCGTCTGCTGGAGTTCGTTTATGGGCCAGCCTGCGCCCTTCCCACAGGGGCCGTTTATTCTCGCCTCTATTTTGCGCTGCCCGGTGAATCTGATTTTCGCCCTGCGCCAGCACGGCAAGCTGCATATTCACTGCGAAACCTTTGCCGACCCGCTGCTGTTGCCGCGTGGCGAACGCAAGCAGGCGCTGCAAAACGCTATCGATCATTACGCCGCGCGTCTGGAACATCACGCGCTCCAGTCGCCCCTCGACTGGTTTAATTTTTTCGATTTCTGGCAACTGCCGGAAGTCCAGGACAAGGAGTAA",
      "translation": "MSVNFSPCVLIPCYNHGAMMPGVLARLKPFNLPCIVVDDGSDAATQQQLDNLVAEQPGVTLIRLAENAGKGAAVMRGLQAAADAGFSHAVQVDADGQHAIEDIPKLLALAEQHPAALISGQPIYDDSIPRSRLYGRWVTHVWVWIETLSLQLKDSMCGFRVYPVVPTLQLAKHATIGKRMDFDTEVMVRLYWQGNTSYFVPTRVTYPLDGLSHFDALKDNVRISLMHTRLFFGMLPRIPSLLMRHSSSHWARQSEVKGLWGMRLMLLVWRLLGKTAFSALLYPVVGVYWLTASRARKASQDWLARVRQHQPQAAKLNSYQHFLRFGNAMLDKIASWRGELQLGRDVLFAPGAEAALNVSDPRGKLLLASHLGDVEVCRALAKIQGYKTINALVFSENAQRFKQIMQEMAPQAGINLLPVTDIGPDTAILLKEKLDNGEWVAIVGDRIAINPQRGGDWRVCWSSFMGQPAPFPQGPFILASILRCPVNLIFALRQHGKLHIHCETFADPLLLPRGERKQALQNAIDHYAARLEHHALQSPLDWFNFFDFWQLPEVQDKE",
      "product": ""
     },
     {
      "start": 3954035,
      "end": 3954388,
      "strand": -1,
      "locus_tag": "ctg1_3652",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3652</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3652</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,954,035 - 3,954,388,\n (total: 354 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3652\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3652\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3652_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3652\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3652\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGCCCCATGAAATCGAGCGCCATCAGGCACAAGCGAATCACCTTGAGATTGTTTTGCATCTCAGGGCAGATCTGTTCTGGTTTCGCGGTCATTTTGCCGTACAACCATTACTCCCCGGCGTGGCACAAATCGACTGGGCGATGAGTTACGCGCTTGCCCTGCTCGCGCCCGGTTGGCGTTTTCACTCAATTCAGAACATCAAATTCCAGGCTCCATTGCTGCCGGATAACCGCGTCACACTCACGCTTAGCTGGCAGGAAGAACGCCAGATTCTGAGCTTTAGTTATCAGCGTCACGACGGTGACGCCCGCCACACCGCCAGTAGCGGGAAGATCCGCCTATGTCGGTAA",
      "translation": "MKPHEIERHQAQANHLEIVLHLRADLFWFRGHFAVQPLLPGVAQIDWAMSYALALLAPGWRFHSIQNIKFQAPLLPDNRVTLTLSWQEERQILSFSYQRHDGDARHTASSGKIRLCR",
      "product": ""
     },
     {
      "start": 3954375,
      "end": 3955736,
      "strand": -1,
      "locus_tag": "ctg1_3653",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3653</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3653</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,954,375 - 3,955,736,\n (total: 1362 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 74.5; E-value: 1e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3653\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3653\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3653_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3653\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3653\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGCAGACCTTACCGCTTGCACGCTGGCTGACTGCGCCACGCCCTGATGACACGCCCATTGCGTGGCTGGACGAAAGCACCTGGACGCTGAGCGATTTGCGTCACGATGTCGCGCAACTTATCTGCCGCTTGCAGCAACAGCCAGGTGAACGCTGGGCGCTGTGCTTTGAGAACAGCTATCTGTTTATCGTTGCCCTGCTCGCCACGCTACACGCCGGAAAAACACCGGTGCTTCCGGGGCATAACCGCGTTATCCAGCTTAATGAGCAACGTGAACTTTTTGATGGTGTGCTTAGCGACAGCGAACTTAACTGGCAAGGTTCATTGCTGTTGGTAGCAAGCTCCCCACAAGTCGCGACACAATCATTCACCTTTGCCGCTATAGCGCCTGACGCTTATATCGAGCTGTTTACCTCTGGTTCCACAGGGCAGCCGAAGCGGGTGATTAAACCTGTTCGTTTGTTGGACCGTGAAGCAGAACTGCTGGCTGAACGATTAGGTGCACGTCTTGCCGGAAGTCGTGTCGTCGGTTCCGTATTGCCGCAGCATTTGTACGGCCTGACTTTTCGCGTTTTCCTGCCCATGGCGCTGGGATTACCGCTCCATGCCGCCATGCTCTGGTATGTCGAACAGTTTGCCGCGTTGAGTCATCAGCATCGCTATATCTTCATCAGCAGTCCGGCATTTTTGAAGCGTCTGGATACACAGCTTTCCCCGCCCCCCGTTCAGGTGCTTCTTTCTGCTGGTGGTGAGCTACCGTGGCAGGACGTACAACACACCGCGAGCTGGCTGCGCGTCTGGCCTGATGAAATCTACGGCAGCACGGAAACCGGCGTCATCGCCTGGCGTTACCGCGAACAAGAGCAACGCCGCTGGCGGCCCTTTCCAGGTATGCAGTTCCAGGCCGAAGATGATGCCTTTCGTCTCTTTTCACCTCTGATGGAGGAAGATAGCGGCCTGTTACTCGACGATATCTTGCAGTTTAGCGAAGACGGCCAGTTCCATCTGATGGGGCGTCGCGGACGCATCGTTAAGATTGAAGAAAAACGCATTTCACTCCAGGAAGTAGAACAACGTCTGCTGGCGCTGGACGGTATTCACGAGGCGGCGGCAGTTCCCGTTACGCGCGGCGGGCGTCAGAGTATTGGCGTTTTGCTGGTGCTGAATGACGAAGCTCGCCTGCAATGGCAAAACGGCGGCGGGCACAGCCAGGAAATGGCCTGGCGGCGATTACTGCGCCCGACGCTGGAGCCAGTTGCTATTCCGCGTTACTGGCGCGTTATTGATGAAATGCCAGTAAACAGTATGAACAAGCGTGTCTATGCGCAATTACAGGAGTTATTTCATGAAGCCCCATGA",
      "translation": "MKQTLPLARWLTAPRPDDTPIAWLDESTWTLSDLRHDVAQLICRLQQQPGERWALCFENSYLFIVALLATLHAGKTPVLPGHNRVIQLNEQRELFDGVLSDSELNWQGSLLLVASSPQVATQSFTFAAIAPDAYIELFTSGSTGQPKRVIKPVRLLDREAELLAERLGARLAGSRVVGSVLPQHLYGLTFRVFLPMALGLPLHAAMLWYVEQFAALSHQHRYIFISSPAFLKRLDTQLSPPPVQVLLSAGGELPWQDVQHTASWLRVWPDEIYGSTETGVIAWRYREQEQRRWRPFPGMQFQAEDDAFRLFSPLMEEDSGLLLDDILQFSEDGQFHLMGRRGRIVKIEEKRISLQEVEQRLLALDGIHEAAAVPVTRGGRQSIGVLLVLNDEARLQWQNGGGHSQEMAWRRLLRPTLEPVAIPRYWRVIDEMPVNSMNKRVYAQLQELFHEAP",
      "product": ""
     },
     {
      "start": 3955733,
      "end": 3956314,
      "strand": -1,
      "locus_tag": "ctg1_3654",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3654</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3654</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,955,733 - 3,956,314,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3654\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3654\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3654_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3654\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3654\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCGGGCATTCGCTCGCTACCGATGATTAAGCTGCTGACTGGATTATTGCTGCTCGCCTGGCCGTTTGTGATTTGGTTTGGCTTAGCGCATAACGGCCTGCACTGGTTGTTGCCGCTGATGGCGCTGCTGTTTTTGTTGCGCTTGCGCCAGACCCGTCGCCAGACCGGGCCACTACAAGCCGTCACGCAAATCGTCGCTGTCGTAGGCATCGCCTTGTGTGCCGCCAGCTTTCTGCTGAAAACGCACCAGCTACTGCTGTTTTACCCGGCAGTGGTTAACGCGGTCATGCTGGCGGTTTTTGGCGGTTCGCTGTGGTCGGCAATGCCAATTGTTGAGCGGCTGGCACGTTTGCAGGAGCCAGATCTCCCGGAAAAGGGCGTGCGCTATACCCGCCACGTCACGCAAATCTGGTGCGGCTTTTTCATCATCAACGGCGGAATTGCCCTCTTTACCGCGCTGCATGGCGATATGTCGTTATGGACTGCCTGGAACGGCATGATTGCTTATTTGTTAATGGGAACGTTAATGGCTGGTGAATGGCTGGTGCGCCGTCAGGTGATGAAAAGAGATCGCTCATGA",
      "translation": "MSGIRSLPMIKLLTGLLLLAWPFVIWFGLAHNGLHWLLPLMALLFLLRLRQTRRQTGPLQAVTQIVAVVGIALCAASFLLKTHQLLLFYPAVVNAVMLAVFGGSLWSAMPIVERLARLQEPDLPEKGVRYTRHVTQIWCGFFIINGGIALFTALHGDMSLWTAWNGMIAYLLMGTLMAGEWLVRRQVMKRDRS",
      "product": ""
     },
     {
      "start": 3956319,
      "end": 3956570,
      "strand": -1,
      "locus_tag": "ctg1_3655",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3655</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3655</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,956,319 - 3,956,570,\n (total: 252 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3655\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3655\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3655_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3655\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3655\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACAGAACAACAAACCGTCTATCAGGAAGTCTCAGCTCTGCTGGTTAAGCTGTTTGAAATCGATCCGCAAGACATCAAACCTGAAGCGCGCCTGTACGAAGATTTGGAGCTGGACAGTATCGACGCCGTTGACATGATTGTGCACCTGCAAAAGAAAACCGGTAAGAAAATCAAGCCGGAAGAGTTTAAAGCAGTGCGTACAGTCCAGGATGTCGTCGAGGCTGTAGAACGCCTGCTACAAGAAGCCTGA",
      "translation": "MTEQQTVYQEVSALLVKLFEIDPQDIKPEARLYEDLELDSIDAVDMIVHLQKKTGKKIKPEEFKAVRTVQDVVEAVERLLQEA",
      "product": ""
     },
     {
      "start": 3956582,
      "end": 3956839,
      "strand": -1,
      "locus_tag": "ctg1_3656",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3656</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3656</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,956,582 - 3,956,839,\n (total: 258 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3656\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3656\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3656_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3656\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3656\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAAGCGCTTTATCTTGAAATCAAAAACCTCATTATCTCTACTCTCAATCTGGATGAGCTTTCACCAGATGATATCGAAACCGAAGCGCCGTTGTTTGGTGATGGTTTAGGGCTGGACTCTATCGATGCCCTGGAACTGGGGCTGGCAGTGAAAAATGAATATGGCGTTGTACTTTCTGCGGAAAGTGAAGAGATGCGTCAGCACTTTTTCTCCGTCGCCACTCTGGCCTCTTTCATTGCTGCGCAACGTGCCTGA",
      "translation": "MQALYLEIKNLIISTLNLDELSPDDIETEAPLFGDGLGLDSIDALELGLAVKNEYGVVLSAESEEMRQHFFSVATLASFIAAQRA",
      "product": ""
     },
     {
      "start": 3956820,
      "end": 3957635,
      "strand": -1,
      "locus_tag": "ctg1_3657",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3657</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3657</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,956,820 - 3,957,635,\n (total: 816 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1141:acyltransferase (Score: 73.2; E-value: 3.3e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3657\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3657\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3657_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3657\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3657\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTAATCTGATGTCACGCCTGGAATGGACATGGCGACTGGTTATGACCGGGTTGTGTTTTGCCCTGTTTGGCCTCGGCGGACTACTACTCTCTGTGGTGTGGTTTAACGTACTGTTAGTTTTGGTGTGGAACACTTCCCGCCGCCGTCGTTTGGCGCGTCGCAGCATTGCCGCCAGTTTTCGCCTGTTTTTAACCGCCGCGAAAGGGCTTGGCGTGCTGGATTATCGTATTGATGGGGCTGAAATTTTACGTCAGGAACGCGGTTGCCTCGTCGTAGCTAATCATCCCACGCTTATCGATTACGTACTGCTGGCGTCAGTCATGCCAGAAACTGACTGCCTGGTGAAAAGCGCACTGTTAAAAAATCCTTTTCTTGGCGGCGTTGTGCGGGCGGCAGATTATTTAATCAACAGCGAAGCTGAAACCCTCTTACCCCGCTGCCAACAGCGACTGGCACAGGGTGACACTATTCTGATTTTCCCCGAAGGAACCCGAACTCGTCCCGGAGAAAAAATGACGCTACAACGTGGTGCAGCCAATATTGCGGTCCGTTGTGCCAGTGATTTACGCATCGTAACGATTCGTTGTAGCGAGCATCTACTTGATAAACAAAGTAAATGGTATGACGTTCCACCTGCTAAACCACTCTTTACCGTCGAAGTGGGTGAACGGATACAAATTAACCGTTTTTACGACGCAAACTCACAAGAACCGGCGCTGGCAGCAAGGCAGCTTAACCGGCATCTTTTGCTGCAATTACAACCAGGTACATTACCTCTCTCAGGAAAAAATGATGCAAGCGCTTTATCTTGA",
      "translation": "MSNLMSRLEWTWRLVMTGLCFALFGLGGLLLSVVWFNVLLVLVWNTSRRRRLARRSIAASFRLFLTAAKGLGVLDYRIDGAEILRQERGCLVVANHPTLIDYVLLASVMPETDCLVKSALLKNPFLGGVVRAADYLINSEAETLLPRCQQRLAQGDTILIFPEGTRTRPGEKMTLQRGAANIAVRCASDLRIVTIRCSEHLLDKQSKWYDVPPAKPLFTVEVGERIQINRFYDANSQEPALAARQLNRHLLLQLQPGTLPLSGKNDASALS",
      "product": ""
     },
     {
      "start": 3957632,
      "end": 3958354,
      "strand": -1,
      "locus_tag": "ctg1_3658",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3658</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3658</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,957,632 - 3,958,354,\n (total: 723 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3658\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3658\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3658_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3658\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3658\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAATTTGCATTAAACATTCTCGACTGGCAGGCAAGAGCGCCTGGACTTAGTGAAACGCTGCAATGGCAGGAGTGGTCACGTCAGCCTCAGGCAATTGACCCGACAGCACCGTTGGCAAAATTAAGTGAACTGCCAATGATGACCGCCCGCCGCCTCAGCTCCGGGAGCAAACTGGCTGTTGAATGCGGTCTGGCAATGCTACGCCGCCATCAAATAGACGCCGTTTTGTATACCAGTCGTCATGGCGAGCTGGAGCGCAATTACCGCATTGTTCATGCACTGGCAACCGAACAGGCGCTTTCTCCGACGGACTTCGCGCTCTCCGTACACAACTCTTCCGTGGGTAACCTGACCATTGCGGCCAAACAGCCGATCGTTTCGTCATCGCTTTCGGCTGGTCGCGATAGTTTCCAGCAAGGTTTGAGTGAAGTGCTTAGCCTGCTACAAGCGGGATACCAGCGTGTGTTGATGGTCGATTTTGATGGCTTTCTACCTGAGTTCTATCATCCGCAGCTCCCAGCAGAAATGCCGACCTGGCCATATGCTGTTGCGCTGGTGATTGAAGCTGGCGATGAGTGGCAATGTGAAACACAGCCAGCCATTGCGGGCAATGAAACAACACTGCCGCAAAGCATGTTGTTTTTACAGCACTATTTACAAAATTCAGATGCTTTTTCACTTCCTGGCGAGCGCGTACAGTGGCGCTGGAGCCGTGGATGA",
      "translation": "MKFALNILDWQARAPGLSETLQWQEWSRQPQAIDPTAPLAKLSELPMMTARRLSSGSKLAVECGLAMLRRHQIDAVLYTSRHGELERNYRIVHALATEQALSPTDFALSVHNSSVGNLTIAAKQPIVSSSLSAGRDSFQQGLSEVLSLLQAGYQRVLMVDFDGFLPEFYHPQLPAEMPTWPYAVALVIEAGDEWQCETQPAIAGNETTLPQSMLFLQHYLQNSDAFSLPGERVQWRWSRG",
      "product": ""
     },
     {
      "start": 3958397,
      "end": 3959455,
      "strand": -1,
      "locus_tag": "ctg1_3659",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3659</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3659</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,958,397 - 3,959,455,\n (total: 1059 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1042:O-methyltransferase (Score: 129.9; E-value: 2.1e-39)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3659\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3659\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3659_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3659\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3659\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTATCAACAGGATTCACTTAGCGCACTGGATGCGATTACCGAAGCTCAACGCATTGCCTTTGCCCCTATGCTTTTTCAAACTGCATTGTGTCTGCGTAACGCAGGTGTGCTGACTTATCTTGATAAACAAGGTAAATGTGGTGCCTCCCTGGCAGATATCACTGAAAATAGTCAAATCAATGAATATGCCGCCAGCGTTTTGTTAGATATGGGATTAAGCGGGCGAATAATTACCTGTAAAGAGGGAATATATTATCTGGCAAAGATCGGTCATTTCCTTTTGCATGACACCATGACCCGGGTAAATATGGATTTTACTCAGGACGTCTGTTATCAGGGGCTGTTCTTTTTGGCTGAATCTTTGAAAGAAGGGAAACCCTCTGGCTTAAAAGTATTTGGCGACTGGCCAACGATATATCCGGCACTTTCACAATTACCGGATGCCGCACGTGAAAGCTGGTTCGCTTTTGATCATTACTACTCTGATGGCGCATTTGACGCCGCATTGCCTTATGTATTCGCCAACAACCCTGCAACCCTGTACGATGTGGGCGGAAATACGGGTAAATGGGCCTTACGTTGCTGCCATTACAACGCAAATATCAACGTTACCCTATTAGATTTGCCACAACAAATTGCACTCGCGAAAGAAAATATTGAGAATGCAGGTTTTTCTCATCGCATAGATTTCCACGCGGTGGATATGCTAAGCGACGCGCCATTGCCAAATGGGGCTGATGTCTGGTGGATGAGTCAATTCCTGGATTGTTTTTCGCCAGAGCAAATTGTCGCCATTCTGACCAAAGTGGCAAATGTGATGAAACCCGGCGCAAAACTTTGCATTATGGAATTATTCTGGGATGCACAACGTTTTGAAGCCGCTTCATTTAGTCTGAATGCCTCTTCGCTCTACTTCACCTGCATGGCGAATGGCAATAGCCGGTTTTACAGTGCTGAAAAATTTTATGACTATCTGAATAAAGCAGGGTTCCAGGTAGAAGAACGCCACGATAATTTAGGCGTTGGGCATACTTTATTGATCTGCCAAAAGAAATAA",
      "translation": "MYQQDSLSALDAITEAQRIAFAPMLFQTALCLRNAGVLTYLDKQGKCGASLADITENSQINEYAASVLLDMGLSGRIITCKEGIYYLAKIGHFLLHDTMTRVNMDFTQDVCYQGLFFLAESLKEGKPSGLKVFGDWPTIYPALSQLPDAARESWFAFDHYYSDGAFDAALPYVFANNPATLYDVGGNTGKWALRCCHYNANINVTLLDLPQQIALAKENIENAGFSHRIDFHAVDMLSDAPLPNGADVWWMSQFLDCFSPEQIVAILTKVANVMKPGAKLCIMELFWDAQRFEAASFSLNASSLYFTCMANGNSRFYSAEKFYDYLNKAGFQVEERHDNLGVGHTLLICQKK",
      "product": ""
     },
     {
      "start": 3959525,
      "end": 3959914,
      "strand": -1,
      "locus_tag": "ctg1_3660",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3660</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3660</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,959,525 - 3,959,914,\n (total: 390 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3660\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3660\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3660_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3660\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3660\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAACACTACATGAAATGGTTTGCCGCAATTGCTGTTGTGGGTGCTTTAGCAGGTTGTGCTCGTACTGCACCAATTGACCAGGTCCACTCTACTGTCAGCGCTGGTCACACTCAGGATCAAGTGAAAAAAGCCATTCTTAAAGCAGGTGTAGAACGTCAATGGATAATGTCCGAAGCTGGACCTGGCGTAATTAAAGCACGTCAACAAAGCCGCGCTCACACTGCAGAAATTCGTATTAATTACACCGCATCCAGTTACGATATCAATTATGAAAATAGCCAGAATCTCCAGGCTTCCGGCGGTCAAATTCATAAAAATTATAATCGTTGGGTACGCAACCTCGATAAAGAAATTCAGTTGAATTTATCTGCGGGCGCAGGGCTGTAA",
      "translation": "MKHYMKWFAAIAVVGALAGCARTAPIDQVHSTVSAGHTQDQVKKAILKAGVERQWIMSEAGPGVIKARQQSRAHTAEIRINYTASSYDINYENSQNLQASGGQIHKNYNRWVRNLDKEIQLNLSAGAGL",
      "product": ""
     },
     {
      "start": 3960309,
      "end": 3961358,
      "strand": -1,
      "locus_tag": "ctg1_3661",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3661</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3661</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,960,309 - 3,961,358,\n (total: 1050 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3661\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3661\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3661\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3661\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAAACCTCTCAACCCGATAAAACGGGAATGCACATCTTACTGAAATTGGCCTCGCTGGTAGTAATCCTCGCAGGTATTCATGCTGCGGCAGATATCATTGTGCAACTGTTACTGGCGCTCTTTTTCGCCATCGTCCTCAACCCGCTCGTCACCTGGTTTATTCGTCGTGGAGTCCAGCGCCCCGTTGCCATTACGATCGTAGTAGTGGTTATGCTGATCGCACTTACCGCACTGGTCGGTGTGCTGGCGGCATCATTTAATGAATTTATCTCGATGTTGCCGAAGTTTAATAAGGAGCTGACGCGCAAGCTTTTTAAATTGCAGGAGATGTTACCTTTTCTCAATTTGCATATTTCACCAGAAAGAATGCTACAACGGATGGACTCGGAAAAAGTGGTAACCTTCACCACAGCGCTGATGACGGGGCTTTCCGGGGCAATGGCAAGCGTACTTCTGTTGGTGATGACCGTGGTTTTTATGCTGTTTGAAGTGCGCCACGTTCCTTACAAAATGCGTTTTGCGCTGAATAACCCACAGATTCACATCGCCGGATTACATCGCGCATTAAAAGGCGTTTCTCACTATCTTGCATTGAAGACGCTGTTAAGTTTATGGACAGGCGTAATCGTCTGGCTGGGGCTGGCACTGATGGGAGTTCAGTTCGCACTGATGTGGGCTGTACTGGCATTTTTGCTCAACTATGTGCCCAATATCGGCGCGGTGATCTCCGCCGTACCGCCGATGATCCAGGTGCTGCTGTTTAATGGTGTTTACGAATGCATTCTGGTCGGTGCGCTATTTTTAATCGTCCATATGGTTATTGGCAATATTTTAGAACCACGAATGATGGGCCATCGTCTGGGAATGTCGACACTGGTGGTGTTTCTTTCTTTGTTAGTCTGGGGCTGGCTGCTCGGCCCGGTCGGGATGTTACTTTCAGTACCCTTAACCAGCGTCTGTAAAATCTGGATGGAAACCACTAAGGGAGGCAGTAAACTGGCGATTTTACTGGGACCTGGTAGACCAAAAAGCCGATTACCAGGTTAA",
      "translation": "METSQPDKTGMHILLKLASLVVILAGIHAAADIIVQLLLALFFAIVLNPLVTWFIRRGVQRPVAITIVVVVMLIALTALVGVLAASFNEFISMLPKFNKELTRKLFKLQEMLPFLNLHISPERMLQRMDSEKVVTFTTALMTGLSGAMASVLLLVMTVVFMLFEVRHVPYKMRFALNNPQIHIAGLHRALKGVSHYLALKTLLSLWTGVIVWLGLALMGVQFALMWAVLAFLLNYVPNIGAVISAVPPMIQVLLFNGVYECILVGALFLIVHMVIGNILEPRMMGHRLGMSTLVVFLSLLVWGWLLGPVGMLLSVPLTSVCKIWMETTKGGSKLAILLGPGRPKSRLPG",
      "product": ""
     },
     {
      "start": 3961448,
      "end": 3962695,
      "strand": 1,
      "locus_tag": "ctg1_3662",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3662</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3662</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,961,448 - 3,962,695,\n (total: 1248 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1020:major facilitator transporter (Score: 58.6; E-value: 8.8e-18)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3662\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3662\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMLKMKLCSKYGVIVMPEPALNGLRLNLRIVSIVMFNFASYLTIGLPLAVLPGYVHDVMGFSAFWAGLVISLQYFATLLSRPHAGRYADLLGPKKIVMFGLAGCLLSGGAYFLAGSASSWPVLSLLLLCLGRVILGIGQSFTGTGSTLWGVGAVGSTHIGRVISWNGIVTYGAMAMGAPLGVLCYHWVGLQGLSLFIMAVALVALLLAIPRPAVKASKGKPLPFRAVLGRVWLYGMALAMASAGFGVIATFITLFYDAKGWDGAAFALTLFSCAFVGTRLLFPGGINRIGGLNVAMICFSVEIIGLLLVGVAMVPWMAKVGVLLAGAGFSLVFPALGVVAVKAVPQQNQGAALATYTVFMDLSLGITGPLAGLVMSWAGVSVIYLAAAGLVVIALLLTWRLKKRPPQPLSETASSS\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3662\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3662\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTAAAAATGAAACTCTGTTCTAAATACGGGGTAATCGTGATGCCCGAGCCCGCACTTAATGGTCTGCGTCTGAATCTGCGCATTGTTTCAATTGTCATGTTTAACTTCGCCAGCTATCTCACTATCGGTTTACCGCTCGCGGTATTACCTGGCTATGTCCATGATGTGATGGGATTTAGCGCCTTCTGGGCGGGGTTGGTGATCAGCCTGCAATACTTCGCCACTTTGCTCAGTCGTCCACATGCCGGGCGGTATGCAGATCTATTAGGCCCCAAAAAGATTGTGATGTTTGGGCTGGCTGGCTGTTTGCTCAGTGGTGGGGCCTATTTTCTGGCGGGGAGTGCCAGCAGCTGGCCGGTACTCAGCTTGTTACTGTTGTGTCTTGGGCGTGTGATTCTGGGAATTGGACAAAGCTTTACCGGCACTGGTTCTACTTTGTGGGGCGTCGGTGCGGTGGGATCGACTCACATTGGTCGGGTGATTTCGTGGAACGGCATCGTCACGTATGGTGCGATGGCGATGGGCGCACCGCTTGGTGTTCTGTGCTATCACTGGGTTGGGCTACAAGGACTTTCACTTTTTATTATGGCGGTTGCCCTGGTGGCACTGCTGCTGGCGATCCCACGTCCAGCGGTGAAAGCGAGCAAAGGGAAGCCGCTACCGTTTCGTGCAGTACTGGGGCGAGTCTGGCTTTATGGGATGGCGCTGGCAATGGCGTCTGCCGGGTTTGGCGTTATCGCCACCTTTATCACGCTGTTTTATGACGCGAAAGGTTGGGACGGAGCGGCCTTCGCACTGACGCTATTTAGCTGTGCGTTTGTCGGTACACGATTGTTATTCCCTGGCGGCATTAACCGTATCGGCGGCTTAAACGTAGCGATGATTTGCTTTAGTGTTGAGATAATCGGCTTGCTACTGGTCGGGGTTGCGATGGTACCCTGGATGGCGAAAGTGGGCGTTTTGCTGGCAGGTGCGGGTTTTTCGTTGGTCTTTCCGGCGTTGGGCGTTGTGGCAGTAAAAGCAGTGCCACAGCAAAATCAGGGGGCGGCTCTGGCGACTTATACCGTCTTTATGGATTTATCTCTTGGTATTACCGGACCGTTAGCCGGGTTGGTCATGAGCTGGGCAGGTGTATCCGTGATTTATCTGGCTGCGGCGGGGCTGGTGGTTATTGCATTACTACTAACATGGCGGTTAAAAAAACGGCCTCCGCAACCACTGTCGGAGACCGCTTCATCATCGTAG",
      "translation": "MLKMKLCSKYGVIVMPEPALNGLRLNLRIVSIVMFNFASYLTIGLPLAVLPGYVHDVMGFSAFWAGLVISLQYFATLLSRPHAGRYADLLGPKKIVMFGLAGCLLSGGAYFLAGSASSWPVLSLLLLCLGRVILGIGQSFTGTGSTLWGVGAVGSTHIGRVISWNGIVTYGAMAMGAPLGVLCYHWVGLQGLSLFIMAVALVALLLAIPRPAVKASKGKPLPFRAVLGRVWLYGMALAMASAGFGVIATFITLFYDAKGWDGAAFALTLFSCAFVGTRLLFPGGINRIGGLNVAMICFSVEIIGLLLVGVAMVPWMAKVGVLLAGAGFSLVFPALGVVAVKAVPQQNQGAALATYTVFMDLSLGITGPLAGLVMSWAGVSVIYLAAAGLVVIALLLTWRLKKRPPQPLSETASSS",
      "product": ""
     },
     {
      "start": 3962699,
      "end": 3963256,
      "strand": -1,
      "locus_tag": "ctg1_3663",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3663</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3663</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,962,699 - 3,963,256,\n (total: 558 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3663\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3663\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3663\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3663\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGCAATCTGGTTAAATATGTCGGTATTGGTCTGCTGGTTATGGGGCTTGCGGCTTGTGATGACAAAGACACCAACGCTTCAACTGAAGGCACCGTTGCTGAAAGCAATGCTGCCGGGCAATCAGTAAATTTGTTGGACGGTAAACTCAGTTTCCAGCTACCTGCAGACATGACTGATCAGAGTGGCAAGCTGGGCACTCAGGCCAATAATATGCACGTTTACTCTGATGCCAGTGGGCAGAAAGCTGTCATTGTCATTATGGGTGATGATCCTAACCTGGATCTGGCAGTGCTGGCGAAGCGTCTGGAAGATCAACAGCGCAGCCGTGACCCACAACTGCAGGTCGTCACGAACAAAACCATCGAAGTTAATGGGCACAAGTTACAGCAGCTGGACAGTATTATCTCCGCAAAAGGCCAGACAGCTTATTCTTCTGTTGTTTTAGGCAATGTAGATAAGCAATTGTTGACCATGCAAATTACGTTGCCAGCGGACGATCAACAAAAAGCGCAAACCGCAGCGGAAAGCATCATTAACACTCTGGAAATTAAGTAA",
      "translation": "MRNLVKYVGIGLLVMGLAACDDKDTNASTEGTVAESNAAGQSVNLLDGKLSFQLPADMTDQSGKLGTQANNMHVYSDASGQKAVIVIMGDDPNLDLAVLAKRLEDQQRSRDPQLQVVTNKTIEVNGHKLQQLDSIISAKGQTAYSSVVLGNVDKQLLTMQITLPADDQQKAQTAAESIINTLEIK",
      "product": ""
     },
     {
      "start": 3963329,
      "end": 3963994,
      "strand": -1,
      "locus_tag": "ctg1_3664",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3664</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3664</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,963,329 - 3,963,994,\n (total: 666 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3664\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3664\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3664\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3664\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGCATTTTTCTCAATCGCAGCGCGTAAAAGCGTTGTTCTGGCTATCGCTATTTCATCTGCTGGTGATCACCTCCAGCAACTATCTGGTACAGCTCCCGATTACTATTTTTGGATTTCATACCACCTGGGGCGCGTTTAGCTTTCCGTTTATTTTTCTTGCCACCGACCTGACCGTGCGTATTTTTGGCGCGCCGCTGGCCCGACGCATTATCTTCGCGGTAATGATCCCGGCGTTGCTGATCTCCTACGTCATCTCATCGCTGTTCTATATGGGTTCATGGCAAGGGTTCGGCGCTCTCGCCCACTTCAACCTGTTTGTCGCACGTATTGCCACCGCCAGCTTCATGGCCTACGCGCTGGGGCAGATCCTCGACGTGCACGTCTTTAACCGCCTGCGCCAGAGTCGTCGCTGGTGGCTGGCCCCGACAGCTTCCACGCTGTTTGGGAACGTCAGTGACACGCTGGCCTTCTTCTTCATTGCCTTCTGGCGCAGCCCGGATGCCTTTATGGCCGAGCACTGGATGGAAATCGCGCTGGTCGATTACTGTTTCAAAGTGTTAATCAGTATCGTTTTCTTCCTGCCGATGTATGGCGTATTACTCAATATGCTGTTGAAAAGACTGGCAGACAAATCTGAAATCAACGCATTGCAGGCGAGTTAA",
      "translation": "MTHFSQSQRVKALFWLSLFHLLVITSSNYLVQLPITIFGFHTTWGAFSFPFIFLATDLTVRIFGAPLARRIIFAVMIPALLISYVISSLFYMGSWQGFGALAHFNLFVARIATASFMAYALGQILDVHVFNRLRQSRRWWLAPTASTLFGNVSDTLAFFFIAFWRSPDAFMAEHWMEIALVDYCFKVLISIVFFLPMYGVLLNMLLKRLADKSEINALQAS",
      "product": ""
     },
     {
      "start": 3964198,
      "end": 3964443,
      "strand": 1,
      "locus_tag": "ctg1_3665",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3665</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3665</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,964,198 - 3,964,443,\n (total: 246 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3665\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3665\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3665\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3665\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGATCTCTTTTCCAGCCCTGACCATACTTTAGACGCTCTCGGCCTGCGCTGCCCGGAACCCGTGATGATGGTGCGCAAAACTGTGCGCAATATGCAACCTGGCGAAACGTTGCTGATTATTGCTGATGATCCGGCGACGACACGCGATATTCCTGGGTTTTGTACCTTTATGGAACACGAACTGGTTGCTAAAGAAACGGATGGACTGCCTTATCGTTATTTGATTCGCAAAGGGCATTAA",
      "translation": "MTDLFSSPDHTLDALGLRCPEPVMMVRKTVRNMQPGETLLIIADDPATTRDIPGFCTFMEHELVAKETDGLPYRYLIRKGH",
      "product": ""
     },
     {
      "start": 3964556,
      "end": 3965050,
      "strand": -1,
      "locus_tag": "ctg1_3666",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3666</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3666</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,964,556 - 3,965,050,\n (total: 495 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3666\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3666\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3666\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3666\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTACGTTAAATTCAAATTACTGGGGAAGGCTCGCTGTTGATGAGTCAGAGGGTTTCGCAGAATACGTAACAGTTACGCTTAACAATGAAAAGCGAACTGTCTGGCTAAATATTTTTGAAGATGTCCTGCCAAATACCCCCATTGAGAAAATCGTTCCACTCCTGGATAGCCTCCCTGCATGTACTGAAATTATCCGCAACGTACTTGCGCAAAAGAAAGGAACAAATGCGTTTGTTGATGAGTTTATTGAGTTTCATTTAGATGAACTCGATGCTGAAACATTACAATCTCTTGATATAACTCCACCTACGCACGAGGCCTGTGCAAAGCAACTCACTTTACGTGGCGTTCATCTCTGGTTAGCAGCTCCTGCTCCAGGCAGGTTAAAAATGACCGTGGATTATGGGATATCAAAGGATATCTCGGATCAGTTGCTGGTATTTAATTTTGATGAGCAGGGTGAGTTGCTGGATATTACCTGGGAAAGTTAA",
      "translation": "MITLNSNYWGRLAVDESEGFAEYVTVTLNNEKRTVWLNIFEDVLPNTPIEKIVPLLDSLPACTEIIRNVLAQKKGTNAFVDEFIEFHLDELDAETLQSLDITPPTHEACAKQLTLRGVHLWLAAPAPGRLKMTVDYGISKDISDQLLVFNFDEQGELLDITWES",
      "product": ""
     },
     {
      "start": 3965159,
      "end": 3967360,
      "strand": -1,
      "locus_tag": "ctg1_3667",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3667</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3667</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,965,159 - 3,967,360,\n (total: 2202 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1037:heavy metal translocating P-type ATPase (Score: 547; E-value: 1.2e-165)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3667\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3667\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3667_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3667\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3667\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCGACTCCTGACAATCACGGCAAGAAAGCCCCTCACTTTGCTGCGTTCAAACCGCTAACCACGGCACAGAACACCAACGACTGTTGCTGCGACGGTGCATGTTCCAGCACGCCAACGCTCTCTGAAAACGTCTCCGGCACCCGCTATAGCTGGAAAGTCAGCGGCATGGACTGCGCCGCCTGCGCGCGCAAGGTAGAAAATGCCGTGCGCCAGCTTGCAGGCGTGAATCAGGTGCAGGTGTTGTTCGCCACCGAAAAACTGGTGGTGGATGCCGACAATGACATCCGTGCCCAGGTTGAATCTGCGGTGCAAAAAGCGGGCTATTCCCTGCGCGATGAACAGGCAGCCGCAGAACAACAAGAATCACGCCTGAAAGAGAATCTGCCGCTGATTACGCTAATCGTGTTGATGGCAATCAGCTGGGGTCTGGAGCAGTTTAATCATCCGTTCGGTCAACTGGCGTTTATCGCGACCACACTGTTTGGGCTGTACCCGATTGCGCGCCAGGCATTACGGCTGATCAAATCGGGCAGCTACTTCGCCATTGAAACGTTAATGAGCGTAGCCGCCATTGGCGCGCTGTTTATTGGCGCAACGGCTGAAGCTGCGATGGTGTTGCTGCTGTTTTTGATTGGTGAACGACTGGAAGGCTGGGCCGCCAGCCGCGCGCGTCAGGGCGTTAGCGCGTTAATGGCGCTGAAACCAGAAACCGCCACGCGCCTGCGTAATGGCAAGCGTGAAGAGGTAGCAATTAACAGCCTGCGTCCGGGCGATGTTATCGAAGTTGCGGCAGGTGGGCGTTTACCTGCCGACGGTAAACTGCTCTCGCCCTTTGCCAGTTTTGATGAAAGCGCCCTGACCGGCGAATCCATTCCGGTGGAGCGCGCGACGGGTGATAAAGTTCCTGCAGGCGCCACCAGCGTAGACCGTCTGGTAACGCTGGAAGTGCTGTCAGAACCGGGTGCCAGCGCCATTGACCGGATTCTGAAACTGATCGAAGAAGCCGAAGAGCGCCGCGCGCCCATTGAGCGGTTTATCGACCGTTTCAGCCGTATCTACACGCCCGCGATTATGGCCGTCGCCCTGCTGGTGACGCTGGTGCCGCCGCTGCTGTTTGCCGCAAGCTGGCAGGAGTGGATTTATAAAGGTCTGACGCTGCTGCTGATTGGCTGCCCGTGTGCGTTAGTTATCTCCACGCCTGCGGCGATAACCTCCGGGTTGGCAGCAGCGGCACGCCGCGGGGCGTTGATTAAAGGCGGTGCGGCGCTGGAACAACTAGGTCGTGTTACCCAGGTGGCGTTTGATAAAACCGGTACGCTGACCGTCGGTAAACCGCGCGTTACCGCGATTCATCCGGCAACGGGTATTAGTGAATCTGAACTGCTGACACTGGCAGCGGCGGTCGAGCAAGGCGCGACGCATCCACTGGCGCAGGCCATCGTACGCGAAGCACAGGTTGCTGAACTCGCCATTCCCGCCGCCGAATCACAGCGGGCGCTGGTCGGGTCTGGTATTGAAGCACTGATTAACGGTGAGCGCGTGTTGATATGCGCTGCCGGAAAACATCCGGCTGTTGCATTTGCTGGTTTAATTAACGAACTGGAAAGCGCCGGGCAAACGGTAGTACTGGTGGTGCGTAACGATGAAGTGCTGGGTGTCATTGCATTGCAGGATACCCTGCGCGCCGACGCCGTAACTGCCATCAGCGAACTGAGCGCCCTGGGTGTCAAAGGGGTGATCCTCACTGGCGATAATCCACGCGCAGCGGCGGCAATCGCCGGTGAACTGGGGCTGGAATTTAAAGCGGGCCTGTTGCCAGAAGATAAAGTCAAAGCGGTGACCGAGCTGAATCAACATGCGCCGCTGGCGATGGTCGGTGATGGTATTAACGACGCGCCAGCGATGAAAGCTGCCGCTATTGGGATTGCAATGGGCAGTGGCACAGATGTGGCGCTGGAAACCGCCGACGCAGCATTAACCCATAACCACCTGCGCGGCCTGGCGCAGATGATTGAACTGGCACGCGCCACTCACGCCAATATCCGCCAGAACATCACCATTGCATTGGGGCTGAAAGGGATCTTCCTCGTCACCACGCTATTAGGAATGACTGGCCTTTGGCTGGCGGTGCTGGCAGATACGGGTGCAACAGTGCTGGTGACGGCGAATGCGTTAAGGTTGTTGTGCAGGAAGGGGTAG",
      "translation": "MSTPDNHGKKAPHFAAFKPLTTAQNTNDCCCDGACSSTPTLSENVSGTRYSWKVSGMDCAACARKVENAVRQLAGVNQVQVLFATEKLVVDADNDIRAQVESAVQKAGYSLRDEQAAAEQQESRLKENLPLITLIVLMAISWGLEQFNHPFGQLAFIATTLFGLYPIARQALRLIKSGSYFAIETLMSVAAIGALFIGATAEAAMVLLLFLIGERLEGWAASRARQGVSALMALKPETATRLRNGKREEVAINSLRPGDVIEVAAGGRLPADGKLLSPFASFDESALTGESIPVERATGDKVPAGATSVDRLVTLEVLSEPGASAIDRILKLIEEAEERRAPIERFIDRFSRIYTPAIMAVALLVTLVPPLLFAASWQEWIYKGLTLLLIGCPCALVISTPAAITSGLAAAARRGALIKGGAALEQLGRVTQVAFDKTGTLTVGKPRVTAIHPATGISESELLTLAAAVEQGATHPLAQAIVREAQVAELAIPAAESQRALVGSGIEALINGERVLICAAGKHPAVAFAGLINELESAGQTVVLVVRNDEVLGVIALQDTLRADAVTAISELSALGVKGVILTGDNPRAAAAIAGELGLEFKAGLLPEDKVKAVTELNQHAPLAMVGDGINDAPAMKAAAIGIAMGSGTDVALETADAALTHNHLRGLAQMIELARATHANIRQNITIALGLKGIFLVTTLLGMTGLWLAVLADTGATVLVTANALRLLCRKG",
      "product": ""
     },
     {
      "start": 3967434,
      "end": 3968060,
      "strand": -1,
      "locus_tag": "ctg1_3668",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3668</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3668</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,967,434 - 3,968,060,\n (total: 627 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3668\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3668\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3668\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3668\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTTTGGTCGTTTATCGCTGTCTGTCTTTCCGCATGGCTATCTGTGGATGCATCGTATCGTGGGCCAACCTGGCAACGCTGGGTATTTAAACCATTAACCCTTCTTCTCCTGCTGTTGCTGGCCTGGCAAGCGCCGATGTTCGACGCCATTAGTTATCTGGTGCTGGCGGGACTGTGCGCCTCACTGCTGGGCGATGCGCTAACCCTGTTGCCACGTCAACGTCTGATGTACGCCATCGGCGCATTTTTCCTCTCGCACCTGCTGTACACCATCTATTTCGCCAGTCAGATGACGCTCTCTTTCTTCTGGCCTCTGCCACTGGTGTTGCTGGTGCTGGGCGCGCTGTTACTGGCGATTATCTGGACGCGTCTGGAAGAGTATCGTTGGCCTATCTGCACGTTTATCGGCATGACGCTGGTGATGGTGTGGCTGGCAGGTGAACTGTGGTTCTTCCGTCCGACCGCTCCGGCGCTCTCTGCGTTTGTCGGCGCTTCGTTGCTGTTTATCAGTAACTTTGTCTGGCTGGGTAGTCACTATCGCCGACGCTTCCGTGCGGACAACGCGATTGCTGCGGCCTGCTACTTTGCCGGACATTTCCTCATCGTCCGCTCGCTGTATCTCTGA",
      "translation": "MLWSFIAVCLSAWLSVDASYRGPTWQRWVFKPLTLLLLLLLAWQAPMFDAISYLVLAGLCASLLGDALTLLPRQRLMYAIGAFFLSHLLYTIYFASQMTLSFFWPLPLVLLVLGALLLAIIWTRLEEYRWPICTFIGMTLVMVWLAGELWFFRPTAPALSAFVGASLLFISNFVWLGSHYRRRFRADNAIAAACYFAGHFLIVRSLYL",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 3944882,
      "end": 3948470,
      "tool": "rule-based-clusters",
      "neighbouring_start": 3924882,
      "neighbouring_end": 3968470,
      "product": "arylpolyene",
      "category": "PKS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": [
      {
       "loc": 3941731,
       "len": 15
      }
     ]
    },
    "type": "arylpolyene",
    "products": [
     "arylpolyene"
    ],
    "product_categories": [
     "PKS"
    ],
    "cssClass": "PKS arylpolyene",
    "anchor": "r1c3"
   }
  ]
 },
 {
  "length": 57214,
  "seq_id": "NZ_CP083639.1",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r1c1",
  "r1c2",
  "r1c3"
 ],
 "r1c1": {
  "start": 293204,
  "end": 348217,
  "idx": 1,
  "orfs": [
   {
    "start": 293687,
    "end": 294340,
    "strand": -1,
    "locus_tag": "ctg1_281",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_281</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_281</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 293,687 - 294,340,\n (total: 654 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF00881<br>\n \n  biosynthetic-additional (smcogs) SMCOG1159:dihydropteridine reductase (Score: 317.4; E-value: 6.3e-97)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_281\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_281\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_281\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_281\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGATATCATTTCTGTCGCCTTAAAGCGTCATTCCACTAAGGCATTTGATGCCAGCAAAAAACTTACCCCAGAACAGGCCGAGCAGATCAAAACTCTTCTGCAATACAGCCCATCCAGCACCAACTCCCAGCCGTGGCATTTTATTGTTGCCAGCACGGAAGAAGGCAAAGCGCGTGTTGCCAAATCCGCCGCCGATAATTACGTGTTCAACGAGCGCAAAATGCTTGATGCCTCGCACGTCGTGGTGTTCTGCGCGAAAACCGCGATGGACGATGCCTGGCTGAAACAGGTTGTTGACCAGGAAGATGCCGATGGCCGCTTTGCCACGCCGGAAGCGAAAGCCGCGAACGATAAAGGTCGCAAATTCTTCGCCGATATGCACCGTAAAGATCTGCATGATGATGCTGAGTGGATGGCAAAACAGGTTTACCTCAACGTCGGTAACTTCCTGCTGGGCGTTGCGGCGCTGGGTCTGGACGCGGTGCCAATCGAAGGTTTTGACGCCGCAATCCTCGATGAAGAATTTGGTCTGAAAGAGAAAGGCTACACCAGCCTGGTGGTTGTTCCGGTAGGTCATCACAGCGTCGAAGATTTCAACGCTACACTGCCGAAATCCCGTCTGCCGCAAAACATCACCATAACTGAAGTGTAA",
    "translation": "MDIISVALKRHSTKAFDASKKLTPEQAEQIKTLLQYSPSSTNSQPWHFIVASTEEGKARVAKSAADNYVFNERKMLDASHVVVFCAKTAMDDAWLKQVVDQEDADGRFATPEAKAANDKGRKFFADMHRKDLHDDAEWMAKQVYLNVGNFLLGVAALGLDAVPIEGFDAAILDEEFGLKEKGYTSLVVVPVGHHSVEDFNATLPKSRLPQNITITEV",
    "product": ""
   },
   {
    "start": 294435,
    "end": 294803,
    "strand": -1,
    "locus_tag": "ctg1_282",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_282</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_282</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 294,435 - 294,803,\n (total: 369 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1198:hypothetical protein (Score: 203.4; E-value: 1.5e-62)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_282\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_282\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_282\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_282\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGATAAGCAATCACTGCACGAAACGGCGAAACGCCTGGCCCTTGAGTTACCCTTTGTCGAGCTTTGCTGGCCTTTTGGCCCGGAGTTCGATGTCTTTAAAATTGGCGGCAAGATTTTTATGCTGTCGTCGGAGCTGCGCGGCGTCCCCTTTATCAATTTGAAGTCCGATCCACAAAAATCCCTGTTAAATCAGCAGATATATCCGAGCATTAAGCCAGGGTATCACATGAATAAGAAGCACTGGATTTCAGTGTATCCAGGCGATGAGATCTCCGAAGCGTTACTGCGCGATCTTATCGATGATTCATGGAATTTAGTGGTTGATGGCTTATCTAAACGCGATCAAAAAAGAGTGCGCCCAGACTAA",
    "translation": "MDKQSLHETAKRLALELPFVELCWPFGPEFDVFKIGGKIFMLSSELRGVPFINLKSDPQKSLLNQQIYPSIKPGYHMNKKHWISVYPGDEISEALLRDLIDDSWNLVVDGLSKRDQKRVRPD",
    "product": ""
   },
   {
    "start": 294868,
    "end": 295068,
    "strand": -1,
    "locus_tag": "ctg1_283",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_283</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_283</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 294,868 - 295,068,\n (total: 201 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1253:putative lipoprotein (Score: 139.7; E-value: 5e-43)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_283\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_283\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_283\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_283\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTTTCCTCTCTTGCCTGCTGCTGCCCGCCCCCGCACTGGGGCTGACGCTGGCACAAAAACTGGTGAGCACGTTCCATCTGATGGATCTTAGCCAGCTTTACACTTTATTGTTTTGCCTGTGGTTTTTAGTGCTGGGCGCAATTGAGTATTTTGTTCTGCGCTTTATCTGGCAACGCTGGTTCTCACTGGCGGATTAA",
    "translation": "MAFLSCLLLPAPALGLTLAQKLVSTFHLMDLSQLYTLLFCLWFLVLGAIEYFVLRFIWQRWFSLAD",
    "product": ""
   },
   {
    "start": 295182,
    "end": 296300,
    "strand": -1,
    "locus_tag": "ctg1_284",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_284</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_284</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 295,182 - 296,300,\n (total: 1119 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1165:carboxylate-amine ligase (Score: 540.2; E-value: 3.1e-164)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_284\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_284\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_284\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_284\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCAATGCCCGATTTTCAAGTCTCTGAACCTTTTACCCTCGGTATTGAACTGGAAATGCAGGTGGTTAATCCGCCGGGCTATGACTTAAGCCAGGACTCTTCAACGCTGATTGACGCGGTTAAAAATCAGATCACTGCCGGGGAAGTAAAGCACGATATCACCGAAAGCATGCTGGAGCTGGCGACGGATGTTTGCCGTGATATCAACCAGGCTGCCGGGCAATTTTCAGCGATGCAGAAAGTCGTATTGCAGGCAGCCGCAGACCATCATCTGGAAATTTGCGGCGGGGGCACGCACCCGTTTCAGAAATGGCAGCGTCAGGAGGTATGCGATAACGAACGCTATCAACGAACGCTGGAAAACTTTGGTTATCTCATTCAGCAGGCGACCGTTTTTGGTCAGCATGTCCATGTTGGCTGCGCCAGTGGCGATGACGCCATTTATTTGCTGCACGGCTTGTCGCGGTTTGTGCCGCACTTTATCGCCCTTTCTGCCGCATCGCCGTATATGCAGGGAACGGATACACGCTTTGCTTCCTCAAGACCGAATATTTTTTCCGCCTTTCCCGACAATGGCCCAATGCCGTGGGTCAGTAACTGGCAACAATTTGAAACCCTGTTTCGTTGTCTGAGTTACACCAAGATGATCGACAGCATTAAAGATCTGCACTGGGATATTCGCCCCAGCCCCCATTTTGGCACGGTGGAAGTTCGGGTGATGGATACCCCATTAACCCTTAGCCACGCGGTAAATATGGCGGGATTAATTCAGGCCACCGCCCACTGGTTACTGACGGAACGCCCGTTCAAACATCAGGAGAAAGATTACCTGCTGTATAAATTCAACCGCTTCCAGGCCTGCCGTTATGGGCTGGAAGGTGTCATTACCGATCCGCACACTGGCGATCGTCGACCATTGACGGAAGACACCTTGCGATTGCTGGAAAAAATCGCCCCTTCCGCAGATAAAATTGGCGCATCGAGCGCGATTGAAGCCCTGCATCGCCAGGTCGTTAGCGGTCTGAATGAAGCGCAGCTGATGCGTGATTTCGTCGCCGATGGCGGCTCGCTGATTGGACTGGTGAAAAAGCATTGTGAAATCTGGGCCGGAGAATAA",
    "translation": "MPMPDFQVSEPFTLGIELEMQVVNPPGYDLSQDSSTLIDAVKNQITAGEVKHDITESMLELATDVCRDINQAAGQFSAMQKVVLQAAADHHLEICGGGTHPFQKWQRQEVCDNERYQRTLENFGYLIQQATVFGQHVHVGCASGDDAIYLLHGLSRFVPHFIALSAASPYMQGTDTRFASSRPNIFSAFPDNGPMPWVSNWQQFETLFRCLSYTKMIDSIKDLHWDIRPSPHFGTVEVRVMDTPLTLSHAVNMAGLIQATAHWLLTERPFKHQEKDYLLYKFNRFQACRYGLEGVITDPHTGDRRPLTEDTLRLLEKIAPSADKIGASSAIEALHRQVVSGLNEAQLMRDFVADGGSLIGLVKKHCEIWAGE",
    "product": ""
   },
   {
    "start": 296653,
    "end": 296904,
    "strand": 1,
    "locus_tag": "ctg1_285",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_285</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_285</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 296,653 - 296,904,\n (total: 252 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_285\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_285\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_285\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_285\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGCCCCAGGAGATATTTCTATCAACCCTGGGGCTGCCACTCCAAACCCGAACAATTTGGATGGTAGCCCCTTCTTCGCATGGAGGCAATATAAACATGCTGACGAAATATGCCCTTGTGGCAGTCATAGTGCTGTGTTTGACGGTGCTGGGATTTACGCTTCTGGTCGGCGACTCGCTGTGTGAGTTTACGGTGAAGGAACGTAATATTGAGTTTAAGGCTGTTCTCGCTTACGAACCGAAGAAGTAG",
    "translation": "MKPQEIFLSTLGLPLQTRTIWMVAPSSHGGNINMLTKYALVAVIVLCLTVLGFTLLVGDSLCEFTVKERNIEFKAVLAYEPKK",
    "product": ""
   },
   {
    "start": 297255,
    "end": 297407,
    "strand": 1,
    "locus_tag": "ctg1_286",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_286</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_286</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 297,255 - 297,407,\n (total: 153 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_286\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_286\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_286\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_286\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTGACGAAATATTCCCTTGTGGCGGTCATAGTGCTGTGTTTGACAGTGCTGGGATTTACGCTTCTGGTCGGCGACTCGCTGTGTGAGTTCACCGTAAAGGAACGTAATATTGAGTTCAGGGCTGTTCTCGCTTACGAACCGAAGAAGTAG",
    "translation": "MLTKYSLVAVIVLCLTVLGFTLLVGDSLCEFTVKERNIEFRAVLAYEPKK",
    "product": ""
   },
   {
    "start": 297517,
    "end": 298302,
    "strand": -1,
    "locus_tag": "ctg1_287",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_287</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_287</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 297,517 - 298,302,\n (total: 786 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short_C2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 231.8; E-value: 1.5e-70)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_287\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_287\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_287_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_287\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_287\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCGCAAAAGATTTTGCTCAACAATTGTTTGATCTCCACGATCGCGTCGCCTTTGTCACTGGCGCAGGTAGCGGTATCGGACAAATGATCGCTCTGGCTTTTGCCAGCGCAGGCGCACGAGTGGTGTGTTTTGATCTACGGGAAGATGGCGGACTTAAAGAGACGGTTAATCATATCGAAGCACTTGGTGGACAAGCCTTGTATTACACGGGCGATGTTCGGGAGTTGAGAGATCTTCGCTCAGCAGTCGCTCTGGCAAAAACACATTTTGGTCGTCTGGATATTGCCGTAAACGCCGCTGGAATCGCTAACGCGAACCCGGCGCTGGAAATGGAAAGCGAGCAATGGCAACGCGTTATAGATATCAACCTGACTGGTGTGTGGAATTCCTGTAAGGCGGAAGCCGAGTTAATGGTAGAGAACGGAGGCGGTTCGATTATAAATATTGCGTCAATGTCCGGGATTATCGTCAATCGCGGTCTGGAACAGGCCCACTACAACAGCTCCAAAGCAGGCGTGATTCATTTATCTAAAAGTCTTGCGATGGAATGGGTGAGTAATGGGATCCGCGTGAACTCAATCAGCCCAGGATATACCGCGACACCAATGAATACCCGACCTGAAATGGTGCATCAGACACGGGAGTTTGAAAGCCAGACGCCGATTCAACGGATGGCGAAAGTGGAAGAGATGGCGGGCCCAGCGCTGTTCCTTGCCAGCGATGCGGCGTCATTCTGCACTGGTGTTGATCTGGTGGTCGATGGTGGTTTTATCTGCTGGTAA",
    "translation": "MIAKDFAQQLFDLHDRVAFVTGAGSGIGQMIALAFASAGARVVCFDLREDGGLKETVNHIEALGGQALYYTGDVRELRDLRSAVALAKTHFGRLDIAVNAAGIANANPALEMESEQWQRVIDINLTGVWNSCKAEAELMVENGGGSIINIASMSGIIVNRGLEQAHYNSSKAGVIHLSKSLAMEWVSNGIRVNSISPGYTATPMNTRPEMVHQTREFESQTPIQRMAKVEEMAGPALFLASDAASFCTGVDLVVDGGFICW",
    "product": ""
   },
   {
    "start": 298335,
    "end": 299132,
    "strand": -1,
    "locus_tag": "ctg1_288",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_288</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_288</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 298,335 - 299,132,\n (total: 798 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 238.1; E-value: 1.7e-72)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_288\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_288\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_288_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_288\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_288\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAACGTAATTTTCAGGGTAAGACTGTAGTTATTACCGGGGCATGCCGGGGAATTGGGGCCGGGATCGCTGAACGCTTCGCCCGCGATGGCGCAAATCTGGTGATGGTTTCTAACGCTGCACGCGTTCATGAAACTGCTGAGCAACTGCGCCAACGTTATCAGGCTGACATTTTGTCATTAGAAGTCGATGTGACAGATGAAGCACAAGTACAGGCACTCTATGAACAAGCGGCTGCACGTTTTGGCAGCATCGATGTTTCCATCCAGAATGCGGGCATTATCACCATCGATTATTTTGATCGGATGCCGACTGCTGATTTCGAAAAAGTGCTGGCGGTGAACACGACGGCAGTCTGGCTCTGCTGCCGGGAAGCAGCCAAATATATGGTGAAACAGAATCACGGCTGCCTGATCAACACCTCTTCCGGCCAGGGACGTCAGGGGTTTATCTATACCCCACACTATGCAGCCAGCAAAATGGGGGTGATCGGCATTACGCAAAGCCTGGCCCACGAGTTGGCGCAATGGAATATCACTGTTAACGCCTTCTGCCCGGGTATTATCGAAAGCGAAATGTGGGACTACAACGACCGTGTATGGGGAGAAATTCTCAGTACCGATGACAAGCGTTATGGCAAAGGCGAGCTTATGGCGGAATGGGTGGAAGGTATTCCGATGAAGCGTGCCGGTAAACCTGAAGATGTTGCCGGACTGGTTGCCTTCCTCGCCTCTGACGATGCGCGTTATCTCACCGGTCAAACCATCAACATCGACGGCGGCCTGATTATGTCGTAA",
    "translation": "MQRNFQGKTVVITGACRGIGAGIAERFARDGANLVMVSNAARVHETAEQLRQRYQADILSLEVDVTDEAQVQALYEQAAARFGSIDVSIQNAGIITIDYFDRMPTADFEKVLAVNTTAVWLCCREAAKYMVKQNHGCLINTSSGQGRQGFIYTPHYAASKMGVIGITQSLAHELAQWNITVNAFCPGIIESEMWDYNDRVWGEILSTDDKRYGKGELMAEWVEGIPMKRAGKPEDVAGLVAFLASDDARYLTGQTINIDGGLIMS",
    "product": ""
   },
   {
    "start": 299186,
    "end": 300253,
    "strand": -1,
    "locus_tag": "ctg1_289",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_289</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_289</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 299,186 - 300,253,\n (total: 1068 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1113:inner-membrane translocator (Score: 333.2; E-value: 2.4e-101)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_289\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_289\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_289_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMNQKYMIYMYLLKARTFIALLLVIAFFSVMVPNFLTASNLLIMTQHVAITGLLAIGMTLVILTGGIDLSVGAVAGICGMVAGALLTNGLPLWSGNIIFFNVPEVILCVAVFGILVGLVNGAVITRFGVAPFICTLGMMYVARGSALLFNDGSTYPNLNGIETLGNTGFATLGSGTFLGVYLPIWLMIGFLVLGYWITTKTPLGRYIYAIGGNESAARLAGVPIVKVKVFVYAFSGLCAAFVGLIVASQLQTAHPMTGNMFEMDAIGATVLGGTALAGGRGRVSGSIIGAFVIVFLADGMVMMGVSDFWQMVIKGLVIVTAVVVDQFQQKLQNKVILMRRHEEKMAASPAVKPLSS\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_289\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_289\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAATCAGAAATATATGATCTATATGTACCTGTTGAAGGCCAGAACGTTTATCGCTCTGCTGTTAGTGATCGCCTTCTTTAGTGTGATGGTGCCTAACTTCCTGACGGCCTCTAACCTGCTGATTATGACTCAACACGTTGCGATTACCGGGCTGCTGGCAATCGGAATGACGCTGGTGATCCTGACCGGCGGCATCGATCTTTCCGTCGGCGCGGTAGCGGGGATCTGCGGAATGGTTGCCGGGGCTCTGTTGACAAACGGCCTGCCATTGTGGAGCGGCAATATTATTTTCTTCAACGTGCCGGAAGTGATCCTCTGCGTGGCGGTATTTGGCATTTTAGTGGGACTGGTGAATGGCGCGGTAATCACCCGCTTTGGTGTCGCGCCCTTTATATGCACCCTCGGTATGATGTACGTCGCCCGTGGCTCTGCCCTGCTGTTTAATGACGGCAGCACTTACCCTAATCTCAACGGCATAGAAACGCTGGGCAACACGGGTTTCGCCACCCTTGGTTCTGGCACGTTTTTAGGCGTTTATCTGCCAATCTGGCTGATGATTGGCTTTTTGGTTTTAGGCTACTGGATCACGACTAAAACGCCGCTCGGTCGTTATATCTATGCCATTGGTGGCAATGAATCTGCCGCGCGACTGGCAGGCGTCCCCATCGTAAAAGTCAAAGTGTTCGTCTATGCGTTCTCTGGGTTATGCGCCGCATTTGTCGGTTTGATTGTTGCCTCGCAGCTGCAAACTGCTCACCCAATGACCGGCAATATGTTCGAAATGGATGCTATTGGTGCCACGGTTCTTGGTGGAACTGCGCTGGCGGGTGGTCGGGGACGTGTCTCTGGCTCGATTATCGGTGCCTTTGTCATTGTCTTCCTCGCCGATGGCATGGTGATGATGGGTGTCAGTGATTTCTGGCAAATGGTCATTAAAGGCCTCGTTATCGTCACCGCCGTGGTGGTCGATCAGTTCCAGCAAAAATTGCAAAACAAAGTCATTTTGATGCGTCGCCATGAAGAAAAGATGGCCGCCTCACCTGCCGTAAAACCGCTTTCCAGTTAA",
    "translation": "MNQKYMIYMYLLKARTFIALLLVIAFFSVMVPNFLTASNLLIMTQHVAITGLLAIGMTLVILTGGIDLSVGAVAGICGMVAGALLTNGLPLWSGNIIFFNVPEVILCVAVFGILVGLVNGAVITRFGVAPFICTLGMMYVARGSALLFNDGSTYPNLNGIETLGNTGFATLGSGTFLGVYLPIWLMIGFLVLGYWITTKTPLGRYIYAIGGNESAARLAGVPIVKVKVFVYAFSGLCAAFVGLIVASQLQTAHPMTGNMFEMDAIGATVLGGTALAGGRGRVSGSIIGAFVIVFLADGMVMMGVSDFWQMVIKGLVIVTAVVVDQFQQKLQNKVILMRRHEEKMAASPAVKPLSS",
    "product": ""
   },
   {
    "start": 300271,
    "end": 301815,
    "strand": -1,
    "locus_tag": "ctg1_290",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_290</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_290</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 300,271 - 301,815,\n (total: 1545 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 138.7; E-value: 4.1e-42)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_290\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_290\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_290_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMLPQEIDTPKTHESPVIIETHDLSRIYPGVVALDNVNYRVYRNKVNVLIGENGAGKSTMMKMLAGVETPSSGKIILDGKEVTLNSTHQAEKHGISIIFQELNLFPNMNVMDNIFMANEFFQKGKINEKYQYELAKSLLERLELDVDPYTQLGELGIGHQQLVEIARALSKDTRVLIMDEPTSALSQSEVKVLFNVIAQLKRRGVTIIYISHRLEELMEIGDFITIFRDGRFISERAVSDASIPWIIAQMVGDKKKHFDYQPATQGNTVLAVQGLTALHPSGGYKLNDVTFSLRKGEVIGIYGLLGAGRTELFKGLVGLMPCQSGKIQLNGETIDKCHFQARLKKGLALVPEDRQGEGVVQMMSIQSNMTLSDFSLQGFRRAWKWLNPQKESASVKEMIQQLAIKVSDAELPITSLSGGNQQKVVLGKALMTQPQVVFLDEPTRGIDVGAKTDVYQLVGKMAQQGLAVMFSSSELDEVMALADRILVMADGRITADLPRGEVTREKLIAASTPQD\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_290\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_290\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTGCCGCAAGAAATTGACACTCCCAAGACTCATGAATCACCTGTAATCATAGAAACTCATGACTTATCGCGCATTTATCCTGGTGTGGTGGCGTTAGATAACGTGAATTACCGTGTCTATCGCAATAAAGTGAATGTGCTTATTGGTGAAAACGGTGCGGGTAAATCCACAATGATGAAAATGCTGGCGGGGGTTGAAACACCTTCCTCAGGCAAGATCATTCTTGATGGTAAAGAAGTTACCCTAAATTCTACCCATCAGGCCGAAAAACATGGAATTAGTATCATTTTTCAGGAGCTGAATTTATTCCCGAATATGAATGTCATGGATAACATTTTCATGGCTAATGAATTTTTTCAGAAAGGGAAGATTAACGAAAAATATCAATATGAATTAGCCAAATCTTTACTAGAGAGACTGGAACTGGATGTTGATCCCTATACCCAACTGGGAGAACTTGGTATTGGTCATCAACAACTGGTGGAGATTGCCCGTGCCCTTTCTAAAGATACCCGGGTACTGATTATGGATGAACCGACGTCGGCCCTCAGCCAGTCGGAAGTCAAAGTCCTTTTCAATGTGATCGCACAACTGAAGCGCCGTGGTGTCACCATCATTTATATCTCCCACCGACTGGAAGAGTTGATGGAGATTGGCGATTTCATCACCATCTTCCGTGATGGTCGCTTTATTAGTGAACGCGCCGTGAGCGATGCCAGTATTCCGTGGATCATCGCGCAAATGGTCGGTGATAAGAAAAAACATTTTGATTATCAACCAGCTACACAAGGTAACACTGTACTGGCGGTACAGGGGTTAACGGCGCTACATCCCAGCGGTGGTTACAAACTCAATGATGTGACATTCAGCCTGCGTAAAGGCGAAGTTATCGGCATTTACGGCTTGCTGGGCGCAGGACGTACTGAGCTATTTAAGGGGCTGGTGGGCCTGATGCCCTGTCAGAGTGGGAAGATCCAGCTTAATGGTGAAACCATCGACAAATGCCATTTCCAGGCGCGGCTCAAAAAGGGGCTGGCGTTGGTGCCAGAAGATCGCCAGGGCGAAGGCGTCGTTCAGATGATGTCGATTCAGTCCAATATGACGCTATCCGATTTCAGCCTGCAAGGTTTTCGCCGTGCCTGGAAATGGCTGAATCCGCAAAAAGAGAGCGCCAGTGTGAAAGAGATGATCCAGCAACTGGCGATCAAAGTCAGCGATGCCGAACTCCCTATTACCTCACTCAGCGGCGGTAACCAGCAAAAAGTGGTGCTTGGCAAAGCGTTGATGACCCAGCCACAGGTGGTGTTTCTTGATGAACCCACACGCGGCATTGATGTTGGCGCAAAAACCGATGTCTATCAGCTGGTGGGAAAAATGGCACAACAGGGGCTGGCAGTCATGTTCTCTTCTTCAGAACTCGATGAAGTCATGGCACTGGCAGATCGCATTCTGGTGATGGCTGATGGCCGTATTACCGCTGATCTCCCCCGGGGCGAAGTCACCCGAGAGAAACTGATCGCGGCTTCAACACCTCAAGATTAA",
    "translation": "MLPQEIDTPKTHESPVIIETHDLSRIYPGVVALDNVNYRVYRNKVNVLIGENGAGKSTMMKMLAGVETPSSGKIILDGKEVTLNSTHQAEKHGISIIFQELNLFPNMNVMDNIFMANEFFQKGKINEKYQYELAKSLLERLELDVDPYTQLGELGIGHQQLVEIARALSKDTRVLIMDEPTSALSQSEVKVLFNVIAQLKRRGVTIIYISHRLEELMEIGDFITIFRDGRFISERAVSDASIPWIIAQMVGDKKKHFDYQPATQGNTVLAVQGLTALHPSGGYKLNDVTFSLRKGEVIGIYGLLGAGRTELFKGLVGLMPCQSGKIQLNGETIDKCHFQARLKKGLALVPEDRQGEGVVQMMSIQSNMTLSDFSLQGFRRAWKWLNPQKESASVKEMIQQLAIKVSDAELPITSLSGGNQQKVVLGKALMTQPQVVFLDEPTRGIDVGAKTDVYQLVGKMAQQGLAVMFSSSELDEVMALADRILVMADGRITADLPRGEVTREKLIAASTPQD",
    "product": ""
   },
   {
    "start": 301817,
    "end": 302437,
    "strand": -1,
    "locus_tag": "ctg1_291",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_291</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_291</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 301,817 - 302,437,\n (total: 621 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_291\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_291\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_291\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_291\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGATAAAAAAGTCTGGCTGGCGCTGGCAATTCTGAGCCTGGGTGGATGTCGCATCGTCTCGCAGCAGGAACTTGCCGATCTCAAATCCCCGCCTAATCCTCATATGGCAAATATCGACCAGACCTGGCAGAAAAATATCGTGCCGCAGGTGGTAGAAAATGCGCGTCCGGTTGCGGAATTAATGGCGGCGCTACAGGCAGAAAAAGATGTCGATGCTGCCTGTAAAACGCTGGGCTATCGTTCTCAAGAAGAAAACCCGTGTATTTTCTACGTTAAAGTCGAAGGAGGCATCACCAATATCGATGCAAAATCCCGTAGCGGAAAAATGACCATCGCAGATATCAGCGGCATGAATATTGTCGTGCAGACGGGGCCAACTCTTCGCGGCACGCTTCTGCGAGATGCATATAAAGGCGCGAGCTATGAGCATTTTAACGATCAGGTTTTATTTGGTGAATATGGTCGTGCTATCAATGAGCAAGCCATCAATATGATTCAGTCGGCAAGGCTTAAAACCGGGGAAACGGTTCAGGTTTATGGCATATTTTCTGCATGGGATATTCCGCAAACTATCCCGGATATAACGCCTGCGAAAATAGCCAGGGCGGGAGGCGAGTAA",
    "translation": "MDKKVWLALAILSLGGCRIVSQQELADLKSPPNPHMANIDQTWQKNIVPQVVENARPVAELMAALQAEKDVDAACKTLGYRSQEENPCIFYVKVEGGITNIDAKSRSGKMTIADISGMNIVVQTGPTLRGTLLRDAYKGASYEHFNDQVLFGEYGRAINEQAINMIQSARLKTGETVQVYGIFSAWDIPQTIPDITPAKIARAGGE",
    "product": ""
   },
   {
    "start": 302484,
    "end": 303419,
    "strand": -1,
    "locus_tag": "ctg1_292",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_292</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_292</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 302,484 - 303,419,\n (total: 936 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1205:ABC transporter, carbohydrate uptake (Score: 238.2; E-value: 1.6e-72)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_292\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_292\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_292_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMKLRLTLLTAATLTALSFSAHAVEKGTIMIMVNSLDNPYYASEAKGASEKAQQLGYKTTILSHGEDVKKQNELIDTAIGKKVQGIILDNADSTASVAAIEKAKKAGIPVILINREIPVDDVALVQITHNNFQAGSEVANVFVEKMGEKGKYAELTCNLADNNCVTRSKSFHQVIDQFPEMVSVAKQDAKGTLIDGKRIMDSILQAHPDVKGVICGNGPVALGAIAALKAANRNDVIVVGIDGSNDERDAVKAESLQATVMLQAQAIAAQGVTDLDNYLQKGVKPAKQRVMFRGILITKDNADKVQDFNIKS\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_292\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_292\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAATTACGTTTAACACTGTTAACCGCTGCGACCCTGACTGCTCTTTCTTTTTCTGCCCATGCGGTAGAAAAAGGAACCATTATGATTATGGTCAATTCACTGGATAATCCTTATTACGCCTCGGAAGCGAAAGGTGCCAGTGAAAAAGCCCAGCAACTGGGATATAAAACGACCATTCTTTCTCATGGTGAAGATGTCAAAAAACAGAATGAACTGATCGATACTGCAATTGGTAAAAAAGTTCAGGGTATTATTTTAGATAATGCTGACTCTACTGCCAGTGTTGCAGCCATTGAAAAAGCAAAAAAAGCAGGTATTCCCGTTATATTAATTAATCGCGAAATACCTGTGGATGATGTTGCACTGGTGCAAATTACCCATAATAACTTCCAGGCTGGCTCGGAAGTTGCCAACGTATTTGTCGAGAAAATGGGAGAGAAAGGAAAATATGCCGAACTCACCTGTAATCTTGCTGATAATAATTGCGTAACTCGCTCGAAATCTTTCCACCAGGTCATTGACCAGTTCCCTGAAATGGTCAGTGTGGCGAAGCAAGATGCCAAAGGCACGTTAATTGATGGCAAACGAATAATGGACAGTATTCTGCAAGCCCATCCCGATGTTAAAGGGGTGATTTGTGGTAATGGTCCGGTTGCACTGGGAGCTATCGCAGCATTGAAAGCAGCCAATCGCAATGACGTTATTGTTGTCGGCATTGATGGCAGTAACGATGAACGCGATGCCGTGAAAGCCGAATCATTGCAGGCTACCGTGATGTTACAAGCACAAGCCATTGCCGCGCAGGGTGTTACCGATCTGGATAATTACCTGCAAAAAGGAGTTAAACCAGCCAAACAGCGGGTGATGTTCCGCGGCATTCTGATAACCAAAGATAACGCAGATAAAGTCCAGGATTTCAATATCAAATCCTGA",
    "translation": "MKLRLTLLTAATLTALSFSAHAVEKGTIMIMVNSLDNPYYASEAKGASEKAQQLGYKTTILSHGEDVKKQNELIDTAIGKKVQGIILDNADSTASVAAIEKAKKAGIPVILINREIPVDDVALVQITHNNFQAGSEVANVFVEKMGEKGKYAELTCNLADNNCVTRSKSFHQVIDQFPEMVSVAKQDAKGTLIDGKRIMDSILQAHPDVKGVICGNGPVALGAIAALKAANRNDVIVVGIDGSNDERDAVKAESLQATVMLQAQAIAAQGVTDLDNYLQKGVKPAKQRVMFRGILITKDNADKVQDFNIKS",
    "product": ""
   },
   {
    "start": 303523,
    "end": 305043,
    "strand": -1,
    "locus_tag": "ctg1_293",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_293</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_293</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 303,523 - 305,043,\n (total: 1521 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1210:glycerol kinase (Score: 534.9; E-value: 2.7e-162)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_293\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_293\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_293_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_293\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_293\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTTGCAGGAAATAAAGAGTTCGTTATTGCGTTGGATGAGGGTACCACCAATGCAAAAGCCATCGCACTTGATGGTTTCGGTAACGTGGTGGCGAAGTTTTCTCAACCACTTGCTATTCAGACGCCACGTGAAGGCTGGGTTGAGCAATCCGGGGAAGCGTTAATCTCTGCCTCGCTTGACGTTATTGCCCAGGCCATCAGCCACGTGGGGGCAGAAAATGTAGCGGCTCTGGCTATCAGTAATCAGCGTGAAACGGCTATCGGCTGGTATCGTCAGAGTGGAAAACCACTCAATGCGGCGATTACCTGGCAATGCACGCGCAGTGCAGAGTTTTGTGAAACACTTCGTCGCGAGGGCAAAGAGCAGCAAATTAAAACGACTACAGGCCTGCCTATCGCCCCGCTATTTTCCGCTTTCAAGATGCGTTGGCTACTGGAATCTACATCTGAGGGTGTGCAACTTGCCGACCAGGGTGAAATTTGTCTCGGCACCATTGATGCCTGGTTACTATGGAACTTGACTGCTGGCGATTCATTTTGCTGCGACCACTCTAACGCCGCGCGAACTCAATTACTTAACCTGAAAACAGGCGAGTGGGATGAGGAAATGCTGGCATTGTTTCATATTCCACGCGCTGCATTGCCAGAAATTAAACCATCCAGTGGCCTGTTCGGTTATACCCGAGGGCTTAAAACAATTCCGGATGGTATTCCCGTCATGGCGATGGTGGGCGATTCTCACGCCGCTCTTTTTGGTCATGCGTTGGGAGAAGCGGGATGTGTGAAAGCGACCTATGGGACCGGTTCTTCCGTCATGGCCCCCGTCAACTCTGCTCAGTGTGATATCGCCACACTTGCCACAACCATTGCCTGGCATGACGGCGAAAATATTGTTTACGGTCTGGAAGGAAATATCCCCCACACCGGGGATGCCGTGGCATGGATGGCTGATAGCACCGGTTTAAGTGAACTGACAGACGCTGAGCTGGCCCACGAACTGAATACCCTGCCAGCCTCAGTGGATTCGACTATGGGCGTTTATTTTGTTCCTGCTCTCACTGGCCTGGGCGCACCATGGTGGGATGACAGTGCTCGCGGCGTGGTGTGTGGCTTAAGCCGTGGCGTAAAGCGCGCGCATTTGATTCGCGCCGCACTGGAATCAATCACTTACCAAATTGCAGATGTAGTAGAAGCCATGCAACAGCATGATAATTTTCACTTATCGGCGTTAATGGTGGATGGCGGCCCGACCAAAAATGACTGGTTGATGCAATATCAGGCGGATCTGCTGGGTTGCCCGGTGATGCGCAGTGATGTGCCAGAGCTTTCGGCCATTGGTGCGGGTCTGCTCGCCCGCAAAGCGCTTACCCCCGGCACCGTTGCAGATTTAAAAACGTTATTAACTGAACACAGTGAATTTAAACCGGACATGGCGCGTCATCAGCGACTGCAAAAGAGATGGCAGGAGTGGCGTCATGCGGTAAACAGAACATTATGGAAACCGGCATCGTCAATTTGA",
    "translation": "MFAGNKEFVIALDEGTTNAKAIALDGFGNVVAKFSQPLAIQTPREGWVEQSGEALISASLDVIAQAISHVGAENVAALAISNQRETAIGWYRQSGKPLNAAITWQCTRSAEFCETLRREGKEQQIKTTTGLPIAPLFSAFKMRWLLESTSEGVQLADQGEICLGTIDAWLLWNLTAGDSFCCDHSNAARTQLLNLKTGEWDEEMLALFHIPRAALPEIKPSSGLFGYTRGLKTIPDGIPVMAMVGDSHAALFGHALGEAGCVKATYGTGSSVMAPVNSAQCDIATLATTIAWHDGENIVYGLEGNIPHTGDAVAWMADSTGLSELTDAELAHELNTLPASVDSTMGVYFVPALTGLGAPWWDDSARGVVCGLSRGVKRAHLIRAALESITYQIADVVEAMQQHDNFHLSALMVDGGPTKNDWLMQYQADLLGCPVMRSDVPELSAIGAGLLARKALTPGTVADLKTLLTEHSEFKPDMARHQRLQKRWQEWRHAVNRTLWKPASSI",
    "product": ""
   },
   {
    "start": 305394,
    "end": 306344,
    "strand": -1,
    "locus_tag": "ctg1_294",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_294</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_294</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 305,394 - 306,344,\n (total: 951 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_294\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_294\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_294\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_294\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTAAGCAGGATGAACAGCGGCTACTGGTGAAGATCGCCACTCTTTACTATCTTGAGGGGCGAAAACAGTCTGACATCGCCCAACTTCTCTCGCTTTCTCAGTCATTTATCTCCAGAGCGCTAACCCGTTGCCAGAAAGAAGGCGTGGTTAAAATCAGCGTTGTCCAGCCGTCAAATATCTTTCTCAATCTGGAAAAAGGCATTGAAGAGCGTTACGGCATTAAACAAGCGATTGTTGTCGATACCGAAGATGATGCCACTGACCATACCATTAAACGTGCTATCGGCTCTGCCGCCGCGCACTATCTGGAAACGCGTTTAAGACCAAAAGATTTCATTGGCGTCTCTTCCTGGAGTTCTACGATTCGCGCGATGGTCGATGAAGTTCACGCCCAAAACTTAAAAGCCAGCGGCGTTATTCAGCTGCTGGGCGGCGTGGGGCCAAACGGCAATGTGCAGGCAACTATTTTGACACAGACCCTGGCCCAGCATCTGAATTGCGAAGCCTGGTTACTTCCTTCTCAAAGCATTGAAGGTTCGGTAGAAGAGAAAAAACGCCTGGTGGCAAGCCAGGATGTGGCTGACGTTATCGCCAGATTTGACGACGTCGATATCGCCATTGTCGGCATCGGTATCCTTGAACCCTCGCAGTTACTAAAAACCTCGGGCAACTATTATCACGAGGATATGTTACAGGTACTGGCGGATCGCGGTGCTGTGGGCGATATCTGCCTGCATTACTACGATAAACATGGTCAGCCAGTGTTGCAGGACGATGAAGATCCAGTGATTGGTATGGCACTGGATAAAATCAAAAAATGCCCGAATGTGGTGGCGCTGGCGGGCGGCAAAGACAAAGTTGCCGCCATCAAAGGCGCCATGCAGGGTGGTTATATCGATGTTTTGATCACTGATTACCCCACCGCCAGAATGCTGATTGCGGATTAA",
    "translation": "MAKQDEQRLLVKIATLYYLEGRKQSDIAQLLSLSQSFISRALTRCQKEGVVKISVVQPSNIFLNLEKGIEERYGIKQAIVVDTEDDATDHTIKRAIGSAAAHYLETRLRPKDFIGVSSWSSTIRAMVDEVHAQNLKASGVIQLLGGVGPNGNVQATILTQTLAQHLNCEAWLLPSQSIEGSVEEKKRLVASQDVADVIARFDDVDIAIVGIGILEPSQLLKTSGNYYHEDMLQVLADRGAVGDICLHYYDKHGQPVLQDDEDPVIGMALDKIKKCPNVVALAGGKDKVAAIKGAMQGGYIDVLITDYPTARMLIAD",
    "product": ""
   },
   {
    "start": 306707,
    "end": 307537,
    "strand": 1,
    "locus_tag": "ctg1_295",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_295</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_295</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 306,707 - 307,537,\n (total: 831 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) DXP_synthase_N<br>\n \n  biosynthetic-additional (rule-based-clusters) TPP_enzyme_C<br>\n \n  biosynthetic-additional (smcogs) SMCOG1204:transketolase (Score: 353.3; E-value: 4.8e-107)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_295\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_295\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_295_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_295\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_295\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAATCCCTATAGCTATGATATCCAGACCCTTGAGCGAAAAGCGCGGGCGGTACGCCGCCATATCGTGCGCTTAAATGCCAATAGCCCGGCAGGTGGACACACCGGGGCCGATCTCTCTCAGGTTGAATTACTGACCGCACTCTATTTTCGTATACTCAATGTCGCCCCGGATCGCCTTCACGACGATGACCGGGATATATACATTCAGTCAAAAGGCCATGCTGTTGGATGTTACTACTGCGTGCTGGCGGAAGCAGGATTCTTCCCACTGGAATGGCTTTCCACTTATCAGCAGCCAAATTCACACTTACCCGGCCATCCGGTTCGGCAAAAAACGCCAGGTATTGAACTGAATACCGGAGCACTGGGGCATGGTTTCCCTGTGGCTGTAGGACTTGCGCTGGCGGCGAAAAAAAGTCAAAGCCGTCGTCGTATCTTCTTAATTACTGGCGATGGTGAGCTGGCTGAGGGCAGTAACTGGGAAGCTGCACTGGCGGCGGCGCATTACGGGCTTGATAACCTGGTCATTATTAATGACAAAAATAATCTGCAATTAGCCGGGCCAACGCGCGAAATCATGAACACCGATCCTCTGGCAGAGAAATGGCTGGCATTCGGTATGCAGGTTACTGAATGTCAGGGCAATGATATGGCTTCGGTTGTCGCGACGCTTGAAGAGCTTAAACAGGAAGGCAAACCGAATGTGGTGATTGCCCACACCACTAAAGGGGCAGGCATTTCCTTTATACAAGGGCGTGCGGAATGGCATCACCGGGTGCCGAAAGGCGATGAAATTGAACAGGCACTGGAGGAACTCAAAGATGCGTAA",
    "translation": "MNPYSYDIQTLERKARAVRRHIVRLNANSPAGGHTGADLSQVELLTALYFRILNVAPDRLHDDDRDIYIQSKGHAVGCYYCVLAEAGFFPLEWLSTYQQPNSHLPGHPVRQKTPGIELNTGALGHGFPVAVGLALAAKKSQSRRRIFLITGDGELAEGSNWEAALAAAHYGLDNLVIINDKNNLQLAGPTREIMNTDPLAEKWLAFGMQVTECQGNDMASVVATLEELKQEGKPNVVIAHTTKGAGISFIQGRAEWHHRVPKGDEIEQALEELKDA",
    "product": ""
   },
   {
    "start": 307530,
    "end": 308465,
    "strand": 1,
    "locus_tag": "ctg1_296",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_296</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_296</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 307,530 - 308,465,\n (total: 936 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1110:1-deoxy-D-xylulose-5-phosphate synthase (Score: 292.7; E-value: 3.8e-89)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_296\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_296\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_296_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_296\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_296\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGTAACAGTGAACATCTGGCAAATGTGATGGTTCAGGCGTTTATCGATGCCGTAAATGAGGGGATCGATTTGGTGCCTGTGGTGGCTGATTCAACGTCTACGGCAAAAATTGCTCCCTTTATTAAGCAATTTCCTGACCGACTGGTGAATGTGGGTATTGCCGAACAGAGTATGGTTGGTACAGCTGCCGGGCTGGCGCTGGGCGGCAAGGTGGCTGTTACTTGCAATGCCGCGCCGTTTCTTATCGCTCGCGCTAACGAGCAAATCAAGGTTGATGTCTGCTACAACTTTACCAACGTAAAATTGTTCGGTCTGAATGCCGGGGCGAGTTATGGACCGCTAGCGAGCACGCATCATGCGATTGATGACATTGCGGTTATGCGTGGTTTCGGCAATATCCAGATCTTTGCCCCGTCTTCACCGCTGGAGTGCCGTCAGGTGATTGATTATGCCCTTCGCTATCAGGGACCTGTTTATATCCGTATGGACGGTAAAGCCCTGCCGGAAATCCACGATGAGGACTACCGATTTGTGCCTGGTGCCGTGGTGACTTTACGCGAGGGCAGCGAACTGGCGCTGGTAGCCACAGGTTCTACCGTTCATGAAGTGGTCGATGCCGCAGAACTTTTAGCGCAATCTGGTATCGCGGCTACAGTTGTCAGCGTACCGTCGATTCGCCCATGCGACACCAAAGCATTGCTGGCAGTGTTAAAAGGATGCAAAGCAGTGATGACGGTTGAAGAGCATAACGTCAATGGCGGCCTTGGTAGCCTGGTCGCGGAAGTGTTGGCAGAGGCCGGAACGGGGATCAAATTAAAACGCGCGGGCATTATGGATGGAGAATATGCCGCAGCGGCGGATCGTGGGTGGTTGCGTCAGCATCATGGCTTTGATGCTGCCGGAATTGCAGCTCAGGCACGGGAAATGCTTTGA",
    "translation": "MRNSEHLANVMVQAFIDAVNEGIDLVPVVADSTSTAKIAPFIKQFPDRLVNVGIAEQSMVGTAAGLALGGKVAVTCNAAPFLIARANEQIKVDVCYNFTNVKLFGLNAGASYGPLASTHHAIDDIAVMRGFGNIQIFAPSSPLECRQVIDYALRYQGPVYIRMDGKALPEIHDEDYRFVPGAVVTLREGSELALVATGSTVHEVVDAAELLAQSGIAATVVSVPSIRPCDTKALLAVLKGCKAVMTVEEHNVNGGLGSLVAEVLAEAGTGIKLKRAGIMDGEYAAAADRGWLRQHHGFDAAGIAAQAREML",
    "product": ""
   },
   {
    "start": 308467,
    "end": 309249,
    "strand": -1,
    "locus_tag": "ctg1_297",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_297</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_297</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 308,467 - 309,249,\n (total: 783 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1060:4&#39;-phosphopantetheinyl transferase (Score: 190.7; E-value: 3.9e-58)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_297\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_297\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_297_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_297\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_297\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAACGCCTTATCCGGCCTACAAAAATCTTGCCAATTCAATATATTGCAGGATAGTGTAGGCCTGATAAGCGTAGCGCATCAGGCAGTTTTGCGTTTGTCATCAGTCTCTAATATGGTCGACATGAAAACTACGCATACCTCCCTCCCCTTTGCCGGACATACGCTGCATTTTGTTGAGTTCGATCCAGTAAGTTTTCGCGAGCAGGATTTACTCTGGCTGCCACACTACGCACAACTGCAACACGCTGGACGTAAACGTAAAACAGAGCATTTAGCCGGACGGATCGCTGCTGTTTACGCCTTGCGGGAATATGGCTATAAATGTGTGCCCGCAATCGGCGAGCTACGCCAACCTGTGTGGCCTGCGGAGGTATACGGCAGTATTAGCCACTGCGGGACTACGGCATTGGCAGTGGTATCCCGTCAACAGATTGGCATTGATATCGAAGAGATTTTCTCTGTACAAACCGCAAGAGAATTGACAGACAACATTATTACACCAGCAGAACACGAGCGACTCGCAGAATGCGGTTTAACCTTTTCTCTGGCGCTGACACTGGCATTTTCCGCCAAAGAGAGCGCATTTAAGACAGGCGAGATCCAAACTGATGCCGGTTTTCAGCACTACCAAATTGGAAATTGTCAGCATCAACAGATGAAGATAAGTGGGCCGAATGGCGACCATATTGTGCAGTGGTTAGTAAGGGGTAATAACGTTATTACCTTGTGCCGGGCAGATAAACACCCGCACACTGCCGCATGCGGGTTGTCTGGCGGATAA",
    "translation": "MNALSGLQKSCQFNILQDSVGLISVAHQAVLRLSSVSNMVDMKTTHTSLPFAGHTLHFVEFDPVSFREQDLLWLPHYAQLQHAGRKRKTEHLAGRIAAVYALREYGYKCVPAIGELRQPVWPAEVYGSISHCGTTALAVVSRQQIGIDIEEIFSVQTARELTDNIITPAEHERLAECGLTFSLALTLAFSAKESAFKTGEIQTDAGFQHYQIGNCQHQQMKISGPNGDHIVQWLVRGNNVITLCRADKHPHTAACGLSGG",
    "product": ""
   },
   {
    "start": 309301,
    "end": 311541,
    "strand": -1,
    "locus_tag": "ctg1_298",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_298</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_298</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 309,301 - 311,541,\n (total: 2241 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1082:TonB-dependent siderophore receptor family (Score: 1043.1; E-value: 0.0)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_298\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_298\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_298_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMNKKIHSLALLVNLGIYGVAQAQEPTDTPVSHDDTIVVTAAEQNLQAPGVSTITADEIRKNPVARDVSEIIRTMPGVNLTGNSTSGQRGNNRQIDIRGMGPENTLILIDGKPVSSRNSVRQGWRGERDTRGDTSWVPPEMIERIEVLRGPAAARYGNGAAGGVVNIITKKGSGEWHGSWDAYFNAPEHKEEGATKRTNFSLTGPLGDQFSFRLYGNLDKTQADAWDINQGHQSARAGTYATTLPAGREGVINKDINGVVRWDFAPMQSLELEAGYSRQGNLYAGDTQNTNSDAYTRSKYGDETNRLYRQNYSLTWNGGWDNGVTTSNWVQYEHTRNSRIPEGLAGGTEGKFNEKATQDFVDIDLDDVMLHSEVNLPIDFLVNQTLTLGTEWNQQRMKDLSSNTQALTGTNTGGAIDGVSATDRSPYSKAEIFSLFAENNMELTDSTIVTPGLRFDHHSIVGNNWSPALNISQGLGDDFTLKMGIARAYKAPSLYQTNPNYILYSKGQGCYASAGGCYLQGNDDLKAETSINKEIGLEFKRDGWLAGVTWFRNDYRNKIEAGYVAVGQNAVGTDLYQWDNVPKAVVEGLEGSLNVPVSETVMWTNNITYMLKSENKTTGDRLSIIPEYTLNSTLSWQAREDLSMQTTFTWYGKQQPKKYNYKGQPAVGPETKEISPYSIVGLSATWDVTKNVSLTGGVDNLFDKRLWRAGNAQTTGDLAGANYIAGAGAYTYNEPGRTWYMSVNTHF\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_298\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_298\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACAAGAAGATTCATTCCCTGGCCTTGTTGGTCAATCTGGGGATTTATGGGGTAGCGCAGGCACAAGAGCCAACCGATACTCCTGTTTCACATGACGATACTATTGTCGTTACCGCCGCCGAGCAGAACTTGCAGGCGCCTGGCGTTTCGACCATCACCGCAGATGAAATCCGCAAAAACCCGGTTGCCCGCGATGTGTCGGAGATCATTCGTACCATGCCTGGCGTTAACCTGACCGGTAACTCCACCAGTGGTCAGCGTGGTAATAACCGCCAGATTGATATTCGCGGCATGGGTCCGGAAAACACGCTGATTTTGATTGACGGTAAGCCTGTCAGCAGCCGTAACTCGGTGCGTCAGGGCTGGCGTGGCGAGCGTGATACCCGTGGTGATACCTCCTGGGTGCCGCCTGAAATGATTGAACGTATTGAAGTTCTGCGTGGTCCGGCAGCTGCGCGTTATGGCAACGGCGCGGCGGGCGGCGTGGTTAACATCATTACCAAAAAAGGCAGCGGCGAGTGGCACGGCTCCTGGGATGCTTATTTCAATGCGCCAGAACATAAAGAGGAAGGTGCCACCAAACGCACCAACTTTAGCTTGACCGGTCCGCTGGGCGACCAATTCAGCTTTCGTTTATATGGCAACCTCGACAAAACTCAGGCTGATGCGTGGGATATTAACCAGGGCCATCAGTCCGCGCGTGCCGGAACCTATGCCACGACGTTACCAGCCGGGCGCGAAGGGGTGATCAACAAAGATATCAATGGCGTGGTGCGTTGGGACTTCGCCCCTATGCAGTCACTCGAACTTGAAGCGGGCTACAGCCGCCAGGGTAACCTGTATGCGGGTGACACCCAGAACACCAACTCTGACGCTTACACTCGCTCTAAATATGGCGATGAAACCAACCGCCTGTATCGCCAGAACTACTCGCTGACCTGGAACGGTGGCTGGGATAACGGCGTGACCACCAGCAATTGGGTGCAGTACGAACACACCCGTAACTCGCGTATACCGGAAGGTTTGGCGGGCGGCACCGAAGGGAAATTTAACGAAAAAGCGACACAAGATTTCGTCGATATCGATCTTGATGACGTGATGTTGCACAGCGAAGTTAACCTGCCGATTGATTTCCTCGTTAACCAGACGCTGACGCTGGGGACTGAGTGGAATCAGCAGCGGATGAAGGACTTAAGTTCCAACACCCAGGCCCTGACCGGAACGAATACCGGCGGTGCTATTGATGGTGTAAGTGCTACTGACCGTAGCCCATATTCAAAGGCAGAAATTTTCTCGCTGTTTGCCGAAAACAATATGGAGCTGACTGACAGCACCATCGTAACGCCGGGGCTGCGTTTCGATCATCACAGCATTGTCGGCAATAACTGGAGTCCGGCGCTGAATATATCGCAAGGTTTAGGCGATGACTTCACGCTGAAAATGGGCATCGCCCGTGCTTATAAAGCGCCGAGCCTGTACCAGACTAACCCGAACTACATTCTCTACAGTAAAGGTCAGGGCTGCTATGCCAGCGCGGGCGGCTGCTATTTGCAAGGTAATGATGACCTGAAAGCGGAAACCAGCATCAACAAAGAGATTGGTCTGGAGTTCAAACGCGACGGCTGGCTGGCGGGTGTCACCTGGTTCCGTAACGATTATCGCAATAAGATTGAAGCGGGCTATGTGGCTGTCGGGCAAAACGCAGTCGGCACCGATCTCTATCAGTGGGATAACGTTCCAAAAGCGGTGGTTGAAGGTCTGGAAGGATCGTTAAATGTGCCGGTTAGCGAAACGGTGATGTGGACCAATAACATCACTTATATGCTGAAGAGTGAAAACAAAACCACGGGCGACCGTTTATCGATCATCCCGGAATATACGTTGAACTCAACGCTGAGCTGGCAGGCACGGGAAGATTTGTCGATGCAAACGACCTTCACCTGGTACGGCAAGCAGCAGCCGAAGAAGTACAACTATAAAGGTCAGCCAGCGGTTGGACCGGAAACCAAAGAAATCAGTCCGTACAGCATTGTGGGCCTGAGCGCGACCTGGGATGTGACGAAGAATGTCAGTCTGACCGGCGGCGTGGACAACCTGTTCGACAAGCGTTTGTGGCGTGCGGGTAATGCCCAGACCACGGGCGATTTGGCAGGAGCCAACTATATCGCGGGTGCCGGGGCGTATACCTATAACGAGCCGGGACGTACATGGTATATGAGCGTAAACACTCACTTCTGA",
    "translation": "MNKKIHSLALLVNLGIYGVAQAQEPTDTPVSHDDTIVVTAAEQNLQAPGVSTITADEIRKNPVARDVSEIIRTMPGVNLTGNSTSGQRGNNRQIDIRGMGPENTLILIDGKPVSSRNSVRQGWRGERDTRGDTSWVPPEMIERIEVLRGPAAARYGNGAAGGVVNIITKKGSGEWHGSWDAYFNAPEHKEEGATKRTNFSLTGPLGDQFSFRLYGNLDKTQADAWDINQGHQSARAGTYATTLPAGREGVINKDINGVVRWDFAPMQSLELEAGYSRQGNLYAGDTQNTNSDAYTRSKYGDETNRLYRQNYSLTWNGGWDNGVTTSNWVQYEHTRNSRIPEGLAGGTEGKFNEKATQDFVDIDLDDVMLHSEVNLPIDFLVNQTLTLGTEWNQQRMKDLSSNTQALTGTNTGGAIDGVSATDRSPYSKAEIFSLFAENNMELTDSTIVTPGLRFDHHSIVGNNWSPALNISQGLGDDFTLKMGIARAYKAPSLYQTNPNYILYSKGQGCYASAGGCYLQGNDDLKAETSINKEIGLEFKRDGWLAGVTWFRNDYRNKIEAGYVAVGQNAVGTDLYQWDNVPKAVVEGLEGSLNVPVSETVMWTNNITYMLKSENKTTGDRLSIIPEYTLNSTLSWQAREDLSMQTTFTWYGKQQPKKYNYKGQPAVGPETKEISPYSIVGLSATWDVTKNVSLTGGVDNLFDKRLWRAGNAQTTGDLAGANYIAGAGAYTYNEPGRTWYMSVNTHF",
    "product": ""
   },
   {
    "start": 311784,
    "end": 312986,
    "strand": 1,
    "locus_tag": "ctg1_299",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_299</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_299</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 311,784 - 312,986,\n (total: 1203 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1098:enterobactin/ferric enterobactin esterase (Score: 585; E-value: 1.5e-177)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_299\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_299\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_299_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_299\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_299\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGACAGCGTTAAAAGTAGGAAGTGAGAGCTGGTGGCAGTCGAAACATGGCCCGGAATGTCAGCGTCTGAATGACAAAATGTATCAGGTCACTTTCTGGTGGCGTGATCCACAAGGTGCTGAAGACCACTCGACGATAAAGCGCGTATGGGTCTATATCACTGGCGTGACCGATCACCATCAGAACAGCCAACCCCAGTCGATGCAGCGAATTGCAGGGACCGATGTCTGGCAGTGGACGACACAACTCAATGCCAACTGGCGCGGCAGCTACTGTTTTATTCCTACCGAACGTGATGACATTTTTTCTGCACCATCCCCTGATCGCCTTGAATTGCGCGAAGGCTGGCGAAAACTATTACCCCAGGCGATAGCCGATCCGCTGAATCCACAAAGCTGGAAAGGTGGGCGAGGGCACGCTGTTTCTGCACTTGAAATGCCGCAAGCGCCCCTGCAACCTGGATGGGATTGTCCGCAAGCGCCAGAAACGCCTGCCAAAGAAATTATCTGGAAAAGTGAACGGTTGAAAAATTCACGCCGTGTATGGATTTTTACCACCGGCGATGCAACAGCAGAAGAACGTCCGCTGGCAGTTTTACTTGATGGCGAATTTTGGGCGCAGAGTATGCCCGTCTGGCCTGCGCTGACTTCTCTGACCCATCGTCAGCAACTTCCTCCCGCCGTGTACGTGTTGATCGACTCTATCGACACCACGCAACGTGCCCACGAACTGCCATGTAATGCGGATTTCTGGCTGGCAGCACAGCAAGAGTTATTACCCCAGGTGAAAACTATCGCCCCCTTTAGCGATCGCGCCGATCTTACTGTGGTCGCCGGGCAGAGTTTTGGTGGGCTTTCCGCGCTGTATGCCGGACTGCGCTGGCCTGAACGCTTTGGCTGTGTATTAAGCCAGTCGGGATCGTACTGGTGGCCGCATCGGGGCGGGCAGCAAGAGGGCGTGTTACTTGAACAGCTCAAAGCTGGTGAAGTTAGCGCCGAAGGTCTGCGCATTGTGCTGGAAGCGGGTATTCGCGAGCCGATGATCATGCGGGCCAATCAGGCGCTGTATGCGCAATTAACCCCCCTAAAAGAATCCATTTTCTGGCGTCAGGTTGACGGCGGACATGATGCGCTTTGTTGGCGCGGTGGCTTGATGCAGGGGCTAATCGACCTCTGGCAACCACTTTTCCATGACAGGAGTTGA",
    "translation": "MTALKVGSESWWQSKHGPECQRLNDKMYQVTFWWRDPQGAEDHSTIKRVWVYITGVTDHHQNSQPQSMQRIAGTDVWQWTTQLNANWRGSYCFIPTERDDIFSAPSPDRLELREGWRKLLPQAIADPLNPQSWKGGRGHAVSALEMPQAPLQPGWDCPQAPETPAKEIIWKSERLKNSRRVWIFTTGDATAEERPLAVLLDGEFWAQSMPVWPALTSLTHRQQLPPAVYVLIDSIDTTQRAHELPCNADFWLAAQQELLPQVKTIAPFSDRADLTVVAGQSFGGLSALYAGLRWPERFGCVLSQSGSYWWPHRGGQQEGVLLEQLKAGEVSAEGLRIVLEAGIREPMIMRANQALYAQLTPLKESIFWRQVDGGHDALCWRGGLMQGLIDLWQPLFHDRS",
    "product": ""
   },
   {
    "start": 312989,
    "end": 313207,
    "strand": 1,
    "locus_tag": "ctg1_300",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_300</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_300</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 312,989 - 313,207,\n (total: 219 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1009:mbtH-like protein (Score: 95.3; E-value: 2.3e-29)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_300\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_300\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_300_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_300\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_300\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCATTCAGTAATCCCTTCGATGATCCGCAGGGCGTGTTTTACATTTTACGCAATGCGCAGGGGCAATTCAGTCTGTGGCCGCAACAGTGCGCCTTACCGGCAGGCTGGGATGTTGTGTGTCAGCCGCAGTCACAGGCGTCCTGCCAGCACTGGCTGGACGCCCACTGGCGTACTCTGACACCGGCGAATTTCATCCAGCAGCAGGAGGCGCAATGA",
    "translation": "MAFSNPFDDPQGVFYILRNAQGQFSLWPQQCALPAGWDVVCQPQSQASCQHWLDAHWRTLTPANFIQQQEAQ",
    "product": ""
   },
   {
    "start": 313204,
    "end": 317085,
    "strand": 1,
    "locus_tag": "ctg1_301",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_301</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_301</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 313,204 - 317,085,\n (total: 3882 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS: Condensation<br>\n \n  biosynthetic (rule-based-clusters) NRP-metallophore: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRP-metallophore: Condensation<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1127:condensation domain-containing protein (Score: 253.4; E-value: 8.1e-77)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-ctg1_301 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>Thioesterase</strong> (1066..1276)</dt>\n   <dd>\n   \n    active site serine present: True<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_301\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_301\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_301_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_301\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_301\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCCAGCATTTACCTTTAGTTGCCGCACAGCCCGGCATCTGGATGGCAGAAAAACTGTCGGATTTACCCTCCGCCTGGAGCGTGGCGCATTACGTTGAGTTAACCGGAGATGTTGATGCGCCATTACTGGCTCGCGCGGTGGTTGCCGGATTAGCGCAAGCAGATACGCTGCGGATGCGTTTTACGGAAGATAACGGCGAAGTCTGGCAATGGGTCGATGATGCGCTGACGTTCGAACTGCCAGAAATTATCGACCTGCGAACCAACATTGATCCGCACGGTACTGCGCAGGCATTAATGCAGGCGGATTTGCAACAAGATCTGCGCGTCGATAGCGGTAAACCTCTGGTTTTTCATCAACTGATACAGGTGGCAGATAACCGCTGGTACTGGTATCAGCGTTACCACCATTTGCTGGTCGATGGCTTCAGTTTCCCGGTCATTACCCGCCAGATCGCCAACATTTACTGTGCATGGATGCGTGGCGAACCAACACCGGCTTCGCCGTTTACGCCTTTCGCTGACGTGGTGGAAGAGTACCAGCAGTATCGCGAAAGCGAAGCCTGGCAGCGTGATGCGGCATTCTGGGCGGAGCAACGTCGTCAACTACCACCGCCCGCGTCACTTTCTCCAGTCCCTTTACCGGGGCGCAGCGCCTCGGCAGATATTTTGCGTCTGAAACTGGAATTTAACGGCGGGGAATTCCGCCAGTTGGCTACGCAACTTTCAGGTTTACAACGTACCGATATAGCCCTTGCGCTGGCGGCTTTGTGGCTGGGGCGATTGTGCAACCACATGGACTATGCCGCCGGATTTATCTTTATGCGTCGACTGGGCTCAGCTGCGCTGACGGCTACCGGACCTGTGCTCAACGTGTTGCCGTTGGGTATTCACATTGAGGCACAAGAAACGTTGCCGCAACTGGCAGCCCGACTAGCGGCACAACTGAAAAAAATGCGTCGTCATCAACGTTACGATGCCGAACAAATTGTCCGTGACAGTGGGCGAGTCGCAGGAGAGGAACCGTTGTTCGGTCCGGTACTCAATATCAAGGTGTTTGATTACCAACTGGATATTCCTGATGTACAGGCGCAAACCCATACCCTGGCAACCGGTCCGGTTAATGACCTTGAACTGGCGCTGTTCCCGGATGAACACGGTGATTTGAGTATTGAGATCCTCGCCAATAAACAGCGTTACGATGAGCCAACGTTAATCCAGCATGCTGAACGGCTGAAAATGCTGACGGCGCAGTTTGCCGCGGATCCGGCGCGGTTGTGCGGCGATGTCGATATTATGCTGCCAGAAGAGTATGCACAGCTGGCGCAGATCAACGCCACTCAGGTTGAGATTCCAGAAACCACACTGAGCGCGCTGGTGGCAGAACAGGCGGCAAAAACGCCGGATGCTCCGGCACTGGCAGATGTGCGTTACCAGTTCAGTTATCGGGAAATGCGCGAGCAGGTGGTGGCGCTGGCGAATCTGCTGCGTGAGCGCGGCGTCAAACCTGGCGACAGCGTAGCGGTGGCACTACCGCGCTCGGTCTTTTTGACTATGGCGCTACATGCGATAGTTGAAGCAGGTGCGGCCTGGCTACCGCTGGATACGGGCTATCCGGACGATCGCCTGAAAATGATGCTGGAAGATGCGTGTCCGTCACTGTTAATCACCACCGATGATCAACTGCCGCGCTTTAGCGATATCCCCAATTTAACCAGTCTTTGCTATAACGCCCCGCTTACACCGCAGGGCAGTGCGCCGCTGCAACTTTCACAACCGCACCACACGGCTTATATCATCTTTACCTCCGGTTCCACCGGCAGGCCGAAAGGGGTGATGGTCGGGCAGACGGCTATCGTTAACCGCCTGTTATGGATGCAAAACCACTACACGCTCACAGGCGAAGATGTTGTTGCCCAAAAAACGCCGTGCAGTTTTGATGTCTCGGTGTGGGAGTTTTTCTGGCCGTTTATTGCTGGGGCGAAACTGGTGATGGCTGAACCGGAAGCGCACCGCGATCCGCTCGCTATGCAACAATTCTTTGCCGAATATGGCGTAACGACCACGCATTTTGTGCCGTCGATGCTGGCGGCGTTTGTTGCTTCGCTGACGTCGGAAACCGCTCGCCAGAGTTGCGCGACGTTGAAACAGGTTTTCTGTAGTGGAGAAGCCTTACCAGCCGATTTATGTCGCGAATGGCAGCAGTTAACTGGCGCGCCGTTACATAATCTTTATGGCCCGACGGAAGCGGCGGTGGATGTGAGCTGGTATCCAGCCTTTGGTGCTGAACTTGCAGCGGTACGCGGCAGCAGTGTGCCGATTGGCTACCCGGTGTGGAACACGGGCCTGCGCATTCTCGATGCGATGATGCATCCGGTGCCGCCGGGTGTGGCAGGCGATCTCTATCTCACCGGTATTCAACTGGCGCAGGGGTATCTTGGACGACCCGATCTGACAGCCAGCCGCTTTATTGCCGATCCTTTCGCGCCAGGTGAACGGATGTACCGTACCGGAGATGTTGCCCGCTGGCTGGATAACGGCGCGGTGGAGTATCTCGGGCGTAGTGATGATCAGCTAAAAATTCGTGGTCAGCGGATTGAACTGGGCGAAATCGATCGTGTGATGCAGGCGCTGCCGGATGTCGAGCAAGCAGTTACCCACGCTTGTGTGATTAATCAGGCGGCAGCCACCGGAGGGGATGCGCGTCAACTGGTGGGCTATCTGGTGTCGCAATCGGGCCTGCCACTGGATACCAGCACATTGCAGGCGCAGCTTCGCGAAAAATTGCCACCGCATATGGTGCCCGTGGTTCTGCTGCAACTGCCACAGTTACCACTTAGCGCCAACGGTAAGCTGGATCGCAAAGCCTTACCGTTGCCGGAACTGAAGGCACAAGCGCCGGGGCGTGCGCCGAAAGCGGGCAGTGAAACGATTATCGCCGCGGCGTTCTCGTCATTGCTGGGTTGTGACGTGCAGGATGCCGATGCTGATTTCTTTGCGCTTGGCGGTCATTCACTACTGGCAATGAAACTGGCTGCGCAGTTAAGTCGACAGTTTGCCCGTCAGATGACGCCGGGGCAGGTGATGGTCGCGTCAACCGTCGCCAAACTGGCAACGGTTATTGATGGTGAAGAAGACAGCTCCCGGCGCATGGGATTTGAAACCATCCTGCCGTTGCGTGAAGGTAATGGCCCGACGCTGTTTTGTTTCCATCCAGCATCTGGTTTTGCCTGGCAGTTTAGCGTGCTCTCGCGTTATCTAGATCCTCAATGGTCGATTATTGGCATCCAGTCTCCGCGCCCTCATGGCCCCATGCAGACGGCGGCAAACCTGGATGAAGTCTGCGAAGCGCATCTGGCAACGTTACTTGAACAACAACCGCACGGTCCTTATTACCTGCTGGGGTATTCGCTGGGCGGTACGCTGGCGCAGGGAATAGCGGCAAGGCTGCGTGCCCGTGGCGAACAGGTAGCATTTCTTGGCTTGCTGGATACCTGGCCGCCAGAAACGCAGAACTGGCAGGAAAAAGAAGCTAATGGTCTGGACCCGGAAGTGTTGGCGGAGATTAACCGCGAACGTGAAGCCTTCCTGGCGGCACAGCAGGGGAGTACTTCAACGGAGCTGTTTACCACCATTGAAGGCAACTACGCTGATGCAGTGCGCTTGTTGACCACTGCTCATAGTGTACCGTTTGACGGCAAAGCGACGCTGTTTGTTGCCGAACGTACTCTTCAGGAAGGAATGAGTCCCGAACGGGCCTGGTCGCCGTGGATAGCCGAGCTGGATATTTATCGTTTAGATTGTGCGCATGTGGATATTATTTCCCCTGGTTATTTTAAACAAATAGGACCATTAATAAGGACATCAATTAATAACTAA",
    "translation": "MSQHLPLVAAQPGIWMAEKLSDLPSAWSVAHYVELTGDVDAPLLARAVVAGLAQADTLRMRFTEDNGEVWQWVDDALTFELPEIIDLRTNIDPHGTAQALMQADLQQDLRVDSGKPLVFHQLIQVADNRWYWYQRYHHLLVDGFSFPVITRQIANIYCAWMRGEPTPASPFTPFADVVEEYQQYRESEAWQRDAAFWAEQRRQLPPPASLSPVPLPGRSASADILRLKLEFNGGEFRQLATQLSGLQRTDIALALAALWLGRLCNHMDYAAGFIFMRRLGSAALTATGPVLNVLPLGIHIEAQETLPQLAARLAAQLKKMRRHQRYDAEQIVRDSGRVAGEEPLFGPVLNIKVFDYQLDIPDVQAQTHTLATGPVNDLELALFPDEHGDLSIEILANKQRYDEPTLIQHAERLKMLTAQFAADPARLCGDVDIMLPEEYAQLAQINATQVEIPETTLSALVAEQAAKTPDAPALADVRYQFSYREMREQVVALANLLRERGVKPGDSVAVALPRSVFLTMALHAIVEAGAAWLPLDTGYPDDRLKMMLEDACPSLLITTDDQLPRFSDIPNLTSLCYNAPLTPQGSAPLQLSQPHHTAYIIFTSGSTGRPKGVMVGQTAIVNRLLWMQNHYTLTGEDVVAQKTPCSFDVSVWEFFWPFIAGAKLVMAEPEAHRDPLAMQQFFAEYGVTTTHFVPSMLAAFVASLTSETARQSCATLKQVFCSGEALPADLCREWQQLTGAPLHNLYGPTEAAVDVSWYPAFGAELAAVRGSSVPIGYPVWNTGLRILDAMMHPVPPGVAGDLYLTGIQLAQGYLGRPDLTASRFIADPFAPGERMYRTGDVARWLDNGAVEYLGRSDDQLKIRGQRIELGEIDRVMQALPDVEQAVTHACVINQAAATGGDARQLVGYLVSQSGLPLDTSTLQAQLREKLPPHMVPVVLLQLPQLPLSANGKLDRKALPLPELKAQAPGRAPKAGSETIIAAAFSSLLGCDVQDADADFFALGGHSLLAMKLAAQLSRQFARQMTPGQVMVASTVAKLATVIDGEEDSSRRMGFETILPLREGNGPTLFCFHPASGFAWQFSVLSRYLDPQWSIIGIQSPRPHGPMQTAANLDEVCEAHLATLLEQQPHGPYYLLGYSLGGTLAQGIAARLRARGEQVAFLGLLDTWPPETQNWQEKEANGLDPEVLAEINREREAFLAAQQGSTSTELFTTIEGNYADAVRLLTTAHSVPFDGKATLFVAERTLQEGMSPERAWSPWIAELDIYRLDCAHVDIISPGYFKQIGPLIRTSINN",
    "product": ""
   },
   {
    "start": 317331,
    "end": 318470,
    "strand": 1,
    "locus_tag": "ctg1_302",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_302</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_302</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 317,331 - 318,470,\n (total: 1140 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1254:ferric enterobactin transport protein FepE (Score: 708; E-value: 4.1e-215)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_302\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_302\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSSLNVNREKDSDFVGYALPSPDRNEIDLLHLIDVLWRAKKQIIAISFAFACAGILISFLLPQKWTSAAVVTPAEAVQWQELERTFTKLRVLDVDAGIDRSSVFNLFIKKFQSPTLLEDYLRSSPYVMDQLKGAEIDELELHRAIVALSEKMKAVDENSSKKKDETALYTAWRLSFTAPTKEEAQQVLAGYIQYISNLVVTESLENIRNKLEIKTRFEQEKLAQDRVKIRNQLDANIQRLNYSLDIANAAGIKKPVYSNGQAVKDDPEFSISLGADGIQRKLEIEKGVTDVAELNGDLRNRQYYVEQLKKLNVSDVKFSPFKYQMKPSLPVKKDGPGRAIIAILAALVGGMVACGSVLMRNAMLSRKMEKAITVDEQLV\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_302\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_302\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCATCATTAAATGTAAATCGAGAAAAAGACTCGGATTTCGTCGGCTATGCATTACCTTCGCCTGACAGAAATGAAATAGATTTATTACATCTTATTGACGTTCTTTGGCGGGCAAAGAAGCAAATTATTGCCATTAGTTTTGCATTTGCTTGTGCCGGAATATTAATTTCCTTTTTGTTGCCACAAAAATGGACCAGTGCAGCGGTAGTCACTCCTGCAGAAGCCGTGCAGTGGCAGGAACTGGAAAGAACATTTACCAAATTACGTGTACTGGATGTCGACGCTGGTATTGATCGTAGCAGCGTATTTAACCTTTTTATTAAGAAGTTTCAATCTCCTACACTGCTGGAAGATTATCTCCGCTCCTCACCTTATGTTATGGATCAACTGAAAGGAGCTGAAATTGATGAACTGGAGTTACACCGGGCTATTGTTGCGCTCAGCGAGAAAATGAAAGCGGTGGATGAGAACTCCAGCAAGAAGAAAGATGAAACTGCGCTCTATACTGCCTGGCGTTTAAGCTTTACTGCACCGACAAAAGAAGAAGCACAGCAGGTTCTGGCAGGTTATATCCAGTATATTTCCAATCTGGTGGTTACAGAATCACTGGAGAATATCCGTAATAAACTGGAAATTAAAACCCGTTTTGAGCAAGAAAAACTGGCTCAGGATCGTGTGAAAATACGTAATCAGTTGGATGCAAATATTCAACGACTGAATTATTCGCTCGACATTGCCAACGCTGCCGGGATTAAAAAACCAGTTTATAGCAACGGACAGGCAGTAAAAGACGATCCAGAATTTTCAATTTCTCTCGGTGCCGATGGTATTCAGCGTAAACTGGAAATCGAAAAAGGCGTTACAGACGTAGCCGAACTGAATGGCGATTTGCGTAATCGACAGTATTACGTAGAGCAACTCAAAAAGCTGAATGTTAGCGATGTCAAATTTTCACCGTTTAAATATCAGATGAAACCATCATTGCCGGTGAAGAAAGATGGTCCGGGGAGAGCGATTATTGCCATTCTGGCAGCGCTTGTGGGTGGAATGGTTGCTTGTGGTAGTGTACTGATGCGTAACGCCATGCTTTCTCGCAAGATGGAGAAAGCCATTACGGTAGATGAACAGTTAGTGTGA",
    "translation": "MSSLNVNREKDSDFVGYALPSPDRNEIDLLHLIDVLWRAKKQIIAISFAFACAGILISFLLPQKWTSAAVVTPAEAVQWQELERTFTKLRVLDVDAGIDRSSVFNLFIKKFQSPTLLEDYLRSSPYVMDQLKGAEIDELELHRAIVALSEKMKAVDENSSKKKDETALYTAWRLSFTAPTKEEAQQVLAGYIQYISNLVVTESLENIRNKLEIKTRFEQEKLAQDRVKIRNQLDANIQRLNYSLDIANAAGIKKPVYSNGQAVKDDPEFSISLGADGIQRKLEIEKGVTDVAELNGDLRNRQYYVEQLKKLNVSDVKFSPFKYQMKPSLPVKKDGPGRAIIAILAALVGGMVACGSVLMRNAMLSRKMEKAITVDEQLV",
    "product": ""
   },
   {
    "start": 318505,
    "end": 319305,
    "strand": -1,
    "locus_tag": "ctg1_303",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_303</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_303</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 318,505 - 319,305,\n (total: 801 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 223.9; E-value: 3.7e-68)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_303\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_303\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_303_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMTESVARLRGEQLTLGYGKYTVAENLTVEIPDGHFTAIIGPNGCGKSTLLRTLSRLMTPAHGHVWLDGEHIQHYASKEVARRIGLLAQNATTPGDITVQELVARGRYPHQPLFTRWRKEDEEAVTKAMQATGITHLANQSVDTLSGGQRQRAWIAMVLAQETAIMLLDEPTTWLDISHQIDLLELLSELNREKGYTLAAVLHDLNQACRYASHLIALREGKIVAQGAPKEIVTAELIERIYGLRCMIIDDPVAGTPLVVPLGRNKK\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_303\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_303\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGAATCAGTAGCCCGTTTGCGTGGCGAACAGTTAACCCTAGGATATGGCAAATATACCGTTGCGGAAAATCTGACTGTAGAAATTCCTGATGGTCACTTCACGGCAATTATCGGGCCAAATGGCTGCGGTAAATCCACGTTACTGCGTACCTTAAGCCGCCTGATGACGCCTGCTCACGGGCATGTCTGGCTGGATGGCGAGCACATTCAACATTACGCCAGTAAAGAGGTCGCACGCCGGATTGGTTTACTGGCGCAAAACGCCACCACGCCGGGAGATATCACCGTGCAGGAGTTAGTAGCGCGCGGGCGTTACCCGCATCAACCGCTGTTTACCCGCTGGCGTAAAGAAGATGAAGAAGCGGTAACGAAAGCGATGCAGGCCACAGGAATAACTCATCTGGCAAATCAAAGCGTTGATACCCTCTCCGGTGGACAACGTCAGCGAGCGTGGATCGCGATGGTGCTGGCCCAGGAAACGGCAATTATGCTGCTCGATGAACCAACGACCTGGCTGGATATCAGTCATCAGATTGATCTACTGGAACTGCTAAGCGAACTGAACCGCGAGAAAGGCTATACTCTGGCGGCGGTACTGCACGATCTTAATCAGGCCTGTCGTTACGCCAGCCATTTGATTGCATTGCGGGAAGGGAAAATTGTCGCTCAGGGAGCACCGAAAGAGATTGTCACTGCTGAATTGATCGAGCGTATTTATGGTTTGCGTTGCATGATAATTGACGATCCGGTAGCCGGAACACCGCTTGTAGTGCCGCTCGGGAGAAATAAAAAATGA",
    "translation": "MTESVARLRGEQLTLGYGKYTVAENLTVEIPDGHFTAIIGPNGCGKSTLLRTLSRLMTPAHGHVWLDGEHIQHYASKEVARRIGLLAQNATTPGDITVQELVARGRYPHQPLFTRWRKEDEEAVTKAMQATGITHLANQSVDTLSGGQRQRAWIAMVLAQETAIMLLDEPTTWLDISHQIDLLELLSELNREKGYTLAAVLHDLNQACRYASHLIALREGKIVAQGAPKEIVTAELIERIYGLRCMIIDDPVAGTPLVVPLGRNKK",
    "product": ""
   },
   {
    "start": 319302,
    "end": 320294,
    "strand": -1,
    "locus_tag": "ctg1_304",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_304</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_304</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 319,302 - 320,294,\n (total: 993 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1011:transport system permease protein (Score: 353.1; E-value: 2.1e-107)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_304\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_304\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_304_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMIYVSRRLIITCLLLLIACVMASVWGLRSGAVTLETSQVFAALMGDAPRSMTMVVTEWRLPRVLMALLIGAALGVSGAIFQSLMRNPLGSPDVMGFNTGAWSGVLVAMVLFGQDLTAIALAAMAGGIITSLLVWLLAWRNGIDTFRLIIIGIGVRAMLVAFNTWLLLKASLETALTAGLWNAGSLNGLTWAKTSPSAPIIILMLIAAALLVRRMRLLEMGDDTACALGVSVERSRLLMMLVAVVLTAAATALAGPISFIALVAPHIARRISGTARWGLTQAALCGALLLLAADLCAQQLFMPYQLPVGVVTVSLGGIYLIVLLIQESRKK\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_304\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_304\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTTACGTCTCTCGTCGATTAATTATCACCTGTCTGCTGTTGCTAATAGCCTGTGTGATGGCAAGCGTGTGGGGATTACGCAGCGGTGCCGTCACGCTGGAAACCTCGCAGGTATTTGCCGCGCTGATGGGTGACGCACCGCGCAGTATGACAATGGTGGTCACCGAATGGCGTTTACCGCGGGTACTAATGGCGCTGTTGATTGGTGCGGCACTGGGCGTCAGCGGCGCGATTTTTCAGTCGTTGATGCGTAACCCACTCGGCAGCCCTGACGTAATGGGCTTTAACACCGGAGCGTGGAGCGGCGTGCTGGTGGCGATGGTGCTGTTTGGTCAGGACCTGACGGCTATCGCGCTGGCAGCAATGGCGGGCGGCATTATCACTTCGCTGCTGGTCTGGTTGCTTGCCTGGCGTAACGGTATCGACACCTTTCGGTTGATTATTATCGGCATCGGCGTTCGCGCCATGCTGGTGGCCTTTAATACCTGGCTGTTGCTGAAAGCGTCTTTAGAAACGGCGTTAACAGCGGGTTTGTGGAATGCCGGATCGCTCAATGGCCTGACGTGGGCAAAAACCTCGCCCTCCGCGCCCATCATTATATTGATGCTAATTGCCGCCGCCTTACTGGTAAGGCGGATGCGCTTGCTGGAGATGGGTGATGACACCGCGTGTGCGTTAGGCGTCAGCGTCGAACGTTCGCGTCTATTAATGATGCTGGTCGCCGTAGTACTTACCGCAGCTGCCACTGCCCTGGCGGGGCCGATTTCCTTTATTGCTTTAGTCGCGCCACACATTGCCCGCCGCATCAGCGGCACCGCTCGCTGGGGGCTAACCCAGGCGGCGCTGTGCGGTGCGCTGTTACTGCTGGCAGCCGATCTCTGTGCTCAGCAACTGTTTATGCCGTATCAACTTCCGGTTGGCGTCGTTACCGTCAGCCTCGGCGGTATTTACCTTATCGTCTTGTTAATTCAGGAGTCTCGCAAAAAATGA",
    "translation": "MIYVSRRLIITCLLLLIACVMASVWGLRSGAVTLETSQVFAALMGDAPRSMTMVVTEWRLPRVLMALLIGAALGVSGAIFQSLMRNPLGSPDVMGFNTGAWSGVLVAMVLFGQDLTAIALAAMAGGIITSLLVWLLAWRNGIDTFRLIIIGIGVRAMLVAFNTWLLLKASLETALTAGLWNAGSLNGLTWAKTSPSAPIIILMLIAAALLVRRMRLLEMGDDTACALGVSVERSRLLMMLVAVVLTAAATALAGPISFIALVAPHIARRISGTARWGLTQAALCGALLLLAADLCAQQLFMPYQLPVGVVTVSLGGIYLIVLLIQESRKK",
    "product": ""
   },
   {
    "start": 320291,
    "end": 321295,
    "strand": -1,
    "locus_tag": "ctg1_305",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_305</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_305</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 320,291 - 321,295,\n (total: 1005 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1011:transport system permease protein (Score: 339.7; E-value: 2.5e-103)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_305\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_305\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_305_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSGSVAVTRAIAVPGLLLLLIIATALSLLIGAKSLPASVVLEALSGTCQSADCTIVLDARLPRTLAGLLAGGALGLAGALMQTLTRNPLADPGLLGVNAGASFAIVLGAALFGYSSAQEQLAMAFAGALVASLIVAFTGSQGGGQLSPVRLTLAGVALAAVLEGLTSGIALLNPDVYDQLRFWQAGSLDIRNLHTLKVVLIPVLIAGATALLLSRALNSLSLGSDTATALGSRVARTQLIGLLTITVLCGSATAVVGPIAFIGLMMPHMARWLVGADHRWSLPVTLLATPALLLFADIIGRVIVPGELRVSVVSAFIGAPVLIFLVRRKTRGGA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_305\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_305\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCTGGTTCTGTTGCCGTGACACGCGCCATTGCCGTGCCCGGATTGCTGTTATTACTGATTATCGCGACGGCATTAAGCCTGCTCATTGGGGCAAAATCACTCCCCGCTTCCGTAGTGCTGGAGGCCCTCTCCGGCACCTGCCAGAGCGCCGACTGCACCATCGTGCTCGACGCGCGACTGCCGCGTACCCTTGCCGGTTTACTGGCAGGCGGCGCGCTTGGCCTTGCCGGGGCGTTAATGCAAACCCTCACCCGAAACCCACTTGCCGACCCCGGCTTGCTTGGCGTGAACGCCGGGGCCAGCTTTGCCATTGTGCTGGGCGCGGCGCTGTTTGGTTACTCATCCGCGCAGGAACAACTAGCGATGGCCTTCGCCGGGGCGCTGGTGGCCTCGTTGATTGTTGCCTTTACTGGCAGCCAGGGCGGTGGGCAGTTAAGTCCGGTGCGTTTAACTCTGGCGGGCGTGGCGCTGGCGGCAGTGCTGGAAGGGCTGACCAGCGGCATCGCCCTGCTTAATCCCGACGTCTACGATCAACTGCGTTTCTGGCAAGCCGGTTCGCTGGATATTCGTAATTTACACACCTTAAAAGTAGTGCTGATCCCGGTGCTGATCGCTGGAGCAACTGCACTATTACTGAGCCGCGCGCTGAACAGTTTAAGCCTTGGCAGTGACACCGCGACGGCGCTGGGCAGTCGCGTGGCGCGCACACAGTTGATTGGTCTGCTGACGATTACCGTGCTTTGTGGTAGTGCGACGGCGGTAGTTGGCCCGATTGCTTTTATTGGCCTGATGATGCCGCACATGGCACGTTGGTTGGTTGGAGCCGATCATCGCTGGTCGCTGCCCGTCACGCTGCTCGCCACACCAGCCCTGCTGCTGTTTGCCGATATTATCGGGCGTGTGATTGTTCCCGGCGAACTGCGCGTTTCTGTAGTCAGTGCCTTTATTGGCGCACCAGTGCTGATCTTCCTTGTACGACGTAAAACGCGAGGTGGCGCATGA",
    "translation": "MSGSVAVTRAIAVPGLLLLLIIATALSLLIGAKSLPASVVLEALSGTCQSADCTIVLDARLPRTLAGLLAGGALGLAGALMQTLTRNPLADPGLLGVNAGASFAIVLGAALFGYSSAQEQLAMAFAGALVASLIVAFTGSQGGGQLSPVRLTLAGVALAAVLEGLTSGIALLNPDVYDQLRFWQAGSLDIRNLHTLKVVLIPVLIAGATALLLSRALNSLSLGSDTATALGSRVARTQLIGLLTITVLCGSATAVVGPIAFIGLMMPHMARWLVGADHRWSLPVTLLATPALLLFADIIGRVIVPGELRVSVVSAFIGAPVLIFLVRRKTRGGA",
    "product": ""
   },
   {
    "start": 321406,
    "end": 322656,
    "strand": 1,
    "locus_tag": "ctg1_306",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_306</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_306</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 321,406 - 322,656,\n (total: 1251 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1020:major facilitator transporter (Score: 394.9; E-value: 6.5e-120)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_306\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_306\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_306_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMNKQSWLLNLSLLKTHPAFRAVFLARFISIVSLGLLGVAVPVQIQMMTHSTWQVGLSVTLTGGAMFVGLMVGGVLADRYERKKVILLARGTCGIGFIGLCLNALLPEPSLLAIYLLGLWDGFFASLGVTALLAATPALVGRENLMQAGAITMLTVRLGSVISPMIGGLLLATGGVAWNYGLAAAGTFITLLPLLSLPALPPPPQPREHPLKSLLAGFRFLLASPLVGGIALLGGLLTMASAVRVLYPALADNWQMSAAQIGFLYAAIPLGAAIGALTSGKLAHSARPGLLMLLSTLGSFLAIGLFGLMPMWILGVVCLALFGWLSAVSSLLQYTMLQTQTPEAMLGRINGLWTAQNVTGDAIGAALLGGLGAMMTPVASASASGFGLLIIGVLLLLVLVELRRFRQTPPQVTASDS\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_306\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_306\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAATAAACAATCCTGGCTGCTTAACCTCAGCCTGTTGAAAACGCACCCGGCGTTTCGCGCAGTATTCCTCGCTCGTTTTATCTCTATTGTTTCTCTGGGTTTGCTCGGCGTCGCGGTGCCAGTGCAGATCCAGATGATGACGCATTCTACCTGGCAGGTGGGGCTTTCGGTGACGCTGACCGGCGGCGCGATGTTTGTTGGCCTGATGGTCGGCGGTGTGCTGGCGGATCGCTATGAACGCAAAAAAGTGATTTTGCTGGCGCGCGGCACCTGTGGCATTGGCTTCATTGGACTGTGCCTTAATGCACTGCTGCCGGAGCCGTCATTGCTGGCAATCTATTTACTTGGTTTATGGGATGGTTTTTTCGCATCACTTGGCGTTACGGCGCTACTGGCGGCGACACCAGCACTGGTAGGGCGTGAAAACCTAATGCAGGCCGGGGCGATCACCATGTTGACCGTGCGGCTGGGATCGGTAATTTCGCCCATGATTGGCGGCTTACTGCTGGCGACTGGCGGCGTAGCCTGGAACTACGGGCTGGCGGCGGCGGGCACGTTTATTACCTTGCTACCATTGTTAAGCCTTCCGGCGCTACCTCCGCCACCGCAACCGCGTGAGCATCCGTTGAAATCATTACTGGCAGGATTTCGTTTTCTGCTCGCCAGCCCGCTGGTGGGAGGGATTGCACTGCTGGGGGGATTATTGACGATGGCGAGCGCGGTACGGGTACTGTATCCGGCGCTGGCTGACAACTGGCAGATGTCGGCGGCACAGATTGGTTTTCTCTATGCGGCGATCCCGCTCGGTGCAGCTATTGGCGCGTTAACCAGCGGGAAGCTGGCACATAGCGCGCGACCAGGGTTATTGATGCTGCTCTCCACGCTGGGATCGTTCCTCGCCATTGGTTTGTTTGGCCTGATGCCGATGTGGATTTTAGGCGTGGTTTGCCTGGCGCTGTTCGGCTGGCTGAGCGCGGTTAGTTCATTGCTGCAATACACAATGCTGCAAACGCAAACCCCGGAAGCGATGTTAGGGCGGATTAACGGTTTGTGGACGGCACAAAACGTGACGGGCGATGCTATAGGCGCAGCGCTGTTGGGTGGTCTGGGAGCGATGATGACGCCGGTGGCCTCCGCAAGCGCGAGTGGTTTTGGTTTGTTGATTATCGGCGTGTTGTTGTTGCTGGTACTGGTGGAGTTGCGTCGTTTTCGCCAGACGCCGCCGCAGGTGACAGCGTCTGACAGTTAA",
    "translation": "MNKQSWLLNLSLLKTHPAFRAVFLARFISIVSLGLLGVAVPVQIQMMTHSTWQVGLSVTLTGGAMFVGLMVGGVLADRYERKKVILLARGTCGIGFIGLCLNALLPEPSLLAIYLLGLWDGFFASLGVTALLAATPALVGRENLMQAGAITMLTVRLGSVISPMIGGLLLATGGVAWNYGLAAAGTFITLLPLLSLPALPPPPQPREHPLKSLLAGFRFLLASPLVGGIALLGGLLTMASAVRVLYPALADNWQMSAAQIGFLYAAIPLGAAIGALTSGKLAHSARPGLLMLLSTLGSFLAIGLFGLMPMWILGVVCLALFGWLSAVSSLLQYTMLQTQTPEAMLGRINGLWTAQNVTGDAIGAALLGGLGAMMTPVASASASGFGLLIIGVLLLLVLVELRRFRQTPPQVTASDS",
    "product": ""
   },
   {
    "start": 322660,
    "end": 323616,
    "strand": -1,
    "locus_tag": "ctg1_307",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_307</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_307</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 322,660 - 323,616,\n (total: 957 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1033:iron compound ABC transporter, periplasmic (Score: 339.1; E-value: 3.3e-103)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_307\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_307\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_307_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMRLAPLYHNALLLAGLLLSGISAVQAADWPRQITDSRGTHTLESPPQRIVSTSVTLTGSLLAIDAPVIASGATTPNNRVADDQGFLRQWSKVAKERKLQRLYIGEPNAEAVAAQMPDLILISATGGDSALALYDQLSTIAPTLIINYDDKSWQSLLTQLGEITGHEKQAAERIAQFDKQLAAAKEQIKLPPQPVTAIVYTAAAHSANLWTAESAQGQMLEQLGFTLARLPAGLNASQSQGKRHDIIQLGGENLAAGLNGESLFLFAGDQKDADAIYANPLLAHLPAVQNKQVYALGTETFRLDYYSAMQVLDRLKALF\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_307\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_307\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGACTCGCCCCGCTCTACCACAACGCCCTTCTTTTAGCAGGACTTTTGCTTTCAGGAATATCCGCAGTTCAGGCTGCCGACTGGCCGCGTCAGATTACTGACAGTCGTGGTACTCATACCCTGGAAAGCCCGCCGCAGCGTATTGTTTCCACCAGCGTCACCCTGACCGGCTCACTGCTGGCGATTGATGCACCAGTGATCGCCAGCGGCGCGACCACGCCGAATAACCGCGTAGCGGATGACCAGGGCTTTTTACGCCAGTGGAGCAAGGTGGCGAAAGAACGCAAACTGCAACGTCTCTATATCGGCGAACCGAACGCCGAAGCGGTGGCCGCGCAAATGCCGGATCTGATTTTAATTAGCGCAACCGGCGGCGATTCGGCGCTGGCGCTGTACGATCAGCTTTCCACCATCGCCCCGACGTTAATCATCAATTACGACGACAAAAGCTGGCAGTCGCTGTTAACGCAGCTTGGCGAAATTACCGGGCATGAGAAACAAGCGGCAGAGCGGATTGCGCAGTTTGATAAGCAACTGGCGGCGGCGAAAGAGCAAATCAAATTACCGCCGCAGCCGGTCACTGCCATTGTCTATACCGCCGCCGCGCACAGTGCCAATCTCTGGACAGCTGAATCAGCACAAGGGCAGATGCTGGAACAACTCGGCTTTACGCTGGCCAGGTTGCCCGCAGGCTTAAACGCCAGCCAAAGCCAGGGCAAACGCCATGACATCATTCAGCTTGGTGGGGAAAATCTGGCGGCAGGGTTAAATGGCGAGTCGCTATTCCTGTTCGCCGGTGATCAGAAAGACGCCGATGCGATTTATGCCAATCCACTGCTCGCACACCTGCCTGCAGTACAAAACAAGCAGGTTTATGCGCTGGGAACCGAGACGTTCCGACTGGATTACTACAGCGCCATGCAAGTGCTGGATCGGCTTAAGGCGCTGTTCTAA",
    "translation": "MRLAPLYHNALLLAGLLLSGISAVQAADWPRQITDSRGTHTLESPPQRIVSTSVTLTGSLLAIDAPVIASGATTPNNRVADDQGFLRQWSKVAKERKLQRLYIGEPNAEAVAAQMPDLILISATGGDSALALYDQLSTIAPTLIINYDDKSWQSLLTQLGEITGHEKQAAERIAQFDKQLAAAKEQIKLPPQPVTAIVYTAAAHSANLWTAESAQGQMLEQLGFTLARLPAGLNASQSQGKRHDIIQLGGENLAAGLNGESLFLFAGDQKDADAIYANPLLAHLPAVQNKQVYALGTETFRLDYYSAMQVLDRLKALF",
    "product": ""
   },
   {
    "start": 323805,
    "end": 324980,
    "strand": 1,
    "locus_tag": "ctg1_308",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_308</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_308</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 323,805 - 324,980,\n (total: 1176 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRP-metallophore: EntC<br>\n \n  biosynthetic-additional (smcogs) SMCOG1018:isochorismate synthase (Score: 408.9; E-value: 5.5e-124)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_308\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_308\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_308_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_308\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_308\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGATACGTCACTGGCTGAGGAAGTACAGCAGACCATGGCAACACTTGCGCCCAATCGCTTTTTCTTTATGTCGCCGTACCGCAGTTTTACGACGTCAGGATGTTTCGCCCGCTTTGATGAACCGGCTGTGAACGGGGATTCGCCCGACAGTCCCTTCCAGCAAAAACTCACCGCGCTGTTTGCCGATGCCAAAGCGCAGGGCATTAAAAATCCGGTGATGGTTGGGGCGATTCCCTTCGATCCACGTCAGCCTTCGTCGCTGTATATTCCCGAATCCTGGCAGTCGTTCTCCCGGCTGGAAAAACAGACTTCAGCCCGCCGTTTCACCCGCAGCCAGTCGCTGAACGTGGTGGAACGTCAGGCAATTCCTGAACAAGCTACGTTTGAACAGATGGTTGCCCGCGCCGCCGCACTTACCGCCACGCCGCAAGTCGACAAAGTGGTGTTGTCACGGTTGATTGATATCACCACTGACGCCGTCATTGATAGTGGCGTATTGCTGGAACGGTTGATTGTGCAAAACCCGGTTAGTTACAACTTCCATGTGCCGTTAGCTGATGGTGGCGTCCTGCTGGGAGCCAGCCCGGAACTGCTGCTACGTAAAGACGGCGAGCGTTTTAGCTCCATTCCGTTAGCCGGTTCCGCGCGCCGTCAGCCGGATGACGTGCTCGATCGCGAAGCGGGTAATCGTCTGCTGGCGTCAGAAAAAGATCGCCATGAACATGAACTTGTCACTCAGGCGATGAAAGAGGTACTGCGCGAACGCAGTAGTGAGTTACACGTTCCATCCTCCCCACAATTGCTCACCACACCGACGCTGTGGCATCTCGCAACACCCTTTGAAGGCAAAGCGAATTCGCAAGAAAACGCATTGACTCTGGCCTGTCTGCTGCATCCGACCCCCGCGCTGAGCGGTTTCCCGCATCAGGCCGCGACCCAGGTGATTGCTGAGCTGGAACCGTTCGACCGCGAACTGTTTGGCGGCATTGTGGGTTGGTGTGACAGCGAAGGTAACGGCGAGTGGGTGGTGACCATCCGCTGCGCGAAGCTGCGGGAAAATCAGGTACGTCTGTTTGCCGGAGCGGGGATTGTGCCTGCGTCCTCACCGTTGGGTGAATGGCGCGAAACGGGCGTCAAACTTTCTACCATGTTGAACGTTTTTGGATTGCATTAA",
    "translation": "MDTSLAEEVQQTMATLAPNRFFFMSPYRSFTTSGCFARFDEPAVNGDSPDSPFQQKLTALFADAKAQGIKNPVMVGAIPFDPRQPSSLYIPESWQSFSRLEKQTSARRFTRSQSLNVVERQAIPEQATFEQMVARAAALTATPQVDKVVLSRLIDITTDAVIDSGVLLERLIVQNPVSYNFHVPLADGGVLLGASPELLLRKDGERFSSIPLAGSARRQPDDVLDREAGNRLLASEKDRHEHELVTQAMKEVLRERSSELHVPSSPQLLTTPTLWHLATPFEGKANSQENALTLACLLHPTPALSGFPHQAATQVIAELEPFDRELFGGIVGWCDSEGNGEWVVTIRCAKLRENQVRLFAGAGIVPASSPLGEWRETGVKLSTMLNVFGLH",
    "product": ""
   },
   {
    "start": 324990,
    "end": 326600,
    "strand": 1,
    "locus_tag": "ctg1_309",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_309</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_309</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 324,990 - 326,600,\n (total: 1611 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 451.9; E-value: 3.7e-137)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_309\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_309\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_309_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_309\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_309\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCATTCCATTCACCCGCTGGCCGGAAGAGTTTGCCCGTCGCTATCGGGAAAAAGGCTACTGGCAGGATTTGCCACTGACCGACATTCTGACTCGCCACGCTGCGAGTGACAGCATCGCGGTTATCGACGGCGAGCGGCAGTTGAGTTACCGGGAGCTGAATCAGGCGGCGGATAACCTCGCCTGTAGTTTGCGCCGTCAGGGCATTAAACCCGGTGAAACCGCGCTGGTACAACTGGGTAACGTCGCTGAATTGTATATTACCTTTTTCGCGCTGCTGAAACTGGGCGTTGCGCCGGTGCTGGCGCTGTTCAGTCATCAGCGTAGTGAACTGAACGCCTATGCCAGCCAGATTGAACCGGCGTTACTGATTGCCGATCGCCAACATGCGCTATTTAGCGGGGATGATTTCCTCAACACATTTGTTGCAGAGCATTCTTCCATTCGCGTGGTGCAACTGCTGAACGACAGCGGTGAGCATAACTTGCAGGATGCGATTAACCATCCGGCTGAGGATTTTACTGCCACGCCATCTCCTGCTGATGAAGTGGCCTATTTCCAGCTTTCCGGCGGCACCACCGGCACACCGAAACTGATCCCGCGCACTCATAACGACTACTACTACAGCGTGCGTCGTAGCGTCGAGATTTGTCAGTTCACACAACAGACGCGCTACCTGTGCGCGATCCCGGCGGCTCATAACTACGCCATGAGTTCGCCGGGATCGTTGGGGGTATTTCTCGCTGGCGGCACTGTCGTTCTGGCTGCCGACCCCAGCGCCACGCTTTGTTTCCCATTGATTGAAAAACATCAGGTGAACGTCACCGCGCTGGTGCCGCCAGCAGTCAGCCTGTGGTTACAGGCGCTGACCGAAGGTGAAAGCCGGGCGCAGCTTGCCTCGCTGAAACTGTTACAGGTCGGTGGCGCACGTCTTTCTGCCACGCTTGCGGCGCGTATTCCCGCAGAGATTGGCTGCCAGTTACAGCAGGTATTCGGCATGGCGGAAGGGCTGGTGAACTACACCCGTCTTGATGATAGCGCGGAGAAAATTATCCATACCCAGGGCTATCCAATGTGTCCGGATGATGAAGTGTGGGTTGCCGATGCTGACGGAAATCCACTGCCGCAAGGGGAGGTTGGACGCCTGATGACGCGCGGGCCGTACACCTTCCGCGGCTATTACAAAAGTCCACAGCACAATGCCAGCGCCTTTGATGCCAACGGTTTTTACTGTTCCGGCGATCTGATCTCTATTGATCCAGAGGGGTACATCACCGTGCAGGGGCGCGAGAAAGATCAGATCAACCGTGGCGGCGAGAAGATCGCTGCCGAAGAGATCGAAAACCTGTTACTGCGCCATCCGGCGGTGATCTACGCCGCCCTGGTGAGTATGGAAGATGAGCTGATGGGCGAAAAAAGCTGTGCTTATCTGGTGGTAAAAGAACCACTGCGTGCGGTACAGGTGCGTCGTTTCCTGCGTGAACAGGGTATTGCCGAATTTAAATTACCGGATCGCGTGGAGTGTGTAGATTCACTTCCGCTGACGGCGGTCGGGAAAGTCGATAAAAAACAATTACGTCAGTGGCTGGCGTCACGCGCATCAGCCTGA",
    "translation": "MSIPFTRWPEEFARRYREKGYWQDLPLTDILTRHAASDSIAVIDGERQLSYRELNQAADNLACSLRRQGIKPGETALVQLGNVAELYITFFALLKLGVAPVLALFSHQRSELNAYASQIEPALLIADRQHALFSGDDFLNTFVAEHSSIRVVQLLNDSGEHNLQDAINHPAEDFTATPSPADEVAYFQLSGGTTGTPKLIPRTHNDYYYSVRRSVEICQFTQQTRYLCAIPAAHNYAMSSPGSLGVFLAGGTVVLAADPSATLCFPLIEKHQVNVTALVPPAVSLWLQALTEGESRAQLASLKLLQVGGARLSATLAARIPAEIGCQLQQVFGMAEGLVNYTRLDDSAEKIIHTQGYPMCPDDEVWVADADGNPLPQGEVGRLMTRGPYTFRGYYKSPQHNASAFDANGFYCSGDLISIDPEGYITVQGREKDQINRGGEKIAAEEIENLLLRHPAVIYAALVSMEDELMGEKSCAYLVVKEPLRAVQVRRFLREQGIAEFKLPDRVECVDSLPLTAVGKVDKKQLRQWLASRASA",
    "product": ""
   },
   {
    "start": 326614,
    "end": 327471,
    "strand": 1,
    "locus_tag": "ctg1_310",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_310</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_310</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 326,614 - 327,471,\n (total: 858 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1027:isochorismatase (Score: 416; E-value: 8.1e-127)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_310\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_310\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_310_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_310\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_310\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTATTCCAAAATTACAGGCTTACGCACTGCCGGAGTCTCACGATATTCCGCACAATAAAGTCAACTGGACCTTTGAGCCGCAACGTGCCGCGTTGTTAATCCATGATATGCAGGACTATTTTGTTAGCTTCTGGGGCGAGAACTGCCCGATGATGGAGCAGGTGATCGCGAATATTGCGGCACTACGCAACTACTGCAAACAGCACAATATCCCGGTTTATTACACCGCCCAGCCGAAAGAGCAGAGCGATGAAGATCGGGCGCTGTTGAATGATATGTGGGGGCCGGGCCTGACCCGTTCGCCGGAACAGCAAAAGGTGGTGGATCGCCTGACGCCAGATGCCGACGACACGGTGCTGGTGAAGTGGCGCTACAGCGCGTTTCATCGTTCTCCGCTGGAACAAATGCTCAAAGAGAGTGGACGTAACCAACTGATTATAACCGGGGTGTACGCCCACATTGGCTGTATGACCACCGCAACCGACGCATTTATGCGCGATATTAAACCGTTTATGGTGGCAGATGCGCTGGCCGATTTCAGCCGTGACGAGCATTTGATGTCTCTGAAATATGTGGCCGGACGGTCTGGCCGGGTGGTGATGACCGAAGAACTATTGCCTGCACCGATCCCTTCAACCAAAGCGGCGCTGCGAGAGGTGATCCTGCCGTTGCTGGACGAGTCCGATGAACCCTTCGATGACGACAACCTGATCGATTACGGTCTGGATTCGGTGCGCATGATGGCGCTGGCGGCGCGCTGGCGCAAAGTGCATGGCGATATCGATTTTGTCATGCTGGCGAAAAATCCGACCATCGATGCCTGGTGGAAGCTACTCTCCCGCGAGGTGAAATGA",
    "translation": "MAIPKLQAYALPESHDIPHNKVNWTFEPQRAALLIHDMQDYFVSFWGENCPMMEQVIANIAALRNYCKQHNIPVYYTAQPKEQSDEDRALLNDMWGPGLTRSPEQQKVVDRLTPDADDTVLVKWRYSAFHRSPLEQMLKESGRNQLIITGVYAHIGCMTTATDAFMRDIKPFMVADALADFSRDEHLMSLKYVAGRSGRVVMTEELLPAPIPSTKAALREVILPLLDESDEPFDDDNLIDYGLDSVRMMALAARWRKVHGDIDFVMLAKNPTIDAWWKLLSREVK",
    "product": ""
   },
   {
    "start": 327471,
    "end": 328217,
    "strand": 1,
    "locus_tag": "ctg1_311",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_311</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_311</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 327,471 - 328,217,\n (total: 747 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRP-metallophore: EntA<br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short_C2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 238.4; E-value: 1.4e-72)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_311\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_311\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_311_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_311\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_311\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGATTTCAGCGGCAAAAATGTCTGGGTAACCGGTGCGGGGAAAGGTATTGGCTACGCCACGGCGCTGGCATTTGTTGAGGCCGGAGCGAAAGTTACAGGTTTTGATCAAGCGTTCACTCTGGAGCAATATCCCTTTGCGACCGAAGTAATGGATGTAGCCGACGCTGCGCAGGTGGCGCAAGTGTGTCAGCGACTGTTAGCGCAAACGGAGCGACTGGACGTGCTGGTCAATGCGGCGGGAATTTTGCGCATGGGCGCGACCGATCAGCTCAGCAAGGAGGACTGGCAGCAGACTTTTTCGGTTAACGTCGGCGGTGCGTTTAACCTGTTCCAGCAAACCATGAACCAGTTTCGCCGTCAGCGGGGCGGGGCGATTGTCACTGTGGCGTCCGACGCCGCACACACGCCGCGTATTGGTATGAGTGCTTATGGCGCGTCGAAAGCGGCGCTGAAAAGCCTGGCGTTGAGCGTCGGGCTGGAACTGGCGGGTAGCGGTGTGCGCTGTAATGTGGTTTCCCCGGGGTCCACCGACACCGATATGCAACGCACGCTGTGGGTGAGTGATGACGCCGAAGAGCAGCGTATTCGCGGCTTTGGCGAGCAGTTTAAACTCGGCATTCCGCTGGGGAAAATCGCCCGTCCACAAGAGATCGCCAACACGATTTTGTTCCTCGCCTCTGACCTCGCCAGCCATATCACCCTACAGGATATTGTGGTAGATGGCGGCTCAACACTGGGGGCATAA",
    "translation": "MDFSGKNVWVTGAGKGIGYATALAFVEAGAKVTGFDQAFTLEQYPFATEVMDVADAAQVAQVCQRLLAQTERLDVLVNAAGILRMGATDQLSKEDWQQTFSVNVGGAFNLFQQTMNQFRRQRGGAIVTVASDAAHTPRIGMSAYGASKAALKSLALSVGLELAGSGVRCNVVSPGSTDTDMQRTLWVSDDAEEQRIRGFGEQFKLGIPLGKIARPQEIANTILFLASDLASHITLQDIVVDGGSTLGA",
    "product": ""
   },
   {
    "start": 328220,
    "end": 328633,
    "strand": 1,
    "locus_tag": "ctg1_312",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_312</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_312</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 328,220 - 328,633,\n (total: 414 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1144:thioesterase superfamily protein (Score: 208.5; E-value: 4.3e-64)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_312\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_312\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_312_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_312\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_312\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCTGGAAACGCCATTTAACGCTCGACGAACTGAACGCCACCAGCGATAACACAATGGTGGCGCATCTGGGAATTGTTTATACCCGTCTGGGCGATGATGTGCTGGAAGCCGAAATGCCGGTTGATACCCGTACTCATCAACCGTTCGGTTTACTACATGGCGGCGCATCGGCGGCGCTGGCGGAAACCCTGGGATCGATGGCCGGATTTATGATGACTCGCGACGGACAGTGCGTGGTGGGCACGGAGCTTAACGCCACACATCATCGCCCAGTGTCTGAGGGAAAGGTACGCGGCGTCTGCCAGCCGCTGCATCTTGGGCGGCAAAATCAGAGCTGGGAAATCGTTGTTTTCGATGAACAGGGGCGGCGTTGCTGCACTTGCCGGCTGGGTACGGCAGTTTTGGGATGA",
    "translation": "MIWKRHLTLDELNATSDNTMVAHLGIVYTRLGDDVLEAEMPVDTRTHQPFGLLHGGASAALAETLGSMAGFMMTRDGQCVVGTELNATHHRPVSEGKVRGVCQPLHLGRQNQSWEIVVFDEQGRRCCTCRLGTAVLG",
    "product": ""
   },
   {
    "start": 328814,
    "end": 330919,
    "strand": 1,
    "locus_tag": "ctg1_313",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_313</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_313</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 328,814 - 330,919,\n (total: 2106 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1185:carbon starvation protein A (Score: 1372.6; E-value: 0.0)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_313\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_313\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_313\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_313\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACAAATCAGGGAAATACCTCGTCTGGACAGTGCTCTCTGTAATGGGAGCATTTGCTCTGGGATACATTGCTTTAAATCGTGGGGAACAGATCAACGCGCTGTGGATTGTGGTGGCGTCGGTCTGTATCTATCTGATCGCTTACCGTTTTTATGGTCTTTATATCGCCAAAAATGTATTGGCGGTTGACCCGACGCGTATGACGCCAGCGGTGCGCCATAACGACGGGCTGGACTATGTGCCGACGGACAAGAAAGTGCTGTTCGGTCACCATTTTGCGGCTATTGCCGGAGCAGGCCCGTTGGTGGGGCCGGTACTGGCGGCGCAAATGGGCTACCTACCGGGGATGATCTGGCTACTTGCCGGGGTGGTTCTCGCCGGTGCAGTGCAGGATTTCATGGTGCTGTTTGTTTCCACGCGCCGTGACGGTCGCTCGCTGGGCGAGCTGGTTAAAGAAGAGATGGGGCCAACTGCCGGGGTGATTGCGCTGGTGGCCTGCTTTATGATCATGGTCATTATCCTTGCAGTACTGGCGATGATCGTGGTGAAAGCCCTGACTCATAGCCCGTGGGGAACGTATACCGTTGCGTTCACCATTCCGCTGGCGCTGTTCATGGGGATTTACCTGCGCTATCTGCGTCCGGGCCGCATTGGGGAAGTGTCGGTGATTGGCCTGGTATTCCTTATTTTCGCCATTATCTCTGGCGGCTGGGTGGCAGAAAGCCCGACCTGGGCACCGTACTTTGACTTTACCGGCGTGCAGCTGACCTGGATGCTGGTGGGTTACGGTTTTGTGGCGGCGGTTCTGCCGGTGTGGTTGCTGCTGGCTCCGCGTGACTACCTCTCTACCTTCCTGAAAATCGGGACTATCGTCGGTCTGGCGGTAGGCATTTTGATTATGCGTCCGACGCTGACCATGCCTGCGCTGACCAAATTTGTAGATGGCACTGGTCCGGTATGGACCGGTAATCTGTTCCCGTTCCTGTTTATTACTATCGCCTGTGGCGCGGTGTCTGGCTTCCATGCGCTGATCTCTTCCGGCACCACACCGAAGATGCTGGCGAACGAAGGTCAGGCGTGCTTTATCGGCTACGGTGGAATGTTGATGGAATCCTTCGTGGCGATTATGGCACTGGTTTCTGCCTGTATCATCGATCCGGGCGTGTACTTCGCGATGAACAGCCCGATGGCGGTGCTGGCTCCGGCGGGGACGGCGGATGTAGTGGCATCTGCTGCGCAGGTAGTGAGTAGCTGGGGCTTTAGCATTACGCCAGATACGTTAAATCAGATTGCCAGCGAAGTGGGCGAACAGTCGATCATTTCCCGTGCGGGCGGTGCGCCGACCCTGGCGGTGGGGATGGCCTACATTCTGCACGGCGCGCTGGGTGGCATGATGGATGTGGCGTTCTGGTATCACTTCGCCATTCTGTTTGAAGCACTGTTTATTCTGACGGCGGTGGATGCGGGTACGCGTGCTGCGCGCTTTATGTTGCAGGATCTGCTGGGCGTGGTTTCTCCGGGCCTGAAACGGACCGATTCACTGCCTGCTAACCTGCTGGCAACGGCGCTGTGCGTGCTGGCGTGGGGTTACTTTCTGCATCAGGGCGTGGTCGATCCGCTGGGCGGTATTAACACTCTGTGGCCGCTGTTTGGTATTGCCAACCAGATGCTGGCAGGGATGGCGCTGATGCTCTGTGCCGTGGTGTTGTTCAAGATGAAACGTCAACGTTACGCCTGGGTGGCGCTGGTACCAACGGCCTGGCTGCTGATTTGTACCCTGACCGCAGGCTGGCAGAAAGCGTTTAGCCCGGATGCGAAAGTCGGTTTCCTGGCGATTGCTAACAAGTTCCAGGCAATGATCGACAGCGGCAATATTCCGTCGCAGTATACTGAGTCACAACTGGCGCAACTGGTGTTCAACAACCGTCTGGATGCCGGATTAACCATCTTCTTTATGGTGGTTGTGGTGGTTCTGGCGCTGTTCTCGATTAAGACGGCACTGGCGGCATTGAAAGAGCCGAAGCCAACGGCGAAAGAAACGCCGTATGAGCCAATGCCGGAAAATGTCGAGGAGATCGTGGCGCAGGCGAAAGGCGCGCACTAA",
    "translation": "MNKSGKYLVWTVLSVMGAFALGYIALNRGEQINALWIVVASVCIYLIAYRFYGLYIAKNVLAVDPTRMTPAVRHNDGLDYVPTDKKVLFGHHFAAIAGAGPLVGPVLAAQMGYLPGMIWLLAGVVLAGAVQDFMVLFVSTRRDGRSLGELVKEEMGPTAGVIALVACFMIMVIILAVLAMIVVKALTHSPWGTYTVAFTIPLALFMGIYLRYLRPGRIGEVSVIGLVFLIFAIISGGWVAESPTWAPYFDFTGVQLTWMLVGYGFVAAVLPVWLLLAPRDYLSTFLKIGTIVGLAVGILIMRPTLTMPALTKFVDGTGPVWTGNLFPFLFITIACGAVSGFHALISSGTTPKMLANEGQACFIGYGGMLMESFVAIMALVSACIIDPGVYFAMNSPMAVLAPAGTADVVASAAQVVSSWGFSITPDTLNQIASEVGEQSIISRAGGAPTLAVGMAYILHGALGGMMDVAFWYHFAILFEALFILTAVDAGTRAARFMLQDLLGVVSPGLKRTDSLPANLLATALCVLAWGYFLHQGVVDPLGGINTLWPLFGIANQMLAGMALMLCAVVLFKMKRQRYAWVALVPTAWLLICTLTAGWQKAFSPDAKVGFLAIANKFQAMIDSGNIPSQYTESQLAQLVFNNRLDAGLTIFFMVVVVVLALFSIKTALAALKEPKPTAKETPYEPMPENVEEIVAQAKGAH",
    "product": ""
   },
   {
    "start": 331047,
    "end": 331244,
    "strand": 1,
    "locus_tag": "ctg1_314",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_314</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_314</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 331,047 - 331,244,\n (total: 198 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1211:hypothetical protein (Score: 157.8; E-value: 9e-49)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_314\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_314\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_314\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_314\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTTGATTCACTGGCAAAAGCTGGAAAATATTTAGGTCAGGCGGCGAAACTGATGATTGGTATGCCCGATTACGACAACTATGTCGAACATATGCGGGTTAACCATCCTGATCAAACGCCGATGACCTACGAAGAGTTTTTCCGGGAGCGGCAGGACGCGCGCTACGGTGGAAAAGGCGGCGCGCGTTGCTGCTAA",
    "translation": "MFDSLAKAGKYLGQAAKLMIGMPDYDNYVEHMRVNHPDQTPMTYEEFFRERQDARYGGKGGARCC",
    "product": ""
   },
   {
    "start": 331254,
    "end": 332342,
    "strand": -1,
    "locus_tag": "ctg1_315",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_315</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_315</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 331,254 - 332,342,\n (total: 1089 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Fe-ADH<br>\n \n  biosynthetic-additional (smcogs) SMCOG1181:dehydrogenase (Score: 636.2; E-value: 2.4e-193)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_315\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_315\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_315\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_315\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCTCACAATCCTATCCGCGTCGTCGTCGGCCCGGCTAACTACTTTTCACATCCCGGAAGTTTCAATCACCTGCAAGATTTTTTTACTGATGAACAGCTTTCTCGCGCAGCGTGGATCTACGGCGAACGCGCCATTGCGGCTGCGCAATGCAAACTTCCGCCAGCGTTTGAACTGCCAGGGGCAAAGCATATTTTGTTTCGCGGTCATTGCAGTGAAAGCGATGTGCAACAACTGGCGGCTGAGTCCGGTGACGATCGCAGCGTAGTGATTGGCGTCGGCGGCGGCGCACTGCTCGACACCGCGAAAGCCCTCGCCCGCCGTCTCGGTCTGCCGTTTGTTGCCGTTCCAACGATTGCCGCTACTTGCGCTGCCTGGACACCGCTCTCCGTCTGGTATAACGATGCCGGACAGGCGCTACATTATGAGATTTTCGACGACGCCAATTTTATGGTGCTGGTGGAACCGGAGATTATCCTCAATGCGCCGCAAGAATATCTGCTGGCGGGAATCGGTGACACGCTGGCGAAATGGTATGAAGCGGTGGTGCTGGCCCCACAACCAGAAACGTTGCCGCTAACCGTACGGCTGGGGATTAATAATGCGCAGGCCATTCGTGACGTCTTGTTAAGCAGTAGCGAGCAGGCGCTTGCCGATCAGCAAAATCAGCAGTTAACGCGATCATTTTGCGATGTGGTGGATGCGATTATCGCCGGAGGCGGAATGGTCGGTGGTCTGGGCGATCGTTTTACGCGTGTGGCGGCGGCCCATGCCGTGCATAACGGTCTGACTGTACTGCCACAAACCGAGAAGTTTCTCCACGGCACCAAAGTCGCCTACGGAATTCTGGTGCAAAGCGCCTTGCTGGGTCAGGATGCTGTGCTGGCACAATTAACCGGGGCGTATCAGCGTTTTCATCTGCCGACCACGCTGGCGGAGCTGGAAGTGGATATCAATGATCAGGCGGAGATCGACAAAGTGATTGCCCACACCTTGCGTCCGGCGGAATCCATTCATTACCTGCCGGTCACGCTGACACCAGATACGTTGCGTGCAGCGTTCGAAAAAGTGGAATCGTTTAAAGTCTGA",
    "translation": "MPHNPIRVVVGPANYFSHPGSFNHLQDFFTDEQLSRAAWIYGERAIAAAQCKLPPAFELPGAKHILFRGHCSESDVQQLAAESGDDRSVVIGVGGGALLDTAKALARRLGLPFVAVPTIAATCAAWTPLSVWYNDAGQALHYEIFDDANFMVLVEPEIILNAPQEYLLAGIGDTLAKWYEAVVLAPQPETLPLTVRLGINNAQAIRDVLLSSSEQALADQQNQQLTRSFCDVVDAIIAGGGMVGGLGDRFTRVAAAHAVHNGLTVLPQTEKFLHGTKVAYGILVQSALLGQDAVLAQLTGAYQRFHLPTTLAELEVDINDQAEIDKVIAHTLRPAESIHYLPVTLTPDTLRAAFEKVESFKV",
    "product": ""
   },
   {
    "start": 332451,
    "end": 333611,
    "strand": 1,
    "locus_tag": "ctg1_316",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_316</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_316</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 332,451 - 333,611,\n (total: 1161 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_1_2<br>\n \n  biosynthetic-additional (rule-based-clusters) DegT_DnrJ_EryC1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1019:aminotransferase (Score: 389.3; E-value: 3.4e-118)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_316\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_316\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_316_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_316\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_316\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACAAATAACCCTCTGATTCCAAAAAGTAAACTTCCACAACTTGGCACCACTATTTTCACCCAGATGAGCGCACTGGCGCAGCAACACCAGGCGATTAACCTGTCGCAAGGCTTTCCTGATTTTGATGGTCCGCGCTATTTGCAGGAGCGGCTGGCATACCATGTTGACCAGGGGGCAAACCAATACGCGCCTATGACTGGCGTGCAGGCCTTGCGCGAGGCGATTGCTCAGAAAACGGAACGTCTGTATGGCTATCAACCGGATGCCGATAGTGATATCACCGTAACGGCAGGGGCGACGGAAGCGTTATATGCAGCGATTACCGCATTGGTGCGCAATGGTGATGAAGTGATCTGCTTTGATCCCAGCTATGACAGTTACGCGCCCGCCATCGCGCTTTCGGGGGGAATAGTGAAACGTATTGCACTGCAACCACCGCATTTTCGCGTGGACTGGCAGGAATTTGCCGCATTGTTAAGCGAGCGCACCCGACTGGTGATCCTTAACACCCCGCATAACCCCAGTGCTACTGTCTGGCAGCAGACTGATTTTTCTGCTTTGTGGCAGGCAATTGCCGGGCACGAGATTTTTGTTATTAGCGATGAAGTTTACGAGCATATCAACTTTTCACAGCAGGGCCATGCCAGTGTGCTGGCGCATCCGCAACTGCGTGAGCGGGCGGTGGCGGTGTCATCGTTTGGTAAGACTTATCATATGACCGGCTGGAAAGTGGGCTATTGTGTTGCGCCTGCGCCCATCAGCGCCGAGATCCGCAAAGTGCATCAGTATCTGACTTTTTCGGTGAATACCCCGGCGCAGCTGGCCCTTGCCGATATGCTGCGAACAGAACCCGAACACTACCTTGCGTTACCGGACTTTTATCGCCAGAAGCGCGATATTCTGGTGAACGCCTTAAGTGAGAGTCGGCTGGAGATTTTACCGTGCGAAGGCACTTACTTTTTGCTGGTGGATTACAGCGCGGTTTCTTCGCTGGATGACGTTGAGTTTTGCCAGTGGCTGACGCGGGAGCATGGCGTGGCGGCGATCCCGCTGTCGGTATTTTGCGCCGATCCATTCCCCCATAAGCTCATTCGTCTCTGTTTTGCCAAGAAGGAATCGACGTTGCTGGCGGCAGCTGAACGCCTGCGCCAGCTGTAA",
    "translation": "MTNNPLIPKSKLPQLGTTIFTQMSALAQQHQAINLSQGFPDFDGPRYLQERLAYHVDQGANQYAPMTGVQALREAIAQKTERLYGYQPDADSDITVTAGATEALYAAITALVRNGDEVICFDPSYDSYAPAIALSGGIVKRIALQPPHFRVDWQEFAALLSERTRLVILNTPHNPSATVWQQTDFSALWQAIAGHEIFVISDEVYEHINFSQQGHASVLAHPQLRERAVAVSSFGKTYHMTGWKVGYCVAPAPISAEIRKVHQYLTFSVNTPAQLALADMLRTEPEHYLALPDFYRQKRDILVNALSESRLEILPCEGTYFLLVDYSAVSSLDDVEFCQWLTREHGVAAIPLSVFCADPFPHKLIRLCFAKKESTLLAAAERLRQL",
    "product": ""
   },
   {
    "start": 333612,
    "end": 334229,
    "strand": -1,
    "locus_tag": "ctg1_317",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_317</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_317</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 333,612 - 334,229,\n (total: 618 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1232:hypothetical protein (Score: 406.7; E-value: 2.6e-124)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_317\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_317\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_317\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_317\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAACAACATTTAAAGCAGGAGTTAACCCATTTTCTTGCCAGTTTGCCAGAAGACGAAAGAGTAGAGGCAATCAACGAGTTTCGCCAGGCGATCCATAAAGTCAGCCCTTTCCGTGAGGAGCCGGTGGACTGCGTGCTCTGGGTAAAAAAAGAACAGCTCAAGCCAAACAATTACAACCCCAATAATGTTGCACCACCAGAGAAAAGACTGTTACAGGTCTCTATAGAGACTGACGGCTTTACCCAACCCATTGTCGTTTCGCCATCCAGCCAAAATGAGTATGAGATTGTCGATGGTTTCCACCGTCACCTGGTGGGTAAAGAGAACGGTACACTAGGTGTAAGGCTAAAAGGTTATCTGCCAGTGACCTGTCTGGATGGCAATCGCCACGAACGCATCGCCGCAACTATTCGTCATAACCGCGCTCGTGGCCGCCACCAAATCACAGCCATGTCAGAAATCGTTCGTGAACTCAGCCAGTTGGGATGGGACGACAATAAAATCGGCAAAGAGCTGGGTATGGACAGCGACGAAGTGTTGCGCCTGAAACAAATTAACGGCCTGCAAGAGTTATTTGCTGACCGTCAATATTCCCGTGCCTGGACAGTAAAATAA",
    "translation": "MKQHLKQELTHFLASLPEDERVEAINEFRQAIHKVSPFREEPVDCVLWVKKEQLKPNNYNPNNVAPPEKRLLQVSIETDGFTQPIVVSPSSQNEYEIVDGFHRHLVGKENGTLGVRLKGYLPVTCLDGNRHERIAATIRHNRARGRHQITAMSEIVRELSQLGWDDNKIGKELGMDSDEVLRLKQINGLQELFADRQYSRAWTVK",
    "product": ""
   },
   {
    "start": 334226,
    "end": 335437,
    "strand": -1,
    "locus_tag": "ctg1_318",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_318</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_318</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 334,226 - 335,437,\n (total: 1212 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1221:hypothetical protein (Score: 820; E-value: 4.7e-249)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_318\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_318\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_318\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_318\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCTATTCATAAAATTCCTCTTTTCATTAATGTCCTCGACGCTGCGAGGGAGCGCATTCATTGGACGCTAAAAAATTTAGATCGCGTTTGCGTATCCTTTTCCGGTGGTAAAGACTCTGGAGTGATGTTACACCTCACCGCCCAGCTTGCTCGTCAGTTGAACAAAAAAATATTCGTTTTATTTATTGATTGGGAAGCTCAATTCAATCACACCATTAATTATGTCCAGGCCATAAATGATCAATATGCTGACGTCATCGATACCATTTACTGGATCGCTTTACCGCTCACCACGCAAAATGCTCTATCACAGTACCAACCACAATGGCAGTGCTGGGAGCCCGACACAGAATGGGTTCGCCAGCCTCCTACGACAGCCATAACATCCCCTGATTACTTTCCTTTTTACCAGGAAGGTATGACTTTCGAGCACTTTGTTCGCGAATTTGCCGACTGGTTTTCACAGCAACGTCCGGCAGCAATGCTAATCGGTATACGGGCCGATGAATCCTATAACCGCTTTGTTGCAATCGCCACTGAGCACAAGAAACGTTTTGCCGACGACAAACCCTGGACGACATTAGCCCCCGGAGGTCACACCTGGTACATTTACCCGATTTATGACTGGAAAACAGCCGATATCTGGACATGGTATGCAAAAACCAATTCGCTCTGTAATCCTCTGTACAATGTAATGTACCAGGCGGGCGTTCCCTTACGCTATATGAGGATTTGTGAACCTTTTGGCCCGGAACAGAGACAAGGATTGTGGTTATACCACGTCATTGAACCAGAGCAATGGGCAAAGATGTGCGCCCGAGTCAGTGGCGTAAAAAGCGGGGGAATTTACGCCGGACAGGACAACAAGTTTTATGGTCACCGAAAACTGCTTAAACCCGATCACCTTAGCTGGCAGGAGTATGCCCTGCTATTACTCAACAGTATGCCAGAACATACCGCAGAGCATTATCGTAATAAGATCGCCGTTTACCTGAAATGGTACAAGAAGAAAGGAATGGACGAAATTCCCCAGACCCAACAAGGTGATATCGGTGCAAAGGATATTCCATCCTGGAGGCGCATTTGTAAGGTGCTGCTTAATAACGATTACTGGTGCCGGGCACTGTCATTCAGCCCAACAAAATCTCAACATTATCAACGGTATAGCGAACGAATTAAAGCCAAACGCAAACTCTGGGGAATATTATGA",
    "translation": "MSIHKIPLFINVLDAARERIHWTLKNLDRVCVSFSGGKDSGVMLHLTAQLARQLNKKIFVLFIDWEAQFNHTINYVQAINDQYADVIDTIYWIALPLTTQNALSQYQPQWQCWEPDTEWVRQPPTTAITSPDYFPFYQEGMTFEHFVREFADWFSQQRPAAMLIGIRADESYNRFVAIATEHKKRFADDKPWTTLAPGGHTWYIYPIYDWKTADIWTWYAKTNSLCNPLYNVMYQAGVPLRYMRICEPFGPEQRQGLWLYHVIEPEQWAKMCARVSGVKSGGIYAGQDNKFYGHRKLLKPDHLSWQEYALLLLNSMPEHTAEHYRNKIAVYLKWYKKKGMDEIPQTQQGDIGAKDIPSWRRICKVLLNNDYWCRALSFSPTKSQHYQRYSERIKAKRKLWGIL",
    "product": ""
   },
   {
    "start": 335545,
    "end": 336483,
    "strand": -1,
    "locus_tag": "ctg1_319",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_319</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_319</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 335,545 - 336,483,\n (total: 939 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1125:LysR family transcriptional regulator (Score: 351.8; E-value: 5.2e-107)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_319\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_319\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_319\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_319\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCCAATTTGTACGATCTAAAAAAATTCGATTTAAATCTGCTGGTTATTTTTGAATGTATTTATGAAAATCTAAGTATCAGTAAAGCTGCGGAAACTCTTTATATCACGCCATCAGCAGTTAGCCAGTCACTTCAACGTTTACGACTGCAGTTTAATGATCCATTGTTTGTTCGTGCAGGCAAAGGTATATCGCCAACTATTGTCGGTATAAATTTGCATCACCACCTGGGAAAAAATTTGGATGGGCTTGAGCAAATCATCAATATTATGAATGCATCGGAGCTAAAAAATAAATTTGTTATTTACGGGCCGCAATTGATTTCAACGTTCAACGTCACCCGTTTAATTACCTGCCTGCGTGAGGAAGCATCAGTAGAGATCGAATATCATGATATTTTAACGTCAACCGAAACCGGAGAAGAGTTACTGGCTCATCGCAAAGCTGATCTGGTTGTGACAATGCTTCCTATGATCAATCGCTCCGTACTTTGCATGCCATTTCAGTCCATTAGCAATGTATTAGTTTGTCGTAATAATCATCCACGCATGAAAAATGAGTGCTCTCTTGATGATATTCTGAAAGAAGAATTTACTATGCTTATGTCTGAAGCACCTGGATTGGACGAATATCAGTCCCGCATGGATAAAATAATGGTAAATCGAAAGATTGCATTCCGCAGTCAGTCATTAACTTCTATTATTAATATTATTGCAGAAACTGATATTATTGGGATCATTCCACAAAAACTTTATAAAATATATCGTTCCATTCTGAATCTGAGAGAAATAAAGATAGATTATACTCTCCCTTTAATGCGTCTGTATATTTCGTACAATAAATCATCACTTTATAATAAAGCATTTTCAAATTTCATTACCAGGATTGCAGACGAGAAACAATCGAGCCAAAAAAGCATTCACTCGACAAATAATTAA",
    "translation": "MANLYDLKKFDLNLLVIFECIYENLSISKAAETLYITPSAVSQSLQRLRLQFNDPLFVRAGKGISPTIVGINLHHHLGKNLDGLEQIINIMNASELKNKFVIYGPQLISTFNVTRLITCLREEASVEIEYHDILTSTETGEELLAHRKADLVVTMLPMINRSVLCMPFQSISNVLVCRNNHPRMKNECSLDDILKEEFTMLMSEAPGLDEYQSRMDKIMVNRKIAFRSQSLTSIINIIAETDIIGIIPQKLYKIYRSILNLREIKIDYTLPLMRLYISYNKSSLYNKAFSNFITRIADEKQSSQKSIHSTNN",
    "product": ""
   },
   {
    "start": 336683,
    "end": 337429,
    "strand": -1,
    "locus_tag": "ctg1_320",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_320</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_320</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 336,683 - 337,429,\n (total: 747 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1233:disulfide isomerase/thiol-disulfide oxidase (Score: 454.8; E-value: 9.3e-139)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_320\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_320\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_320_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_320\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_320\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTAAAAAAGTCACTTTTAATGACAATGTTACCTGCCATCGCCTTCGCACAGGAGTTACCAGAAGCAGTTAAAGCAATTGAAAAACAAGGCATTACCATAATAAAACCTTTCGACGCCCCCGGCGGCATGAAAGGCTATCTGGGGAAATATCAGGATATGGGCGTCACCATCTATCTGACCCCCGATGGTAAGCATGCTATCTCCGGCTACATGTACAACGAAAAAGGTGAAAACCTGAGCAATACACTTATCGAAAAAGAAATTTATGCGCCAGCCGGACGCGAAATGTGGCAACGGATGGAACAATCGCACTGGCTCCTCGACGGTAAAAAAGACGCGCCAGTCATAGTCTACGTTTTCGCCGATCCGTTCTGTCCTTATTGCAAACAATTCTGGAAACAGACGCGCCCCTGGGTAGAGTCGGGTAAAGTACAACTAAGAACCTTACTGGTCGGCGTCATCAAACCAGAAAGTCCTGCTACAGCAGCAGCTATTCTCGCCAGTAAAGATCCCGCCAGCACCTGGAGTAAATACGAATCTTCAGAAGGTAAATTGCAACTGAATGTGACTGCTAATATTACGTCGGAGCAGATGAAAACTCTGAAAGATAATGAAAAGTTGATGGATGATCTAGGGGCCAATGTCACACCTGCAATCTATTACATGAGCAAAGACAACACTCTGCAACAAGCGGTAGGTTTGCCAGATAATAAAACGCTTAATACCATTATGGGCGAGGAATAA",
    "translation": "MLKKSLLMTMLPAIAFAQELPEAVKAIEKQGITIIKPFDAPGGMKGYLGKYQDMGVTIYLTPDGKHAISGYMYNEKGENLSNTLIEKEIYAPAGREMWQRMEQSHWLLDGKKDAPVIVYVFADPFCPYCKQFWKQTRPWVESGKVQLRTLLVGVIKPESPATAAAILASKDPASTWSKYESSEGKLQLNVTANITSEQMKTLKDNEKLMDDLGANVTPAIYYMSKDNTLQQAVGLPDNKTLNTIMGEE",
    "product": ""
   },
   {
    "start": 337802,
    "end": 338365,
    "strand": 1,
    "locus_tag": "ctg1_321",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_321</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_321</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 337,802 - 338,365,\n (total: 564 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1196:alkyl hydroperoxide reductase/ Thiol specific (Score: 179.4; E-value: 6.4e-55)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_321\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_321\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_321_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_321\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_321\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCTTGATTAACACCAAAATTAAACCTTTTAAAAACCAGGCATTCAAAAACGGCGAATTCATCGAAATCACCGAAAAAGATACCGAAGGCCGCTGGAGCGTCTTCTTCTTCTACCCGGCTGACTTTACTTTCGTATGCCCGACCGAACTGGGTGACGTTGCTGACCACTACGAAGAACTGCAGAAACTGGGCGTAGACGTATACGCAGTATCTACCGATACTCACTTCACCCACAAAGCATGGCACAGCAGCTCTGAAACTATCGCTAAAATCAAATATGCGATGATCGGCGACCCGACTGGCGCCCTGACCCGTAACTTCGAAAACATGCGTGAAGAAGAAGGTCTGGCTGACCGCGCAACCTTCGTTGTTGACCCGCAGGGTATCATCCAGGCTATCGAAGTTACCGCTGAAGGCATTGGCCGTGACGCGTCTGACCTGCTGCGTAAAATCAAAGCAGCACAGTACGTGGCTTCTCACCCAGGTGAAGTTTGCCCGGCTAAATGGAAAGAAGGTGAAGCAACTCTGGCTCCGTCTCTGGACCTGGTTGGTAAAATCTAA",
    "translation": "MSLINTKIKPFKNQAFKNGEFIEITEKDTEGRWSVFFFYPADFTFVCPTELGDVADHYEELQKLGVDVYAVSTDTHFTHKAWHSSSETIAKIKYAMIGDPTGALTRNFENMREEEGLADRATFVVDPQGIIQAIEVTAEGIGRDASDLLRKIKAAQYVASHPGEVCPAKWKEGEATLAPSLDLVGKI",
    "product": ""
   },
   {
    "start": 338506,
    "end": 340101,
    "strand": 1,
    "locus_tag": "ctg1_322",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_322</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_322</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 338,506 - 340,101,\n (total: 1596 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Pyr_redox_2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1176:alkyl hydroperoxide reductase subunit (Score: 674.9; E-value: 1.2e-204)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_322\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_322\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_322_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_322\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_322\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATGATGTTTAAAGCCCAGGAGATAAACATGCTCGACACAAATATGAAAACTCAACTCAAGGCTTACCTTGAGAAATTGACCAAGCCTGTTGAGTTAATTGCCACGCTGGATGACAGCGCTAAATCGGCAGAAATCAAGGAACTGTTGGCTGAAATCGCAGAACTGTCAGACAAAGTCACCTTTAAAGAAGATAACAGCTTGCCGGTGCGTAAGCCGTCTTTCCTGATCACTAACCCAGGTTCCAACCAGGGGCCACGTTTTGCAGGTTCCCCGCTGGGCCACGAGTTCACCTCGCTGGTACTGGCGTTGTTGTGGACCGGTGGTCATCCGTCGAAAGAAGCGCAGTCTCTGCTGGAGCAGATTCGCCATATTGACGGTGATTTTGAATTCGAAACCTATTACTCGCTCTCTTGCCACAACTGCCCGGACGTAGTGCAGGCGCTGAACCTGATGAGCGTACTGAATCCGCGTATTAAGCATACGGCAATTGACGGCGGCACCTTCCAGAACGAAATCACCGATCGCAACGTGATGGGCGTTCCGGCAGTGTTCGTAAATGGGAAAGAGTTTGGTCAGGGCCGCATGACTATTTCCGAAATCGTCGCCAAAATTGATACTGGCGCGGAAAAACGTGCGGCAGAAGAGCTGAACAAGCGTGATGCTTATGACGTATTAATCGTTGGTTCCGGCCCGGCGGGTGCAGCGGCAGCAATTTACTCCGCACGTAAAGGCATCCGTACCGGTCTGATGGGCGAACGTTTTGGTGGTCAGATCCTCGATACCGTTGATATCGAAAACTACATTTCTGTACCGAAGACCGAAGGGCAGAAGCTGGCAGGTGCGCTGAAAGTTCACGTTGATGAATACGACGTTGATGTGATCGACAGCCAGAGCGCCAGCAAACTGATTCCGGCAGCGGTTGAAGGTGGCCTGCATCAGATTGAAACAGCTTCTGGCGCGGTACTGAAAGCACGCAGCATTATCGTGGCGACCGGTGCAAAATGGCGCAACATGAATGTTCCGGGCGAAGATCAGTATCGCACCAAAGGCGTGACCTACTGCCCGCACTGCGACGGCCCGCTGTTTAAAGGCAAACGCGTAGCGGTTATCGGCGGTGGTAACTCCGGCGTGGAAGCGGCAATCGACCTGGCGGGTATCGTTGAACACGTAACTCTGCTGGAATTTGCGCCAGAAATGAAAGCAGACCAGGTTCTGCAGGACAAACTGCGCAGCCTGAAAAATGTCGACATTATTCTGAATGCGCAAACCACGGAAGTGAAAGGCGATGGTAGCAAAGTCGTAGGTCTGGAATATCGTGATCGTGTCAGCGGCGATATTCACAGCATCGAACTGGCCGGTATTTTCGTTCAGATTGGTCTGCTGCCGAACACCAACTGGCTGGAAGGCGCAGTCGAACGTAACCGCATGGGCGAGATAATCATTGATGCGAAATGCGAAACCAACGTCAAAGGCGTGTTCGCAGCGGGTGACTGTACGACGGTTCCGTACAAGCAGATCATCATCGCCACTGGCGAAGGTGCCAAAGCCTCTCTGAGTGCATTTGACTACCTGATTCGCACCAAAACTGCATAA",
    "translation": "MMMFKAQEINMLDTNMKTQLKAYLEKLTKPVELIATLDDSAKSAEIKELLAEIAELSDKVTFKEDNSLPVRKPSFLITNPGSNQGPRFAGSPLGHEFTSLVLALLWTGGHPSKEAQSLLEQIRHIDGDFEFETYYSLSCHNCPDVVQALNLMSVLNPRIKHTAIDGGTFQNEITDRNVMGVPAVFVNGKEFGQGRMTISEIVAKIDTGAEKRAAEELNKRDAYDVLIVGSGPAGAAAAIYSARKGIRTGLMGERFGGQILDTVDIENYISVPKTEGQKLAGALKVHVDEYDVDVIDSQSASKLIPAAVEGGLHQIETASGAVLKARSIIVATGAKWRNMNVPGEDQYRTKGVTYCPHCDGPLFKGKRVAVIGGGNSGVEAAIDLAGIVEHVTLLEFAPEMKADQVLQDKLRSLKNVDIILNAQTTEVKGDGSKVVGLEYRDRVSGDIHSIELAGIFVQIGLLPNTNWLEGAVERNRMGEIIIDAKCETNVKGVFAAGDCTTVPYKQIIIATGEGAKASLSAFDYLIRTKTA",
    "product": ""
   },
   {
    "start": 340223,
    "end": 340651,
    "strand": -1,
    "locus_tag": "ctg1_323",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_323</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_323</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 340,223 - 340,651,\n (total: 429 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_323\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_323\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_323\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_323\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTACAAAACAATCATTATGCCAGTTGATGTTTTTGAAATGGAGTTAAGTGACAAAGCTGTACGTCACGCTGAATTTCTCGCCCAGGATGACGGCGTAATTCATTTACTTCATGTATTACCGGGCGCTGCAAGCCTTAGTCTGCACCGTTTTGCTGCTGATGTGCGACGTTTTGAAGAGCATCTGCAACATGAAGCTGAAGAACGTCTGCAAACGATGGTCAGCCACTTCACCATCGATCCTTCCCGCATTAAACAACATGTCCGTTTTGGTAGCGTGCGAGATGAAGTCAACGAGTTAGCGAAAGAACTCGATGCAGATGTAGTGGTTATCGGTTCGCGTAATCCATCAATTTCAACCCATCTGTTAGGTTCTAACGCCTCCAGTGTGATCCGTCACGCTAATCTGCCTGTACTGGTCGTTCGCTAA",
    "translation": "MYKTIIMPVDVFEMELSDKAVRHAEFLAQDDGVIHLLHVLPGAASLSLHRFAADVRRFEEHLQHEAEERLQTMVSHFTIDPSRIKQHVRFGSVRDEVNELAKELDADVVVIGSRNPSISTHLLGSNASSVIRHANLPVLVVR",
    "product": ""
   },
   {
    "start": 340776,
    "end": 340865,
    "strand": -1,
    "locus_tag": "ctg1_324",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_324</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_324</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 340,776 - 340,865,\n (total: 90 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_324\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_324\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_324\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_324\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGTGAAGTGCTGGGTATCACTGCTTTTTTTATTTTAGTTGCAGCGATCATCGTTGCGGCAGTGTTATACCTTGAGCAACACTGGTAG",
    "translation": "MGEVLGITAFFILVAAIIVAAVLYLEQHW",
    "product": ""
   },
   {
    "start": 341010,
    "end": 341420,
    "strand": -1,
    "locus_tag": "ctg1_325",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_325</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_325</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 341,010 - 341,420,\n (total: 411 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_325\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_325\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_325\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_325\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCAGACCAACAATTATCATTAACGACCTTGATGCAGAACGCATCGATATGCTGCTGGAACAACCTGCATACGCTGGCCTGCCCATTGCCGATGCGTTAAATGCGGAACTTGACCGCGCACAGATGTGCTCGCCTGAAACCATGCCAAATGATGTGGTGACCATGAATAGTCGGGTTAAATTCCGTAATCTGAGCGATGGCGAAGTCCGTGTGCGCACGCTGGTTTATCCGGCCAAAATGACTGACAGCAACACACAACTTTCCGTAATGGCTCCTGTGGGAGCAGCCCTCCTGGGACTCCGTGTTGGTGATACCATCCACTGGGAACTGCCGGGCGGCACCTCCACGCACCTTGAAGTGCTGGAACTGGAATACCAGCCAGAAGCTGCTGGCGACTACCTGCTTTAA",
    "translation": "MSRPTIIINDLDAERIDMLLEQPAYAGLPIADALNAELDRAQMCSPETMPNDVVTMNSRVKFRNLSDGEVRVRTLVYPAKMTDSNTQLSVMAPVGAALLGLRVGDTIHWELPGGTSTHLEVLELEYQPEAAGDYLL",
    "product": ""
   },
   {
    "start": 341619,
    "end": 342425,
    "strand": -1,
    "locus_tag": "ctg1_326",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_326</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_326</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 341,619 - 342,425,\n (total: 807 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_326\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_326\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_326\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_326\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAATTACTCAGATATTCCTGCACATTATTGGCTATCTCACTGCTTCCCTTCACCTCTGCTCGTGCTGACGAACTACAGCCTAAGCAGTATGCTGATTTCGATCGCTATGTTCTGGCACTCTCCTGGCAAACAGGCTTTTGTCAAAGCCAGCATGACCGTGGGCGCAAAGAACCTGTCGAATGTCGTTTGCAAAAAGAAACCGAAGATAAATCCGCTTTCCTGACTGTTCACGGGCTTTGGCCTGGCTTGCCAAAATCAGTAGCGGCACGCGGAGTTGATGAGCGACGCTGGATGCGCTATGGCTGTGCCACTCGCCCTATTCCAAATTTTCCTGAAGTACGTGCCAGCCGGAAGTGTTCCTCTCCTGAAACTGGATTATCTCTGGAAACAGCAGCCAGACTTAGCGAAGTGATGCCCGGAGCAGGCGGGCGTTCATGCCTGGAACGCTATGAATACGCCAAACATGGGGCCTGTTTTGGCTTCGATCCGGATGCTTACTTCGAGACTATGGTACGCCTGAATAAAGAATTCAAAAGCAGTGCCGTTGGCGAGTTCCTTGTTGAAAATTACGGTAAAACCGTTTCGCGCAGTGATTTTGACGCTGCTATTGCCAAAAGCTGGGGAAGTGAAAACGTCAAAGCGGTAAAATTAAGCTGTCAGGGCAAACCGGCTTATCTGACAGAGATTCAAATCTCCCTGCGCGCCAACCAAATCAACGCCCCATTATCTGCCAGTTCCCTCCAACCGCAGCCACACCCGGGGAATTGCGGTAATCAATTTATCATTGATAAAGTGGGTTATTGA",
    "translation": "MKLLRYSCTLLAISLLPFTSARADELQPKQYADFDRYVLALSWQTGFCQSQHDRGRKEPVECRLQKETEDKSAFLTVHGLWPGLPKSVAARGVDERRWMRYGCATRPIPNFPEVRASRKCSSPETGLSLETAARLSEVMPGAGGRSCLERYEYAKHGACFGFDPDAYFETMVRLNKEFKSSAVGEFLVENYGKTVSRSDFDAAIAKSWGSENVKAVKLSCQGKPAYLTEIQISLRANQINAPLSASSLQPQPHPGNCGNQFIIDKVGY",
    "product": ""
   },
   {
    "start": 342660,
    "end": 344030,
    "strand": -1,
    "locus_tag": "ctg1_327",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_327</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_327</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 342,660 - 344,030,\n (total: 1371 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_327\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_327\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_327_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_327\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_327\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTAACTTTTATCGAACTCCTGATTGGGGTAATCGTTATAGTGGGTGTTGCCCGCTACATTATTAAGGGGTATTCCGCCACTGGCGTACTCTTTGTCGGCGGTCTGGCGTTATTGATTATTAGCGCTTTGATGGGCCACAAAGTACTGCCGTCCAGCGCCACCAGTACTGGTTACTCAGCGACTGATATCGTTGAATATATTAAGATATTACTGATGAGTCGTGGCGGCGACCTTGGCATGATGATTATGATGTTGTGCGGATTTGCTGCGTACATGACTCATATTGGTGCCAATGATATGGTTGTAAAGCTGGCTTCCAAACCATTGCAGTATATTAACTCGCCTTATTTGCTGATGATTGCAGCTTATTTTGTCGCTTGCCTGATGTCTCTTGCGGTTTCCTCTGCGACAGGGCTTGGTGTGTTGTTAATGGCGACCTTATTCCCGGTAATGGTTAACGTTGGTATCAGTCGTGGTGCGGCGGCCGCTATATGTGCCTCTCCTGCGGCAATCATTCTTTCTCCAACTTCTGGCGATGTGGTTCTGGCAGCAGAAGCCGCAGAAATGCCATTAATTGATTTTGCCTTTAAAACAACGCTGCCCATTTCTATAGCGGCAATCATTGGTATGGCGATTGCCCACTTTTTCTGGCAGCGCTATCTCGATAAGAAAGAACATATCTCCCATGAGATGCTGGACGTCAACGAAATCACCACTACGGCTCCGGCGTTTTACGCCATTCTGCCGTTTACCCCGATCATCGGTGTTCTGATTTTTGACGGCAAATGGGGGCCACAGCTGCACATCATTACCATTCTGGTTATTTGTATGTTGTTAGCTGCCGTACTGGAATTTGTTCGTGGTTTTGATACCCAGAAAGTCTTCTCCGGGCTGGAAGTGGCGTATCGCGGCATGGCAGATGCGTTTGCCAGTGTAGTAATGTTGTTGGTTGCTGCCGGGGTTTTTGCTCAAGGGTTGAGCACAATCGGCTTTATCCAGAGCTTGATTTCCATTGCCACCTCATTTGGCTCGGCAAGCATTATTCTGATGCTGGTTCTGGTAATTTTAACCATGCTGGCAGCGATGACCACCGGATCGGGTAATGCGCCGTTCTATGCTTTTGTTGAGATGATCCCCAAACTGGCCCATTCATCAGGAATCAATCCGGCTTATTTATCGATTCCTATGCTACAGGCATCCAACCTGGGACGTACCATCTCACCGGTTTCTGGCGTGGTTGTTGCAGTGGCAGGGATGGCAAAAATCTCCCCCTTCGAAGTAGTAAAACGCACTTCTGTACCGGTACTGGTGGGGTTATTGATTGTGATAATCGCCACTGAGATCCTGGTTCCTGGAGCTGCAGCCTAA",
    "translation": "MLTFIELLIGVIVIVGVARYIIKGYSATGVLFVGGLALLIISALMGHKVLPSSATSTGYSATDIVEYIKILLMSRGGDLGMMIMMLCGFAAYMTHIGANDMVVKLASKPLQYINSPYLLMIAAYFVACLMSLAVSSATGLGVLLMATLFPVMVNVGISRGAAAAICASPAAIILSPTSGDVVLAAEAAEMPLIDFAFKTTLPISIAAIIGMAIAHFFWQRYLDKKEHISHEMLDVNEITTTAPAFYAILPFTPIIGVLIFDGKWGPQLHIITILVICMLLAAVLEFVRGFDTQKVFSGLEVAYRGMADAFASVVMLLVAAGVFAQGLSTIGFIQSLISIATSFGSASIILMLVLVILTMLAAMTTGSGNAPFYAFVEMIPKLAHSSGINPAYLSIPMLQASNLGRTISPVSGVVVAVAGMAKISPFEVVKRTSVPVLVGLLIVIIATEILVPGAAA",
    "product": ""
   },
   {
    "start": 344471,
    "end": 345055,
    "strand": 1,
    "locus_tag": "ctg1_328",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_328</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_328</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 344,471 - 345,055,\n (total: 585 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_328\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_328\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_328\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_328\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTAATAACGATCTTGATAATTGCAAAAAAATATCTGACTTATCTGATAATTGTAATTGCAACACAATTATCTCTTGTTCATCAAGTTATTGCCGGAAGTCATTCTGGCTGGTGGCAAACGTTAGGTAACAACGTAGCGGAAACCTGGCAACAACCTGAACATTACGATTTATACATTCCAGCGATCACCTGGCATGCACGTTTTGCTTACGATAAAGAAAAAACGGATCGTTATAACGAACGTCCTTGGGGTGGTGGCTTTGGACAATCGCGTTGGGACGAAAAAGGTAACTGGCATGGCTTGTACATGATGGTCTTTAAAGATTCATGGAATGAATGGGAACCTATTGGCGGTTATGGCTGGGAAAGCACATGGCGTCCGTTTTCAGATGACAATTTCCATGTTGGATTGGGCTTTACCGCAGGTGTGACGATGCGGGATAACTGGAACTACATTCCACTCCCTGTGTTGTTACCTTTGGCGTCAATAGGCTATGGCCCTGCCACTTTTCAGATGACGTATATTCCCGGAACCTACAACAACGGTAATGTGTACTTTGCGTGGATGCGTTTTCAGTTCTGA",
    "translation": "MVITILIIAKKYLTYLIIVIATQLSLVHQVIAGSHSGWWQTLGNNVAETWQQPEHYDLYIPAITWHARFAYDKEKTDRYNERPWGGGFGQSRWDEKGNWHGLYMMVFKDSWNEWEPIGGYGWESTWRPFSDDNFHVGLGFTAGVTMRDNWNYIPLPVLLPLASIGYGPATFQMTYIPGTYNNGNVYFAWMRFQF",
    "product": ""
   },
   {
    "start": 345241,
    "end": 345450,
    "strand": 1,
    "locus_tag": "ctg1_329",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_329</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_329</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 345,241 - 345,450,\n (total: 210 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1255:cold-shock DNA-binding domain protein (Score: 99.5; E-value: 1.4e-30)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_329\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_329\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_329_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_329\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_329\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCTAAGATTAAAGGTAACGTTAAGTGGTTTAATGAATCCAAAGGATTCGGTTTCATTACTCCGGAAGATGGCAGCAAAGACGTGTTCGTACACTTCTCTGCAATCCAGACTAATGGTTTTAAAACTCTGGCTGAAGGTCAGCGCGTAGAGTTCGAAATCACTAACGGTGCCAAAGGCCCTTCCGCTGCAAACGTAATCGCGCTGTAA",
    "translation": "MSKIKGNVKWFNESKGFGFITPEDGSKDVFVHFSAIQTNGFKTLAEGQRVEFEITNGAKGPSAANVIAL",
    "product": ""
   },
   {
    "start": 345504,
    "end": 345887,
    "strand": -1,
    "locus_tag": "ctg1_330",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_330</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_330</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 345,504 - 345,887,\n (total: 384 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_330\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_330\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_330\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_330\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGTTACAACTTCTTTTAGCAGTTTTTATTGGCGGTGGAACAGGTAGCGTGGCGAGATGGATGTTGAGTATGCGCTTTAACCCCCTGCATCAGGCAATTCCATTAGGAACACTGGCGGCAAATTTACTTGGCGCATTCATCATCGGAATGGGCTTTGCCTGGTTCAGTCGCATGACAAATATCGATCCAGTTTGGAAGGTGCTGATCACTACGGGTTTTTGCGGTGGCCTGACAACATTCTCTACATTTTCTGCAGAGGTCGTGTTTTTGTTGCAGGAAGGGCGCTTTGGTTGGGCGATGTTAAATGTGCTGGTCAATCTGCTGGGATCGTTTGCCATGACCGCCCTGGCATTCTGGATTTTTTCTGCATCGACCGCGAATTAA",
    "translation": "MLQLLLAVFIGGGTGSVARWMLSMRFNPLHQAIPLGTLAANLLGAFIIGMGFAWFSRMTNIDPVWKVLITTGFCGGLTTFSTFSAEVVFLLQEGRFGWAMLNVLVNLLGSFAMTALAFWIFSASTAN",
    "product": ""
   },
   {
    "start": 345979,
    "end": 346767,
    "strand": 1,
    "locus_tag": "ctg1_331",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_331</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_331</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 345,979 - 346,767,\n (total: 789 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1294:Nitrilase/cyanide hydratase and apolipoprotein (Score: 178.5; E-value: 2.7e-54)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_331\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_331\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg1_331_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_331\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_331\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTGGTTGCCGCAGGGCAGTTTGCCGTTTCACCCGTATGGGAAAGGAACGCAGAAACATGTGTATCGTTGATGGAGCAGGCCGCCGAAAGCGATGTCTCTCTGCTAGTTTTGCCGGAGGCGTTGTTGGCTCGGGATGATCTTGATCCAGATTTGGCGGTGAAGTCCGCTCAACCTGTTGAAGGGGATTTTCTTGCACGGTTACTACGCGAGAGCAAACGTAACACGATGACTACTGTGCTGGCGATACATGTGCCTTCAGTTCCTGGCAGGGCGTTCAATATGCTGGTCGCGCTGCAAAGAGGAAAAATTATTGCCCGGTATGCCAAGTTGCATCTCTATGATGCTTTTGCCATCCAGGAATCACGCAATGTTGATGCAGGAAAATCACTACCACCATTACTGGATGTTGACGGAATGAAGGTTGGGCTGATGACGTGCTACGATTTACGCTTTCCTGAACTGGCGTTGGCCCATGCGTTGCAAGGAGCAGAAATATTGGTCCTGCCGGCAGCCTGGGTGCGTGGTGCGCTGAAAGAACATCACTGGTCCACACTGCTGGCGGCACGGGCGCTGGATACTACCTGTTACATGGTCGCTGCGGGGGAGTGTGGAACACGCAATATTGGGCAAAGCCGTATTATTGATCCTTTTGGCGTTACGCTTGCAGCCGCAGCAGAAATACCTGCATTGATTATTGCTGATATATCCGCTGAGCGCGTTCGCCAGGTCAGGGCACAATTGCCCGTTTTAGCCAACCGCCGATTTGCGCCACCGCAATTGCTGTGA",
    "translation": "MLVAAGQFAVSPVWERNAETCVSLMEQAAESDVSLLVLPEALLARDDLDPDLAVKSAQPVEGDFLARLLRESKRNTMTTVLAIHVPSVPGRAFNMLVALQRGKIIARYAKLHLYDAFAIQESRNVDAGKSLPPLLDVDGMKVGLMTCYDLRFPELALAHALQGAEILVLPAAWVRGALKEHHWSTLLAARALDTTCYMVAAGECGTRNIGQSRIIDPFGVTLAAAAEIPALIIADISAERVRQVRAQLPVLANRRFAPPQLL",
    "product": ""
   },
   {
    "start": 346896,
    "end": 347099,
    "strand": 1,
    "locus_tag": "ctg1_332",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_332</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_332</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 346,896 - 347,099,\n (total: 204 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_332\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_332\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_332\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_332\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGTGAGATTAGTATTACCAAGTTGCTGGTTGTTGCAGCACTGGTCGTCCTGTTGTTTGGTACGAAGAAGCTACGCACATTGGGCGGTGACCTCGGTGCTGCCATTAAAGGTTTCAAGAAAGCGATGAATGATGAAGACGCGGGTGCGAAGAAAGACGCAAACGGCGATCTTCCGGCAGAAAAATTAACTCATAAAGAGTAA",
    "translation": "MGEISITKLLVVAALVVLLFGTKKLRTLGGDLGAAIKGFKKAMNDEDAGAKKDANGDLPAEKLTHKE",
    "product": ""
   },
   {
    "start": 347213,
    "end": 348178,
    "strand": -1,
    "locus_tag": "ctg1_333",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_333</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_333</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 347,213 - 348,178,\n (total: 966 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF04055<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_333\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_333\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_333\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_333\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTAAACCCATTGTGATGGAACGCGGTGTTAAATACCGCGATGCCGATAAGATGGCCCTTATCCCGGTTAAAAACGTGGTAACAGAGCGCGAAGCCCTGCTACGTAAGCCGGAATGGATGAAAATCAAACTTCCAGCGGACTCCACCCGTATCCAGGGCATCAAAGCCGCAATGCGCAAAAATGGCCTGCATTCTGTCTGCGAGGAAGCTTCCTGCCCCAACCTGGCGGAATGTTTCAATCACGGAACAGCAACATTTATGATCCTCGGTGCGATTTGTACGCGCCGCTGCCCTTTCTGCGACGTAGCACATGGTCGCCCGGTTGCTCCTGATGCCAATGAACCTGTGAAACTGGCACAAACCATCGCAGATATGGCTCTACGCTATGTCGTGATTACTTCCGTGGATCGTGATGATCTGCGTGACGGCGGTGCGCAACACTTTGCCGATTGCATTACTGCTATCCGCGAAAAAAGCCCATCAATTAAAATTGAAACGCTGGTGCCTGACTTCCGTGGTCGCATGGATCGTGCGCTGGATATCCTCACCGCAACGCCACCAGACGTATTCAACCATAACCTGGAGAACGTACCACGTATCTACCGCCAGGTTCGTCCCGGGGCTGACTATAACTGGTCACTGAAGCTGCTGGAGCGCTTTAAAGAAGCACATCCTGAGATCCCAACCAAGTCTGGCTTGATGGTAGGTCTGGGTGAAACGAATGAAGAAATCATTGAAGTGATGCGTGACCTGCGTCGGCATGGTGTAACCATGTTGACTCTGGGGCAATATTTACAGCCAAGCCGTCATCACTTGCCGGTTCAGCGTTACGTTAGCCCGGACGAATTTGAAGAGATGAAAGCTGAAGCACTGGCGATGGGCTTCACCCATGCTGCTTGTGGGCCTTTTGTGCGATCTTCTTACCATGCAGATTTGCAGGCTAAAGGTATTGAAGTGAAGTAA",
    "translation": "MSKPIVMERGVKYRDADKMALIPVKNVVTEREALLRKPEWMKIKLPADSTRIQGIKAAMRKNGLHSVCEEASCPNLAECFNHGTATFMILGAICTRRCPFCDVAHGRPVAPDANEPVKLAQTIADMALRYVVITSVDRDDLRDGGAQHFADCITAIREKSPSIKIETLVPDFRGRMDRALDILTATPPDVFNHNLENVPRIYRQVRPGADYNWSLKLLERFKEAHPEIPTKSGLMVGLGETNEEIIEVMRDLRRHGVTMLTLGQYLQPSRHHLPVQRYVSPDEFEEMKAEALAMGFTHAACGPFVRSSYHADLQAKGIEVK",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 293204,
    "end": 348216,
    "tool": "",
    "neighbouring_start": 293203,
    "neighbouring_end": 348217,
    "product": "CC 1: chemical_hybrid",
    "kind": "candidatecluster",
    "prefix": "",
    "height": 0
   },
   {
    "start": 313203,
    "end": 328217,
    "tool": "rule-based-clusters",
    "neighbouring_start": 293203,
    "neighbouring_end": 348217,
    "product": "NRP-metallophore",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   },
   {
    "start": 313203,
    "end": 317085,
    "tool": "rule-based-clusters",
    "neighbouring_start": 293203,
    "neighbouring_end": 337085,
    "product": "NRPS",
    "category": "NRPS",
    "height": 4,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": [
    {
     "loc": 323646,
     "len": 15
    },
    {
     "loc": 323761,
     "len": 15
    },
    {
     "loc": 346019,
     "len": 12
    }
   ]
  },
  "type": "NRP-metallophore,NRPS",
  "products": [
   "NRP-metallophore",
   "NRPS"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS",
  "anchor": "r1c1"
 },
 "r1c2": {
  "start": 1788258,
  "end": 1814551,
  "idx": 2,
  "orfs": [
   {
    "start": 1789246,
    "end": 1791510,
    "strand": -1,
    "locus_tag": "ctg1_1696",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1696</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1696</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,789,246 - 1,791,510,\n (total: 2265 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1696\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1696\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1696\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1696\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAAAATTACATCTATTAGCATTTGCGTCTTATTCGGTATTTTCCCGCTAACCTTATTACCAACATTACCTGGCTTCCCTGTCATAGCGATTCTTTTTGTTACTGCATGCGTGCTGGCTTTAATTCCACGACAACCGCTGCGCTATTTGGCTCTGACTTTGCTCTTTTTTCTGTGGGGGATTCTGGCTGCCAAACAAATCACATGGCCTTCTGAAGTTTTACCGACTGCGATACAGGAAGCCCAGGTTCTTATTACTGGTACTGATCATATGACAACCCATTATGGTCAGATTACCCATCTGTCAGGGAAACGCGTATTCCCTGCGCCTGGCATTGTTTTGTATGGTCAATATCTGCCGGGTGAAGTCTGTGCAGGCCAACGCTGGTTGATGAAATTAAAAGTCCGTGCAGTGCATGGGCAACTAAATGATGGTGGTTTTGACAGCCAACGATATGCGCTGGCTCAACATCAACCTCTCACTGGGCGATTTCTTAACGCAACTGCGATAGATGCGCGTTGTAGCTTACGTGCTGAGTATCTGGCTTCGTTAACTCAGACTTTGGCTAATTATTTATGGAAACCGGTTATTTTAGGCCTGGGGATGGGAGAACGTTTATCAATCCCTCAGGAGATCAAGCGCATTATGCGTGATACCGGAACGGCCCATCTGATGGCTATTTCTGGATTGCATATTGCTTTTGCCGCAGTTCTCGCGGCAGGGATTATCCGGGGAATGCAGTTTTTATTGCCAGCCCAACGTATTTTCTGGCAAGTTCCTCTCATTGGCGGGGTAGGCTGTGCTATTTTTTATGCCTGGCTGACAGGTATGCAACCACCGGCCTTACGTACCGTTGTTGCTTTAACCGTCTGGGGAATGCTTAAAATAAGTGGCCGTCAATGGAGCGGATGGGACGTCTGGCTATGCTGCCTTGCAGCAATTTTAATAACCGATCCGATAGCGATACTTTCCGATAGTCTGTGGCTCTCCGCTTTTGCAGTTGCGGCGCTCATTTTTTGGTATCAATGGTGCCCATTGCCCTCGCTATCATTACCACGTTTACTTCGCCCTTTCGTTTCTCTGGTGCATTTGCAAATTGGTATCACGCTTTTATTGTTACCTGTTCAGATAGTTATTTTTCATGGTCTCAGTCTCAGTTCATTGATAGCCAATTTATTTGCTGTCCCGCTGGTTACTTTTATCTCTGTGCCCCTTATCCTGGCGGGTATGGTGATACACCTTACCGGACCACAAGTGCTTGAGCAGGGGCTCTGGTATTTAGCCGACTACTCACTGGCAATATTATTCCGGGCACTGGAGTTACTTCCTGGTGGTTGGGTAAATATCAGCGAGCAATGGCGATGGTTGGCATTTTCTCCGTGGCCTGGTTTGTTGATATGGCGGCTTAATGCCTGGAGAGCAGTTCCGTTTTTATGTTTATCAGGAATAATCCTTCTAAGTTGGCCGCTATGGAGAGCTCCACGTATTGATATATGGCAAGTGCATATGCTCGATGTAGGGCAGGGGCTGGCAATGGTGATTGAGCGAAACGGCAAAGCTATTCTCTATGATACGGGGCTTGCGTGGCCAGGAGGCGATAGTGGGCAACAACTCATCATTCCCTGGCTACGTTGGCATAACTTACAGCCTGAAGGCATCATTCTCAGCCACGAGCATCTTGATCATCGTGGAGGATTGGATTCTTTGTTAAAAATCTGGCCAGAAATGTGGGTCAGAAGTCCACTCGGATGGCAGAGTCATCTTCCCTGTATACGTGGTGAAACGTGGCAGTGGCAGGGACTTAATTTCTCCGCGCACTGGCCACTCAAGGTTGATTCGGAGCAGGGGAATAATCGCTCTTGTGTAGTCAAAATAGATGACGGCAAGCAGAGCATCTTGTTGACTGGCGATATCGAGGCTCCAGCTGAACAAAAAATGCTTAGTCACTATTGGCAGTACCTGGCGGCGACAATTATTCAGGTGCCCCATCATGGTAGTAATACATCCTCAACTCTGCCTTTGCTTCAACGGGTAAATGGCTCTGTCGCACTGGCATCAGCGTCGCGCTATAACGCGTGGCGTCTGCCTTCGTGGAAAGTAAAACAGCGATATCTGAAACAAGAATACCAATGGTTAGATACGCCCCATTCTGGGCAAATAACGGTCGATTTTTCTCCGCAAAGTTGGCAGATAAGCAGTATGAGGGAACAAATTTTACCGCGTTGGTATCATCAGTGGTTTGGCGTGTCAGAGGATAACGGGTAG",
    "translation": "MKITSISICVLFGIFPLTLLPTLPGFPVIAILFVTACVLALIPRQPLRYLALTLLFFLWGILAAKQITWPSEVLPTAIQEAQVLITGTDHMTTHYGQITHLSGKRVFPAPGIVLYGQYLPGEVCAGQRWLMKLKVRAVHGQLNDGGFDSQRYALAQHQPLTGRFLNATAIDARCSLRAEYLASLTQTLANYLWKPVILGLGMGERLSIPQEIKRIMRDTGTAHLMAISGLHIAFAAVLAAGIIRGMQFLLPAQRIFWQVPLIGGVGCAIFYAWLTGMQPPALRTVVALTVWGMLKISGRQWSGWDVWLCCLAAILITDPIAILSDSLWLSAFAVAALIFWYQWCPLPSLSLPRLLRPFVSLVHLQIGITLLLLPVQIVIFHGLSLSSLIANLFAVPLVTFISVPLILAGMVIHLTGPQVLEQGLWYLADYSLAILFRALELLPGGWVNISEQWRWLAFSPWPGLLIWRLNAWRAVPFLCLSGIILLSWPLWRAPRIDIWQVHMLDVGQGLAMVIERNGKAILYDTGLAWPGGDSGQQLIIPWLRWHNLQPEGIILSHEHLDHRGGLDSLLKIWPEMWVRSPLGWQSHLPCIRGETWQWQGLNFSAHWPLKVDSEQGNNRSCVVKIDDGKQSILLTGDIEAPAEQKMLSHYWQYLAATIIQVPHHGSNTSSTLPLLQRVNGSVALASASRYNAWRLPSWKVKQRYLKQEYQWLDTPHSGQITVDFSPQSWQISSMREQILPRWYHQWFGVSEDNG",
    "product": ""
   },
   {
    "start": 1791713,
    "end": 1791997,
    "strand": -1,
    "locus_tag": "ctg1_1697",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1697</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1697</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,791,713 - 1,791,997,\n (total: 285 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1132:DNA-binding protein HU 1 (Score: 105.9; E-value: 1.7e-32)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1697\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1697\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region2/ctg1_1697_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1697\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1697\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCAAGTCAGAATTGATTGAAAGACTTGCAACCCAGCAATCGCATATTCCTGCCAAAGTGGTTGAAGATGCCGTTAAAGAGATGCTGGAGCATATGGCCTCGACTCTTGCGCAGGGCGAGCGTATTGAAATCCGCGGTTTCGGCAGTTTCTCTTTGCACTACCGCGCACCTCGCACCGGACGTAACCCAAAAACTGGTGATAAAGTTGAACTTGAAGGCAAATATGTGCCGCACTTTAAGCCAGGTAAAGAACTGCGCGATCGCGCCAATATTTACGGTTGA",
    "translation": "MTKSELIERLATQQSHIPAKVVEDAVKEMLEHMASTLAQGERIEIRGFGSFSLHYRAPRTGRNPKTGDKVELEGKYVPHFKPGKELRDRANIYG",
    "product": ""
   },
   {
    "start": 1792157,
    "end": 1793830,
    "strand": -1,
    "locus_tag": "ctg1_1698",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1698</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1698</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,792,157 - 1,793,830,\n (total: 1674 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1698\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1698\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region2/ctg1_1698_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1698\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1698\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTGAATCTTTTGCTCAACTCTTTGAAGAGTCCTTAAAAGAAATCGAAACCCGCCCGGGTTCTATCGTTCGTGGTGTTGTTGTTGCTATCGACAAAGACGTAGTACTGGTTGACGCTGGTCTGAAATCTGAGTCTGCCATTCCGGCTGAGCAGTTCAAAAACGCCCAGGGCGAAATTGAAATCCAGGTTGGTGACGAAGTTGACGTTGCTCTGGATGCAGTAGAAGACGGTTTCGGTGAAACCCTGCTGTCTCGTGAGAAAGCAAAACGTCACGAAGCGTGGCTGATGCTGGAAAAAGCTTACGAAGAAGCAGCAACCGTTACTGGTGTAATCAATGGCAAAGTCAAGGGCGGCTTCACTGTTGAGCTGAACGGTATTCGTGCGTTCCTGCCAGGTTCTCTGGTAGACGTTCGTCCGGTTCGTGACACCCTGCACCTGGAAGGCAAAGAGCTTGAATTCAAAGTAATCAAGCTGGACCAGAAGCGTAACAACGTTGTTGTTTCTCGTCGTGCTGTTATTGAGTCTGAAAACAGTGCAGAACGCGATCAGCTGCTGGAAAACCTGCAGGAAGGCATGGAAGTTAAAGGTATCGTTAAGAACCTCACTGACTACGGTGCATTCGTTGATCTGGGTGGTGTTGACGGTCTGCTGCACATCACCGACATGGCGTGGAAACGCGTTAAACATCCGAGCGAAATCGTAAACGTTGGCGACGAAATCACTGTTAAAGTGCTGAAGTTCGACCGCGAACGTACCCGTGTATCTCTGGGCCTGAAACAACTGGGCGAAGATCCGTGGGTAGCTATCGCTAAACGTTATCCGGAAGGTACCAAACTGACCGGTCGCGTGACCAACCTGACCGACTACGGCTGCTTCGTTGAAATCGAAGAAGGCGTTGAAGGCCTGGTACACGTTTCCGAAATGGATTGGACCAACAAAAACATCCACCCGTCCAAAGTTGTTAACGTTGGCGATGTAGTGGAAGTGATGGTTCTGGATATCGACGAAGAACGTCGTCGTATCTCCCTGGGTCTGAAGCAGTGCAAATCTAACCCATGGCAGCAGTTCGCGGAAACCCACAACAAGGGCGACCGTGTTGAAGGTAAAATCAAGTCTATCACTGACTTCGGTATCTTCATCGGGCTGGACGGCGGTATCGACGGCCTGGTTCACCTGTCTGACATCTCCTGGAACGTTGCAGGCGAAGAAGCAGTTCGTGAATACAAAAAAGGCGACGAAATCGCAGCAGTTGTACTGCAGGTTGATGCAGAACGTGAACGTATCTCCCTGGGCGTTAAGCAGCTCGCAGAAGATCCGTTCAACAACTGGGTTGCTCTGAACAAGAAAGGCGCTATCGTGACCGGTAAAGTAACTGCAGTTGACGCTAAAGGCGCAACCGTAGAACTGGCTGACGGCGTTGAAGGTTACCTGCGTGCTTCTGAAGCATCCCGTGACCGCGTTGAAGACGCTACCCTGGTTCTGAGCGTTGGCGACGAAGTTGAAGCTAAATTCACCGGCGTTGATCGTAAAAACCGCGCAATCAGCCTGTCTGTTCGTGCGAAAGACGAAGCTGACGAGAAAGATGCAATCGCAACTGTTAACAAACAGGAAGATGCAAACTTCTCTAACAATGCAATGGCTGAAGCTTTCAAAGCAGCTAAAGGCGAGTAA",
    "translation": "MTESFAQLFEESLKEIETRPGSIVRGVVVAIDKDVVLVDAGLKSESAIPAEQFKNAQGEIEIQVGDEVDVALDAVEDGFGETLLSREKAKRHEAWLMLEKAYEEAATVTGVINGKVKGGFTVELNGIRAFLPGSLVDVRPVRDTLHLEGKELEFKVIKLDQKRNNVVVSRRAVIESENSAERDQLLENLQEGMEVKGIVKNLTDYGAFVDLGGVDGLLHITDMAWKRVKHPSEIVNVGDEITVKVLKFDRERTRVSLGLKQLGEDPWVAIAKRYPEGTKLTGRVTNLTDYGCFVEIEEGVEGLVHVSEMDWTNKNIHPSKVVNVGDVVEVMVLDIDEERRRISLGLKQCKSNPWQQFAETHNKGDRVEGKIKSITDFGIFIGLDGGIDGLVHLSDISWNVAGEEAVREYKKGDEIAAVVLQVDAERERISLGVKQLAEDPFNNWVALNKKGAIVTGKVTAVDAKGATVELADGVEGYLRASEASRDRVEDATLVLSVGDEVEAKFTGVDRKNRAISLSVRAKDEADEKDAIATVNKQEDANFSNNAMAEAFKAAKGE",
    "product": ""
   },
   {
    "start": 1793941,
    "end": 1794624,
    "strand": -1,
    "locus_tag": "ctg1_1699",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1699</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1699</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,793,941 - 1,794,624,\n (total: 684 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1699\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1699\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1699\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1699\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGGCAATTGCCCCGGTAATTACCATTGATGGCCCAAGCGGTGCAGGAAAAGGCACCTTGTGCAAGGCAATGGCGGAAGCATTGCAATGGCATCTGTTGGATTCAGGAGCGATCTATCGTGTACTGGCATTGGCTGCCTTACATCACCATGTCGATGTTGCATCGGAAGACGCACTGGTACCGCTGGCTTCCCATCTTGATGTGCGCTTTATTTCAACTAACGGCAATCTGGAAGTTATCCTCGAAGGAGAAGACGTCAGCGGAGAAATCAGAACACAAGAAGTGGCGAATGCAGCATCACAAGTTGCTGCTTTTCCTCGTGTTCGTGAAGCTTTATTGCGTCGTCAGCGCGCGTTTCGCGAACTGCCCGGACTGATTGCCGACGGGCGTGACATGGGAACGGTGGTTTTTCCTGATGCGCCAGTAAAAATATTCCTTGATGCCTCCTCTGAAGAACGCGCGCATCGTCGCATGCTACAGTTGCAGGAGAAAGGCTTTAGTGTTAACTTTGAACGCCTTTTGGCCGAGATCAAAGAGCGTGATGACCGTGATCGTAATCGAGCGGTAGCCCCTCTGGTTCCGGCGGCTGATGCTTTAGTGTTAGATTCAACCACCTTAAGCATTGAGCAAGTGATTGAAAAAGCGTTACAATACGCGCGCCAAAAACTGGCTCTCGCATAA",
    "translation": "MTAIAPVITIDGPSGAGKGTLCKAMAEALQWHLLDSGAIYRVLALAALHHHVDVASEDALVPLASHLDVRFISTNGNLEVILEGEDVSGEIRTQEVANAASQVAAFPRVREALLRRQRAFRELPGLIADGRDMGTVVFPDAPVKIFLDASSEERAHRRMLQLQEKGFSVNFERLLAEIKERDDRDRNRAVAPLVPAADALVLDSTTLSIEQVIEKALQYARQKLALA",
    "product": ""
   },
   {
    "start": 1794811,
    "end": 1796088,
    "strand": -1,
    "locus_tag": "ctg1_1700",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1700</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1700</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,794,811 - 1,796,088,\n (total: 1278 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1700\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1700\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region2/ctg1_1700_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1700\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1700\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAATCCCTGACGTTACAACCCATCGCCCGTGTCGATGGCACTATTAATCTGCCCGGTTCCAAGAGCGTTTCTAACCGCGCTTTATTGCTGGCGGCTTTGGCACACGGTAAAACAGTATTAACTAATCTGCTGGATAGCGATGATGTTCGCCATATGCTTAATGCGTTAAAGGCATTAGGGGTAAGCTATTCGCTTTCTACCGATCGTACACGTTGCGAGATCATCGGTAACGGAGGTCCATTACACGCAGAGAGTGCACTGGAGTTGTTCCTCGGTAATGCCGGAACGGCAATGCGTCCGCTGGCGGCAGCTCTTTGTCTGGGTAGCAATGATATTGTTCTGACCGGTGAACCGCGCATGAAAGAACGGCCGATTGGTCATCTTGTAGATGCGTTGCGCCAGGGCGGAGCGGGAATCACTTACCTGGAGCAAGAAAACTATCCACCGCTGCGTTTACAGGGCGGCTTTACTGGTGGCAACGTTGACGTTGATGGTTCCGTTTCCAGTCAATTCCTCACCGCACTATTAATGACTGCGCCGCTTGCGCCGGAAGATACAGTTATTCGTATTAAAGGTGATCTGGTTTCTAAACCTTATATCGATATCACCCTCAACCTGATGAAAACGTTTGGTGTTGAAGTTGAAAATCAGCGCTATCAACAATTTGTGGTGAAAGGTGGTCAATCTTATCAGTCACCGGGCAGCTATTTAGTGGAAGGGGATGCATCTTCGGCTTCTTACTTTCTTGCTGCGGCAGCGATCAAAGGTGGTACGGTAAAAGTGACGGGCATTGGACGCAATAGTATGCAAGGCGATATTCACTTTGCTGACGTACTGGAAAAAATGGGCGCGACCATTAGCTGGGGCGACGATTATATATCCTGCACACGCGGTGAACTGAACGGCATTGATATGGATATGAACCATATTCCCGATGCGGCGATGACCATTGCCACGACGGCGTTATTTGCAAAAGGCACCACCACGCTGCGCAATATCTATAACTGGCGTGTTAAAGAGACTGATCGCCTGTTTGCGATGGCAACAGAACTGCGTAAAGTCGGTGCGGAAGTAGAAGAGGGGCACGATTTTATTCGTATCACTCCACTGGAAAAACTGAAATTTGCCGAGATCGCGACTTATAACGATCACCGAATGGCGATGTGTTTTTCGCTTGTCGCCTTGTCAGATACGGCAGTGACAATTTTGGATCCTAAATGTACCGCCAAAACGTTCCCGGACTATTTTGAGCAGTTGGCTCGCATTAGTGCATAA",
    "translation": "MESLTLQPIARVDGTINLPGSKSVSNRALLLAALAHGKTVLTNLLDSDDVRHMLNALKALGVSYSLSTDRTRCEIIGNGGPLHAESALELFLGNAGTAMRPLAAALCLGSNDIVLTGEPRMKERPIGHLVDALRQGGAGITYLEQENYPPLRLQGGFTGGNVDVDGSVSSQFLTALLMTAPLAPEDTVIRIKGDLVSKPYIDITLNLMKTFGVEVENQRYQQFVVKGGQSYQSPGSYLVEGDASSASYFLAAAAIKGGTVKVTGIGRNSMQGDIHFADVLEKMGATISWGDDYISCTRGELNGIDMDMNHIPDAAMTIATTALFAKGTTTLRNIYNWRVKETDRLFAMATELRKVGAEVEEGHDFIRITPLEKLKFAEIATYNDHRMAMCFSLVALSDTAVTILDPKCTAKTFPDYFEQLARISA",
    "product": ""
   },
   {
    "start": 1796158,
    "end": 1797246,
    "strand": -1,
    "locus_tag": "ctg1_1701",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1701</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1701</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,796,158 - 1,797,246,\n (total: 1089 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_5<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1701\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1701\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1701\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1701\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTCAGGTATTCAATTTTAGTTCAGGCCCGGCAATGCTTCCGGCAGATGTGCTCAAGCAGGCGCAACAAGAGTTGTGTGACTGGAATGGTCTTGGTACATCCGTTATGGAAATTAGCCACCGTGGCAAAGAATTTATCAAAGTCGCAGAAGAAGCAGAGCACGATTTCCGCGAGCTGTTAAACGTTCCTTCAAACTATAAAGTACTCTTTTGCCATGGTGGTGGCCGTGGGCAATTTGCGGCGGTGCCACTGAATATACTTGGTGATAAGACTACCGCAGATTATGTTGATGCGGGCTACTGGGCGGCAAGCGCTATCAAAGAAGCGAAAAAATATTGCACGCCAAATGTGTTTGACGCCAAAGTAACCGTTGACGGTCTGCGCGCGGTGAAGCCAATGCGTGAATGGCAACTTTCTGATAACGCAGCTTACCTGCACTATTGCCCGAATGAAACTATTGATGGTATCGCCATTGACGAAACGCCAGACTTCGGTAACGAAGTGGTTGTCGCTGCCGATTTCTCATCAACCATTCTTTCTCGTCCAATCGATGTGAGCCGTTACGGCGTGATCTATGCTGGCGCGCAGAAAAATATCGGCCCAGCTGGTCTGACAATTGTCATTGTGCGTGAAGACTTGCTGGGTAAAGCGAATATCGCGTGTCCGTCGATTCTGGATTATTCCATCCTCAACGATAACGACTCTATGTTTAACACGCCGCCGACGTTTGCCTGGTACTTATCTGGCCTGGTCTTCAAATGGCTGAAAGCGAATGGTGGGGTGGCTGCAATGGATAAAATCAATCAGCAGAAAGCGGAGCTGCTTTACGGCGCCATTGATAACAGCGATTTTTACCGTAATGACGTAGCGAAAGCTAACCGTTCTCGGATGAACGTGCCGTTCCAGTTGGCGGACAATGCTCTCGATAAACTGTTCCTCGAAGAGTCTTTCGCTGCGGGGCTGCATGCGCTGAAAGGGCATCGCGTGGTCGGCGGTATGCGTGCGTCAATTTATAACGCAATGCCTCTGGAAGGTGTCATAGCCCTGACTGATTTTATGGCTGATTTCGAACGTCGCCACGGTTAA",
    "translation": "MAQVFNFSSGPAMLPADVLKQAQQELCDWNGLGTSVMEISHRGKEFIKVAEEAEHDFRELLNVPSNYKVLFCHGGGRGQFAAVPLNILGDKTTADYVDAGYWAASAIKEAKKYCTPNVFDAKVTVDGLRAVKPMREWQLSDNAAYLHYCPNETIDGIAIDETPDFGNEVVVAADFSSTILSRPIDVSRYGVIYAGAQKNIGPAGLTIVIVREDLLGKANIACPSILDYSILNDNDSMFNTPPTFAWYLSGLVFKWLKANGGVAAMDKINQQKAELLYGAIDNSDFYRNDVAKANRSRMNVPFQLADNALDKLFLEESFAAGLHALKGHRVVGGMRASIYNAMPLEGVIALTDFMADFERRHG",
    "product": ""
   },
   {
    "start": 1797436,
    "end": 1798128,
    "strand": -1,
    "locus_tag": "ctg1_1702",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1702</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1702</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,797,436 - 1,798,128,\n (total: 693 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1702\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1702\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1702\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1702\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGGCGTTCGATCTCCACCGTATGGCATTTGATAAAGTGCCTTTTGATTTCCTTGGCGAAGTTGCACTACGTAGTCTTTATACCTTTGTACTGGTCTTTTTATTCCTCAAAATGACCGGAAGACGCGGTGTGCGGCAGATGTCGCTTTTTGAAGTGTTAATCATTCTGACGCTGGGGTCAGCGGCGGGAGATGTGGCGTTTTATGATGATGTGCCGATGGTCCCGGTACTTATCGTCTTTATTACTCTGGCGTTGTTATACCGCCTGGTAATGTGGTTGATGGCGCACAGTGAGAAACTGGAAGATCTTCTGGAAGGCAAACCGGTTGTCATTATTGAAGATGGCGAACTGGCCTGGTCGAAACTCAATAACTCCAACATGACGGAATTTGAGTTTTTTATGGAACTGCGACTCCGGGGTGTGGAACAACTGGGGCAGGTCCGCCTGGCTATACTCGAAACCAACGGGCAAATCAGTGTCTATTTCTTTGAAGATGACAAGGTGAAACCGGGTTTACTTATTTTACCCAGTGATTGTACTCAGCGTTACAAAGTGGTACCGGAGTCGGCGGACTATGCCTGCATCCGTTGCAGTGAAATCATTCATATGAACGCGGGGGAAAAACAATTATGTCCGCGCTGTGCAAATCCAGAATGGACGAAGGCAAGCCGGGCGAAACGGGTGACCTGA",
    "translation": "MKAFDLHRMAFDKVPFDFLGEVALRSLYTFVLVFLFLKMTGRRGVRQMSLFEVLIILTLGSAAGDVAFYDDVPMVPVLIVFITLALLYRLVMWLMAHSEKLEDLLEGKPVVIIEDGELAWSKLNNSNMTEFEFFMELRLRGVEQLGQVRLAILETNGQISVYFFEDDKVKPGLLILPSDCTQRYKVVPESADYACIRCSEIIHMNAGEKQLCPRCANPEWTKASRAKRVT",
    "product": ""
   },
   {
    "start": 1798258,
    "end": 1800018,
    "strand": 1,
    "locus_tag": "ctg1_1703",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1703</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1703</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,798,258 - 1,800,018,\n (total: 1761 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) thiopeptide: YcaO<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1703\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1703\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region2/ctg1_1703_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1703\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1703\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGCAAACATTTATCCCCGGCAAAGATGCCGCTCTGGAAGATTCCATCGCTCGCTTCCAGCAAAAACTTTCAGACCTCGGTTTTCAGATTGAAGAGGCCTCCTGGCTGAATCCCGTGCCTAACGTCTGGTCTGTACATATTCGTGACAAAGAGTGCGCACTGTGTTTTACCAACGGTAAAGGCGCAACCAAAAAAGCGGCGCTGGCATCCGCCCTCGGTGAATATTTCGAGCGTCTCTCAACCAACTACTTTTTTGCTGACTTCTGGCTGGGCGAAACCATCGCCAACGGTCCGTTCGTGCATTATCCCAACGAAAAATGGTTCCCACTGACCGAAAACGACGATGTGCCGGAAGGACTGCTCGATGACCGTCTGCGCGCGTTTTACGACCCTGAAAATGAACTGACCGGCAGCATGCTGATTGACCTGCAATCCGGTAACGAAGATCGTGGTATTTGCGGTCTGCCATTTACGCGCCAGTCCGACAATCAGACCGTTTATATTCCGATGAATATCATTGGTAACTTGTACGTTTCTAACGGTATGTCCGCTGGCAATACCCGCAACGAAGCACGCGTTCAAGGGTTGTCCGAAGTTTTCGAACGCTACGTGAAAAACCGCATTATTGCTGAAAGCATCAGCTTGCCGGAAATCCCGGCAGACGTGCTGGCACGTTACCCTGCAGTAGTTGAAGCAATCGAAACACTGGAAGCGGAAGGTTTCCCAATCTTTGCTTATGATGGTTCGCTTGGCGGCCAGTATCCAGTGATTTGCGTGGTACTGTTCAATCCGGCTAACGGCACTTGCTTTGCCTCTTTCGGTGCGCATCCTGATTTTGGCGTAGCACTGGAACGTACCGTGACCGAGCTGCTGCAAGGTCGTGGCCTGAAAGATTTGGATGTGTTTACTCCGCCAACCTTCGATGATGAAGAAGTTGCTGAACATACCAACCTTGAAACGCACTTTATCGATTCCAGCGGTTTAATCTCCTGGGACCTGTTCAAGCAGGATGCCGATTATCCGTTTGTGGACTGGAATTTCTCCGGCACCACGGAAGAAGAGTTTGCCACGCTGATGGCTATCTTCAACAACGAAGATAAAGAAGTTTATATTGCCGATTACGAGCATCTGGGCGTTTATGCTTGTCGTATTATCGTGCCTGGCATGTCCGATATTTATCCGGCTGAAGATTTGTGGTTAGCGAATAACAGCATGGGCAGCCATTTACGTGAAACGATTCTTTCACTCCCAGGCAGCGAGTGGGAAAAAGAAGATTACCTGAACCTCATCGAGCAACTGGATGAAGAAGGTTTTGATGACTTTACCCGCGTGCGTGAGCTATTGGGTCTGGCAACCGGGCCGGATAACGGCTGGTACACTCTGCGTATCGGTGAATTAAAGGCTATGCTGGCGCTGGCTGGTGGCGATCTGGAACAGGCTCTGGTCTGGACCGAATGGACGATGGAGTTTAACTCATCGGTCTTCAGCCCGGAACGCGCAAACTATTATCGCTGCCTGCAAACCCTCCTGCTGCTGGCTCAGGAAGAAGATCGCCAGCCACTGCAATATCTGAATGCTTTTATCCGCATGTACGGCGCGGAGGCGGTAGAAGCCGCCAGTGCGGCAATGAGTGGCGAAGCGGCGTTTTACGGCCTGCAACCGGTAGATAGCGATCTGCACGCATTCGCCGCACATCAGTCGCTGCTGAAGGCCTATGAAAAGCTGCAACGCGCCAAAGCGACATTCTGGACAAAATGA",
    "translation": "MTQTFIPGKDAALEDSIARFQQKLSDLGFQIEEASWLNPVPNVWSVHIRDKECALCFTNGKGATKKAALASALGEYFERLSTNYFFADFWLGETIANGPFVHYPNEKWFPLTENDDVPEGLLDDRLRAFYDPENELTGSMLIDLQSGNEDRGICGLPFTRQSDNQTVYIPMNIIGNLYVSNGMSAGNTRNEARVQGLSEVFERYVKNRIIAESISLPEIPADVLARYPAVVEAIETLEAEGFPIFAYDGSLGGQYPVICVVLFNPANGTCFASFGAHPDFGVALERTVTELLQGRGLKDLDVFTPPTFDDEEVAEHTNLETHFIDSSGLISWDLFKQDADYPFVDWNFSGTTEEEFATLMAIFNNEDKEVYIADYEHLGVYACRIIVPGMSDIYPAEDLWLANNSMGSHLRETILSLPGSEWEKEDYLNLIEQLDEEGFDDFTRVRELLGLATGPDNGWYTLRIGELKAMLALAGGDLEQALVWTEWTMEFNSSVFSPERANYYRCLQTLLLLAQEEDRQPLQYLNAFIRMYGAEAVEAASAAMSGEAAFYGLQPVDSDLHAFAAHQSLLKAYEKLQRAKATFWTK",
    "product": ""
   },
   {
    "start": 1800423,
    "end": 1801280,
    "strand": 1,
    "locus_tag": "ctg1_1704",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1704</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1704</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,800,423 - 1,801,280,\n (total: 858 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1704\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1704\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1704\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1704\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAAAGCTGACAACCCTTTTGATCTTATTCTTCCTGCTGCGATGGCCAAAGTTGCCGAAGAAGCAGGTGTCTATAAAGCAACGAAACATCCGCTTAAGACTTTCTATCTGGCGATTACCGCTGGTGTATTCATCTCTATCGCTTTTGTTTTCTATATCACTGCAACAACAGGTGCTGGTGCGATGCCATATGGCATGGCAAAACTGGTTGGCGGTATCTGCTTCTCTCTGGGCCTCATTCTTTGTGTTGTTTGTGGTGCTGATCTCTTTACTTCAACAGTTCTGATTGTTGTTGCTAAAGCCAGTGGACGCATCACCTGGGGGCAACTGGCGAAGAACTGGCTTAATGTCTATTTTGGTAACCTGATCGGTGCATTACTGTTTGTTCTGCTGATGTGGCTTTCCGGCGAATATATGACTGCGAATGGTCAGTGGGGACTTAACGTCCTGCAAACAGCCGATCATAAAATGCACCATACTTTTATTGAAGCTGTTGCCCTCGGTATCCTGGCAAACCTGATGGTCTGTCTGGCTGTGTGGATGAGCTACTCTGGCCGTAGCCTGATGGACAAATCGTTTATCATGATTCTTCCTGTCGCCATGTTCGTAGCCAGTGGATTCGAACACAGCATCGCAAACATGTTTATGATCCCAATGGGTATCGTAATTCGTGACTTTGCATCACCGGAATTCTGGACCGCTATCGGTTCTTCTCCGGAAAATTTTTCTCACCTGACCGTGATGGGCTTCATCACTGATAACCTGATTCCGGTTACGATCGGTAACATTATTGGCGGTGGTTTGTTGGTTGGGTTGACATACTGGGTCATTTATCTGCGTGATAACGATCATCACTAA",
    "translation": "MKADNPFDLILPAAMAKVAEEAGVYKATKHPLKTFYLAITAGVFISIAFVFYITATTGAGAMPYGMAKLVGGICFSLGLILCVVCGADLFTSTVLIVVAKASGRITWGQLAKNWLNVYFGNLIGALLFVLLMWLSGEYMTANGQWGLNVLQTADHKMHHTFIEAVALGILANLMVCLAVWMSYSGRSLMDKSFIMILPVAMFVASGFEHSIANMFMIPMGIVIRDFASPEFWTAIGSSPENFSHLTVMGFITDNLIPVTIGNIIGGGLLVGLTYWVIYLRDNDHH",
    "product": ""
   },
   {
    "start": 1801336,
    "end": 1803618,
    "strand": 1,
    "locus_tag": "ctg1_1705",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1705</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1705</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,801,336 - 1,803,618,\n (total: 2283 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1705\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1705\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1705\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1705\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCGAGCTTAATGAAAAGTTAGCCACAGCCTGGGAAGGTTTTACCAAAGGTGACTGGCAGAATGAAGTAAACGTCCGTGACTTCATCCAGAAAAACTACACTCCGTACGAGGGTGACGAGTCCTTCCTGGCTGGCGCTACTGACGCGACCACTACCCTGTGGGACAAAGTAATGGAAGGCGTTAAACTGGAAAACCGCACTCACGCGCCAGTTGACTTTGACACCGCTGTTGCTTCCACCATCACTTCCCACGACGCTGGCTACATCAACAAAGCGCTGGAAAAAATTGTTGGTCTGCAGACTGAAGCTCCGCTGAAACGTGCTCTTATCCCGTTCGGTGGTATCAAAATGATCGAAGGTTCCTGCAAAGCGTACAACCGCGAACTGGACCCGATGATCAAAAAAATCTTCACTGAATACCGTAAAACTCACAACCAGGGCGTGTTCGACGTTTATACTCCGGACATCCTGCGTTGCCGTAAATCCGGGGTTCTGACCGGTTTGCCAGATGCTTATGGTCGTGGCCGTATCATTGGTGACTACCGTCGCGTTGCGCTGTACGGTATCGACTACCTGATGAAAGACAAATACGCTCAGTTCACCTCTCTGCAGGCAGATCTGGAAAATGGCGTAAATCTGGAAGCAACTATCCGTCTGCGTGAAGAAATTGCTGAACAGCACCGCGCTCTGGGTCAGATGAAAGAAATGGCTGCCAAATACGGCTACGACATTTCTGGTCCGGCAACCAACGCTCAGGAAGCTATCCAGTGGACTTACTTCGGCTACCTGGCTGCTGTTAAGTCTCAGAACGGTGCTGCAATGTCCTTCGGTCGTACCTCCACCTTCCTGGATGTGTACATCGAACGTGACCTGAAAGCTGGCAAGATCACCGAACAAGAAGCGCAGGAAATGGTTGACCACCTGGTCATGAAACTGCGTATGGTTCGCTTCCTGCGTACCCCGGAATACGATGAACTGTTCTCTGGCGACCCGATCTGGGCAACCGAATCTATCGGTGGTATGGGCCTCGACGGTCGTACCCTGGTTACCAAAAACAGCTTCCGTTTCCTGAACACCCTGTACACCATGGGTCCGTCTCCGGAACCGAACATGACCATTCTGTGGTCTGAAAAACTGCCGCTGAACTTCAAGAAATTCGCTGCTAAAGTGTCCATCGACACCTCTTCTCTGCAGTATGAGAACGATGACCTGATGCGTCCGGACTTCAACAACGATGACTACGCTATCGCTTGCTGCGTAAGCCCGATGATCGTTGGTAAACAAATGCAGTTCTTCGGTGCGCGTGCAAACCTGGCGAAAACCATGCTGTACGCAATCAACGGCGGCGTTGACGAAAAACTGAAAATGCAGGTTGGTCCGAAATCTGAACCGATCAAAGGCGACGTCCTGAACTACGATGAAGTGATGGAGCGCATGGATCACTTCATGGACTGGCTGGCTAAACAGTACATCACTGCACTGAACATCATCCACTACATGCACGACAAGTACAGCTACGAAGCCTCTCTGATGGCGCTGCACGACCGTGACGTTATCCGCACCATGGCGTGTGGTATCGCTGGTCTGTCCGTTGCTGCTGACTCCCTGTCTGCAATCAAATATGCGAAAGTTAAACCGATTCGTGACGAAGACGGTCTGGCTATCGACTTCGAAATCGAAGGCGAATACCCGCAGTTTGGTAACAACGATCCGCGTGTAGATGACCTGGCTGTTGACCTGGTAGAACGTTTCATGAAGAAAATTCAGAAACTGCACACCTACCGTGACGCAATCCCGACTCAGTCTGTTCTGACCATCACTTCTAACGTTGTGTATGGTAAGAAAACTGGTAACACCCCAGACGGTCGTCGTGCTGGCGCGCCGTTCGGACCGGGTGCTAACCCGATGCACGGTCGTGACCAGAAAGGTGCTGTAGCGTCTCTGACTTCCGTTGCTAAACTGCCGTTCGCTTACGCTAAAGATGGTATCTCCTACACCTTCTCTATCGTTCCGAACGCACTGGGTAAAGACGACGAAGTTCGTAAGACCAACCTGGCTGGTCTGATGGATGGTTACTTCCACCACGAAGCATCCATCGAAGGTGGTCAGCACCTGAACGTTAACGTGATGAACCGTGAAATGCTGCTCGACGCGATGGAAAATCCGGAAAAATATCCGCAGCTGACCATCCGTGTATCTGGCTACGCAGTACGTTTCAACTCGCTGACTAAAGAACAGCAGCAGGACGTAATTACCCGTACCTTCACTCAAACCATGTAA",
    "translation": "MSELNEKLATAWEGFTKGDWQNEVNVRDFIQKNYTPYEGDESFLAGATDATTTLWDKVMEGVKLENRTHAPVDFDTAVASTITSHDAGYINKALEKIVGLQTEAPLKRALIPFGGIKMIEGSCKAYNRELDPMIKKIFTEYRKTHNQGVFDVYTPDILRCRKSGVLTGLPDAYGRGRIIGDYRRVALYGIDYLMKDKYAQFTSLQADLENGVNLEATIRLREEIAEQHRALGQMKEMAAKYGYDISGPATNAQEAIQWTYFGYLAAVKSQNGAAMSFGRTSTFLDVYIERDLKAGKITEQEAQEMVDHLVMKLRMVRFLRTPEYDELFSGDPIWATESIGGMGLDGRTLVTKNSFRFLNTLYTMGPSPEPNMTILWSEKLPLNFKKFAAKVSIDTSSLQYENDDLMRPDFNNDDYAIACCVSPMIVGKQMQFFGARANLAKTMLYAINGGVDEKLKMQVGPKSEPIKGDVLNYDEVMERMDHFMDWLAKQYITALNIIHYMHDKYSYEASLMALHDRDVIRTMACGIAGLSVAADSLSAIKYAKVKPIRDEDGLAIDFEIEGEYPQFGNNDPRVDDLAVDLVERFMKKIQKLHTYRDAIPTQSVLTITSNVVYGKKTGNTPDGRRAGAPFGPGANPMHGRDQKGAVASLTSVAKLPFAYAKDGISYTFSIVPNALGKDDEVRKTNLAGLMDGYFHHEASIEGGQHLNVNVMNREMLLDAMENPEKYPQLTIRVSGYAVRFNSLTKEQQQDVITRTFTQTM",
    "product": ""
   },
   {
    "start": 1803811,
    "end": 1804551,
    "strand": 1,
    "locus_tag": "ctg1_1706",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1706</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1706</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,803,811 - 1,804,551,\n (total: 741 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) thiopeptide: PF04055<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1706\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1706\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1706\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1706\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCAGTTATTGGTCGCATTCACTCCTTTGAATCCTGTGGAACCGTAGACGGCCCAGGTATTCGCTTTATTACTTTTTTCCAGGGCTGCCTGATGCGCTGCCTGTATTGTCATAACCGCGACACTTGGGACACGCATGGTGGTAAAGAAGTTACCGTTGAAGATTTAATGAAAGAGGTGGTGACCTATCGCCACTTTATGAATGCATCTGGCGGTGGTGTTACCGCGTCCGGCGGCGAGGCAATCCTGCAAGCCGAGTTTGTTCGTGACTGGTTCCGCGCCTGCAAAAAAGAAGGTATTCATACCTGTCTGGACACTAACGGTTTTGTTCGTCGTTACGATCCGGTGATTGATGAACTGCTGGAAGTAACCGACCTGGTGATGCTCGATCTCAAACAGATGAACGACGAGATCCACCAAAATCTGGTTGGAGTTTCCAACCACCGCACGCTGGAGTTCGCCAAATATCTGGCGAACAAAAATGTGAAGGTTTGGATCCGCTACGTTGTTGTCCCAGGCTGGTCTGATGATGATGATTCTGCCCATCGTCTGGGTGAATTTACCCGCGATATGGGCAACGTCGAGAAAATCGAGCTTCTCCCCTACCACGAGCTGGGCAAACACAAATGGGTGGCAATGGGTGAAGAGTACAAACTCGACGGCGTGAAACCACCGAAAAAAGAGACCATGGAACGCGTGAAAGGCATTCTTGAGCAATATGGCCATAAGGTAATGTTCTAA",
    "translation": "MSVIGRIHSFESCGTVDGPGIRFITFFQGCLMRCLYCHNRDTWDTHGGKEVTVEDLMKEVVTYRHFMNASGGGVTASGGEAILQAEFVRDWFRACKKEGIHTCLDTNGFVRRYDPVIDELLEVTDLVMLDLKQMNDEIHQNLVGVSNHRTLEFAKYLANKNVKVWIRYVVVPGWSDDDDSAHRLGEFTRDMGNVEKIELLPYHELGKHKWVAMGEEYKLDGVKPPKKETMERVKGILEQYGHKVMF",
    "product": ""
   },
   {
    "start": 1804761,
    "end": 1806191,
    "strand": -1,
    "locus_tag": "ctg1_1707",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1707</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1707</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,804,761 - 1,806,191,\n (total: 1431 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1038:phenylalanine-specific permease (Score: 93.9; E-value: 1.2e-28)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1707\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1707\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1707\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1707\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCGCGTAATGGGCAGGAAAAACAGTTGCGATGGTACAATATTGCATTGATGTCATTTATTACAGTCTGGGGATTTGGCAATGTTGTTAATAATTATGCAAACCAGGGATTAGTGGTAGTTTTCTCATGGTTGTTTATATTTATCCTTTATTTTACTCCGTATGCTCTTATTGTCGGACAACTGGGTTCAACGTTTAAAGATGGGAAGGGCGGAGTTAGCACCTGGATTAAGCATACTATGGGGCCAGGACTGGCTTATCTTGCCGCATGGACCTATTGGGTGGTGCATATTCCTTACCTGGCACAAAAACCTCAAACAATTCTGATTGCTCTTGGTTGGGCCGTGAAAGGTGACGGTTCACTAATTAAAGAATACTCGGTGGTAGTATTACAGGGGCTAACATTAGTGTTGTTTGTCTTCTTTATGTGGGTCGCATCGCGCGGTATGAAATCGCTGAAAACCGTCGGTTCGATTGCGGGAATCGCGATGTTTGTAATGTCGCTGTTATATGTGGCGATGGCAGTAGCTGCACCGGCTATAACTGAAGTTCATATTGCGACCACTAATATTACCTCGGAAACGTTTATTCCTCATATAGATTTCACCTACATAACGACTATTTCGATGTTAGTTTTTGCAGTGGGCGGTGCTGAGAAGATTTCTCCTTACGTTAATCAAACGTGTAATCCGGGAAAAGAGTTTCCAAAAGGGATGCTATGTTTAGCAGCAATGGTTGCGGTGTGTGCAATTCTGGGATCGCTGGCGATGGGGATGATGTTTGACTCGCGGCATATTCCGGATGATTTAATGACCAATGGGCAATATTATGCCTTCCAGAAATTGGGAGAGTATTACAATATGGGTAATTCCTTAATGGTCATTTACGCCATTGCTAATACCCTTGGGCATGTTGCTGCACTGGTATTCTCAATTGATGCGCCACTGAAAGTCTTACTAGGGGATGCAGACAGGAAATATATTCCTGCAAGATTGTGCCGTACAAATGATTCAGGAACACCAGTTAACGGGTATATTTTGACGCTGGTGTTAGTGGCGATCCTGATAATGCTGCCAACGCTGGGTATTGGTGATATGAATAATCTCTACAAATGGTTGTTGAATCTTAACTCGGTAGTGATGCCACTGCGTTATTTGTGGGTGTTTGTTGCATTTATTGCAGTCGTTCGCCTGGCGCAGAAATATAAACCAGAGTATGTCTTTATTCGTAATAGATGGCTGGCGATGATCGTCGGGATTTGGTGTTTTGCCTTTACCGCTTTTGCCTGTTTGACGGGGATCTTCCCGAAAATGGAAGCCTTCACTACCGAGTGGACTTTCCAGCTGGCGCTGAACATTGCAACGCCGTTTGTGCTGGTAGGATTAGGGCTGATATTCCCGTTGTTGGCGCGTAAAGCGAATAGTGAATAA",
    "translation": "MARNGQEKQLRWYNIALMSFITVWGFGNVVNNYANQGLVVVFSWLFIFILYFTPYALIVGQLGSTFKDGKGGVSTWIKHTMGPGLAYLAAWTYWVVHIPYLAQKPQTILIALGWAVKGDGSLIKEYSVVVLQGLTLVLFVFFMWVASRGMKSLKTVGSIAGIAMFVMSLLYVAMAVAAPAITEVHIATTNITSETFIPHIDFTYITTISMLVFAVGGAEKISPYVNQTCNPGKEFPKGMLCLAAMVAVCAILGSLAMGMMFDSRHIPDDLMTNGQYYAFQKLGEYYNMGNSLMVIYAIANTLGHVAALVFSIDAPLKVLLGDADRKYIPARLCRTNDSGTPVNGYILTLVLVAILIMLPTLGIGDMNNLYKWLLNLNSVVMPLRYLWVFVAFIAVVRLAQKYKPEYVFIRNRWLAMIVGIWCFAFTAFACLTGIFPKMEAFTTEWTFQLALNIATPFVLVGLGLIFPLLARKANSE",
    "product": ""
   },
   {
    "start": 1806399,
    "end": 1807547,
    "strand": -1,
    "locus_tag": "ctg1_1708",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1708</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1708</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,806,399 - 1,807,547,\n (total: 1149 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1169:sugar transport protein (Score: 62.6; E-value: 5.6e-19)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1708\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1708\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSIYTRPVMLLLSGLLLLTLAIAVLNTLVPLWLAHEHLPTWQVGMVSSSYFTGNLVGTLLTGYLIKRLGFNRSYYLASLVFAAGCLGLGLMIGFWSWMAWRFVAGVGCAMIWVVVESALMCSGTSRNRGRLLAAYMMIYYVGTFLGQLLVSKVSTELMNVLPWVTALILAGILPLLFTRILSQQTESRKTTSITSMLKLRQARLGVNGCIISGIVLGSLYGLMPLYLNHQGISNSNIGFWMAVLVSAGIVGQWPIGRLADKFGRLLVLRVQIFVVILGSIAMLTHTAMAPALFILGAAGFTLYPVAMAWSCEKVSQDQLVAMNQALLLSYTIGSLLGPSFTAMLMQHYSDNLLFIMIASVSFIYLLMLLRNARHTSNPVAHV\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1708\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1708\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCTATCTATACCCGGCCTGTCATGCTTTTGCTGTCTGGCCTGCTTTTGTTGACCCTGGCGATAGCGGTATTGAACACGCTTGTACCGCTATGGCTTGCTCATGAACATCTACCGACATGGCAGGTTGGTATGGTCAGCTCATCTTATTTCACTGGTAATCTGGTGGGCACATTGTTGACAGGGTATTTGATCAAACGCCTCGGATTTAACCGTAGTTACTACCTTGCATCTTTGGTTTTTGCTGCGGGATGTCTGGGCCTGGGCTTAATGATTGGCTTCTGGAGTTGGATGGCCTGGCGTTTTGTTGCGGGCGTTGGTTGTGCCATGATTTGGGTGGTGGTTGAAAGCGCTCTGATGTGCAGTGGTACATCGCGCAATCGTGGCCGTCTGCTCGCTGCATATATGATGATCTATTATGTGGGAACGTTTCTGGGGCAGTTGCTGGTTAGTAAAGTTTCTACCGAACTAATGAATGTTTTGCCCTGGGTTACAGCTCTGATTCTGGCTGGAATTCTGCCTCTGTTATTTACTCGTATCCTGAGTCAGCAAACTGAATCTCGGAAAACAACATCTATTACCTCAATGCTGAAACTACGCCAGGCGCGATTAGGTGTTAATGGCTGTATTATTTCCGGCATAGTGCTTGGCTCTTTATACGGGTTGATGCCACTTTATCTGAACCATCAGGGAATTAGTAATTCCAACATTGGTTTTTGGATGGCGGTGTTAGTGAGTGCTGGAATTGTAGGACAGTGGCCAATTGGTCGCCTGGCTGATAAATTTGGCCGGTTGTTAGTTTTGCGTGTTCAGATTTTTGTGGTGATTTTGGGAAGCATTGCCATGCTTACACATACAGCAATGGCTCCTGCATTATTTATCCTCGGCGCTGCTGGGTTTACACTTTACCCTGTCGCTATGGCCTGGTCTTGCGAAAAAGTTTCGCAAGACCAATTAGTTGCTATGAATCAGGCATTGCTTTTGAGTTACACAATCGGCAGTTTGCTGGGGCCGTCATTTACCGCGATGTTAATGCAGCATTATTCCGATAATCTGTTATTTATTATGATTGCCAGCGTATCATTTATTTACCTGCTCATGTTACTTCGTAATGCCAGACATACCTCAAATCCTGTGGCACACGTGTAA",
    "translation": "MSIYTRPVMLLLSGLLLLTLAIAVLNTLVPLWLAHEHLPTWQVGMVSSSYFTGNLVGTLLTGYLIKRLGFNRSYYLASLVFAAGCLGLGLMIGFWSWMAWRFVAGVGCAMIWVVVESALMCSGTSRNRGRLLAAYMMIYYVGTFLGQLLVSKVSTELMNVLPWVTALILAGILPLLFTRILSQQTESRKTTSITSMLKLRQARLGVNGCIISGIVLGSLYGLMPLYLNHQGISNSNIGFWMAVLVSAGIVGQWPIGRLADKFGRLLVLRVQIFVVILGSIAMLTHTAMAPALFILGAAGFTLYPVAMAWSCEKVSQDQLVAMNQALLLSYTIGSLLGPSFTAMLMQHYSDNLLFIMIASVSFIYLLMLLRNARHTSNPVAHV",
    "product": ""
   },
   {
    "start": 1807860,
    "end": 1808486,
    "strand": 1,
    "locus_tag": "ctg1_1709",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1709</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1709</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,807,860 - 1,808,486,\n (total: 627 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1709\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1709\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region2/ctg1_1709_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1709\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1709\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCAGGCCCTATGTTCGTCTCGATAAAAATGACGCTGCGGTACTATTAGTTGATCATCAAGCTGGATTATTGTCACTTGTCAGGGATATTGAGCCTGACAAATTCAAAAATAATGTTCTGGCATTAGGCGATTTAGCAAAATATTTCAAACTCCCCACCATTCTCACTACCAGTTTCGAAACAGGTCCCAATGGTCCACTGGTTCCCGAACTTAAGGCACAGTTCCCGGATGCGCCTTATATTGCCCGTCCTGGCAATATCAATGCCTGGGATAATGAAGATTTTGTCAAAGCCGTAAAAGCTACGGGTAAAAAGCAGTTGATCATTGCAGGTGTAGTAACTGAAGTATGTGTTGCTTTCCCGGCACTTTCAGCCATAGAAGAAGGTTTTGATGTCTTCGTGGTGACTGATGCTTCAGGCACATTTAACGAGATCACACGCCATTCGGCATGGGATCGTATGTCGCAAGCAGGAGCGCAATTAATGACATGGTTTGGCGTCGCCTGCGAGTTGCACCGCGACTGGAGAAACGATATTGAGGGGCTGGCGACACTGTTCTCAAATCATATTCCTGACTATCGTAATCTGATGACGAGTTACGACACCTTAACGAAACAGAAATAA",
    "translation": "MTRPYVRLDKNDAAVLLVDHQAGLLSLVRDIEPDKFKNNVLALGDLAKYFKLPTILTTSFETGPNGPLVPELKAQFPDAPYIARPGNINAWDNEDFVKAVKATGKKQLIIAGVVTEVCVAFPALSAIEEGFDVFVVTDASGTFNEITRHSAWDRMSQAGAQLMTWFGVACELHRDWRNDIEGLATLFSNHIPDYRNLMTSYDTLTKQK",
    "product": ""
   },
   {
    "start": 1808544,
    "end": 1809836,
    "strand": -1,
    "locus_tag": "ctg1_1710",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1710</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1710</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,808,544 - 1,809,836,\n (total: 1293 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1710\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1710\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region2/ctg1_1710_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1710\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1710\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTCGATCCCAATCTGCTGCGTAATGAGCCAGACGCAGTCGCTGAAAAACTGGCACGCCGGGGCTTTAAGCTGGATGTAGATAAGTTGGGCGCTCTTGAGGAGCGTCGTAAAGTATTGCAGGTCAAAACGGAAAACCTGCAAGCGGAGCGTAACTCCCGATCGAAATCCATTGGCCAGGCGAAAGCGCGGGGGGAAGATATCGAGCCTTTACGTCTGGAAGTGAACAAACTGGGCGAAGAGCTGGATGCAGCAAAAGCCGAGCTGGATGCTTTACAGGCTGAAATTCGCGATATCGCGCTGACAATCCCTAACCTGCCTGCAGATGAAGTGCCGGTAGGTAAAGATGAAAATGACAACGTTGAAGTCAGCCGCTGGGGTACCCCGCGTGAGTTTGACTTCGAAGTTCGTGACCACGTGACGCTGGGTGAAATGCACTCTGGCCTGGACTTTGCAGCCGCAGTTAAGCTGACCGGTTCGCGCTTTGTGGTGATGAAAGGGCAGATTGCTCGTATGCACCGCGCACTGGCGCAGTTTATGCTAGATCTGCATACCGAACAGCACGGTTATAGTGAAAACTATGTTCCGTATCTGGTTAACCAGGACACGCTGTACGGTACAGGGCAGTTGCCGAAGTTTGCTGGCGATCTGTTCCATACTCGTCCGCTGGAAGAAGAAGCAGATACCAGTAACTACGCACTGATCCCAACGGCAGAAGTTCCGCTGACTAACCTGGTACGCGGTGAAATCATTGATGAAGATGATCTGCCAATTAAGATGACCGCCCACACCCCATGCTTCCGTTCTGAAGCCGGTTCATATGGTCGTGACACCCGTGGTCTGATCCGTATGCACCAGTTCGACAAAGTTGAAATGGTGCAGATCGTTCGCCCGGAAGACTCAATGGCGGCGCTGGAAGAGATGACCGGTCATGCGGAAAAAGTCCTGCAGTTGCTGGGCCTGCCGTACCGTAAAATCATTCTTTGCACCGGCGACATGGGCTTTGGCGCTTGCAAAACTTACGACCTGGAAGTATGGATCCCGGCACAGAACACCTACCGCGAGATCTCTTCCTGCTCCAACGTTTGGGATTTCCAGGCGCGTCGTATGCAGGCACGTTGCCGTAGCAAGTCGGACAAGAAAACCCGTCTGGTTCATACCCTGAACGGTTCTGGTCTGGCTGTTGGTCGTACGCTGGTTGCGGTAATGGAAAACTATCAGCAGGCTGATGGTCGTATCGAAGTACCGGAAGTTTTACGCCCGTACATGAACGGCCTTGAATATATCGGTTAA",
    "translation": "MLDPNLLRNEPDAVAEKLARRGFKLDVDKLGALEERRKVLQVKTENLQAERNSRSKSIGQAKARGEDIEPLRLEVNKLGEELDAAKAELDALQAEIRDIALTIPNLPADEVPVGKDENDNVEVSRWGTPREFDFEVRDHVTLGEMHSGLDFAAAVKLTGSRFVVMKGQIARMHRALAQFMLDLHTEQHGYSENYVPYLVNQDTLYGTGQLPKFAGDLFHTRPLEEEADTSNYALIPTAEVPLTNLVRGEIIDEDDLPIKMTAHTPCFRSEAGSYGRDTRGLIRMHQFDKVEMVQIVRPEDSMAALEEMTGHAEKVLQLLGLPYRKIILCTGDMGFGACKTYDLEVWIPAQNTYREISSCSNVWDFQARRMQARCRSKSDKKTRLVHTLNGSGLAVGRTLVAVMENYQQADGRIEVPEVLRPYMNGLEYIG",
    "product": ""
   },
   {
    "start": 1809927,
    "end": 1811270,
    "strand": -1,
    "locus_tag": "ctg1_1711",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1711</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1711</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,809,927 - 1,811,270,\n (total: 1344 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1711\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1711\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1711\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1711\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGCAATCTGTCGCTCGATTTTTCGGATAATACTTTTCAACCTCTGGCCGCGCGTATGCGGCCAGAAAATTTAGCACAGTATATCGGTCAGCAACATTTGCTGGCTGCGGGGAAGCCGTTGCCGCGTGCAATCGAAGCCGGGCATTTGCATTCGATGATTCTCTGGGGGCCACCGGGTACCGGCAAAACAACCCTCGCTGAAGTGATTGCCCGCTATGCGAACGCTGATGTGGAACGTATTTCTGCCGTCACCTCTGGCGTGAAAGAGATTCGCGAGGCGATCGAGCGCGCCCGGCAAAACCGCAATGCAGGTCGCCGCACTATTCTTTTTGTTGATGAAGTTCACCGTTTCAACAAAAGCCAGCAGGATGCATTTCTGCCACATATTGAAGACGGCACCATCACTTTTATTGGCGCAACCACTGAAAACCCGTCGTTTGAGCTTAATTCGGCACTGCTTTCCCGTGCCCGTGTCTATCTGTTGAAATCCCTGAGTACAGAGGATATTGAGCAAGTACTAACTCAGGCGATGGAAGACAAAACCCGTGGCTATGGTGGTCAGGATATTGTTCTGCCAGATGAAACACGACGCGCCATTGCTGAACTGGTGAATGGCGACGCGCGCCGGGCGTTAAATACGCTGGAAATGATGGCGGATATGGCCGAAGTCGATGATAGCGGTAAGCGGGTCCTGAAGCCTGAATTACTGACCGAAATCGCCGGTGAACGTAGCGCCCGTTTTGATAACAAAGGCGATCGCTTTTACGATCTCATTTCCGCGCTGCATAAATCGGTGCGGGGTAGCGCACCTGATGCAGCTCTCTACTGGTATGCACGCATTATTACCGCCGGGGGCGATCCGTTATATGTCGCGCGCCGTTGCCTGGCGATAGCGTCTGAAGATGTTGGCAATGCCGACCCACGCGCGATGCAGGTGGCAATAGCAGCCTGGGATTGCTTTACCCGCGTTGGCCCGGCAGAAGGTGAACGCGCCATTGCTCAGGCGATTGTTTACCTGGCCTGCGCGCCAAAAAGCAACGCTGTCTATACCGCGTTTAAAGCCGCGCTGGCCGATGCTCGCGAACGTCCGGATTATGACGTACCGGTTCATTTGCGCAATGCGCCGACCAAACTGATGAAGGAAATGGGCTACGGTCAGGAATATCGTTATGCTCATGATGAAGCAAACGCTTATGCTGCCGGTGAGGTTTACTTCCCGCCGGAAATAGCACAAACACGCTATTATTTCCCGACAAACAGGGGCCTTGAAGGCAAGATTGGCGAAAAGCTCGCCTGGCTGGCTGAACAGGATCAAAATAGCCCCATAAAACGCTACCGTTAA",
    "translation": "MSNLSLDFSDNTFQPLAARMRPENLAQYIGQQHLLAAGKPLPRAIEAGHLHSMILWGPPGTGKTTLAEVIARYANADVERISAVTSGVKEIREAIERARQNRNAGRRTILFVDEVHRFNKSQQDAFLPHIEDGTITFIGATTENPSFELNSALLSRARVYLLKSLSTEDIEQVLTQAMEDKTRGYGGQDIVLPDETRRAIAELVNGDARRALNTLEMMADMAEVDDSGKRVLKPELLTEIAGERSARFDNKGDRFYDLISALHKSVRGSAPDAALYWYARIITAGGDPLYVARRCLAIASEDVGNADPRAMQVAIAAWDCFTRVGPAEGERAIAQAIVYLACAPKSNAVYTAFKAALADARERPDYDVPVHLRNAPTKLMKEMGYGQEYRYAHDEANAYAAGEVYFPPEIAQTRYYFPTNRGLEGKIGEKLAWLAEQDQNSPIKRYR",
    "product": ""
   },
   {
    "start": 1811281,
    "end": 1811892,
    "strand": -1,
    "locus_tag": "ctg1_1712",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1712</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1712</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,811,281 - 1,811,892,\n (total: 612 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_1712\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_1712\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1712\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_1712\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAAAAATTGCCATCACCTGTGCATTACTCTCAAGTTTAGTGGCGTCCAGTGTTTGGGCTGATGCCGCAAGCGATCTGAAAAGCCGTCTGGATAAAGTCAGCAGCTTCCACGCCAGTTTCACACAAAAAGTAACTGACGGTAGCGGCGCGGCGGTGCAGGAAGGTCAGGGCGATCTGTGGGTGAAACGTCCAAATTTATTCAACTGGCATATGACTCAACCTGATGAAAGCATTCTGGTTTCTGACGGTAAAACACTGTGGTTCTATAACCCGTTCGTTGAGCAAGCTACGGCAACCTGGCTGAAAGATGCCACCGGTAATACGCCGTTTATGCTGATTGCCCGCAACCAGTCCAGCGACTGGCAGCAGTACAATATCAAACAGAATGGCGATGACTTTGTCCTGACGCCGAAAGCCAGCAATGGCAATCTGAAGCAGTTCACCATTAACGTGGGACGTGATGGCACAATCCATCAGTTTAGCGCGGTGGAGCAGGACGATCAGCGCAGCAGTTATCAACTGAAATCTCAGCAAAATGGGGCTGTGGATGCAGCGAAATTTACCTTCACCCCGCCGCAAGGCGTCACGGTAGATGATCAACGTAAGTAG",
    "translation": "MKKIAITCALLSSLVASSVWADAASDLKSRLDKVSSFHASFTQKVTDGSGAAVQEGQGDLWVKRPNLFNWHMTQPDESILVSDGKTLWFYNPFVEQATATWLKDATGNTPFMLIARNQSSDWQQYNIKQNGDDFVLTPKASNGNLKQFTINVGRDGTIHQFSAVEQDDQRSSYQLKSQQNGAVDAAKFTFTPPQGVTVDDQRK",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 1798257,
    "end": 1804551,
    "tool": "rule-based-clusters",
    "neighbouring_start": 1788257,
    "neighbouring_end": 1814551,
    "product": "thiopeptide",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "thiopeptide",
  "products": [
   "thiopeptide"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP thiopeptide",
  "anchor": "r1c2"
 },
 "r1c3": {
  "start": 3924883,
  "end": 3968470,
  "idx": 3,
  "orfs": [
   {
    "start": 3930139,
    "end": 3931191,
    "strand": -1,
    "locus_tag": "ctg1_3629",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3629</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3629</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,930,139 - 3,931,191,\n (total: 1053 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3629\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3629\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3629\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3629\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACATATACATCGGATGGCTATTCAAGTTAATTCCTTTAGTTATGGGTATAATATGTATTGCGTTGGGTGACTTTGTATTATCAGGTTCCGGGCAAAGTGAATATTTTGTGGCGGGGCATGTTCTTATTTCACTTTCTGCAATATGTCTGGCATTATTCACTACTGCATTTATTATTATTTCGCAGCTAACGCATGGTGTGAATAAGCTCTACAATACCCTTTTTCCTGTTATCGGTTACGCTGGATCTGTTGCAACTATGATTTGGGGATGGTCACTGCTGGCAAGTGATAATGTCATGGCCGATGAATTTGTTGCCGGGCATGTTATTTTTGGTGTTGGAATGATTGCCGCTTGTGTATCGACTGTAGCCGCCTCCTCCGGTCATTTTCTGTTGATCCCGAAAAATGCTGCGGGCAGTAAGAGTGATGGTACGCCGTTGCAGGCTTATTCTTCACTCATTGGCAACTGTCTGATTGCCGTGCCGCTACTTCTGACCGTCTTTGGTTTTATATGGTCCGTTACTTTACTGCGAAGTGCTAATATCACACCACATTACGTTGCAGGCCATGTCCTATTGGGATTAACGGCAATTTGTGCCTGTCTCATTGGACTGGTTGCCACTATTGTTCATCAAACACGTAATACCTTCTCGGAAAAAGAGCATTGGTTGTGGTGCTATTGGGTTATTTTACTTGGCACACTGACGGTTATTCAGGGGATCTACGTTTTAGTCAGTTCTGATGAAAGTGCCAGACTGGCTCCCGGTATTATTCTTATTTGTCTGGGAATGATCTGCTACAGTATTTTCTCCAAAGTATGGTTATTGGCGCTGGTATGGCGACGCACATGCGCTTTAGCCAATAGAATACCCATGATTCCGGTATTTACCTGTCTGTTTTGCCTGTTCCTGGCTGCATTCCTTGCTGAAGTGGCGCAAGTCGATATGGCTTATTTTATTCCTTCGCGAGTACTGGTCGGCTTAGGTGCGGTATGTTTCACCCTGTTCTCTATTGTTTCGATATTAGAAGCAGGTTCTGCAAAAAAATAA",
    "translation": "MNIYIGWLFKLIPLVMGIICIALGDFVLSGSGQSEYFVAGHVLISLSAICLALFTTAFIIISQLTHGVNKLYNTLFPVIGYAGSVATMIWGWSLLASDNVMADEFVAGHVIFGVGMIAACVSTVAASSGHFLLIPKNAAGSKSDGTPLQAYSSLIGNCLIAVPLLLTVFGFIWSVTLLRSANITPHYVAGHVLLGLTAICACLIGLVATIVHQTRNTFSEKEHWLWCYWVILLGTLTVIQGIYVLVSSDESARLAPGIILICLGMICYSIFSKVWLLALVWRRTCALANRIPMIPVFTCLFCLFLAAFLAEVAQVDMAYFIPSRVLVGLGAVCFTLFSIVSILEAGSAKK",
    "product": ""
   },
   {
    "start": 3931924,
    "end": 3932991,
    "strand": 1,
    "locus_tag": "ctg1_3630",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3630</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3630</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,931,924 - 3,932,991,\n (total: 1068 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1029:RND family efflux transporter MFP subunit (Score: 146.4; E-value: 1.8e-44)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3630\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3630\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3630_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMDKSKRHLAWWVVGLLAVAAVVAWWLLRPAGVPEGFAVSNGRIEATEVDIASKIAGRIDTILVKEGQFVREGEVLAKMDTRVLQEQRLEAIAQIKEAQSAVAAAQALLEQRQSETRAAQSLVNQRQAELDSVAKRHTRSRSLAHRGAISAQQLDDDRAAAESARAALESAKAQVSASKAAIEAARTNIIQAQTRVEAAQATERRIAADIDDSELKAPRDGRVQYRVAEPGEVLAAGGRVLNMVDLSDVYMTFFLPTEQAGTLKLGGEARLILDAAPDLRIPATISFVASVAQFTPKTVETSDERLKLMFRVKARIPPELLQQHLEYVKTGLPGVAWVRVNEELPWPDDLAVRLPQ\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3630\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3630\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGATAAGAGTAAGCGCCATCTGGCGTGGTGGGTTGTCGGGTTACTGGCGGTGGCTGCTGTCGTGGCGTGGTGGCTGTTGCGCCCGGCGGGTGTGCCGGAAGGCTTTGCCGTCAGCAATGGGCGTATTGAAGCGACGGAAGTGGATATCGCCAGCAAAATTGCCGGGCGTATCGACACCATTCTGGTGAAAGAAGGCCAGTTTGTTCGTGAAGGTGAAGTATTGGCGAAGATGGATACTCGCGTGTTGCAGGAACAGCGACTGGAAGCTATCGCGCAAATCAAAGAGGCACAAAGTGCCGTTGCCGCCGCGCAGGCTTTGCTGGAGCAACGGCAAAGTGAAACTCGTGCCGCGCAGTCACTGGTTAATCAACGCCAGGCCGAACTGGACTCTGTGGCCAAACGTCATACGCGCTCTCGCTCACTGGCCCATCGAGGGGCTATTTCTGCGCAACAGCTGGACGACGACCGTGCCGCCGCCGAAAGCGCCCGTGCTGCGCTGGAATCGGCAAAAGCCCAGGTTTCGGCTTCTAAAGCGGCTATAGAAGCGGCACGTACCAATATCATTCAGGCGCAAACGCGCGTCGAAGCCGCGCAAGCCACTGAACGGCGCATTGCCGCAGATATCGATGACAGCGAACTGAAAGCCCCGCGTGACGGACGCGTGCAGTATCGGGTTGCCGAGCCAGGGGAAGTGCTGGCGGCAGGCGGTCGGGTGCTGAATATGGTCGATCTCAGCGACGTCTATATGACCTTCTTCCTGCCAACCGAACAGGCGGGTACGCTGAAACTGGGCGGCGAAGCCCGGCTGATCCTCGATGCCGCGCCAGATCTGCGTATTCCGGCGACCATCAGCTTTGTCGCCAGCGTCGCCCAGTTCACACCAAAAACCGTCGAAACCAGCGATGAGCGGCTGAAACTGATGTTCCGCGTCAAAGCGCGTATCCCACCGGAATTACTCCAGCAGCATCTGGAATATGTCAAAACCGGTTTGCCGGGCGTGGCGTGGGTGCGGGTGAATGAAGAACTTCCGTGGCCTGACGACCTTGCGGTGAGGTTGCCGCAATGA",
    "translation": "MDKSKRHLAWWVVGLLAVAAVVAWWLLRPAGVPEGFAVSNGRIEATEVDIASKIAGRIDTILVKEGQFVREGEVLAKMDTRVLQEQRLEAIAQIKEAQSAVAAAQALLEQRQSETRAAQSLVNQRQAELDSVAKRHTRSRSLAHRGAISAQQLDDDRAAAESARAALESAKAQVSASKAAIEAARTNIIQAQTRVEAAQATERRIAADIDDSELKAPRDGRVQYRVAEPGEVLAAGGRVLNMVDLSDVYMTFFLPTEQAGTLKLGGEARLILDAAPDLRIPATISFVASVAQFTPKTVETSDERLKLMFRVKARIPPELLQQHLEYVKTGLPGVAWVRVNEELPWPDDLAVRLPQ",
    "product": ""
   },
   {
    "start": 3932988,
    "end": 3935723,
    "strand": 1,
    "locus_tag": "ctg1_3631",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3631</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3631</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,932,988 - 3,935,723,\n (total: 2736 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 191.6; E-value: 2.7e-58)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3631\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3631\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3631_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMTHLELVPVPPVAQLAGVSQHYGKTVALNNITLDIPARCMVGLIGPDGVGKSSLLSLISGARVIEQGNVIVLGGDMRDPRHRRDVCPRIAWMPQGLGKNLYHTLSVYENVDFFARLFGHDKAEREVRINELLTSTGLAPFRDRPAGKLSGGMKQKLGLCCALIHDPELLILDEPTTGVDPLSRAQFWDLIDSIRQRQSNMSVLVATAYMEEAERFDWLVAMNAGEVLATGSAEELRQQTQSATLEEAFINLLPQAQRQAHQAVVIPPYQSEKADIAIEARDLTMRFGSFVAVDHVNFRIPRGEIFGFLGSNGCGKSTTMKMLTGLLPASEGEAWLFGQPVDPKDIDTRRRVGYMSQAFSLYNELTVRQNLELHARLFHIPEAEIPARVAEMSERFKLNDVEDVLPESLPLGIRQRLSLAVAVIHRPEMLILDEPTSGVDPVARDMFWQLMVDLSRQDKVTIFISTHFMNEAERCDRISLMHAGKVLASGTPQELVEKRGAASLEEAFIAYLQEAAGQSNEAEAPPVVHDTTHAPRQGFSLRRLFSYSRREALELRRDPVRSTLALMGTVILMLIMGYGISMDVENLRFAVLDRDQTVSSQAWTLNLSGSRYFIEQPPLTSYDELDRRMRAGDITVAIEIPPNFGRDIARGTPVELGVWIDGAMPSRAETVKGYVQAMHQSWLQDVASRQSTPASQSGLMNIETRYRYNPDVKSLPAIVPAVIPLLLMMIPSMLSALSVVREKELGSIINLYVTPTTRSEFLLGKQLPYIGLGMLNFFLLCALSVFVFGVPHKGSFLTLTLAALLYIIIATGMGLLISTFMKSQIAAIFGTAIITLIPATQFSGMIDPVASLEGPGRWIGEVYPTSHFLTIARGTFSKALDLTDLWQLFIPLLIAIPLVMGLSILLLKKQEG\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3631\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3631\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGCATCTGGAACTGGTTCCCGTCCCGCCTGTCGCGCAACTGGCGGGCGTGAGCCAGCATTATGGAAAAACTGTTGCGCTGAACAATATCACTCTCGATATTCCGGCCCGCTGCATGGTTGGGCTGATTGGCCCGGACGGCGTCGGGAAGTCGAGTTTGTTGTCACTGATTTCCGGTGCCCGCGTCATTGAGCAGGGCAACGTGATCGTGCTGGGCGGCGATATGCGCGACCCGAGGCATCGCCGTGACGTCTGCCCGCGCATTGCCTGGATGCCGCAGGGACTGGGCAAAAACCTCTACCACACCTTGTCGGTGTATGAAAACGTCGATTTTTTCGCCCGCCTGTTCGGTCACGACAAAGCAGAGCGGGAAGTACGAATTAATGAACTGCTGACCAGCACCGGTTTAGCACCGTTTCGCGATCGTCCGGCAGGGAAACTCTCCGGCGGGATGAAGCAAAAACTGGGGCTGTGCTGTGCGTTAATCCACGACCCGGAACTGTTGATTCTTGATGAGCCTACGACGGGGGTTGACCCGCTCTCCCGCGCCCAGTTCTGGGATCTGATCGATAGCATTCGCCAGCGGCAGAGCAATATGAGCGTGCTGGTTGCCACCGCCTATATGGAAGAGGCGGAACGCTTCGACTGGCTGGTAGCGATGAATGCCGGAGAAGTGCTGGCGACTGGCAGCGCCGAAGAACTGCGGCAGCAAACGCAAAGCGCCACGCTGGAAGAAGCATTTATAAATCTGTTACCGCAAGCGCAACGCCAGGCGCATCAGGCGGTAGTGATCCCACCGTATCAATCTGAAAAAGCAGACATTGCCATCGAAGCACGCGATCTGACCATGCGTTTTGGTTCCTTCGTTGCCGTTGATCACGTCAATTTCCGCATTCCACGTGGGGAGATTTTTGGATTCCTTGGTTCGAACGGCTGCGGTAAATCCACCACCATGAAAATGCTTACTGGACTGCTGCCTGCCAGCGAAGGTGAGGCGTGGCTGTTCGGGCAACCGGTTGATCCAAAAGATATCGATACCCGCCGTCGGGTGGGCTATATGTCGCAGGCGTTTTCGCTCTATAACGAGCTCACCGTGCGGCAAAACCTGGAGTTACATGCCCGTTTGTTTCACATCCCGGAAGCGGAAATTCCCGCGCGAGTGGCTGAAATGAGCGAGCGTTTTAAGCTCAACGACGTTGAGGATGTTCTGCCGGAGTCATTGCCGCTCGGCATTCGCCAGCGGCTTTCGCTGGCGGTGGCGGTGATTCATCGCCCGGAAATGTTAATCCTCGATGAGCCTACTTCTGGCGTCGATCCAGTGGCGAGGGATATGTTCTGGCAGTTAATGGTGGATCTTTCGCGCCAGGACAAAGTGACCATTTTCATCTCCACCCACTTTATGAACGAAGCGGAACGCTGCGACCGCATCTCACTGATGCACGCCGGAAAAGTGCTCGCCAGCGGTACACCGCAGGAACTGGTTGAGAAACGCGGAGCCGCCAGCCTGGAAGAGGCTTTTATCGCCTATTTGCAGGAAGCGGCAGGGCAGAGCAACGAAGCCGAAGCGCCGCCTGTGGTACATGATACCACCCACGCGCCGCGTCAGGGATTTAGCCTGCGACGTCTGTTTAGCTACAGCCGTCGCGAAGCACTGGAACTGCGCCGCGATCCGGTACGTTCGACGCTGGCGCTGATGGGAACGGTGATCCTGATGCTGATAATGGGTTACGGCATCAGTATGGATGTGGAAAACCTGCGCTTTGCGGTGCTTGATCGCGACCAGACCGTCAGTAGCCAGGCGTGGACGCTCAATCTCTCCGGTTCCCGTTACTTTATCGAGCAGCCGCCGCTCACCAGTTATGACGAGCTTGATCGCCGGATGCGTGCGGGCGATATCACCGTGGCGATTGAGATTCCACCCAATTTCGGGCGCGATATCGCGCGTGGTACGCCTGTGGAACTCGGTGTCTGGATCGACGGTGCGATGCCGAGTCGCGCCGAAACGGTAAAAGGTTACGTGCAGGCCATGCACCAGAGCTGGTTACAGGATGTGGCGAGTCGGCAATCCACGCCCGCGAGCCAAAGCGGGCTGATGAATATTGAGACACGCTATCGCTATAACCCGGACGTAAAAAGCCTGCCAGCGATTGTTCCGGCGGTGATCCCACTGTTGCTGATGATGATTCCGTCGATGTTAAGCGCCCTTAGCGTGGTACGGGAAAAAGAGTTGGGGTCGATTATCAACCTTTACGTTACCCCCACCACCCGCAGCGAATTTTTACTTGGCAAACAGCTACCGTACATCGGGCTGGGAATGCTGAACTTTTTCCTGCTCTGCGCCCTGTCGGTGTTTGTGTTTGGCGTGCCGCATAAAGGCAGTTTCCTGACGCTCACCCTGGCGGCGTTGCTGTATATCATCATTGCCACCGGAATGGGGCTGCTGATCTCTACTTTTATGAAAAGCCAGATTGCCGCCATTTTCGGTACGGCGATTATCACGTTGATTCCGGCGACGCAGTTTTCCGGGATGATCGATCCGGTAGCTTCGCTGGAAGGTCCAGGACGTTGGATCGGCGAGGTTTACCCGACCAGTCATTTTCTGACTATCGCCCGCGGAACGTTCTCGAAAGCGCTGGATCTGACGGATTTATGGCAACTTTTTATCCCGTTGCTGATAGCCATTCCACTGGTGATGGGCTTAAGCATCCTGCTGCTGAAAAAACAGGAGGGATGA",
    "translation": "MTHLELVPVPPVAQLAGVSQHYGKTVALNNITLDIPARCMVGLIGPDGVGKSSLLSLISGARVIEQGNVIVLGGDMRDPRHRRDVCPRIAWMPQGLGKNLYHTLSVYENVDFFARLFGHDKAEREVRINELLTSTGLAPFRDRPAGKLSGGMKQKLGLCCALIHDPELLILDEPTTGVDPLSRAQFWDLIDSIRQRQSNMSVLVATAYMEEAERFDWLVAMNAGEVLATGSAEELRQQTQSATLEEAFINLLPQAQRQAHQAVVIPPYQSEKADIAIEARDLTMRFGSFVAVDHVNFRIPRGEIFGFLGSNGCGKSTTMKMLTGLLPASEGEAWLFGQPVDPKDIDTRRRVGYMSQAFSLYNELTVRQNLELHARLFHIPEAEIPARVAEMSERFKLNDVEDVLPESLPLGIRQRLSLAVAVIHRPEMLILDEPTSGVDPVARDMFWQLMVDLSRQDKVTIFISTHFMNEAERCDRISLMHAGKVLASGTPQELVEKRGAASLEEAFIAYLQEAAGQSNEAEAPPVVHDTTHAPRQGFSLRRLFSYSRREALELRRDPVRSTLALMGTVILMLIMGYGISMDVENLRFAVLDRDQTVSSQAWTLNLSGSRYFIEQPPLTSYDELDRRMRAGDITVAIEIPPNFGRDIARGTPVELGVWIDGAMPSRAETVKGYVQAMHQSWLQDVASRQSTPASQSGLMNIETRYRYNPDVKSLPAIVPAVIPLLLMMIPSMLSALSVVREKELGSIINLYVTPTTRSEFLLGKQLPYIGLGMLNFFLLCALSVFVFGVPHKGSFLTLTLAALLYIIIATGMGLLISTFMKSQIAAIFGTAIITLIPATQFSGMIDPVASLEGPGRWIGEVYPTSHFLTIARGTFSKALDLTDLWQLFIPLLIAIPLVMGLSILLLKKQEG",
    "product": ""
   },
   {
    "start": 3935723,
    "end": 3936847,
    "strand": 1,
    "locus_tag": "ctg1_3632",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3632</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3632</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,935,723 - 3,936,847,\n (total: 1125 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1065:ABC-2 type transporter (Score: 60; E-value: 3.4e-18)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3632\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3632\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMRHLRNIFNLGIKELRSLLGDKAMLTLIIFSFTVSVYSSATVTPGSLNLAPIAIADMDQSQLSNRIVNSFYRPWFLPPEMITADEMDAGLDAGRYTFAINIPPNFQRDVLAGRQPDIQVNVDATRMSQAFTGNGYIQNIINGEVNSFVARYRDNSEPLVSLETRMRFNPNLDPAWFGGVMAIINNITMLAIVLTGSALIREREHGTVEHLLVMPIKPFEIMMAKVWSMGLVVLVVSGLSLVLMVKGVLGVPIEGSIPLFMLGVALSLFATTSIGIFMGTIARSMPQLGLLVILVLLPLQMLSGGSTPRESMPQMVQDIMLTMPTTHFVSLAQAILYRGAGFEIVWPQFLTLMAIGGAFFTIALLRFRKTIGTMA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3632\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3632\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGCCATTTACGCAATATTTTTAATCTGGGTATCAAAGAGTTGCGCAGTCTGCTTGGTGATAAAGCGATGCTGACGCTGATTATTTTCTCGTTTACGGTGTCGGTTTATTCATCAGCGACCGTCACGCCAGGATCGTTGAACCTGGCACCGATCGCTATTGCCGATATGGATCAATCGCAGTTATCGAACCGGATCGTTAACAGCTTCTACCGCCCGTGGTTTTTGCCCCCGGAGATGATCACCGCCGATGAGATGGATGCCGGGCTGGACGCCGGGCGCTATACCTTCGCGATAAATATTCCGCCTAATTTTCAGCGTGATGTCCTCGCAGGACGCCAGCCGGATATTCAGGTGAACGTCGATGCCACGCGCATGAGCCAGGCATTCACTGGCAACGGTTATATCCAGAATATTATCAACGGTGAAGTGAACAGCTTTGTCGCGCGCTACCGTGATAACAGCGAACCGTTGGTATCGCTGGAAACCCGCATGCGCTTTAATCCGAACCTCGATCCCGCGTGGTTTGGCGGGGTGATGGCGATCATCAACAACATTACCATGCTGGCGATTGTACTGACCGGATCGGCGCTGATCCGCGAGCGTGAACACGGCACGGTGGAACACTTACTGGTGATGCCGATAAAGCCGTTTGAGATCATGATGGCGAAGGTCTGGTCGATGGGGCTGGTGGTGCTGGTGGTATCGGGATTATCGCTGGTGCTGATGGTAAAAGGCGTGCTGGGCGTACCGATTGAAGGCTCGATCCCGCTGTTTATGCTTGGCGTGGCGCTCAGTCTGTTTGCCACCACGTCAATCGGCATTTTTATGGGGACGATAGCGCGTTCAATGCCGCAACTGGGGCTGCTTGTGATTCTGGTGCTGCTGCCGCTGCAAATGCTTTCCGGTGGCTCCACGCCGCGCGAAAGTATGCCGCAGATGGTGCAGGACATTATGCTGACCATGCCGACGACACACTTTGTTAGCCTTGCGCAGGCCATCCTCTACCGGGGTGCCGGATTCGAAATCGTCTGGCCGCAGTTCCTGACGTTGATGGCAATTGGCGGCGCGTTTTTCACCATCGCGTTGCTGCGATTCAGGAAGACGATTGGGACAATGGCGTAA",
    "translation": "MRHLRNIFNLGIKELRSLLGDKAMLTLIIFSFTVSVYSSATVTPGSLNLAPIAIADMDQSQLSNRIVNSFYRPWFLPPEMITADEMDAGLDAGRYTFAINIPPNFQRDVLAGRQPDIQVNVDATRMSQAFTGNGYIQNIINGEVNSFVARYRDNSEPLVSLETRMRFNPNLDPAWFGGVMAIINNITMLAIVLTGSALIREREHGTVEHLLVMPIKPFEIMMAKVWSMGLVVLVVSGLSLVLMVKGVLGVPIEGSIPLFMLGVALSLFATTSIGIFMGTIARSMPQLGLLVILVLLPLQMLSGGSTPRESMPQMVQDIMLTMPTTHFVSLAQAILYRGAGFEIVWPQFLTLMAIGGAFFTIALLRFRKTIGTMA",
    "product": ""
   },
   {
    "start": 3936938,
    "end": 3937789,
    "strand": -1,
    "locus_tag": "ctg1_3633",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3633</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3633</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,936,938 - 3,937,789,\n (total: 852 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3633\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3633\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3633_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3633\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3633\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCATTAGTTAATGGACGGATACTGCTCGACCGCATTCAGGAAAAACGGGTATTAGCGGGCGCGTTTAATACCACCAATCTGGAGACGACGATTTCAATTTTAAACGCCATTGAGCGTTCAGGATTACCCAACTTCATTCAGATTGCGCCCACCAATGCACAACTCTCGGGATACGATTACATTTATGAAATCGTGAAACGTCACGCCGATAAAATGGATGTTCCGGTCAGTCTTCATCTGGATCACGGGAAAACTCAGGAGGATGTTAAACAGGCGGTGCGCGCGGGCTTTACCTCGGTCATGATTGACGGTGCCGCATTCTCTTTTGAAGAGAATATCGCTTTCACCCAGGAAGCTGTCGATTTCTGTAAATCCTATGGCGTACCGGTTGAAGCGGAGCTGGGGGCGATTCTCGGCAAAGAAGATGATCACGTCAGCGAAGCCGATTGCAAAACGGAACCGGAAAAGGTGAAGACCTTTGTCGAGCGCACCGGTTGCGACATGCTGGCAGTTTCTATTGGCAACGTTCATGGCCTGGACGATATACCGCGTATCGATATCCCCCTGCTGAAGCGCATTGCCGAAGTCTGCCCGGTGCCGCTGGTTATTCACGGCGGCTCCGGTATCGCCCCGGAGATATTGCGCAGCTTTGTTAATTATCGCGTCGCTAAAGTAAATATCGCCAGCGATCTGCGCAAAGCGTTTATCACCGCCGTCGGCAAAGCGTATGTGAATAATCACAACGAGGCGAATCTGGCACGAGTGATGGCATCAGCAAAAAACGCCGTCGAGGAAGATGTGTATAGCAAAATCCTGATGATGAATGAGGGTCATCGGTTGGTTAAATAA",
    "translation": "MPLVNGRILLDRIQEKRVLAGAFNTTNLETTISILNAIERSGLPNFIQIAPTNAQLSGYDYIYEIVKRHADKMDVPVSLHLDHGKTQEDVKQAVRAGFTSVMIDGAAFSFEENIAFTQEAVDFCKSYGVPVEAELGAILGKEDDHVSEADCKTEPEKVKTFVERTGCDMLAVSIGNVHGLDDIPRIDIPLLKRIAEVCPVPLVIHGGSGIAPEILRSFVNYRVAKVNIASDLRKAFITAVGKAYVNNHNEANLARVMASAKNAVEEDVYSKILMMNEGHRLVK",
    "product": ""
   },
   {
    "start": 3937820,
    "end": 3938089,
    "strand": -1,
    "locus_tag": "ctg1_3634",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3634</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3634</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,937,820 - 3,938,089,\n (total: 270 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3634\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3634\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3634\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3634\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTGAGTAAAACCGTGGAGGTCAGAAACAGTACTGGCCTGCATGCACGTCCGGCGGCTTGTCTGGTGAAAGCCGCCAAAAAGTTTAGCTGTAAAGTGACGCTGCATTATGAGGGTAATGATATTAATGCCACCAGCATGATGAATATTATGCGCGCCGGAATAAAAGGCGGCAAAACGGTGGAAATACGCTGCGAAGGCGATGATGAAAATGAGGCAATACAAACTCTCACCGCCTTATTTCGTGACCGCTTCGGTGAAGCTGAATAA",
    "translation": "MLSKTVEVRNSTGLHARPAACLVKAAKKFSCKVTLHYEGNDINATSMMNIMRAGIKGGKTVEIRCEGDDENEAIQTLTALFRDRFGEAE",
    "product": ""
   },
   {
    "start": 3938079,
    "end": 3939587,
    "strand": -1,
    "locus_tag": "ctg1_3635",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3635</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3635</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,938,079 - 3,939,587,\n (total: 1509 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1210:glycerol kinase (Score: 257.6; E-value: 3.2e-78)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3635\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3635\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3635\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3635\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCTGATAACAGCGCAGCTATCGTTATCGATATTGGCACCACCAATTGCAAAGTCACCTGCTTTTCCTGCCTGGACGCAACGACGTTGGGCGCGCATAAATTCGTGACGGCAAAACAGATCTCCCCACAGGGCGATGTCGATTTCGATATCGACGCCCTCTGGCAGGAGGTCCGCCAGGCGATAGCACAACTGAACGCCGCTTCGCCGCTGCCAGTCAGGCGGATCAGCATTGCCAGTTTTGGCGAGTCAGGCGTGTTTCTTGACGAGCATGGCGAGATCCTGACGCCAATGCTGGCATGGTATGACCGTCGCGGTGAAGAGTTTCTGGCTACACTTAGCGAGGCAGACAGTGCGGCACTTTATGACATTTGCGGATTACCGCTGCACAGCAATTACTCTGCCTTCAAAATGCGTTGGTTGCTGGAACATTACCCACTGCGTAATCGCCGCGGCCTGCACTGGCTACATGCGCCGGAAGTACTGCTCTGGCGGCTGACCGGCGAACAGCGCACGGATATCACCTTAGCCAGCCGCACGCTGTGTCTGGACGTGCGCAAAGGCGAATGGTCAGCGAAAGCGGCGGCGTTGTTACACGTTCCCTGTTCGGCATTTGCGCCATTGGTGCAGCCAGGCGAACACGCCGGATGGGTCAGCGAGTCGCTCTGCAAAACGCTTGGGTTCTCGCAACCGGTCAGCGTGACGCTGGCCGGACATGACCATATGGTGGGTGCACGGGCGTTGCAGATGATGCCGGGCGATATCCTTAACTCGACGGGGACCACAGAAGGCATTCTGCAACTGGATACACAACCGACGCTGGATGAACAGGCCAAACGTGACAAGCTGGCAAACGGCTGTTATTCGCTTGCAAACCAGTTCACCCTGTTTGCGTCGCTGCCCGTGGGCGGTTTCGCTCTGGAGTGGCTGCGTAACACGTTCCGGCTAACCGATGAGGAGATCGCCGCATCACTTACTCGCGGACATGCGGATTACCTGGCGGGGAACTGGTCGCTCGATGACATTCCCCTCTTTATTCCACATCTTCGCGGTTCGGGTTCGCCCTATAAAAATCGCCATACCCGTGGATTATTTTATGGGCTTAGCGATACGTTAAATATTGACATGTTAATTGCCAGCGTCTCACTGGGATTAACCATGGAATTTGCCAACTGCTTCGCCTGTTTTAATGTGCCTGGCACCAGCGCGTTAAAAGTAATCGGCCCGGCAACCCATAATCCCCTTTGGCTGCAATTAAAGGCGGATATTTTACAGCGTCCGGTTGAGGCAATTGCATTTAACGAGGCGGTTTCTGTCGGAGCATTATTAACTGCCGCACCGGATATTCCACCGCCGCAAGTTACCATAGCCCAACGTTTGTTACCGAATCGGGCGAGATACCATCAATTACAGCGTTATCAGCACAAATGGAAAAGCTGGTATCAGTTGAAATTACAGCAAGAAGGCGTGATGCCATTACACCATCGGGAGGAGCACTATGTTGAGTAA",
    "translation": "MPDNSAAIVIDIGTTNCKVTCFSCLDATTLGAHKFVTAKQISPQGDVDFDIDALWQEVRQAIAQLNAASPLPVRRISIASFGESGVFLDEHGEILTPMLAWYDRRGEEFLATLSEADSAALYDICGLPLHSNYSAFKMRWLLEHYPLRNRRGLHWLHAPEVLLWRLTGEQRTDITLASRTLCLDVRKGEWSAKAAALLHVPCSAFAPLVQPGEHAGWVSESLCKTLGFSQPVSVTLAGHDHMVGARALQMMPGDILNSTGTTEGILQLDTQPTLDEQAKRDKLANGCYSLANQFTLFASLPVGGFALEWLRNTFRLTDEEIAASLTRGHADYLAGNWSLDDIPLFIPHLRGSGSPYKNRHTRGLFYGLSDTLNIDMLIASVSLGLTMEFANCFACFNVPGTSALKVIGPATHNPLWLQLKADILQRPVEAIAFNEAVSVGALLTAAPDIPPPQVTIAQRLLPNRARYHQLQRYQHKWKSWYQLKLQQEGVMPLHHREEHYVE",
    "product": ""
   },
   {
    "start": 3939580,
    "end": 3940938,
    "strand": -1,
    "locus_tag": "ctg1_3636",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3636</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3636</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,939,580 - 3,940,938,\n (total: 1359 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3636\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3636\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3636\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3636\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACGATATCGCGCATACCCTCTATAATATTGTGCAATATATATTGGGATTTGGCCCGACGGTAATGTTGCCGTTGGTGTTATTTATTCTTGCTCTCTGTTTTAAAGTAAAACCCGCTAAAGCCTTACGTTCGTCATTAACAGTCGGCATTGGTTTTGTCGGTATTTATGCCATTTTCGATATTCTTACCAGCAATGTCGGGCCTGCGGCCCAGGCGATGGTTGAACGCACCGGAATTAATTTACCGGTGGTGGATTTAGGCTGGCCGCCGCTTTCCGCTATTACATGGGGTTCCCCAATTGCCCCATTTGTTATTCCCCTGACCATTCTGATTAACGTGGCGATGCTGGCGTTAAATAAAACCCGCACCGTTGACGTAGATATGTGGAACTACTGGCATTTTGCCCTTGCTGGTACGCTGGTTTATTACAGCACCGGCAGCCTGTTCTTTGGTTTGCTGGCGGCGGCGATTGCCGCAGTGGTGGTGCTAAAACTCGCCGACTGGTCTGCGCCACTGGTACAAAAATACTTTGGCCTGGAAGGGATCTCATTGCCGACGCTCTCTTCGGTGGTGTTCTTCCCGGTCGGTCTGCTGGTCGACAAAATCATCGACCATATCCCTGGCCTCAATCGTATTCATATCGACCCGGAAACCGTACAGAAAAAGTTTGGCATCTTCGGCGAACCGATGATGGTTGGCACTATTCTGGGCATTCTGCTCGGCGTAATTGCCGGATACGATTTCAAAAAAGTCTTGCTGCTTGGCATCAGCATTGGCGGTGTGATGTTCATCCTGCCACGCATGGTACGCATTCTGATGGAAGGTTTATTACCGCTGTCTGAAGCCATTAAAAAGTATCTCAATGCCAAATACCCTGACCGTGACGATCTCTATATCGGCCTGGATATCGCCGTTGCCGTAGGTAACCCGGCGATTATCTCCACCGCCCTGCTGCTGACGCCAATCTCGGTCTTTATCGCGTTTGTCCTTCCGGGTAATGAAGTCCTGCCGCTTGGCGACCTTGCCAACCTGGCGGTAATGGCGTCGATGATCGCTTTAGCCAGCCGTGGCAATATTTTCCGCACCGTTCTGGCGGCGATTCCGGTGATTATTGCCGACCTGTGGATTGCTACCAAAATCGCGCCGTTTATTACCGGAATGGCGAAAGACGTTAACTTCAAATTTGCCGAAGGCTCCAGCGGCCAGGTTTCCAGTTTCCTTGATGGCGGTAACCCGTTCCGCTTCTGGCTGCTGGAAATCTTCAACGGCAATCTCATCGCCATTGGTCTGGTGCCGGTTATCGCCCTGGTACTGTATGGCATTTTCCGAATGACGCGGAGCACGGTTTATGCCTGA",
    "translation": "MNDIAHTLYNIVQYILGFGPTVMLPLVLFILALCFKVKPAKALRSSLTVGIGFVGIYAIFDILTSNVGPAAQAMVERTGINLPVVDLGWPPLSAITWGSPIAPFVIPLTILINVAMLALNKTRTVDVDMWNYWHFALAGTLVYYSTGSLFFGLLAAAIAAVVVLKLADWSAPLVQKYFGLEGISLPTLSSVVFFPVGLLVDKIIDHIPGLNRIHIDPETVQKKFGIFGEPMMVGTILGILLGVIAGYDFKKVLLLGISIGGVMFILPRMVRILMEGLLPLSEAIKKYLNAKYPDRDDLYIGLDIAVAVGNPAIISTALLLTPISVFIAFVLPGNEVLPLGDLANLAVMASMIALASRGNIFRTVLAAIPVIIADLWIATKIAPFITGMAKDVNFKFAEGSSGQVSSFLDGGNPFRFWLLEIFNGNLIAIGLVPVIALVLYGIFRMTRSTVYA",
    "product": ""
   },
   {
    "start": 3941015,
    "end": 3941296,
    "strand": -1,
    "locus_tag": "ctg1_3637",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3637</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3637</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,941,015 - 3,941,296,\n (total: 282 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3637\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3637\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3637\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3637\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTCAAACCATTTTATTTGTCTGCGCCACGGGTATTGCCACATCCACGGCGGTAACAGAAAAAGTCATGGAATATTGTAAAGAGCACGGTCTTAACGTCAATTATTCCCAAACCAACGTTGCCTCTTTACCTGGAAATACTGACGGCGTAGCACTGGTAGTCTCAACGACTAAAGTGCCTTATGAACTCGACGTCCCGGTGGTTAACGGCTTGCCGATTATTACCGGTATTGGCGAAGAGAAAGTACTGGCGCAAATTGTTTCGATCCTTAAAAAGTAA",
    "translation": "MSQTILFVCATGIATSTAVTEKVMEYCKEHGLNVNYSQTNVASLPGNTDGVALVVSTTKVPYELDVPVVNGLPIITGIGEEKVLAQIVSILKK",
    "product": ""
   },
   {
    "start": 3941293,
    "end": 3941766,
    "strand": -1,
    "locus_tag": "ctg1_3638",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3638</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3638</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,941,293 - 3,941,766,\n (total: 474 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3638\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3638\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3638\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3638\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAAGGCATACAGTTTCAGGAAAATTATATTCAACGACTTCCGGCAGGGTTAAGCGTTGAACAGATCATCCGTCAGTTAGCGCAACCGTTGGTTGCCGCCGAGCTGGTGGTCCCTGATTTTGCCGATCACGTACTGGAACGTGAGGCGACGTACCCAACGGGGCTGCCTACCGAACCACCGTGCGTCGCCATTCCGCACACGGACCATAAACATGTCCGGCACAATGCAATTGCCGTCGGTATTTTGCCAGAGCCGGTAGAGTTTGCCGATATGGGCGGCGACCCTGATCCCGTGCCTGTCAGGGTGATTTTTTTGCTCGCCTTAAGCGAAAGTAACAAACAATTAAATGCCCTGGGCTGGATTATGGAGATGATTCAGGATACGCCCTTTATGCGCGCCCTGCTTACGATGGAAACAACAGAAATACACACAGTAATCTTAAACAAAATGAAAGAACGAGGTGAAATATGA",
    "translation": "MQGIQFQENYIQRLPAGLSVEQIIRQLAQPLVAAELVVPDFADHVLEREATYPTGLPTEPPCVAIPHTDHKHVRHNAIAVGILPEPVEFADMGGDPDPVPVRVIFLLALSESNKQLNALGWIMEMIQDTPFMRALLTMETTEIHTVILNKMKERGEI",
    "product": ""
   },
   {
    "start": 3941791,
    "end": 3942537,
    "strand": -1,
    "locus_tag": "ctg1_3639",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3639</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3639</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,941,791 - 3,942,537,\n (total: 747 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1136:GntR family transcriptional regulator (Score: 163.3; E-value: 1.2e-49)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3639\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3639\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3639_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3639\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3639\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAATCATTAAGTAAGTCGTCACAAATACCGCTCTATCAACAAGTGGTGGAGTGGATAAGAGAAAGTATTTATACCGGGGATCTGGTGGAAGACGATCGCATTCCTTCGGAATACCAGATTATGGATATGCTGGAAGTGAGTCGGGGAACCGTTAAAAAAGCAGTCGCCCAACTGGTAAAAGAAGGCGTGTTGATACAGGTCCAGGGGAAGGGAACATTTGTCAAAAAAGAGAACGTGGCATATCCGTTAGGTGAAGGATTATTGTCATTCGCGGAATCGCTGGAAAGCCAGAAAATACATTTTACCACTGAAGTTATTACGTCACGGATTGAACCGGCTAATCGTTATGTGGCAGAGAAATTAAGAATAACGCCCGGTCAGGATATTCTTTACCTTGAACGTTTACGTTCGATTGGTGATGAAAAAGCGATGCTGATAGAGAACCGTATCAATATTGAGCTATGCCCCGGCATCGTGGAAATCGATTTTAATCAACACAATTTATTTCCAACAATAGAAAGTTTGTCGCAAAGAAAAATTCGTTACTCGGAAAGTCGCTATGCCGCGCGATTAATTGGTAATGAACGCGGTCATTTTTTAGATATCAGTGAAGATGCACCCGTTTTGCATCTGGAGCAGTTAGTCTTTTTCTCCCGAGAGTTACCCGTTGAGTTTGGCAACGTCTGGTTAAAAGGCAATAAATATTATCTTGGCACCGTGCTGCAACGGCGGGAAGTGAGTTAA",
    "translation": "MKSLSKSSQIPLYQQVVEWIRESIYTGDLVEDDRIPSEYQIMDMLEVSRGTVKKAVAQLVKEGVLIQVQGKGTFVKKENVAYPLGEGLLSFAESLESQKIHFTTEVITSRIEPANRYVAEKLRITPGQDILYLERLRSIGDEKAMLIENRINIELCPGIVEIDFNQHNLFPTIESLSQRKIRYSESRYAARLIGNERGHFLDISEDAPVLHLEQLVFFSRELPVEFGNVWLKGNKYYLGTVLQRREVS",
    "product": ""
   },
   {
    "start": 3942886,
    "end": 3943752,
    "strand": -1,
    "locus_tag": "ctg1_3640",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3640</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3640</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,942,886 - 3,943,752,\n (total: 867 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3640\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3640\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3640\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3640\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAAATAATCGATAAAAATAAAAAAAGAAGAGAGAACAGAGAAACTTTTTTGTATGCAAAATATAAAGCCTATACCCTTAATCAACTGATTCCTCTTTTATTTAAAAAAAATAGTCTTACACGGCAGGCTGCCATTTTTCGATTACAAATAATTGGAACAGATGAGGTTTTTACCTTTGCTGTTAATCTTTGTCAGTCAGAAGGTAAACAGGAAAGAAAGACAGGAATATCCATTCTAAGTCAACTTTCGATGTCTCCCGAGCACCTGACTCAATCTTTTAATTTAGTCGAAGCGTTATTAGAAAAGGAAACGTCCGCTAACGTAAGAGCTGCTGCGGTTAATGCAATAGGCCATTTTTGCAGAAGAAACCCATCATTCAACAGCCGGGCACCAGAACTACTGACTCGAACAACATATGATAAATCGGTCAATACACGTTGCGCGACTGCGGCAGCGCTATCTGAAATAAATAACATAAAAGCCATTCCGCTGCTCTTATCGTTACTTAACGACAGCAACGGAGATGTGAGAAATTGGGCTGCATTCTCTGTTAATACAAACGAATATGATTCGAAAGAGATACGAGAGGCATTCGTCAAAATGCTTTCAGATGATCATGAACATGCCAGGCTAGAGGCTATTTTTGGATTAGCTGAAAGAAAAGATAGTCGTGTGGTAAAAACAATAATTAATGAGTTAGAGAAAGATATAATTTTTGACGAACTTATTGTTGTCGCGGGAGATTTAGGGAGTAAAAGATTCCTTCCTGTTCTTAAAAAATTATTGTCTGAATTTAATGATGAAAAAACCATTGGGAAAATAAAAATAGCAATACAAAAAATTACAAGTCCCTATGAATTTTAA",
    "translation": "MEIIDKNKKRRENRETFLYAKYKAYTLNQLIPLLFKKNSLTRQAAIFRLQIIGTDEVFTFAVNLCQSEGKQERKTGISILSQLSMSPEHLTQSFNLVEALLEKETSANVRAAAVNAIGHFCRRNPSFNSRAPELLTRTTYDKSVNTRCATAAALSEINNIKAIPLLLSLLNDSNGDVRNWAAFSVNTNEYDSKEIREAFVKMLSDDHEHARLEAIFGLAERKDSRVVKTIINELEKDIIFDELIVVAGDLGSKRFLPVLKKLLSEFNDEKTIGKIKIAIQKITSPYEF",
    "product": ""
   },
   {
    "start": 3943856,
    "end": 3944257,
    "strand": -1,
    "locus_tag": "ctg1_3641",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3641</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3641</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,943,856 - 3,944,257,\n (total: 402 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3641\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3641\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3641\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3641\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAACGTGTCACCATTACTCTCGATGACGATTTACTGGAAACGCTGGATAACCTGAGTCAGCGCCGTGGTTACAACAACCGCTCGGAAGCCATCCGCGATATTTTGCGCGGCGCCCTGGCGCAAGAAAGCACTCAACAGCACGGTACTGAGGGTTTTGCGGTTCTCTCTTATGTGTATGAGCATGAGAAGCGTGATTTAGCCAGCCGTATCGTCTCGACCCAGCACCATCACCACGATCTCTCTGTTGCCACGCTGCATGTACATATCAATCACGACGATTGCCTGGAAATCGCCGTGCTGAAAGGTGACATGGGCGACGTACAACATTTTGCCGATGACGTTATTTCCCAGCGCGGCGTACGGCACGGGCATTTGCAGTGCTTACCGAAGGAAGATTGA",
    "translation": "MQRVTITLDDDLLETLDNLSQRRGYNNRSEAIRDILRGALAQESTQQHGTEGFAVLSYVYEHEKRDLASRIVSTQHHHHDLSVATLHVHINHDDCLEIAVLKGDMGDVQHFADDVISQRGVRHGHLQCLPKED",
    "product": ""
   },
   {
    "start": 3944297,
    "end": 3944881,
    "strand": -1,
    "locus_tag": "ctg1_3642",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3642</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3642</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,944,297 - 3,944,881,\n (total: 585 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1012:4&#39;-phosphopantetheinyl transferase (Score: 103.8; E-value: 1.3e-31)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3642\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3642\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3642_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3642\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3642\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTATCGAATCGTTCTGGGAAAAGTATCGACCTTAAGCGCAGCGGCACTGCCATCCGCGCTTATCGAGCAGGCACCGCAGGGTGCCCGCCGTGCACGCTGGCTTGCTGGCCGTGCACTGCTTTCCCATGCGCTTTCGCCACTGCCAGAAATTGTCTATGGCGAACAGGGCAAACCCGCCTTTTCCCCGGAGACTGCACTCTGGTTTAACCTCAGTCATAGCGGCGACGATATCGTGTTGTTGTTAAGCGATGAAGGCGAAGTCGGTTGCGATATCGAAGTCATCCGTCCGCGTGCACAATGGCGTTCGCTGGCGAATGCGGTGTTCAGCCAGGGCGAACATGAGGAACTGGAAGCAGAACATCCCGATCACCAACTCATGGCGTTCTGGCGTATCTGGACGCGAAAAGAAGCCATCGTTAAACAGCGTGGCGGCAGCGCCTGGCAAATTGTCAGCATCGACAGTACACAACAATCGGCGCTCTCAGTCAGCCATTGTCAGTTTGGTTCATTGATCCTCGCAGTCTGCACGCCCACACCATTTGCTCTTACTCATAACGTTCTACAGCAGGTAGAATCACTGTAA",
    "translation": "MYRIVLGKVSTLSAAALPSALIEQAPQGARRARWLAGRALLSHALSPLPEIVYGEQGKPAFSPETALWFNLSHSGDDIVLLLSDEGEVGCDIEVIRPRAQWRSLANAVFSQGEHEELEAEHPDHQLMAFWRIWTRKEAIVKQRGGSAWQIVSIDSTQQSALSVSHCQFGSLILAVCTPTPFALTHNVLQQVESL",
    "product": ""
   },
   {
    "start": 3944883,
    "end": 3946112,
    "strand": -1,
    "locus_tag": "ctg1_3643",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3643</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3643</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,944,883 - 3,946,112,\n (total: 1230 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) arylpolyene: APE_KS1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 295.9; E-value: 8.3e-90)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-ctg1_3643 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>PKS_KS</strong> (83..408)</dt>\n   <dd>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3643\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3643\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3643_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3643\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3643\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACACGTCGCGTAGTGATTACAGGAATGGGCGGCGTGACTGCCTTTGGTGAAAACTGGCAGGACGTTTCTGCACGCTTACTGGCGTATGAAAATGCGGTGCGCAAAATGCCGGAGTGGCAGGTCTATGATGGTCTGCATACCCTGCTTGGCGCGCCTGTTGATGATTTCACGCTGCCGGAGCACTACACCCGCAAGCGTATCCGTGCGATGGGCCGCGTGTCGCAAATGTCGACCCGTGCCAGCGAGCTGGCGTTAGAGCAGGCAGGGTTGATTGGCGATCCGATATTAACCAGCGGTGAAACGGGCATTGCGTACGGTTCATCGACCGGCAGTACCGGTCCGGTGAGCGAGTTCGCCACCATGCTGACGGAAAAGCACACCAATAACATCACTGGCACCACCTATGTGCAGATGATGCCGCACACCACCGCCGTTAATACCGGGCTATTTTTTGGCCTGCGCGGACGGGTGATCCCAACCTCCAGCGCCTGTACCTCCGGCAGCCAGGCGATCGGCTACGCGTGGGAAGCCATTCGTCACGGTTATCAAACGGTAATGGTTGCTGGTGGCGCCGAAGAGTTATGCCCTTCAGAAGCGGCGGTGTTTGATACGCTTTTCGCCACCAGCCAGCACAATGACGCGCCGAAAACCACGCCGTCGCCGTTCGATGAAAACCGCGACGGGCTGGTGATTGGCGAAGGCGCAGGCACGCTCATTCTCGAAGAACTGGAGCACGCCAAAGCGCGCGGCGCGACCATTTACGGTGAAATCGTTGGCTTTGCCACCAACTGCGACGCGGCACATATTACCCAGCCTCAGCGTGAGACCATGCAATATTGTATGGAAAAATCGTTAAAAATCGCCGGGTTAAGTGCAAGTGATATCGGCTATATTTCGGCGCATGGTACGGCGACTGATCGTGGTGATGTAGCAGAAAGCCAGGCGACGGTAGCAATTTATGGCGATAACGTACCGATCTCCTCGCTTAAAAGTTATTTTGGGCATACCCTTGGTGCCTGCGGAGCACTCGAAGCCTGGATGAGCTTACAAATGATGCGTGAAGGCTGGTTTGCGCCTACGCTAAATTTGAGCCAGCCAGATGCGAACTGCGGTGCGCTGGATTACATCATGGGTGAAGCCCGCAAGATTGATTGTGAGTTTTTGCAGAGTAACAACTTTGCCTTTGGTGGCATTAATACCTCCATCATCATAAAACGTTGGCCCTGA",
    "translation": "MTRRVVITGMGGVTAFGENWQDVSARLLAYENAVRKMPEWQVYDGLHTLLGAPVDDFTLPEHYTRKRIRAMGRVSQMSTRASELALEQAGLIGDPILTSGETGIAYGSSTGSTGPVSEFATMLTEKHTNNITGTTYVQMMPHTTAVNTGLFFGLRGRVIPTSSACTSGSQAIGYAWEAIRHGYQTVMVAGGAEELCPSEAAVFDTLFATSQHNDAPKTTPSPFDENRDGLVIGEGAGTLILEELEHAKARGATIYGEIVGFATNCDAAHITQPQRETMQYCMEKSLKIAGLSASDIGYISAHGTATDRGDVAESQATVAIYGDNVPISSLKSYFGHTLGACGALEAWMSLQMMREGWFAPTLNLSQPDANCGALDYIMGEARKIDCEFLQSNNFAFGGINTSIIIKRWP",
    "product": ""
   },
   {
    "start": 3946109,
    "end": 3946840,
    "strand": -1,
    "locus_tag": "ctg1_3644",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3644</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3644</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,946,109 - 3,946,840,\n (total: 732 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 214.2; E-value: 3.4e-65)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3644\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3644\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3644_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3644\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3644\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTCGTTCAGTTCTGGTTACTGGTGCCAGCAAAGGCATTGGTCGCGCCATCGCCTGCCAACTGGCGGCAGACGGCTTTAATATTGGCGTTCACTATCACCGTGACGCCGCAGGCGCTCAGGAAACGCTGAATACCATTGTCGCCAACGGTGGTAACGGGCGTTTGCTCAGTTTCGACGTCGCAAACCGCGAACAGTGTCGGGAAGTGCTGGAGCACGAGATCGCGCAACACGGTGCCTGGTACGGCGTGGTTAGTAACGCCGGGATCGCCCGCGATGCCGCTTTTCCGGCTTTAAGCGATGACGACTGGGATGCGGTGATCCACACCAACCTCGACAGTTTCTACAACGTCATTCAGCCGTGCATTATGCCGATGATCGGCGCACGCCAGGGTGGACGCATCATCACGCTGTCCTCGGTTTCCGGCGTAATGGGCAATCGCGGCCAGGTGAACTACAGCGCTGCCAAAGCCGGAATTATCGGCGCAACAAAAGCACTGGCTATCGAACTCGCGAAGCGCAAAATCACCGTCAACTGCATCGCGCCGGGGCTTATTGATACCGGGATGATCGAAATGGAAGAGAGCGCTCTGAAAGAGGCAATGTCGATGATCCCCATGAAACGCATGGGCCAGGCGGAAGAAGTTGCCGGGCTTGCCAGCTATTTAATGTCTGATATTGCGGGTTACGTCACCCGCCAGGTTATTTCCATCAACGGAGGGATGTTATGA",
    "translation": "MSRSVLVTGASKGIGRAIACQLAADGFNIGVHYHRDAAGAQETLNTIVANGGNGRLLSFDVANREQCREVLEHEIAQHGAWYGVVSNAGIARDAAFPALSDDDWDAVIHTNLDSFYNVIQPCIMPMIGARQGGRIITLSSVSGVMGNRGQVNYSAAKAGIIGATKALAIELAKRKITVNCIAPGLIDTGMIEMEESALKEAMSMIPMKRMGQAEEVAGLASYLMSDIAGYVTRQVISINGGML",
    "product": ""
   },
   {
    "start": 3946855,
    "end": 3947304,
    "strand": -1,
    "locus_tag": "ctg1_3645",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3645</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3645</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,946,855 - 3,947,304,\n (total: 450 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3645\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3645\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3645_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3645\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3645\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGCCACTATTTATCACCCGGCGCTTATCTGCCCCACGATGCGCCCATGTTGCTGCTGGAAGAAGTGGTGAGCGTCAGCGATGACAGCGCCGTGTGCCGCGTGACGGTTTCGCCCAGTGGTGTACTGGAACCGTTTCTCGACCCGGACGGCAATCTCCCTGGCTGGTTTGCCCTTGAACTGATGGCGCAAACCGTCGGCGTCTGGTCTGGCTGGCATCGCCACCAGCAGGGCAAAAACAGTATTGAGTTAGGGATGGTACTGGGCGCGCGTGAATTGCTTTGCGCCGCTGGCATTCTGCCCGCAGGCCAGACGCTGACCATTACCGTCAAACTGCTGATGCAAGATGAACGCTTCGGTAGTTTTGAGTGCAGCATCAACGACGGCGAGGCAACGGGCCGCATTAACACCTTCCAGCCGACCGCGGAAGAACTTACCACCCTGTTTTAA",
    "translation": "MSHYLSPGAYLPHDAPMLLLEEVVSVSDDSAVCRVTVSPSGVLEPFLDPDGNLPGWFALELMAQTVGVWSGWHRHQQGKNSIELGMVLGARELLCAAGILPAGQTLTITVKLLMQDERFGSFECSINDGEATGRINTFQPTAEELTTLF",
    "product": ""
   },
   {
    "start": 3947301,
    "end": 3948470,
    "strand": -1,
    "locus_tag": "ctg1_3646",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3646</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3646</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,947,301 - 3,948,470,\n (total: 1170 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) arylpolyene: APE_KS2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 206.2; E-value: 1.5e-62)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-ctg1_3646 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>PKS_KS</strong> (138..386)</dt>\n   <dd>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3646\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3646\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3646_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3646\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3646\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTTATATTTCCGCCGTCGGCATGATCAACGCCCTGGGAAATAACCTTGATGAGATCGCAGCCAACCTGACTCGTGGTTCCGCTCCCGGCATGCGCCCACGCGCAGGCTGGTTGCAGGGGCATCCGCAGACGGTCCTGGCTGGCGTGGATGGCGAGCTTCCGCTTATCCCGGAAAAATTCGCTGCGCACCGCTCGCGCAACAATCAGGTCCTGCTGGCGGCGCTGGCGCAGATCCAGCCGCAGGTTGATGACGCTATCGCGAAATATGGCCGCGAGCGCATCGCGATTGTGCTTGGCACCAGCACCTCCGGCCTGCATGAAGGTGACACGCACGTTAACCTGCGCACCCACGGGCAGCCAAGCACCACATGGCACTATGCACAACAAGAACTCGGCGATCCGTCGCGTTTTCTCAGCCACTGGCTGGCGCTCGACGGCCCGGCATATACCCTTTCAACCGCCTGCTCTTCCAGCGCCAGAGCGATGATCAGCGGGCGCAGGCTTATCGAAGCGGGGCTGGTCGATGCTGCCATTGTGGGTGGCGCAGACACCCTGAGCCGGATGCCGATTAACGGTTTTCACAGTCTCGAATCGCTGTCGCCAACCTTATGTCAGCCGTTCGGCCGTGACCGTGCGGGCATCACCATTGGCGAAGGCGCGGGGCTAATGCTGCTGACCCGTGAACCGCAGCCCATCGCGTTGCTGGGCGTTGGTGAATCGAGCGACGCTTACCATATTTCGGCCCCGCATCCGCAGGGCGAAGGGGCAATCCGCGCTATTAACCAGGCGCTGACCGATGCGCAGCTTACGCCAGATGACGTCGGCTATATCAACCTGCACGGCACCGCCACACAACTCAACGATCAGATTGAATCAATAGTGGTTAACGCCCTGTTTGGCGAACGCGTACCGTGCAGCTCCACCAAACATTTGACCGGACACACGCTGGGCGCGGCGGGCATTACCGAGGCGGCAATCAGTATGTTGATCTTACAGCGTGATTTACCGCTGCCCGCTCAGGACTTCAGCCTGTCGCCACGCGATCCCACGCTACCACCGTGCGGCATTATCGAAAAACCACAGCCGCTGGCACGTCCGGTGATCCTGTCCAATTCTTTCGCCTTTGGCGGCAATAACGCCAGCATTCTGCTCGGGAGGGTTTCGTGA",
    "translation": "MIYISAVGMINALGNNLDEIAANLTRGSAPGMRPRAGWLQGHPQTVLAGVDGELPLIPEKFAAHRSRNNQVLLAALAQIQPQVDDAIAKYGRERIAIVLGTSTSGLHEGDTHVNLRTHGQPSTTWHYAQQELGDPSRFLSHWLALDGPAYTLSTACSSSARAMISGRRLIEAGLVDAAIVGGADTLSRMPINGFHSLESLSPTLCQPFGRDRAGITIGEGAGLMLLTREPQPIALLGVGESSDAYHISAPHPQGEGAIRAINQALTDAQLTPDDVGYINLHGTATQLNDQIESIVVNALFGERVPCSSTKHLTGHTLGAAGITEAAISMLILQRDLPLPAQDFSLSPRDPTLPPCGIIEKPQPLARPVILSNSFAFGGNNASILLGRVS",
    "product": ""
   },
   {
    "start": 3948472,
    "end": 3949056,
    "strand": -1,
    "locus_tag": "ctg1_3647",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3647</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3647</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,948,472 - 3,949,056,\n (total: 585 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3647\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3647\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3647_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3647\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3647\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCAAATCCACCTTCTGGCGAGCGTTCGCCCTGACCGCTACGCTTATCCTCACCGGCTGTAGCCACTCGCAATCGGAACAGGAAGGCCGCCCGCAGGCGTGGCTGCAACCTGGCACACGCATCACGCTGCCTGCGCCGGGGATATCGCCCGCCGTCAATTCCCAACAACTGTTGACTGGCAGCTTCAACGGCAAAACCCAGTCGCTGTTGGTGATGCTTAATGCCGACGACCAGAAAATCACCCTTGCCGGACTGTCATCAGTCGGCATTCGTCTGTTTCTGGTGACCTACGATGCGCAAGGGCTACGCGCCGAGCAATCCATCGTCGTCCCGCAACTGCCGCCCGCAAGTCAGGTGCTGGCTGACGTAATGCTCAGCCACTGGCCGATTAGCGCCTGGCAACCGCAACTCCCCGCTGGATGGACGCTTCGCGACAACGGTGACAAACGCGAACTGCGTAACGCCAGTGGCAAACTGGTCACGGAAATCACTTATTTGAATCGCAAAGGAAAACGCGTGCCAATCAGCATTGAGCAGCATGTCTTTAAATACCACATCACCATTCAATACTTAGGTGACTGA",
    "translation": "MIKSTFWRAFALTATLILTGCSHSQSEQEGRPQAWLQPGTRITLPAPGISPAVNSQQLLTGSFNGKTQSLLVMLNADDQKITLAGLSSVGIRLFLVTYDAQGLRAEQSIVVPQLPPASQVLADVMLSHWPISAWQPQLPAGWTLRDNGDKRELRNASGKLVTEITYLNRKGKRVPISIEQHVFKYHITIQYLGD",
    "product": ""
   },
   {
    "start": 3949053,
    "end": 3951371,
    "strand": -1,
    "locus_tag": "ctg1_3648",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3648</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3648</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,949,053 - 3,951,371,\n (total: 2319 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3648\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3648\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3648_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3648\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3648\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGAACGCCAACGTTTTGCCGCCCAGTAAACGCCCCGCGCTGTTATGGGGGCTAGTCTGCCTGGTCATGGCGGCGGCGTTGCTGATCCTGCTGCCGCAATCACGGCTGAACAGTAGCGTGCTGGCTATGTTACCCAAACAGGCGATGGGCGATATTCCCCCAGCGCTGAATGACGGCTTTATGCAGCGTCTGGACCGCCAACTGGTGTGGCTGGTCAGCCCCGGTAAAGAGGCTAATCCCAGGGTCGCTCAGGAGTGGCTGACGCTGCTGCAAAAATCCGCTGCGCTCGGCGACGTTAAAGGACCAATGGATGCCGCCAGCCAGCAAGCGTGGGGAGCGTTTTTCTGGCAGCACCGCAACGGCCTGATTGACCCCGACACCCGCGCCCGCCTGCAAAACGGCGGCGAAGCGCAGGCGCAGTGGATCCTCTCCCAGCTTTATTCCGCATTCTCCGGGGTAAGCGGCAAGGAGCTGCAAAACGATCCGCTGATGTTAATGCGCGGCTCGCAGCTGGCGATGGCGAAAAACGGCCAGCGTTTGCGGCTGATGGACGGCTGGCTGGTGACGCAGGATCCCCAGGGCAACTACTGGTATCTGCTGCACGGTGAACTGGCGGGATCGTCGTTTGATATGCAGCAAACCCACCAGCTCATCACGACCCTGAATACGCTGGAAAAGGATCTGAAAACGCGTTACCCACAGGCGCAGTTGCTCTCGCGCGGCACGGTATTTTACAGCGATTACGCCAGTCAACAGGCGAAGCAGGATATCTCAACCCTGGGCGTGGCAACGCTGCTGGGGGTGATATTACTGATTGTGGCGGTGTTCCGCTCTTTGCGCCCATTGTTGCTTTGCGTGATTTCCATCGGCATCGGCGCGCTGGCGGGAACGGTCGCCACTTTATTGATTTTCGGTGAATTACACCTGATGACGCTGGTGATGAGCATGAGCGTTATCGGCATTTCCGCTGACTACACGCTCTATTACCTCACCGAACGAATGGTGCACGGCAACGACGTTTCGCCGTGGCAAAGCCTGGCGAAAGTACGCAATGCCCTGCTGCTGGCGCTGCTCACAACCGTGGCGGCATATCTGATTATGATGCTCGCCCCCTTCCCCGGCATTCGCCAGATGGCGATTTTTGCCGCCGTCGGGTTGAGCGCCTCCTGTCTGACCGTCCTGTTCTGGCATCCGTGGCTGTGCCGTGGTCTGCCGGTGCGCCCGGTTCCGGCGATGGCGCTGATGCTACGCTGGCTGGCAGCGTGGCGGCGCAATAAAAAACTGTCGCGGGGTCTGCCCGTTGCGCTGGCGCTGTTTTCGCTGGCGGGGATGTCAATGCTGCGCGTCGATGACGATATCTCGCAGTTACAGGCGCTACCGCAGCATATTCTGGCGCAGGAAAAAGCCATTACCGCCCTGACCGGGCAGAGCGTCGATCAAAAATGGTTTGTGGTTTACGGCGACTCCCCACAGCAAACATTGCGGCGACTGGAGAAATATACCGCCTCACTTGAGTATGCGAAAAAAGAGGGGCTTATCAGCAACTACCGCACTATTCCGCTGAACTCCCTGGCGCGGCAGGAGGAAGACTTAGACCTGCTGAAAACGGCTGCCCCGACGGTAACAAAAGCACTGCAAAATGCAGGGCTGACGGCGGTGAAACCAGATCTCAACGCCATGCCGGTGAAGGTCGATGAATGGCTGGCAAGCCCCGCCAGTGAAGGCTGGCGTCTGCTGTGGCTGACGCTGGAAAACGGCGAAAGCGGTGTACTGGTGCCGGTTGAAGGGGTTAAAAGTAGCGCATTGTTGCAGGAAATCGCCAGCTATTACCCTTGCGGCATTGCCTGGGTTGATCGCAAAAGCTCCTTTGATGAATTGTTCGCACTTTACCGCTACGTCTTAACCGGCTTGTTGCTGGTGGCGCTGGCAGTGATTGCCTGCGGCGCAGTGGCCCGTCTCAGCTGGCGCAAAGGGATTATCAGCCTGGTGCCTTCGGTGCTTTCGCTGGGCTGTGGTCTGGCGGTGCTGGCGATGAGCGGGCAGGCGGTGAATCTCTTTTCGCTGCTGGCGCTGGTGCTGGTGCTTGGCATCGGTATCAACTACACGCTGTTTTTCAGTAATCCGCGCGGTACACCGTTAACTTCGCTACTGGCGATAGCGCTGGCAATGCTCACCACCTTGCTGACGCTGGGAATGTTGGTATTCAGCGCCACCCAGGCCATCAGCAGTTTTGGCATTGTGCTGGTGAGCGGTATTTTCACCGCCTTCCTGCTTTCGCCGCTGGCTATGCCCGATAAAAAGAGAACAAAAAAATGA",
    "translation": "MTNANVLPPSKRPALLWGLVCLVMAAALLILLPQSRLNSSVLAMLPKQAMGDIPPALNDGFMQRLDRQLVWLVSPGKEANPRVAQEWLTLLQKSAALGDVKGPMDAASQQAWGAFFWQHRNGLIDPDTRARLQNGGEAQAQWILSQLYSAFSGVSGKELQNDPLMLMRGSQLAMAKNGQRLRLMDGWLVTQDPQGNYWYLLHGELAGSSFDMQQTHQLITTLNTLEKDLKTRYPQAQLLSRGTVFYSDYASQQAKQDISTLGVATLLGVILLIVAVFRSLRPLLLCVISIGIGALAGTVATLLIFGELHLMTLVMSMSVIGISADYTLYYLTERMVHGNDVSPWQSLAKVRNALLLALLTTVAAYLIMMLAPFPGIRQMAIFAAVGLSASCLTVLFWHPWLCRGLPVRPVPAMALMLRWLAAWRRNKKLSRGLPVALALFSLAGMSMLRVDDDISQLQALPQHILAQEKAITALTGQSVDQKWFVVYGDSPQQTLRRLEKYTASLEYAKKEGLISNYRTIPLNSLARQEEDLDLLKTAAPTVTKALQNAGLTAVKPDLNAMPVKVDEWLASPASEGWRLLWLTLENGESGVLVPVEGVKSSALLQEIASYYPCGIAWVDRKSSFDELFALYRYVLTGLLLVALAVIACGAVARLSWRKGIISLVPSVLSLGCGLAVLAMSGQAVNLFSLLALVLVLGIGINYTLFFSNPRGTPLTSLLAIALAMLTTLLTLGMLVFSATQAISSFGIVLVSGIFTAFLLSPLAMPDKKRTKK",
    "product": ""
   },
   {
    "start": 3951340,
    "end": 3951945,
    "strand": -1,
    "locus_tag": "ctg1_3649",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3649</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3649</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,951,340 - 3,951,945,\n (total: 606 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3649\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3649\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3649_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3649\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3649\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAATTTTTACCGCTGCTGGCGCTGCTGATTAGCCCGTTTGTGAGCGCCCTGACCCTGGACGATCTTCAGCAACGCTTTACCGAACAACCGGTGATCCGCGCCCATTTTGATCAAACCCGGACGATTAAAGATCTGCCGCAGCCGCTGCGATCTCAGGGTCAGATGTTGATCGCCCGCGACCAGGGGTTATTGTGGGATCAAACCTCACCGTTCCCCATGCAGCTATTGCTGGATGATAAACGCATGGTGCAGGTGATCAACGGTCAGCCGCCGCAAATCATCACGGCAGAAAACAACCCGCAGATGTTCCAGTTTAACCACCTGCTGCGCGCGCTGTTCCAGGCCGATCGCAAAGTGCTGGAACAAAACTTCCGCGTCGAATTTGCTGACAAAGGCGAAGGCCGCTGGACGCTGCGCCTGACGCCGACCACCACGCCGCTGGATAAAATTTTCAACACCATCGATCTCGCCGGGAAAACCTATCTGGAGAGCATTCAACTTAATGATAAACAGGGCGATCGCACCGATATTGCTCTTACCCAACATCAACTGACGCCAGCGCAACTGACCGATGACGAACGCCAACGTTTTGCCGCCCAGTAA",
    "translation": "MKFLPLLALLISPFVSALTLDDLQQRFTEQPVIRAHFDQTRTIKDLPQPLRSQGQMLIARDQGLLWDQTSPFPMQLLLDDKRMVQVINGQPPQIITAENNPQMFQFNHLLRALFQADRKVLEQNFRVEFADKGEGRWTLRLTPTTTPLDKIFNTIDLAGKTYLESIQLNDKQGDRTDIALTQHQLTPAQLTDDERQRFAAQ",
    "product": ""
   },
   {
    "start": 3951942,
    "end": 3952364,
    "strand": -1,
    "locus_tag": "ctg1_3650",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3650</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3650</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,951,942 - 3,952,364,\n (total: 423 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3650\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3650\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3650_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3650\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3650\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCTTAACGATCCCCGATTTACCGCTGAAGTCGAGCTGATCATTCCATTTCACGACGTCGATATGATGGGCGTGGCCTGGCACGGTAACTATTTTCGCTACTTTGAAGTGGCCCGCGAGGCGCTGCTCAACCAGTTCAATTACGGCTATCGGCAGATGAAAGAGTCCGGTTATTTGTGGCCAGTGGTCGATGCGCGGGTGAAATATCGCCACGCCCTCACCTTTGAGCAACGCATCCGCGTGCGTGCGCATATCGAAGAGTTCGAAAACCGTCTGCGGATTGGCTATCAGATTTTCGATGCCGAAACGGGCAAACGCGCCACCACCGGATACACCATTCAGGTCGCGGTCGACGAGCAAAGTCGCGAACTGTGCTTTGTCAGCCCCGATATTCTGTTTGAACGCATGGGAGTCAAACCATGA",
    "translation": "MLNDPRFTAEVELIIPFHDVDMMGVAWHGNYFRYFEVAREALLNQFNYGYRQMKESGYLWPVVDARVKYRHALTFEQRIRVRAHIEEFENRLRIGYQIFDAETGKRATTGYTIQVAVDEQSRELCFVSPDILFERMGVKP",
    "product": ""
   },
   {
    "start": 3952368,
    "end": 3954044,
    "strand": -1,
    "locus_tag": "ctg1_3651",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3651</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3651</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,952,368 - 3,954,044,\n (total: 1677 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1123:polyprenol-monophosphomannose synthase ppm1 (Score: 85.3; E-value: 8.7e-26)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3651\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3651\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3651_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3651\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3651\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCGGTAAACTTTTCTCCCTGCGTGTTGATCCCCTGCTACAACCACGGCGCAATGATGCCGGGCGTGCTGGCGCGTCTTAAGCCATTTAATCTGCCCTGTATTGTGGTGGATGACGGCAGCGATGCCGCCACGCAACAGCAACTGGATAATCTGGTTGCCGAACAGCCTGGCGTGACCTTAATTCGCCTGGCAGAAAACGCAGGCAAAGGCGCGGCGGTAATGCGCGGCTTACAGGCGGCTGCAGACGCGGGGTTCAGCCATGCGGTACAGGTAGATGCCGACGGTCAGCACGCGATTGAAGATATCCCCAAACTGCTGGCACTCGCTGAACAACACCCTGCGGCACTGATCTCCGGCCAGCCGATTTACGATGACTCCATCCCCCGCTCACGGCTGTACGGGCGCTGGGTCACCCACGTCTGGGTGTGGATCGAAACGCTCTCCCTGCAACTGAAAGACAGCATGTGCGGCTTTCGCGTTTATCCAGTCGTGCCAACGCTGCAACTGGCAAAACACGCCACCATCGGCAAGCGGATGGATTTCGACACCGAAGTGATGGTGCGCCTCTACTGGCAGGGAAACACCAGTTATTTCGTGCCGACCCGCGTCACCTATCCGCTGGACGGGCTTTCGCATTTTGATGCCCTGAAAGATAACGTCCGCATCTCGCTGATGCACACACGTCTGTTTTTCGGCATGTTGCCGCGTATTCCTTCACTGCTGATGCGCCACTCTTCCAGCCACTGGGCGCGGCAGAGCGAAGTGAAAGGATTATGGGGAATGCGCCTGATGCTGCTGGTCTGGCGTCTGCTGGGAAAAACAGCGTTTAGCGCGCTGCTTTACCCGGTGGTGGGCGTCTACTGGCTCACCGCCAGCCGGGCGCGCAAAGCATCGCAAGACTGGCTCGCCCGTGTGCGCCAGCATCAACCACAGGCAGCAAAACTCAACAGCTATCAGCACTTTCTACGTTTCGGCAACGCCATGCTCGACAAAATCGCCAGCTGGCGCGGCGAGCTACAACTCGGGCGTGATGTGCTGTTTGCACCAGGCGCAGAAGCGGCACTTAACGTCAGCGATCCGCGAGGCAAATTGCTGCTGGCCTCGCATCTTGGCGATGTGGAAGTGTGCCGGGCGCTGGCAAAAATTCAGGGCTACAAAACCATTAACGCGCTGGTGTTTAGCGAAAACGCCCAACGTTTTAAACAGATAATGCAGGAGATGGCCCCGCAGGCAGGCATCAACCTGCTCCCGGTGACGGATATCGGCCCGGACACCGCCATCCTGCTAAAAGAGAAGCTGGATAACGGCGAATGGGTGGCGATTGTTGGTGACCGCATCGCCATCAACCCGCAACGCGGCGGCGACTGGCGCGTCTGCTGGAGTTCGTTTATGGGCCAGCCTGCGCCCTTCCCACAGGGGCCGTTTATTCTCGCCTCTATTTTGCGCTGCCCGGTGAATCTGATTTTCGCCCTGCGCCAGCACGGCAAGCTGCATATTCACTGCGAAACCTTTGCCGACCCGCTGCTGTTGCCGCGTGGCGAACGCAAGCAGGCGCTGCAAAACGCTATCGATCATTACGCCGCGCGTCTGGAACATCACGCGCTCCAGTCGCCCCTCGACTGGTTTAATTTTTTCGATTTCTGGCAACTGCCGGAAGTCCAGGACAAGGAGTAA",
    "translation": "MSVNFSPCVLIPCYNHGAMMPGVLARLKPFNLPCIVVDDGSDAATQQQLDNLVAEQPGVTLIRLAENAGKGAAVMRGLQAAADAGFSHAVQVDADGQHAIEDIPKLLALAEQHPAALISGQPIYDDSIPRSRLYGRWVTHVWVWIETLSLQLKDSMCGFRVYPVVPTLQLAKHATIGKRMDFDTEVMVRLYWQGNTSYFVPTRVTYPLDGLSHFDALKDNVRISLMHTRLFFGMLPRIPSLLMRHSSSHWARQSEVKGLWGMRLMLLVWRLLGKTAFSALLYPVVGVYWLTASRARKASQDWLARVRQHQPQAAKLNSYQHFLRFGNAMLDKIASWRGELQLGRDVLFAPGAEAALNVSDPRGKLLLASHLGDVEVCRALAKIQGYKTINALVFSENAQRFKQIMQEMAPQAGINLLPVTDIGPDTAILLKEKLDNGEWVAIVGDRIAINPQRGGDWRVCWSSFMGQPAPFPQGPFILASILRCPVNLIFALRQHGKLHIHCETFADPLLLPRGERKQALQNAIDHYAARLEHHALQSPLDWFNFFDFWQLPEVQDKE",
    "product": ""
   },
   {
    "start": 3954035,
    "end": 3954388,
    "strand": -1,
    "locus_tag": "ctg1_3652",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3652</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3652</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,954,035 - 3,954,388,\n (total: 354 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3652\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3652\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3652_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3652\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3652\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGCCCCATGAAATCGAGCGCCATCAGGCACAAGCGAATCACCTTGAGATTGTTTTGCATCTCAGGGCAGATCTGTTCTGGTTTCGCGGTCATTTTGCCGTACAACCATTACTCCCCGGCGTGGCACAAATCGACTGGGCGATGAGTTACGCGCTTGCCCTGCTCGCGCCCGGTTGGCGTTTTCACTCAATTCAGAACATCAAATTCCAGGCTCCATTGCTGCCGGATAACCGCGTCACACTCACGCTTAGCTGGCAGGAAGAACGCCAGATTCTGAGCTTTAGTTATCAGCGTCACGACGGTGACGCCCGCCACACCGCCAGTAGCGGGAAGATCCGCCTATGTCGGTAA",
    "translation": "MKPHEIERHQAQANHLEIVLHLRADLFWFRGHFAVQPLLPGVAQIDWAMSYALALLAPGWRFHSIQNIKFQAPLLPDNRVTLTLSWQEERQILSFSYQRHDGDARHTASSGKIRLCR",
    "product": ""
   },
   {
    "start": 3954375,
    "end": 3955736,
    "strand": -1,
    "locus_tag": "ctg1_3653",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3653</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3653</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,954,375 - 3,955,736,\n (total: 1362 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 74.5; E-value: 1e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3653\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3653\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3653_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3653\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3653\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGCAGACCTTACCGCTTGCACGCTGGCTGACTGCGCCACGCCCTGATGACACGCCCATTGCGTGGCTGGACGAAAGCACCTGGACGCTGAGCGATTTGCGTCACGATGTCGCGCAACTTATCTGCCGCTTGCAGCAACAGCCAGGTGAACGCTGGGCGCTGTGCTTTGAGAACAGCTATCTGTTTATCGTTGCCCTGCTCGCCACGCTACACGCCGGAAAAACACCGGTGCTTCCGGGGCATAACCGCGTTATCCAGCTTAATGAGCAACGTGAACTTTTTGATGGTGTGCTTAGCGACAGCGAACTTAACTGGCAAGGTTCATTGCTGTTGGTAGCAAGCTCCCCACAAGTCGCGACACAATCATTCACCTTTGCCGCTATAGCGCCTGACGCTTATATCGAGCTGTTTACCTCTGGTTCCACAGGGCAGCCGAAGCGGGTGATTAAACCTGTTCGTTTGTTGGACCGTGAAGCAGAACTGCTGGCTGAACGATTAGGTGCACGTCTTGCCGGAAGTCGTGTCGTCGGTTCCGTATTGCCGCAGCATTTGTACGGCCTGACTTTTCGCGTTTTCCTGCCCATGGCGCTGGGATTACCGCTCCATGCCGCCATGCTCTGGTATGTCGAACAGTTTGCCGCGTTGAGTCATCAGCATCGCTATATCTTCATCAGCAGTCCGGCATTTTTGAAGCGTCTGGATACACAGCTTTCCCCGCCCCCCGTTCAGGTGCTTCTTTCTGCTGGTGGTGAGCTACCGTGGCAGGACGTACAACACACCGCGAGCTGGCTGCGCGTCTGGCCTGATGAAATCTACGGCAGCACGGAAACCGGCGTCATCGCCTGGCGTTACCGCGAACAAGAGCAACGCCGCTGGCGGCCCTTTCCAGGTATGCAGTTCCAGGCCGAAGATGATGCCTTTCGTCTCTTTTCACCTCTGATGGAGGAAGATAGCGGCCTGTTACTCGACGATATCTTGCAGTTTAGCGAAGACGGCCAGTTCCATCTGATGGGGCGTCGCGGACGCATCGTTAAGATTGAAGAAAAACGCATTTCACTCCAGGAAGTAGAACAACGTCTGCTGGCGCTGGACGGTATTCACGAGGCGGCGGCAGTTCCCGTTACGCGCGGCGGGCGTCAGAGTATTGGCGTTTTGCTGGTGCTGAATGACGAAGCTCGCCTGCAATGGCAAAACGGCGGCGGGCACAGCCAGGAAATGGCCTGGCGGCGATTACTGCGCCCGACGCTGGAGCCAGTTGCTATTCCGCGTTACTGGCGCGTTATTGATGAAATGCCAGTAAACAGTATGAACAAGCGTGTCTATGCGCAATTACAGGAGTTATTTCATGAAGCCCCATGA",
    "translation": "MKQTLPLARWLTAPRPDDTPIAWLDESTWTLSDLRHDVAQLICRLQQQPGERWALCFENSYLFIVALLATLHAGKTPVLPGHNRVIQLNEQRELFDGVLSDSELNWQGSLLLVASSPQVATQSFTFAAIAPDAYIELFTSGSTGQPKRVIKPVRLLDREAELLAERLGARLAGSRVVGSVLPQHLYGLTFRVFLPMALGLPLHAAMLWYVEQFAALSHQHRYIFISSPAFLKRLDTQLSPPPVQVLLSAGGELPWQDVQHTASWLRVWPDEIYGSTETGVIAWRYREQEQRRWRPFPGMQFQAEDDAFRLFSPLMEEDSGLLLDDILQFSEDGQFHLMGRRGRIVKIEEKRISLQEVEQRLLALDGIHEAAAVPVTRGGRQSIGVLLVLNDEARLQWQNGGGHSQEMAWRRLLRPTLEPVAIPRYWRVIDEMPVNSMNKRVYAQLQELFHEAP",
    "product": ""
   },
   {
    "start": 3955733,
    "end": 3956314,
    "strand": -1,
    "locus_tag": "ctg1_3654",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3654</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3654</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,955,733 - 3,956,314,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3654\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3654\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3654_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3654\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3654\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCGGGCATTCGCTCGCTACCGATGATTAAGCTGCTGACTGGATTATTGCTGCTCGCCTGGCCGTTTGTGATTTGGTTTGGCTTAGCGCATAACGGCCTGCACTGGTTGTTGCCGCTGATGGCGCTGCTGTTTTTGTTGCGCTTGCGCCAGACCCGTCGCCAGACCGGGCCACTACAAGCCGTCACGCAAATCGTCGCTGTCGTAGGCATCGCCTTGTGTGCCGCCAGCTTTCTGCTGAAAACGCACCAGCTACTGCTGTTTTACCCGGCAGTGGTTAACGCGGTCATGCTGGCGGTTTTTGGCGGTTCGCTGTGGTCGGCAATGCCAATTGTTGAGCGGCTGGCACGTTTGCAGGAGCCAGATCTCCCGGAAAAGGGCGTGCGCTATACCCGCCACGTCACGCAAATCTGGTGCGGCTTTTTCATCATCAACGGCGGAATTGCCCTCTTTACCGCGCTGCATGGCGATATGTCGTTATGGACTGCCTGGAACGGCATGATTGCTTATTTGTTAATGGGAACGTTAATGGCTGGTGAATGGCTGGTGCGCCGTCAGGTGATGAAAAGAGATCGCTCATGA",
    "translation": "MSGIRSLPMIKLLTGLLLLAWPFVIWFGLAHNGLHWLLPLMALLFLLRLRQTRRQTGPLQAVTQIVAVVGIALCAASFLLKTHQLLLFYPAVVNAVMLAVFGGSLWSAMPIVERLARLQEPDLPEKGVRYTRHVTQIWCGFFIINGGIALFTALHGDMSLWTAWNGMIAYLLMGTLMAGEWLVRRQVMKRDRS",
    "product": ""
   },
   {
    "start": 3956319,
    "end": 3956570,
    "strand": -1,
    "locus_tag": "ctg1_3655",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3655</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3655</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,956,319 - 3,956,570,\n (total: 252 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3655\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3655\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3655_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3655\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3655\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACAGAACAACAAACCGTCTATCAGGAAGTCTCAGCTCTGCTGGTTAAGCTGTTTGAAATCGATCCGCAAGACATCAAACCTGAAGCGCGCCTGTACGAAGATTTGGAGCTGGACAGTATCGACGCCGTTGACATGATTGTGCACCTGCAAAAGAAAACCGGTAAGAAAATCAAGCCGGAAGAGTTTAAAGCAGTGCGTACAGTCCAGGATGTCGTCGAGGCTGTAGAACGCCTGCTACAAGAAGCCTGA",
    "translation": "MTEQQTVYQEVSALLVKLFEIDPQDIKPEARLYEDLELDSIDAVDMIVHLQKKTGKKIKPEEFKAVRTVQDVVEAVERLLQEA",
    "product": ""
   },
   {
    "start": 3956582,
    "end": 3956839,
    "strand": -1,
    "locus_tag": "ctg1_3656",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3656</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3656</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,956,582 - 3,956,839,\n (total: 258 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3656\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3656\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3656_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3656\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3656\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAAGCGCTTTATCTTGAAATCAAAAACCTCATTATCTCTACTCTCAATCTGGATGAGCTTTCACCAGATGATATCGAAACCGAAGCGCCGTTGTTTGGTGATGGTTTAGGGCTGGACTCTATCGATGCCCTGGAACTGGGGCTGGCAGTGAAAAATGAATATGGCGTTGTACTTTCTGCGGAAAGTGAAGAGATGCGTCAGCACTTTTTCTCCGTCGCCACTCTGGCCTCTTTCATTGCTGCGCAACGTGCCTGA",
    "translation": "MQALYLEIKNLIISTLNLDELSPDDIETEAPLFGDGLGLDSIDALELGLAVKNEYGVVLSAESEEMRQHFFSVATLASFIAAQRA",
    "product": ""
   },
   {
    "start": 3956820,
    "end": 3957635,
    "strand": -1,
    "locus_tag": "ctg1_3657",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3657</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3657</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,956,820 - 3,957,635,\n (total: 816 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1141:acyltransferase (Score: 73.2; E-value: 3.3e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3657\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3657\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3657_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3657\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3657\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTAATCTGATGTCACGCCTGGAATGGACATGGCGACTGGTTATGACCGGGTTGTGTTTTGCCCTGTTTGGCCTCGGCGGACTACTACTCTCTGTGGTGTGGTTTAACGTACTGTTAGTTTTGGTGTGGAACACTTCCCGCCGCCGTCGTTTGGCGCGTCGCAGCATTGCCGCCAGTTTTCGCCTGTTTTTAACCGCCGCGAAAGGGCTTGGCGTGCTGGATTATCGTATTGATGGGGCTGAAATTTTACGTCAGGAACGCGGTTGCCTCGTCGTAGCTAATCATCCCACGCTTATCGATTACGTACTGCTGGCGTCAGTCATGCCAGAAACTGACTGCCTGGTGAAAAGCGCACTGTTAAAAAATCCTTTTCTTGGCGGCGTTGTGCGGGCGGCAGATTATTTAATCAACAGCGAAGCTGAAACCCTCTTACCCCGCTGCCAACAGCGACTGGCACAGGGTGACACTATTCTGATTTTCCCCGAAGGAACCCGAACTCGTCCCGGAGAAAAAATGACGCTACAACGTGGTGCAGCCAATATTGCGGTCCGTTGTGCCAGTGATTTACGCATCGTAACGATTCGTTGTAGCGAGCATCTACTTGATAAACAAAGTAAATGGTATGACGTTCCACCTGCTAAACCACTCTTTACCGTCGAAGTGGGTGAACGGATACAAATTAACCGTTTTTACGACGCAAACTCACAAGAACCGGCGCTGGCAGCAAGGCAGCTTAACCGGCATCTTTTGCTGCAATTACAACCAGGTACATTACCTCTCTCAGGAAAAAATGATGCAAGCGCTTTATCTTGA",
    "translation": "MSNLMSRLEWTWRLVMTGLCFALFGLGGLLLSVVWFNVLLVLVWNTSRRRRLARRSIAASFRLFLTAAKGLGVLDYRIDGAEILRQERGCLVVANHPTLIDYVLLASVMPETDCLVKSALLKNPFLGGVVRAADYLINSEAETLLPRCQQRLAQGDTILIFPEGTRTRPGEKMTLQRGAANIAVRCASDLRIVTIRCSEHLLDKQSKWYDVPPAKPLFTVEVGERIQINRFYDANSQEPALAARQLNRHLLLQLQPGTLPLSGKNDASALS",
    "product": ""
   },
   {
    "start": 3957632,
    "end": 3958354,
    "strand": -1,
    "locus_tag": "ctg1_3658",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3658</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3658</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,957,632 - 3,958,354,\n (total: 723 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3658\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3658\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3658_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3658\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3658\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAATTTGCATTAAACATTCTCGACTGGCAGGCAAGAGCGCCTGGACTTAGTGAAACGCTGCAATGGCAGGAGTGGTCACGTCAGCCTCAGGCAATTGACCCGACAGCACCGTTGGCAAAATTAAGTGAACTGCCAATGATGACCGCCCGCCGCCTCAGCTCCGGGAGCAAACTGGCTGTTGAATGCGGTCTGGCAATGCTACGCCGCCATCAAATAGACGCCGTTTTGTATACCAGTCGTCATGGCGAGCTGGAGCGCAATTACCGCATTGTTCATGCACTGGCAACCGAACAGGCGCTTTCTCCGACGGACTTCGCGCTCTCCGTACACAACTCTTCCGTGGGTAACCTGACCATTGCGGCCAAACAGCCGATCGTTTCGTCATCGCTTTCGGCTGGTCGCGATAGTTTCCAGCAAGGTTTGAGTGAAGTGCTTAGCCTGCTACAAGCGGGATACCAGCGTGTGTTGATGGTCGATTTTGATGGCTTTCTACCTGAGTTCTATCATCCGCAGCTCCCAGCAGAAATGCCGACCTGGCCATATGCTGTTGCGCTGGTGATTGAAGCTGGCGATGAGTGGCAATGTGAAACACAGCCAGCCATTGCGGGCAATGAAACAACACTGCCGCAAAGCATGTTGTTTTTACAGCACTATTTACAAAATTCAGATGCTTTTTCACTTCCTGGCGAGCGCGTACAGTGGCGCTGGAGCCGTGGATGA",
    "translation": "MKFALNILDWQARAPGLSETLQWQEWSRQPQAIDPTAPLAKLSELPMMTARRLSSGSKLAVECGLAMLRRHQIDAVLYTSRHGELERNYRIVHALATEQALSPTDFALSVHNSSVGNLTIAAKQPIVSSSLSAGRDSFQQGLSEVLSLLQAGYQRVLMVDFDGFLPEFYHPQLPAEMPTWPYAVALVIEAGDEWQCETQPAIAGNETTLPQSMLFLQHYLQNSDAFSLPGERVQWRWSRG",
    "product": ""
   },
   {
    "start": 3958397,
    "end": 3959455,
    "strand": -1,
    "locus_tag": "ctg1_3659",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3659</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3659</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,958,397 - 3,959,455,\n (total: 1059 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1042:O-methyltransferase (Score: 129.9; E-value: 2.1e-39)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3659\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3659\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3659_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3659\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3659\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTATCAACAGGATTCACTTAGCGCACTGGATGCGATTACCGAAGCTCAACGCATTGCCTTTGCCCCTATGCTTTTTCAAACTGCATTGTGTCTGCGTAACGCAGGTGTGCTGACTTATCTTGATAAACAAGGTAAATGTGGTGCCTCCCTGGCAGATATCACTGAAAATAGTCAAATCAATGAATATGCCGCCAGCGTTTTGTTAGATATGGGATTAAGCGGGCGAATAATTACCTGTAAAGAGGGAATATATTATCTGGCAAAGATCGGTCATTTCCTTTTGCATGACACCATGACCCGGGTAAATATGGATTTTACTCAGGACGTCTGTTATCAGGGGCTGTTCTTTTTGGCTGAATCTTTGAAAGAAGGGAAACCCTCTGGCTTAAAAGTATTTGGCGACTGGCCAACGATATATCCGGCACTTTCACAATTACCGGATGCCGCACGTGAAAGCTGGTTCGCTTTTGATCATTACTACTCTGATGGCGCATTTGACGCCGCATTGCCTTATGTATTCGCCAACAACCCTGCAACCCTGTACGATGTGGGCGGAAATACGGGTAAATGGGCCTTACGTTGCTGCCATTACAACGCAAATATCAACGTTACCCTATTAGATTTGCCACAACAAATTGCACTCGCGAAAGAAAATATTGAGAATGCAGGTTTTTCTCATCGCATAGATTTCCACGCGGTGGATATGCTAAGCGACGCGCCATTGCCAAATGGGGCTGATGTCTGGTGGATGAGTCAATTCCTGGATTGTTTTTCGCCAGAGCAAATTGTCGCCATTCTGACCAAAGTGGCAAATGTGATGAAACCCGGCGCAAAACTTTGCATTATGGAATTATTCTGGGATGCACAACGTTTTGAAGCCGCTTCATTTAGTCTGAATGCCTCTTCGCTCTACTTCACCTGCATGGCGAATGGCAATAGCCGGTTTTACAGTGCTGAAAAATTTTATGACTATCTGAATAAAGCAGGGTTCCAGGTAGAAGAACGCCACGATAATTTAGGCGTTGGGCATACTTTATTGATCTGCCAAAAGAAATAA",
    "translation": "MYQQDSLSALDAITEAQRIAFAPMLFQTALCLRNAGVLTYLDKQGKCGASLADITENSQINEYAASVLLDMGLSGRIITCKEGIYYLAKIGHFLLHDTMTRVNMDFTQDVCYQGLFFLAESLKEGKPSGLKVFGDWPTIYPALSQLPDAARESWFAFDHYYSDGAFDAALPYVFANNPATLYDVGGNTGKWALRCCHYNANINVTLLDLPQQIALAKENIENAGFSHRIDFHAVDMLSDAPLPNGADVWWMSQFLDCFSPEQIVAILTKVANVMKPGAKLCIMELFWDAQRFEAASFSLNASSLYFTCMANGNSRFYSAEKFYDYLNKAGFQVEERHDNLGVGHTLLICQKK",
    "product": ""
   },
   {
    "start": 3959525,
    "end": 3959914,
    "strand": -1,
    "locus_tag": "ctg1_3660",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3660</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3660</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,959,525 - 3,959,914,\n (total: 390 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3660\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3660\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3660_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3660\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3660\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAACACTACATGAAATGGTTTGCCGCAATTGCTGTTGTGGGTGCTTTAGCAGGTTGTGCTCGTACTGCACCAATTGACCAGGTCCACTCTACTGTCAGCGCTGGTCACACTCAGGATCAAGTGAAAAAAGCCATTCTTAAAGCAGGTGTAGAACGTCAATGGATAATGTCCGAAGCTGGACCTGGCGTAATTAAAGCACGTCAACAAAGCCGCGCTCACACTGCAGAAATTCGTATTAATTACACCGCATCCAGTTACGATATCAATTATGAAAATAGCCAGAATCTCCAGGCTTCCGGCGGTCAAATTCATAAAAATTATAATCGTTGGGTACGCAACCTCGATAAAGAAATTCAGTTGAATTTATCTGCGGGCGCAGGGCTGTAA",
    "translation": "MKHYMKWFAAIAVVGALAGCARTAPIDQVHSTVSAGHTQDQVKKAILKAGVERQWIMSEAGPGVIKARQQSRAHTAEIRINYTASSYDINYENSQNLQASGGQIHKNYNRWVRNLDKEIQLNLSAGAGL",
    "product": ""
   },
   {
    "start": 3960309,
    "end": 3961358,
    "strand": -1,
    "locus_tag": "ctg1_3661",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3661</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3661</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,960,309 - 3,961,358,\n (total: 1050 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3661\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3661\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3661\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3661\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAAACCTCTCAACCCGATAAAACGGGAATGCACATCTTACTGAAATTGGCCTCGCTGGTAGTAATCCTCGCAGGTATTCATGCTGCGGCAGATATCATTGTGCAACTGTTACTGGCGCTCTTTTTCGCCATCGTCCTCAACCCGCTCGTCACCTGGTTTATTCGTCGTGGAGTCCAGCGCCCCGTTGCCATTACGATCGTAGTAGTGGTTATGCTGATCGCACTTACCGCACTGGTCGGTGTGCTGGCGGCATCATTTAATGAATTTATCTCGATGTTGCCGAAGTTTAATAAGGAGCTGACGCGCAAGCTTTTTAAATTGCAGGAGATGTTACCTTTTCTCAATTTGCATATTTCACCAGAAAGAATGCTACAACGGATGGACTCGGAAAAAGTGGTAACCTTCACCACAGCGCTGATGACGGGGCTTTCCGGGGCAATGGCAAGCGTACTTCTGTTGGTGATGACCGTGGTTTTTATGCTGTTTGAAGTGCGCCACGTTCCTTACAAAATGCGTTTTGCGCTGAATAACCCACAGATTCACATCGCCGGATTACATCGCGCATTAAAAGGCGTTTCTCACTATCTTGCATTGAAGACGCTGTTAAGTTTATGGACAGGCGTAATCGTCTGGCTGGGGCTGGCACTGATGGGAGTTCAGTTCGCACTGATGTGGGCTGTACTGGCATTTTTGCTCAACTATGTGCCCAATATCGGCGCGGTGATCTCCGCCGTACCGCCGATGATCCAGGTGCTGCTGTTTAATGGTGTTTACGAATGCATTCTGGTCGGTGCGCTATTTTTAATCGTCCATATGGTTATTGGCAATATTTTAGAACCACGAATGATGGGCCATCGTCTGGGAATGTCGACACTGGTGGTGTTTCTTTCTTTGTTAGTCTGGGGCTGGCTGCTCGGCCCGGTCGGGATGTTACTTTCAGTACCCTTAACCAGCGTCTGTAAAATCTGGATGGAAACCACTAAGGGAGGCAGTAAACTGGCGATTTTACTGGGACCTGGTAGACCAAAAAGCCGATTACCAGGTTAA",
    "translation": "METSQPDKTGMHILLKLASLVVILAGIHAAADIIVQLLLALFFAIVLNPLVTWFIRRGVQRPVAITIVVVVMLIALTALVGVLAASFNEFISMLPKFNKELTRKLFKLQEMLPFLNLHISPERMLQRMDSEKVVTFTTALMTGLSGAMASVLLLVMTVVFMLFEVRHVPYKMRFALNNPQIHIAGLHRALKGVSHYLALKTLLSLWTGVIVWLGLALMGVQFALMWAVLAFLLNYVPNIGAVISAVPPMIQVLLFNGVYECILVGALFLIVHMVIGNILEPRMMGHRLGMSTLVVFLSLLVWGWLLGPVGMLLSVPLTSVCKIWMETTKGGSKLAILLGPGRPKSRLPG",
    "product": ""
   },
   {
    "start": 3961448,
    "end": 3962695,
    "strand": 1,
    "locus_tag": "ctg1_3662",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3662</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3662</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,961,448 - 3,962,695,\n (total: 1248 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1020:major facilitator transporter (Score: 58.6; E-value: 8.8e-18)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3662\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3662\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMLKMKLCSKYGVIVMPEPALNGLRLNLRIVSIVMFNFASYLTIGLPLAVLPGYVHDVMGFSAFWAGLVISLQYFATLLSRPHAGRYADLLGPKKIVMFGLAGCLLSGGAYFLAGSASSWPVLSLLLLCLGRVILGIGQSFTGTGSTLWGVGAVGSTHIGRVISWNGIVTYGAMAMGAPLGVLCYHWVGLQGLSLFIMAVALVALLLAIPRPAVKASKGKPLPFRAVLGRVWLYGMALAMASAGFGVIATFITLFYDAKGWDGAAFALTLFSCAFVGTRLLFPGGINRIGGLNVAMICFSVEIIGLLLVGVAMVPWMAKVGVLLAGAGFSLVFPALGVVAVKAVPQQNQGAALATYTVFMDLSLGITGPLAGLVMSWAGVSVIYLAAAGLVVIALLLTWRLKKRPPQPLSETASSS\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3662\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3662\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTAAAAATGAAACTCTGTTCTAAATACGGGGTAATCGTGATGCCCGAGCCCGCACTTAATGGTCTGCGTCTGAATCTGCGCATTGTTTCAATTGTCATGTTTAACTTCGCCAGCTATCTCACTATCGGTTTACCGCTCGCGGTATTACCTGGCTATGTCCATGATGTGATGGGATTTAGCGCCTTCTGGGCGGGGTTGGTGATCAGCCTGCAATACTTCGCCACTTTGCTCAGTCGTCCACATGCCGGGCGGTATGCAGATCTATTAGGCCCCAAAAAGATTGTGATGTTTGGGCTGGCTGGCTGTTTGCTCAGTGGTGGGGCCTATTTTCTGGCGGGGAGTGCCAGCAGCTGGCCGGTACTCAGCTTGTTACTGTTGTGTCTTGGGCGTGTGATTCTGGGAATTGGACAAAGCTTTACCGGCACTGGTTCTACTTTGTGGGGCGTCGGTGCGGTGGGATCGACTCACATTGGTCGGGTGATTTCGTGGAACGGCATCGTCACGTATGGTGCGATGGCGATGGGCGCACCGCTTGGTGTTCTGTGCTATCACTGGGTTGGGCTACAAGGACTTTCACTTTTTATTATGGCGGTTGCCCTGGTGGCACTGCTGCTGGCGATCCCACGTCCAGCGGTGAAAGCGAGCAAAGGGAAGCCGCTACCGTTTCGTGCAGTACTGGGGCGAGTCTGGCTTTATGGGATGGCGCTGGCAATGGCGTCTGCCGGGTTTGGCGTTATCGCCACCTTTATCACGCTGTTTTATGACGCGAAAGGTTGGGACGGAGCGGCCTTCGCACTGACGCTATTTAGCTGTGCGTTTGTCGGTACACGATTGTTATTCCCTGGCGGCATTAACCGTATCGGCGGCTTAAACGTAGCGATGATTTGCTTTAGTGTTGAGATAATCGGCTTGCTACTGGTCGGGGTTGCGATGGTACCCTGGATGGCGAAAGTGGGCGTTTTGCTGGCAGGTGCGGGTTTTTCGTTGGTCTTTCCGGCGTTGGGCGTTGTGGCAGTAAAAGCAGTGCCACAGCAAAATCAGGGGGCGGCTCTGGCGACTTATACCGTCTTTATGGATTTATCTCTTGGTATTACCGGACCGTTAGCCGGGTTGGTCATGAGCTGGGCAGGTGTATCCGTGATTTATCTGGCTGCGGCGGGGCTGGTGGTTATTGCATTACTACTAACATGGCGGTTAAAAAAACGGCCTCCGCAACCACTGTCGGAGACCGCTTCATCATCGTAG",
    "translation": "MLKMKLCSKYGVIVMPEPALNGLRLNLRIVSIVMFNFASYLTIGLPLAVLPGYVHDVMGFSAFWAGLVISLQYFATLLSRPHAGRYADLLGPKKIVMFGLAGCLLSGGAYFLAGSASSWPVLSLLLLCLGRVILGIGQSFTGTGSTLWGVGAVGSTHIGRVISWNGIVTYGAMAMGAPLGVLCYHWVGLQGLSLFIMAVALVALLLAIPRPAVKASKGKPLPFRAVLGRVWLYGMALAMASAGFGVIATFITLFYDAKGWDGAAFALTLFSCAFVGTRLLFPGGINRIGGLNVAMICFSVEIIGLLLVGVAMVPWMAKVGVLLAGAGFSLVFPALGVVAVKAVPQQNQGAALATYTVFMDLSLGITGPLAGLVMSWAGVSVIYLAAAGLVVIALLLTWRLKKRPPQPLSETASSS",
    "product": ""
   },
   {
    "start": 3962699,
    "end": 3963256,
    "strand": -1,
    "locus_tag": "ctg1_3663",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3663</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3663</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,962,699 - 3,963,256,\n (total: 558 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3663\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3663\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3663\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3663\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGCAATCTGGTTAAATATGTCGGTATTGGTCTGCTGGTTATGGGGCTTGCGGCTTGTGATGACAAAGACACCAACGCTTCAACTGAAGGCACCGTTGCTGAAAGCAATGCTGCCGGGCAATCAGTAAATTTGTTGGACGGTAAACTCAGTTTCCAGCTACCTGCAGACATGACTGATCAGAGTGGCAAGCTGGGCACTCAGGCCAATAATATGCACGTTTACTCTGATGCCAGTGGGCAGAAAGCTGTCATTGTCATTATGGGTGATGATCCTAACCTGGATCTGGCAGTGCTGGCGAAGCGTCTGGAAGATCAACAGCGCAGCCGTGACCCACAACTGCAGGTCGTCACGAACAAAACCATCGAAGTTAATGGGCACAAGTTACAGCAGCTGGACAGTATTATCTCCGCAAAAGGCCAGACAGCTTATTCTTCTGTTGTTTTAGGCAATGTAGATAAGCAATTGTTGACCATGCAAATTACGTTGCCAGCGGACGATCAACAAAAAGCGCAAACCGCAGCGGAAAGCATCATTAACACTCTGGAAATTAAGTAA",
    "translation": "MRNLVKYVGIGLLVMGLAACDDKDTNASTEGTVAESNAAGQSVNLLDGKLSFQLPADMTDQSGKLGTQANNMHVYSDASGQKAVIVIMGDDPNLDLAVLAKRLEDQQRSRDPQLQVVTNKTIEVNGHKLQQLDSIISAKGQTAYSSVVLGNVDKQLLTMQITLPADDQQKAQTAAESIINTLEIK",
    "product": ""
   },
   {
    "start": 3963329,
    "end": 3963994,
    "strand": -1,
    "locus_tag": "ctg1_3664",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3664</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3664</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,963,329 - 3,963,994,\n (total: 666 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3664\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3664\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3664\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3664\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGCATTTTTCTCAATCGCAGCGCGTAAAAGCGTTGTTCTGGCTATCGCTATTTCATCTGCTGGTGATCACCTCCAGCAACTATCTGGTACAGCTCCCGATTACTATTTTTGGATTTCATACCACCTGGGGCGCGTTTAGCTTTCCGTTTATTTTTCTTGCCACCGACCTGACCGTGCGTATTTTTGGCGCGCCGCTGGCCCGACGCATTATCTTCGCGGTAATGATCCCGGCGTTGCTGATCTCCTACGTCATCTCATCGCTGTTCTATATGGGTTCATGGCAAGGGTTCGGCGCTCTCGCCCACTTCAACCTGTTTGTCGCACGTATTGCCACCGCCAGCTTCATGGCCTACGCGCTGGGGCAGATCCTCGACGTGCACGTCTTTAACCGCCTGCGCCAGAGTCGTCGCTGGTGGCTGGCCCCGACAGCTTCCACGCTGTTTGGGAACGTCAGTGACACGCTGGCCTTCTTCTTCATTGCCTTCTGGCGCAGCCCGGATGCCTTTATGGCCGAGCACTGGATGGAAATCGCGCTGGTCGATTACTGTTTCAAAGTGTTAATCAGTATCGTTTTCTTCCTGCCGATGTATGGCGTATTACTCAATATGCTGTTGAAAAGACTGGCAGACAAATCTGAAATCAACGCATTGCAGGCGAGTTAA",
    "translation": "MTHFSQSQRVKALFWLSLFHLLVITSSNYLVQLPITIFGFHTTWGAFSFPFIFLATDLTVRIFGAPLARRIIFAVMIPALLISYVISSLFYMGSWQGFGALAHFNLFVARIATASFMAYALGQILDVHVFNRLRQSRRWWLAPTASTLFGNVSDTLAFFFIAFWRSPDAFMAEHWMEIALVDYCFKVLISIVFFLPMYGVLLNMLLKRLADKSEINALQAS",
    "product": ""
   },
   {
    "start": 3964198,
    "end": 3964443,
    "strand": 1,
    "locus_tag": "ctg1_3665",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3665</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3665</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,964,198 - 3,964,443,\n (total: 246 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3665\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3665\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3665\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3665\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGATCTCTTTTCCAGCCCTGACCATACTTTAGACGCTCTCGGCCTGCGCTGCCCGGAACCCGTGATGATGGTGCGCAAAACTGTGCGCAATATGCAACCTGGCGAAACGTTGCTGATTATTGCTGATGATCCGGCGACGACACGCGATATTCCTGGGTTTTGTACCTTTATGGAACACGAACTGGTTGCTAAAGAAACGGATGGACTGCCTTATCGTTATTTGATTCGCAAAGGGCATTAA",
    "translation": "MTDLFSSPDHTLDALGLRCPEPVMMVRKTVRNMQPGETLLIIADDPATTRDIPGFCTFMEHELVAKETDGLPYRYLIRKGH",
    "product": ""
   },
   {
    "start": 3964556,
    "end": 3965050,
    "strand": -1,
    "locus_tag": "ctg1_3666",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3666</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3666</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,964,556 - 3,965,050,\n (total: 495 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3666\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3666\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3666\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3666\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTACGTTAAATTCAAATTACTGGGGAAGGCTCGCTGTTGATGAGTCAGAGGGTTTCGCAGAATACGTAACAGTTACGCTTAACAATGAAAAGCGAACTGTCTGGCTAAATATTTTTGAAGATGTCCTGCCAAATACCCCCATTGAGAAAATCGTTCCACTCCTGGATAGCCTCCCTGCATGTACTGAAATTATCCGCAACGTACTTGCGCAAAAGAAAGGAACAAATGCGTTTGTTGATGAGTTTATTGAGTTTCATTTAGATGAACTCGATGCTGAAACATTACAATCTCTTGATATAACTCCACCTACGCACGAGGCCTGTGCAAAGCAACTCACTTTACGTGGCGTTCATCTCTGGTTAGCAGCTCCTGCTCCAGGCAGGTTAAAAATGACCGTGGATTATGGGATATCAAAGGATATCTCGGATCAGTTGCTGGTATTTAATTTTGATGAGCAGGGTGAGTTGCTGGATATTACCTGGGAAAGTTAA",
    "translation": "MITLNSNYWGRLAVDESEGFAEYVTVTLNNEKRTVWLNIFEDVLPNTPIEKIVPLLDSLPACTEIIRNVLAQKKGTNAFVDEFIEFHLDELDAETLQSLDITPPTHEACAKQLTLRGVHLWLAAPAPGRLKMTVDYGISKDISDQLLVFNFDEQGELLDITWES",
    "product": ""
   },
   {
    "start": 3965159,
    "end": 3967360,
    "strand": -1,
    "locus_tag": "ctg1_3667",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3667</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3667</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,965,159 - 3,967,360,\n (total: 2202 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1037:heavy metal translocating P-type ATPase (Score: 547; E-value: 1.2e-165)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3667\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3667\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region3/ctg1_3667_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3667\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3667\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCGACTCCTGACAATCACGGCAAGAAAGCCCCTCACTTTGCTGCGTTCAAACCGCTAACCACGGCACAGAACACCAACGACTGTTGCTGCGACGGTGCATGTTCCAGCACGCCAACGCTCTCTGAAAACGTCTCCGGCACCCGCTATAGCTGGAAAGTCAGCGGCATGGACTGCGCCGCCTGCGCGCGCAAGGTAGAAAATGCCGTGCGCCAGCTTGCAGGCGTGAATCAGGTGCAGGTGTTGTTCGCCACCGAAAAACTGGTGGTGGATGCCGACAATGACATCCGTGCCCAGGTTGAATCTGCGGTGCAAAAAGCGGGCTATTCCCTGCGCGATGAACAGGCAGCCGCAGAACAACAAGAATCACGCCTGAAAGAGAATCTGCCGCTGATTACGCTAATCGTGTTGATGGCAATCAGCTGGGGTCTGGAGCAGTTTAATCATCCGTTCGGTCAACTGGCGTTTATCGCGACCACACTGTTTGGGCTGTACCCGATTGCGCGCCAGGCATTACGGCTGATCAAATCGGGCAGCTACTTCGCCATTGAAACGTTAATGAGCGTAGCCGCCATTGGCGCGCTGTTTATTGGCGCAACGGCTGAAGCTGCGATGGTGTTGCTGCTGTTTTTGATTGGTGAACGACTGGAAGGCTGGGCCGCCAGCCGCGCGCGTCAGGGCGTTAGCGCGTTAATGGCGCTGAAACCAGAAACCGCCACGCGCCTGCGTAATGGCAAGCGTGAAGAGGTAGCAATTAACAGCCTGCGTCCGGGCGATGTTATCGAAGTTGCGGCAGGTGGGCGTTTACCTGCCGACGGTAAACTGCTCTCGCCCTTTGCCAGTTTTGATGAAAGCGCCCTGACCGGCGAATCCATTCCGGTGGAGCGCGCGACGGGTGATAAAGTTCCTGCAGGCGCCACCAGCGTAGACCGTCTGGTAACGCTGGAAGTGCTGTCAGAACCGGGTGCCAGCGCCATTGACCGGATTCTGAAACTGATCGAAGAAGCCGAAGAGCGCCGCGCGCCCATTGAGCGGTTTATCGACCGTTTCAGCCGTATCTACACGCCCGCGATTATGGCCGTCGCCCTGCTGGTGACGCTGGTGCCGCCGCTGCTGTTTGCCGCAAGCTGGCAGGAGTGGATTTATAAAGGTCTGACGCTGCTGCTGATTGGCTGCCCGTGTGCGTTAGTTATCTCCACGCCTGCGGCGATAACCTCCGGGTTGGCAGCAGCGGCACGCCGCGGGGCGTTGATTAAAGGCGGTGCGGCGCTGGAACAACTAGGTCGTGTTACCCAGGTGGCGTTTGATAAAACCGGTACGCTGACCGTCGGTAAACCGCGCGTTACCGCGATTCATCCGGCAACGGGTATTAGTGAATCTGAACTGCTGACACTGGCAGCGGCGGTCGAGCAAGGCGCGACGCATCCACTGGCGCAGGCCATCGTACGCGAAGCACAGGTTGCTGAACTCGCCATTCCCGCCGCCGAATCACAGCGGGCGCTGGTCGGGTCTGGTATTGAAGCACTGATTAACGGTGAGCGCGTGTTGATATGCGCTGCCGGAAAACATCCGGCTGTTGCATTTGCTGGTTTAATTAACGAACTGGAAAGCGCCGGGCAAACGGTAGTACTGGTGGTGCGTAACGATGAAGTGCTGGGTGTCATTGCATTGCAGGATACCCTGCGCGCCGACGCCGTAACTGCCATCAGCGAACTGAGCGCCCTGGGTGTCAAAGGGGTGATCCTCACTGGCGATAATCCACGCGCAGCGGCGGCAATCGCCGGTGAACTGGGGCTGGAATTTAAAGCGGGCCTGTTGCCAGAAGATAAAGTCAAAGCGGTGACCGAGCTGAATCAACATGCGCCGCTGGCGATGGTCGGTGATGGTATTAACGACGCGCCAGCGATGAAAGCTGCCGCTATTGGGATTGCAATGGGCAGTGGCACAGATGTGGCGCTGGAAACCGCCGACGCAGCATTAACCCATAACCACCTGCGCGGCCTGGCGCAGATGATTGAACTGGCACGCGCCACTCACGCCAATATCCGCCAGAACATCACCATTGCATTGGGGCTGAAAGGGATCTTCCTCGTCACCACGCTATTAGGAATGACTGGCCTTTGGCTGGCGGTGCTGGCAGATACGGGTGCAACAGTGCTGGTGACGGCGAATGCGTTAAGGTTGTTGTGCAGGAAGGGGTAG",
    "translation": "MSTPDNHGKKAPHFAAFKPLTTAQNTNDCCCDGACSSTPTLSENVSGTRYSWKVSGMDCAACARKVENAVRQLAGVNQVQVLFATEKLVVDADNDIRAQVESAVQKAGYSLRDEQAAAEQQESRLKENLPLITLIVLMAISWGLEQFNHPFGQLAFIATTLFGLYPIARQALRLIKSGSYFAIETLMSVAAIGALFIGATAEAAMVLLLFLIGERLEGWAASRARQGVSALMALKPETATRLRNGKREEVAINSLRPGDVIEVAAGGRLPADGKLLSPFASFDESALTGESIPVERATGDKVPAGATSVDRLVTLEVLSEPGASAIDRILKLIEEAEERRAPIERFIDRFSRIYTPAIMAVALLVTLVPPLLFAASWQEWIYKGLTLLLIGCPCALVISTPAAITSGLAAAARRGALIKGGAALEQLGRVTQVAFDKTGTLTVGKPRVTAIHPATGISESELLTLAAAVEQGATHPLAQAIVREAQVAELAIPAAESQRALVGSGIEALINGERVLICAAGKHPAVAFAGLINELESAGQTVVLVVRNDEVLGVIALQDTLRADAVTAISELSALGVKGVILTGDNPRAAAAIAGELGLEFKAGLLPEDKVKAVTELNQHAPLAMVGDGINDAPAMKAAAIGIAMGSGTDVALETADAALTHNHLRGLAQMIELARATHANIRQNITIALGLKGIFLVTTLLGMTGLWLAVLADTGATVLVTANALRLLCRKG",
    "product": ""
   },
   {
    "start": 3967434,
    "end": 3968060,
    "strand": -1,
    "locus_tag": "ctg1_3668",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3668</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3668</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,967,434 - 3,968,060,\n (total: 627 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg1_3668\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg1_3668\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3668\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg1_3668\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTTTGGTCGTTTATCGCTGTCTGTCTTTCCGCATGGCTATCTGTGGATGCATCGTATCGTGGGCCAACCTGGCAACGCTGGGTATTTAAACCATTAACCCTTCTTCTCCTGCTGTTGCTGGCCTGGCAAGCGCCGATGTTCGACGCCATTAGTTATCTGGTGCTGGCGGGACTGTGCGCCTCACTGCTGGGCGATGCGCTAACCCTGTTGCCACGTCAACGTCTGATGTACGCCATCGGCGCATTTTTCCTCTCGCACCTGCTGTACACCATCTATTTCGCCAGTCAGATGACGCTCTCTTTCTTCTGGCCTCTGCCACTGGTGTTGCTGGTGCTGGGCGCGCTGTTACTGGCGATTATCTGGACGCGTCTGGAAGAGTATCGTTGGCCTATCTGCACGTTTATCGGCATGACGCTGGTGATGGTGTGGCTGGCAGGTGAACTGTGGTTCTTCCGTCCGACCGCTCCGGCGCTCTCTGCGTTTGTCGGCGCTTCGTTGCTGTTTATCAGTAACTTTGTCTGGCTGGGTAGTCACTATCGCCGACGCTTCCGTGCGGACAACGCGATTGCTGCGGCCTGCTACTTTGCCGGACATTTCCTCATCGTCCGCTCGCTGTATCTCTGA",
    "translation": "MLWSFIAVCLSAWLSVDASYRGPTWQRWVFKPLTLLLLLLLAWQAPMFDAISYLVLAGLCASLLGDALTLLPRQRLMYAIGAFFLSHLLYTIYFASQMTLSFFWPLPLVLLVLGALLLAIIWTRLEEYRWPICTFIGMTLVMVWLAGELWFFRPTAPALSAFVGASLLFISNFVWLGSHYRRRFRADNAIAAACYFAGHFLIVRSLYL",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 3944882,
    "end": 3948470,
    "tool": "rule-based-clusters",
    "neighbouring_start": 3924882,
    "neighbouring_end": 3968470,
    "product": "arylpolyene",
    "category": "PKS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": [
    {
     "loc": 3941731,
     "len": 15
    }
   ]
  },
  "type": "arylpolyene",
  "products": [
   "arylpolyene"
  ],
  "product_categories": [
   "PKS"
  ],
  "cssClass": "PKS arylpolyene",
  "anchor": "r1c3"
 }
};
var details_data = {
 "nrpspks": {
  "r1c1": {
   "id": "r1c1",
   "orfs": [
    {
     "id": "ctg1_287",
     "sequence": "MIAKDFAQQLFDLHDRVAFVTGAGSGIGQMIALAFASAGARVVCFDLREDGGLKETVNHIEALGGQALYYTGDVRELRDLRSAVALAKTHFGRLDIAVNAAGIANANPALEMESEQWQRVIDINLTGVWNSCKAEAELMVENGGGSIINIASMSGIIVNRGLEQAHYNSSKAGVIHLSKSLAMEWVSNGIRVNSISPGYTATPMNTRPEMVHQTREFESQTPIQRMAKVEEMAGPALFLASDAASFCTGVDLVVDGGFICW",
     "domains": [
      {
       "type": "PKS_KR",
       "start": 16,
       "end": 134,
       "predictions": [
        [
         "KR activity",
         "inactive"
        ],
        [
         "KR stereochemistry",
         "C1"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "VAFVTGAGSGIGQMIALAFASAGARVVCFDLREDGGLKETVNHIEALGGQALYYTGDVRELRDLRSAVALAKTHFGRLDIAVNAAGIANANPALEMESEQWQRVIDINLTGVWNSCKA",
       "dna_sequence": "GTCGCCTTTGTCACTGGCGCAGGTAGCGGTATCGGACAAATGATCGCTCTGGCTTTTGCCAGCGCAGGCGCACGAGTGGTGTGTTTTGATCTACGGGAAGATGGCGGACTTAAAGAGACGGTTAATCATATCGAAGCACTTGGTGGACAAGCCTTGTATTACACGGGCGATGTTCGGGAGTTGAGAGATCTTCGCTCAGCAGTCGCTCTGGCAAAAACACATTTTGGTCGTCTGGATATTGCCGTAAACGCCGCTGGAATCGCTAACGCGAACCCGGCGCTGGAAATGGAAAGCGAGCAATGGCAACGCGTTATAGATATCAACCTGACTGGTGTGTGGAATTCCTGTAAGGCG",
       "abbreviation": "KR",
       "html_class": "jsdomain-mod-kr"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg1_288",
     "sequence": "MQRNFQGKTVVITGACRGIGAGIAERFARDGANLVMVSNAARVHETAEQLRQRYQADILSLEVDVTDEAQVQALYEQAAARFGSIDVSIQNAGIITIDYFDRMPTADFEKVLAVNTTAVWLCCREAAKYMVKQNHGCLINTSSGQGRQGFIYTPHYAASKMGVIGITQSLAHELAQWNITVNAFCPGIIESEMWDYNDRVWGEILSTDDKRYGKGELMAEWVEGIPMKRAGKPEDVAGLVAFLASDDARYLTGQTINIDGGLIMS",
     "domains": [
      {
       "type": "PKS_KR",
       "start": 8,
       "end": 167,
       "predictions": [
        [
         "KR activity",
         "inactive"
        ],
        [
         "KR stereochemistry",
         "C1"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "TVVITGACRGIGAGIAERFARDGANLVMVSNAARVHETAEQLRQRYQADILSLEVDVTDEAQVQALYEQAAARFGSIDVSIQNAGIITIDYFDRMPTADFEKVLAVNTTAVWLCCREAAKYMVKQNHGCLINTSSGQGRQGFIYTPHYAASKMGVIGIT",
       "dna_sequence": "ACTGTAGTTATTACCGGGGCATGCCGGGGAATTGGGGCCGGGATCGCTGAACGCTTCGCCCGCGATGGCGCAAATCTGGTGATGGTTTCTAACGCTGCACGCGTTCATGAAACTGCTGAGCAACTGCGCCAACGTTATCAGGCTGACATTTTGTCATTAGAAGTCGATGTGACAGATGAAGCACAAGTACAGGCACTCTATGAACAAGCGGCTGCACGTTTTGGCAGCATCGATGTTTCCATCCAGAATGCGGGCATTATCACCATCGATTATTTTGATCGGATGCCGACTGCTGATTTCGAAAAAGTGCTGGCGGTGAACACGACGGCAGTCTGGCTCTGCTGCCGGGAAGCAGCCAAATATATGGTGAAACAGAATCACGGCTGCCTGATCAACACCTCTTCCGGCCAGGGACGTCAGGGGTTTATCTATACCCCACACTATGCAGCCAGCAAAATGGGGGTGATCGGCATTACG",
       "abbreviation": "KR",
       "html_class": "jsdomain-mod-kr"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg1_297",
     "sequence": "MNALSGLQKSCQFNILQDSVGLISVAHQAVLRLSSVSNMVDMKTTHTSLPFAGHTLHFVEFDPVSFREQDLLWLPHYAQLQHAGRKRKTEHLAGRIAAVYALREYGYKCVPAIGELRQPVWPAEVYGSISHCGTTALAVVSRQQIGIDIEEIFSVQTARELTDNIITPAEHERLAECGLTFSLALTLAFSAKESAFKTGEIQTDAGFQHYQIGNCQHQQMKISGPNGDHIVQWLVRGNNVITLCRADKHPHTAACGLSGG",
     "domains": [
      {
       "type": "ACPS",
       "start": 144,
       "end": 197,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "IGIDIEEIFSVQTARELTDNIITPAEHERLAECGLTFSLALTLAFSAKESAFK",
       "dna_sequence": "ATTGGCATTGATATCGAAGAGATTTTCTCTGTACAAACCGCAAGAGAATTGACAGACAACATTATTACACCAGCAGAACACGAGCGACTCGCAGAATGCGGTTTAACCTTTTCTCTGGCGCTGACACTGGCATTTTCCGCCAAAGAGAGCGCATTTAAG",
       "abbreviation": "",
       "html_class": "jsdomain-other"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg1_301",
     "sequence": "MSQHLPLVAAQPGIWMAEKLSDLPSAWSVAHYVELTGDVDAPLLARAVVAGLAQADTLRMRFTEDNGEVWQWVDDALTFELPEIIDLRTNIDPHGTAQALMQADLQQDLRVDSGKPLVFHQLIQVADNRWYWYQRYHHLLVDGFSFPVITRQIANIYCAWMRGEPTPASPFTPFADVVEEYQQYRESEAWQRDAAFWAEQRRQLPPPASLSPVPLPGRSASADILRLKLEFNGGEFRQLATQLSGLQRTDIALALAALWLGRLCNHMDYAAGFIFMRRLGSAALTATGPVLNVLPLGIHIEAQETLPQLAARLAAQLKKMRRHQRYDAEQIVRDSGRVAGEEPLFGPVLNIKVFDYQLDIPDVQAQTHTLATGPVNDLELALFPDEHGDLSIEILANKQRYDEPTLIQHAERLKMLTAQFAADPARLCGDVDIMLPEEYAQLAQINATQVEIPETTLSALVAEQAAKTPDAPALADVRYQFSYREMREQVVALANLLRERGVKPGDSVAVALPRSVFLTMALHAIVEAGAAWLPLDTGYPDDRLKMMLEDACPSLLITTDDQLPRFSDIPNLTSLCYNAPLTPQGSAPLQLSQPHHTAYIIFTSGSTGRPKGVMVGQTAIVNRLLWMQNHYTLTGEDVVAQKTPCSFDVSVWEFFWPFIAGAKLVMAEPEAHRDPLAMQQFFAEYGVTTTHFVPSMLAAFVASLTSETARQSCATLKQVFCSGEALPADLCREWQQLTGAPLHNLYGPTEAAVDVSWYPAFGAELAAVRGSSVPIGYPVWNTGLRILDAMMHPVPPGVAGDLYLTGIQLAQGYLGRPDLTASRFIADPFAPGERMYRTGDVARWLDNGAVEYLGRSDDQLKIRGQRIELGEIDRVMQALPDVEQAVTHACVINQAAATGGDARQLVGYLVSQSGLPLDTSTLQAQLREKLPPHMVPVVLLQLPQLPLSANGKLDRKALPLPELKAQAPGRAPKAGSETIIAAAFSSLLGCDVQDADADFFALGGHSLLAMKLAAQLSRQFARQMTPGQVMVASTVAKLATVIDGEEDSSRRMGFETILPLREGNGPTLFCFHPASGFAWQFSVLSRYLDPQWSIIGIQSPRPHGPMQTAANLDEVCEAHLATLLEQQPHGPYYLLGYSLGGTLAQGIAARLRARGEQVAFLGLLDTWPPETQNWQEKEANGLDPEVLAEINREREAFLAAQQGSTSTELFTTIEGNYADAVRLLTTAHSVPFDGKATLFVAERTLQEGMSPERAWSPWIAELDIYRLDCAHVDIISPGYFKQIGPLIRTSINN",
     "domains": [
      {
       "type": "Condensation_Starter",
       "start": 2,
       "end": 300,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_C_190411_273.faa&amp;Sequence=%3Eall_C_190411_273.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "QHLPLVAAQPGIWMAEKLSDLPSAWSVAHYVELTGDVDAPLLARAVVAGLAQADTLRMRFTEDNGEVWQWVDDALTFELPEIIDLRTNIDPHGTAQALMQADLQQDLRVDSGKPLVFHQLIQVADNRWYWYQRYHHLLVDGFSFPVITRQIANIYCAWMRGEPTPASPFTPFADVVEEYQQYRESEAWQRDAAFWAEQRRQLPPPASLSPVPLPGRSASADILRLKLEFNGGEFRQLATQLSGLQRTDIALALAALWLGRLCNHMDYAAGFIFMRRLGSAALTATGPVLNVLPLGIHI",
       "dna_sequence": "CAGCATTTACCTTTAGTTGCCGCACAGCCCGGCATCTGGATGGCAGAAAAACTGTCGGATTTACCCTCCGCCTGGAGCGTGGCGCATTACGTTGAGTTAACCGGAGATGTTGATGCGCCATTACTGGCTCGCGCGGTGGTTGCCGGATTAGCGCAAGCAGATACGCTGCGGATGCGTTTTACGGAAGATAACGGCGAAGTCTGGCAATGGGTCGATGATGCGCTGACGTTCGAACTGCCAGAAATTATCGACCTGCGAACCAACATTGATCCGCACGGTACTGCGCAGGCATTAATGCAGGCGGATTTGCAACAAGATCTGCGCGTCGATAGCGGTAAACCTCTGGTTTTTCATCAACTGATACAGGTGGCAGATAACCGCTGGTACTGGTATCAGCGTTACCACCATTTGCTGGTCGATGGCTTCAGTTTCCCGGTCATTACCCGCCAGATCGCCAACATTTACTGTGCATGGATGCGTGGCGAACCAACACCGGCTTCGCCGTTTACGCCTTTCGCTGACGTGGTGGAAGAGTACCAGCAGTATCGCGAAAGCGAAGCCTGGCAGCGTGATGCGGCATTCTGGGCGGAGCAACGTCGTCAACTACCACCGCCCGCGTCACTTTCTCCAGTCCCTTTACCGGGGCGCAGCGCCTCGGCAGATATTTTGCGTCTGAAACTGGAATTTAACGGCGGGGAATTCCGCCAGTTGGCTACGCAACTTTCAGGTTTACAACGTACCGATATAGCCCTTGCGCTGGCGGCTTTGTGGCTGGGGCGATTGTGCAACCACATGGACTATGCCGCCGGATTTATCTTTATGCGTCGACTGGGCTCAGCTGCGCTGACGGCTACCGGACCTGTGCTCAACGTGTTGCCGTTGGGTATTCACATT",
       "abbreviation": "C",
       "html_class": "jsdomain-condensation"
      },
      {
       "type": "AMP-binding",
       "start": 461,
       "end": 863,
       "predictions": [
        [
         "substrate consensus",
         "Ser"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "AEQAAKTPDAPALADVRYQFSYREMREQVVALANLLRERGVKPGDSVAVALPRSVFLTMALHAIVEAGAAWLPLDTGYPDDRLKMMLEDACPSLLITTDDQLPRFSDIPNLTSLCYNAPLTPQGSAPLQLSQPHHTAYIIFTSGSTGRPKGVMVGQTAIVNRLLWMQNHYTLTGEDVVAQKTPCSFDVSVWEFFWPFIAGAKLVMAEPEAHRDPLAMQQFFAEYGVTTTHFVPSMLAAFVASLTSETARQSCATLKQVFCSGEALPADLCREWQQLTGAPLHNLYGPTEAAVDVSWYPAFGAELAAVRGSSVPIGYPVWNTGLRILDAMMHPVPPGVAGDLYLTGIQLAQGYLGRPDLTASRFIADPFAPGERMYRTGDVARWLDNGAVEYLGRSDDQLKIR",
       "dna_sequence": "GCAGAACAGGCGGCAAAAACGCCGGATGCTCCGGCACTGGCAGATGTGCGTTACCAGTTCAGTTATCGGGAAATGCGCGAGCAGGTGGTGGCGCTGGCGAATCTGCTGCGTGAGCGCGGCGTCAAACCTGGCGACAGCGTAGCGGTGGCACTACCGCGCTCGGTCTTTTTGACTATGGCGCTACATGCGATAGTTGAAGCAGGTGCGGCCTGGCTACCGCTGGATACGGGCTATCCGGACGATCGCCTGAAAATGATGCTGGAAGATGCGTGTCCGTCACTGTTAATCACCACCGATGATCAACTGCCGCGCTTTAGCGATATCCCCAATTTAACCAGTCTTTGCTATAACGCCCCGCTTACACCGCAGGGCAGTGCGCCGCTGCAACTTTCACAACCGCACCACACGGCTTATATCATCTTTACCTCCGGTTCCACCGGCAGGCCGAAAGGGGTGATGGTCGGGCAGACGGCTATCGTTAACCGCCTGTTATGGATGCAAAACCACTACACGCTCACAGGCGAAGATGTTGTTGCCCAAAAAACGCCGTGCAGTTTTGATGTCTCGGTGTGGGAGTTTTTCTGGCCGTTTATTGCTGGGGCGAAACTGGTGATGGCTGAACCGGAAGCGCACCGCGATCCGCTCGCTATGCAACAATTCTTTGCCGAATATGGCGTAACGACCACGCATTTTGTGCCGTCGATGCTGGCGGCGTTTGTTGCTTCGCTGACGTCGGAAACCGCTCGCCAGAGTTGCGCGACGTTGAAACAGGTTTTCTGTAGTGGAGAAGCCTTACCAGCCGATTTATGTCGCGAATGGCAGCAGTTAACTGGCGCGCCGTTACATAATCTTTATGGCCCGACGGAAGCGGCGGTGGATGTGAGCTGGTATCCAGCCTTTGGTGCTGAACTTGCAGCGGTACGCGGCAGCAGTGTGCCGATTGGCTACCCGGTGTGGAACACGGGCCTGCGCATTCTCGATGCGATGATGCATCCGGTGCCGCCGGGTGTGGCAGGCGATCTCTATCTCACCGGTATTCAACTGGCGCAGGGGTATCTTGGACGACCCGATCTGACAGCCAGCCGCTTTATTGCCGATCCTTTCGCGCCAGGTGAACGGATGTACCGTACCGGAGATGTTGCCCGCTGGCTGGATAACGGCGCGGTGGAGTATCTCGGGCGTAGTGATGATCAGCTAAAAATTCGT",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PCP",
       "start": 976,
       "end": 1045,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "ETIIAAAFSSLLGCDVQDADADFFALGGHSLLAMKLAAQLSRQFARQMTPGQVMVASTVAKLATVIDGE",
       "dna_sequence": "GAAACGATTATCGCCGCGGCGTTCTCGTCATTGCTGGGTTGTGACGTGCAGGATGCCGATGCTGATTTCTTTGCGCTTGGCGGTCATTCACTACTGGCAATGAAACTGGCTGCGCAGTTAAGTCGACAGTTTGCCCGTCAGATGACGCCGGGGCAGGTGATGGTCGCGTCAACCGTCGCCAAACTGGCAACGGTTATTGATGGTGAA",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "Thioesterase",
       "start": 1066,
       "end": 1276,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "TLFCFHPASGFAWQFSVLSRYLDPQWSIIGIQSPRPHGPMQTAANLDEVCEAHLATLLEQQPHGPYYLLGYSLGGTLAQGIAARLRARGEQVAFLGLLDTWPPETQNWQEKEANGLDPEVLAEINREREAFLAAQQGSTSTELFTTIEGNYADAVRLLTTAHSVPFDGKATLFVAERTLQEGMSPERAWSPWIAELDIYRLDCAHVDIIS",
       "dna_sequence": "ACGCTGTTTTGTTTCCATCCAGCATCTGGTTTTGCCTGGCAGTTTAGCGTGCTCTCGCGTTATCTAGATCCTCAATGGTCGATTATTGGCATCCAGTCTCCGCGCCCTCATGGCCCCATGCAGACGGCGGCAAACCTGGATGAAGTCTGCGAAGCGCATCTGGCAACGTTACTTGAACAACAACCGCACGGTCCTTATTACCTGCTGGGGTATTCGCTGGGCGGTACGCTGGCGCAGGGAATAGCGGCAAGGCTGCGTGCCCGTGGCGAACAGGTAGCATTTCTTGGCTTGCTGGATACCTGGCCGCCAGAAACGCAGAACTGGCAGGAAAAAGAAGCTAATGGTCTGGACCCGGAAGTGTTGGCGGAGATTAACCGCGAACGTGAAGCCTTCCTGGCGGCACAGCAGGGGAGTACTTCAACGGAGCTGTTTACCACCATTGAAGGCAACTACGCTGATGCAGTGCGCTTGTTGACCACTGCTCATAGTGTACCGTTTGACGGCAAAGCGACGCTGTTTGTTGCCGAACGTACTCTTCAGGAAGGAATGAGTCCCGAACGGGCCTGGTCGCCGTGGATAGCCGAGCTGGATATTTATCGTTTAGATTGTGCGCATGTGGATATTATTTCC",
       "abbreviation": "TE",
       "html_class": "jsdomain-terminal"
      }
     ],
     "modules": [
      {
       "start": 2,
       "end": 1276,
       "complete": true,
       "iterative": false,
       "monomer": "Ser",
       "multi_cds": null,
       "match_id": null
      }
     ]
    },
    {
     "id": "ctg1_309",
     "sequence": "MSIPFTRWPEEFARRYREKGYWQDLPLTDILTRHAASDSIAVIDGERQLSYRELNQAADNLACSLRRQGIKPGETALVQLGNVAELYITFFALLKLGVAPVLALFSHQRSELNAYASQIEPALLIADRQHALFSGDDFLNTFVAEHSSIRVVQLLNDSGEHNLQDAINHPAEDFTATPSPADEVAYFQLSGGTTGTPKLIPRTHNDYYYSVRRSVEICQFTQQTRYLCAIPAAHNYAMSSPGSLGVFLAGGTVVLAADPSATLCFPLIEKHQVNVTALVPPAVSLWLQALTEGESRAQLASLKLLQVGGARLSATLAARIPAEIGCQLQQVFGMAEGLVNYTRLDDSAEKIIHTQGYPMCPDDEVWVADADGNPLPQGEVGRLMTRGPYTFRGYYKSPQHNASAFDANGFYCSGDLISIDPEGYITVQGREKDQINRGGEKIAAEEIENLLLRHPAVIYAALVSMEDELMGEKSCAYLVVKEPLRAVQVRRFLREQGIAEFKLPDRVECVDSLPLTAVGKVDKKQLRQWLASRASA",
     "domains": [
      {
       "type": "AMP-binding",
       "start": 34,
       "end": 437,
       "predictions": [
        [
         "substrate consensus",
         "diOH-Bz"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "AASDSIAVIDGERQLSYRELNQAADNLACSLRRQGIKPGETALVQLGNVAELYITFFALLKLGVAPVLALFSHQRSELNAYASQIEPALLIADRQHALFSGDDFLNTFVAEHSSIRVVQLLNDSGEHNLQDAINHPAEDFTATPSPADEVAYFQLSGGTTGTPKLIPRTHNDYYYSVRRSVEICQFTQQTRYLCAIPAAHNYAMSSPGSLGVFLAGGTVVLAADPSATLCFPLIEKHQVNVTALVPPAVSLWLQALTEGESRAQLASLKLLQVGGARLSATLAARIPAEIGCQLQQVFGMAEGLVNYTRLDDSAEKIIHTQGYPMCPDDEVWVADADGNPLPQGEVGRLMTRGPYTFRGYYKSPQHNASAFDANGFYCSGDLISIDPEGYITVQGREKDQINR",
       "dna_sequence": "GCTGCGAGTGACAGCATCGCGGTTATCGACGGCGAGCGGCAGTTGAGTTACCGGGAGCTGAATCAGGCGGCGGATAACCTCGCCTGTAGTTTGCGCCGTCAGGGCATTAAACCCGGTGAAACCGCGCTGGTACAACTGGGTAACGTCGCTGAATTGTATATTACCTTTTTCGCGCTGCTGAAACTGGGCGTTGCGCCGGTGCTGGCGCTGTTCAGTCATCAGCGTAGTGAACTGAACGCCTATGCCAGCCAGATTGAACCGGCGTTACTGATTGCCGATCGCCAACATGCGCTATTTAGCGGGGATGATTTCCTCAACACATTTGTTGCAGAGCATTCTTCCATTCGCGTGGTGCAACTGCTGAACGACAGCGGTGAGCATAACTTGCAGGATGCGATTAACCATCCGGCTGAGGATTTTACTGCCACGCCATCTCCTGCTGATGAAGTGGCCTATTTCCAGCTTTCCGGCGGCACCACCGGCACACCGAAACTGATCCCGCGCACTCATAACGACTACTACTACAGCGTGCGTCGTAGCGTCGAGATTTGTCAGTTCACACAACAGACGCGCTACCTGTGCGCGATCCCGGCGGCTCATAACTACGCCATGAGTTCGCCGGGATCGTTGGGGGTATTTCTCGCTGGCGGCACTGTCGTTCTGGCTGCCGACCCCAGCGCCACGCTTTGTTTCCCATTGATTGAAAAACATCAGGTGAACGTCACCGCGCTGGTGCCGCCAGCAGTCAGCCTGTGGTTACAGGCGCTGACCGAAGGTGAAAGCCGGGCGCAGCTTGCCTCGCTGAAACTGTTACAGGTCGGTGGCGCACGTCTTTCTGCCACGCTTGCGGCGCGTATTCCCGCAGAGATTGGCTGCCAGTTACAGCAGGTATTCGGCATGGCGGAAGGGCTGGTGAACTACACCCGTCTTGATGATAGCGCGGAGAAAATTATCCATACCCAGGGCTATCCAATGTGTCCGGATGATGAAGTGTGGGTTGCCGATGCTGACGGAAATCCACTGCCGCAAGGGGAGGTTGGACGCCTGATGACGCGCGGGCCGTACACCTTCCGCGGCTATTACAAAAGTCCACAGCACAATGCCAGCGCCTTTGATGCCAACGGTTTTTACTGTTCCGGCGATCTGATCTCTATTGATCCAGAGGGGTACATCACCGTGCAGGGGCGCGAGAAAGATCAGATCAACCGT",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg1_310",
     "sequence": "MAIPKLQAYALPESHDIPHNKVNWTFEPQRAALLIHDMQDYFVSFWGENCPMMEQVIANIAALRNYCKQHNIPVYYTAQPKEQSDEDRALLNDMWGPGLTRSPEQQKVVDRLTPDADDTVLVKWRYSAFHRSPLEQMLKESGRNQLIITGVYAHIGCMTTATDAFMRDIKPFMVADALADFSRDEHLMSLKYVAGRSGRVVMTEELLPAPIPSTKAALREVILPLLDESDEPFDDDNLIDYGLDSVRMMALAARWRKVHGDIDFVMLAKNPTIDAWWKLLSREVK",
     "domains": [
      {
       "type": "PP-binding",
       "start": 216,
       "end": 275,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "ALREVILPLLDESDEPFDDDNLIDYGLDSVRMMALAARWRKVHGDIDFVMLAKNPTIDA",
       "dna_sequence": "GCGCTGCGAGAGGTGATCCTGCCGTTGCTGGACGAGTCCGATGAACCCTTCGATGACGACAACCTGATCGATTACGGTCTGGATTCGGTGCGCATGATGGCGCTGGCGGCGCGCTGGCGCAAAGTGCATGGCGATATCGATTTTGTCATGCTGGCGAAAAATCCGACCATCGATGCC",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg1_311",
     "sequence": "MDFSGKNVWVTGAGKGIGYATALAFVEAGAKVTGFDQAFTLEQYPFATEVMDVADAAQVAQVCQRLLAQTERLDVLVNAAGILRMGATDQLSKEDWQQTFSVNVGGAFNLFQQTMNQFRRQRGGAIVTVASDAAHTPRIGMSAYGASKAALKSLALSVGLELAGSGVRCNVVSPGSTDTDMQRTLWVSDDAEEQRIRGFGEQFKLGIPLGKIARPQEIANTILFLASDLASHITLQDIVVDGGSTLGA",
     "domains": [
      {
       "type": "PKS_KR",
       "start": 45,
       "end": 157,
       "predictions": [
        [
         "KR activity",
         "inactive"
        ],
        [
         "KR stereochemistry",
         "C2"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FATEVMDVADAAQVAQVCQRLLAQTERLDVLVNAAGILRMGATDQLSKEDWQQTFSVNVGGAFNLFQQTMNQFRRQRGGAIVTVASDAAHTPRIGMSAYGASKAALKSLALS",
       "dna_sequence": "TTTGCGACCGAAGTAATGGATGTAGCCGACGCTGCGCAGGTGGCGCAAGTGTGTCAGCGACTGTTAGCGCAAACGGAGCGACTGGACGTGCTGGTCAATGCGGCGGGAATTTTGCGCATGGGCGCGACCGATCAGCTCAGCAAGGAGGACTGGCAGCAGACTTTTTCGGTTAACGTCGGCGGTGCGTTTAACCTGTTCCAGCAAACCATGAACCAGTTTCGCCGTCAGCGGGGCGGGGCGATTGTCACTGTGGCGTCCGACGCCGCACACACGCCGCGTATTGGTATGAGTGCTTATGGCGCGTCGAAAGCGGCGCTGAAAAGCCTGGCGTTGAGC",
       "abbreviation": "KR",
       "html_class": "jsdomain-mod-kr"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg1_316",
     "sequence": "MTNNPLIPKSKLPQLGTTIFTQMSALAQQHQAINLSQGFPDFDGPRYLQERLAYHVDQGANQYAPMTGVQALREAIAQKTERLYGYQPDADSDITVTAGATEALYAAITALVRNGDEVICFDPSYDSYAPAIALSGGIVKRIALQPPHFRVDWQEFAALLSERTRLVILNTPHNPSATVWQQTDFSALWQAIAGHEIFVISDEVYEHINFSQQGHASVLAHPQLRERAVAVSSFGKTYHMTGWKVGYCVAPAPISAEIRKVHQYLTFSVNTPAQLALADMLRTEPEHYLALPDFYRQKRDILVNALSESRLEILPCEGTYFLLVDYSAVSSLDDVEFCQWLTREHGVAAIPLSVFCADPFPHKLIRLCFAKKESTLLAAAERLRQL",
     "domains": [
      {
       "type": "Aminotran_1_2",
       "start": 31,
       "end": 383,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "AINLSQGFPDFDGPRYLQERLAYHVDQGANQYAPMTGVQALREAIAQKTERLYGYQPDADSDITVTAGATEALYAAITALVRNGDEVICFDPSYDSYAPAIALSGGIVKRIALQPPHFRVDWQEFAALLSERTRLVILNTPHNPSATVWQQTDFSALWQAIAGHEIFVISDEVYEHINFSQQGHASVLAHPQLRERAVAVSSFGKTYHMTGWKVGYCVAPAPISAEIRKVHQYLTFSVNTPAQLALADMLRTEPEHYLALPDFYRQKRDILVNALSESRLEILPCEGTYFLLVDYSAVSSLDDVEFCQWLTREHGVAAIPLSVFCADPFPHKLIRLCFAKKESTLLAAAERL",
       "dna_sequence": "GCGATTAACCTGTCGCAAGGCTTTCCTGATTTTGATGGTCCGCGCTATTTGCAGGAGCGGCTGGCATACCATGTTGACCAGGGGGCAAACCAATACGCGCCTATGACTGGCGTGCAGGCCTTGCGCGAGGCGATTGCTCAGAAAACGGAACGTCTGTATGGCTATCAACCGGATGCCGATAGTGATATCACCGTAACGGCAGGGGCGACGGAAGCGTTATATGCAGCGATTACCGCATTGGTGCGCAATGGTGATGAAGTGATCTGCTTTGATCCCAGCTATGACAGTTACGCGCCCGCCATCGCGCTTTCGGGGGGAATAGTGAAACGTATTGCACTGCAACCACCGCATTTTCGCGTGGACTGGCAGGAATTTGCCGCATTGTTAAGCGAGCGCACCCGACTGGTGATCCTTAACACCCCGCATAACCCCAGTGCTACTGTCTGGCAGCAGACTGATTTTTCTGCTTTGTGGCAGGCAATTGCCGGGCACGAGATTTTTGTTATTAGCGATGAAGTTTACGAGCATATCAACTTTTCACAGCAGGGCCATGCCAGTGTGCTGGCGCATCCGCAACTGCGTGAGCGGGCGGTGGCGGTGTCATCGTTTGGTAAGACTTATCATATGACCGGCTGGAAAGTGGGCTATTGTGTTGCGCCTGCGCCCATCAGCGCCGAGATCCGCAAAGTGCATCAGTATCTGACTTTTTCGGTGAATACCCCGGCGCAGCTGGCCCTTGCCGATATGCTGCGAACAGAACCCGAACACTACCTTGCGTTACCGGACTTTTATCGCCAGAAGCGCGATATTCTGGTGAACGCCTTAAGTGAGAGTCGGCTGGAGATTTTACCGTGCGAAGGCACTTACTTTTTGCTGGTGGATTACAGCGCGGTTTCTTCGCTGGATGACGTTGAGTTTTGCCAGTGGCTGACGCGGGAGCATGGCGTGGCGGCGATCCCGCTGTCGGTATTTTGCGCCGATCCATTCCCCCATAAGCTCATTCGTCTCTGTTTTGCCAAGAAGGAATCGACGTTGCTGGCGGCAGCTGAACGCCTG",
       "abbreviation": "AmT",
       "html_class": "jsdomain-other"
      }
     ],
     "modules": []
    }
   ]
  },
  "r1c3": {
   "id": "r1c3",
   "orfs": [
    {
     "id": "ctg1_3643",
     "sequence": "MTRRVVITGMGGVTAFGENWQDVSARLLAYENAVRKMPEWQVYDGLHTLLGAPVDDFTLPEHYTRKRIRAMGRVSQMSTRASELALEQAGLIGDPILTSGETGIAYGSSTGSTGPVSEFATMLTEKHTNNITGTTYVQMMPHTTAVNTGLFFGLRGRVIPTSSACTSGSQAIGYAWEAIRHGYQTVMVAGGAEELCPSEAAVFDTLFATSQHNDAPKTTPSPFDENRDGLVIGEGAGTLILEELEHAKARGATIYGEIVGFATNCDAAHITQPQRETMQYCMEKSLKIAGLSASDIGYISAHGTATDRGDVAESQATVAIYGDNVPISSLKSYFGHTLGACGALEAWMSLQMMREGWFAPTLNLSQPDANCGALDYIMGEARKIDCEFLQSNNFAFGGINTSIIIKRWP",
     "domains": [
      {
       "type": "PKS_KS(Iterative-KS)",
       "start": 83,
       "end": 408,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LALEQAGLIGDPILTSGETGIAYGSSTGSTGPVSEFATMLTEKHTNNITGTTYVQMMPHTTAVNTGLFFGLRGRVIPTSSACTSGSQAIGYAWEAIRHGYQTVMVAGGAEELCPSEAAVFDTLFATSQHNDAPKTTPSPFDENRDGLVIGEGAGTLILEELEHAKARGATIYGEIVGFATNCDAAHITQPQRETMQYCMEKSLKIAGLSASDIGYISAHGTATDRGDVAESQATVAIYGDNVPISSLKSYFGHTLGACGALEAWMSLQMMREGWFAPTLNLSQPDANCGALDYIMGEARKIDCEFLQSNNFAFGGINTSIIIKRW",
       "dna_sequence": "CTGGCGTTAGAGCAGGCAGGGTTGATTGGCGATCCGATATTAACCAGCGGTGAAACGGGCATTGCGTACGGTTCATCGACCGGCAGTACCGGTCCGGTGAGCGAGTTCGCCACCATGCTGACGGAAAAGCACACCAATAACATCACTGGCACCACCTATGTGCAGATGATGCCGCACACCACCGCCGTTAATACCGGGCTATTTTTTGGCCTGCGCGGACGGGTGATCCCAACCTCCAGCGCCTGTACCTCCGGCAGCCAGGCGATCGGCTACGCGTGGGAAGCCATTCGTCACGGTTATCAAACGGTAATGGTTGCTGGTGGCGCCGAAGAGTTATGCCCTTCAGAAGCGGCGGTGTTTGATACGCTTTTCGCCACCAGCCAGCACAATGACGCGCCGAAAACCACGCCGTCGCCGTTCGATGAAAACCGCGACGGGCTGGTGATTGGCGAAGGCGCAGGCACGCTCATTCTCGAAGAACTGGAGCACGCCAAAGCGCGCGGCGCGACCATTTACGGTGAAATCGTTGGCTTTGCCACCAACTGCGACGCGGCACATATTACCCAGCCTCAGCGTGAGACCATGCAATATTGTATGGAAAAATCGTTAAAAATCGCCGGGTTAAGTGCAAGTGATATCGGCTATATTTCGGCGCATGGTACGGCGACTGATCGTGGTGATGTAGCAGAAAGCCAGGCGACGGTAGCAATTTATGGCGATAACGTACCGATCTCCTCGCTTAAAAGTTATTTTGGGCATACCCTTGGTGCCTGCGGAGCACTCGAAGCCTGGATGAGCTTACAAATGATGCGTGAAGGCTGGTTTGCGCCTACGCTAAATTTGAGCCAGCCAGATGCGAACTGCGGTGCGCTGGATTACATCATGGGTGAAGCCCGCAAGATTGATTGTGAGTTTTTGCAGAGTAACAACTTTGCCTTTGGTGGCATTAATACCTCCATCATCATAAAACGTTGG",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg1_3644",
     "sequence": "MSRSVLVTGASKGIGRAIACQLAADGFNIGVHYHRDAAGAQETLNTIVANGGNGRLLSFDVANREQCREVLEHEIAQHGAWYGVVSNAGIARDAAFPALSDDDWDAVIHTNLDSFYNVIQPCIMPMIGARQGGRIITLSSVSGVMGNRGQVNYSAAKAGIIGATKALAIELAKRKITVNCIAPGLIDTGMIEMEESALKEAMSMIPMKRMGQAEEVAGLASYLMSDIAGYVTRQVISINGGML",
     "domains": [
      {
       "type": "PKS_KR",
       "start": 3,
       "end": 158,
       "predictions": [
        [
         "KR activity",
         "inactive"
        ],
        [
         "KR stereochemistry",
         "C2"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "SVLVTGASKGIGRAIACQLAADGFNIGVHYHRDAAGAQETLNTIVANGGNGRLLSFDVANREQCREVLEHEIAQHGAWYGVVSNAGIARDAAFPALSDDDWDAVIHTNLDSFYNVIQPCIMPMIGARQGGRIITLSSVSGVMGNRGQVNYSAAKA",
       "dna_sequence": "TCAGTTCTGGTTACTGGTGCCAGCAAAGGCATTGGTCGCGCCATCGCCTGCCAACTGGCGGCAGACGGCTTTAATATTGGCGTTCACTATCACCGTGACGCCGCAGGCGCTCAGGAAACGCTGAATACCATTGTCGCCAACGGTGGTAACGGGCGTTTGCTCAGTTTCGACGTCGCAAACCGCGAACAGTGTCGGGAAGTGCTGGAGCACGAGATCGCGCAACACGGTGCCTGGTACGGCGTGGTTAGTAACGCCGGGATCGCCCGCGATGCCGCTTTTCCGGCTTTAAGCGATGACGACTGGGATGCGGTGATCCACACCAACCTCGACAGTTTCTACAACGTCATTCAGCCGTGCATTATGCCGATGATCGGCGCACGCCAGGGTGGACGCATCATCACGCTGTCCTCGGTTTCCGGCGTAATGGGCAATCGCGGCCAGGTGAACTACAGCGCTGCCAAAGCC",
       "abbreviation": "KR",
       "html_class": "jsdomain-mod-kr"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg1_3646",
     "sequence": "MIYISAVGMINALGNNLDEIAANLTRGSAPGMRPRAGWLQGHPQTVLAGVDGELPLIPEKFAAHRSRNNQVLLAALAQIQPQVDDAIAKYGRERIAIVLGTSTSGLHEGDTHVNLRTHGQPSTTWHYAQQELGDPSRFLSHWLALDGPAYTLSTACSSSARAMISGRRLIEAGLVDAAIVGGADTLSRMPINGFHSLESLSPTLCQPFGRDRAGITIGEGAGLMLLTREPQPIALLGVGESSDAYHISAPHPQGEGAIRAINQALTDAQLTPDDVGYINLHGTATQLNDQIESIVVNALFGERVPCSSTKHLTGHTLGAAGITEAAISMLILQRDLPLPAQDFSLSPRDPTLPPCGIIEKPQPLARPVILSNSFAFGGNNASILLGRVS",
     "domains": [
      {
       "type": "PKS_KS(Iterative-KS)",
       "start": 138,
       "end": 386,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LSHWLALDGPAYTLSTACSSSARAMISGRRLIEAGLVDAAIVGGADTLSRMPINGFHSLESLSPTLCQPFGRDRAGITIGEGAGLMLLTREPQPIALLGVGESSDAYHISAPHPQGEGAIRAINQALTDAQLTPDDVGYINLHGTATQLNDQIESIVVNALFGERVPCSSTKHLTGHTLGAAGITEAAISMLILQRDLPLPAQDFSLSPRDPTLPPCGIIEKPQPLARPVILSNSFAFGGNNASILLG",
       "dna_sequence": "CTCAGCCACTGGCTGGCGCTCGACGGCCCGGCATATACCCTTTCAACCGCCTGCTCTTCCAGCGCCAGAGCGATGATCAGCGGGCGCAGGCTTATCGAAGCGGGGCTGGTCGATGCTGCCATTGTGGGTGGCGCAGACACCCTGAGCCGGATGCCGATTAACGGTTTTCACAGTCTCGAATCGCTGTCGCCAACCTTATGTCAGCCGTTCGGCCGTGACCGTGCGGGCATCACCATTGGCGAAGGCGCGGGGCTAATGCTGCTGACCCGTGAACCGCAGCCCATCGCGTTGCTGGGCGTTGGTGAATCGAGCGACGCTTACCATATTTCGGCCCCGCATCCGCAGGGCGAAGGGGCAATCCGCGCTATTAACCAGGCGCTGACCGATGCGCAGCTTACGCCAGATGACGTCGGCTATATCAACCTGCACGGCACCGCCACACAACTCAACGATCAGATTGAATCAATAGTGGTTAACGCCCTGTTTGGCGAACGCGTACCGTGCAGCTCCACCAAACATTTGACCGGACACACGCTGGGCGCGGCGGGCATTACCGAGGCGGCAATCAGTATGTTGATCTTACAGCGTGATTTACCGCTGCCCGCTCAGGACTTCAGCCTGTCGCCACGCGATCCCACGCTACCACCGTGCGGCATTATCGAAAAACCACAGCCGCTGGCACGTCCGGTGATCCTGTCCAATTCTTTCGCCTTTGGCGGCAATAACGCCAGCATTCTGCTCGGG",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg1_3653",
     "sequence": "MKQTLPLARWLTAPRPDDTPIAWLDESTWTLSDLRHDVAQLICRLQQQPGERWALCFENSYLFIVALLATLHAGKTPVLPGHNRVIQLNEQRELFDGVLSDSELNWQGSLLLVASSPQVATQSFTFAAIAPDAYIELFTSGSTGQPKRVIKPVRLLDREAELLAERLGARLAGSRVVGSVLPQHLYGLTFRVFLPMALGLPLHAAMLWYVEQFAALSHQHRYIFISSPAFLKRLDTQLSPPPVQVLLSAGGELPWQDVQHTASWLRVWPDEIYGSTETGVIAWRYREQEQRRWRPFPGMQFQAEDDAFRLFSPLMEEDSGLLLDDILQFSEDGQFHLMGRRGRIVKIEEKRISLQEVEQRLLALDGIHEAAAVPVTRGGRQSIGVLLVLNDEARLQWQNGGGHSQEMAWRRLLRPTLEPVAIPRYWRVIDEMPVNSMNKRVYAQLQELFHEAP",
     "domains": [
      {
       "type": "AMP-binding",
       "start": 14,
       "end": 306,
       "predictions": [
        [
         "substrate consensus",
         "X"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "RPDDTPIAWLDESTWTLSDLRHDVAQLICRLQQQPGERWALCFENSYLFIVALLATLHAGKTPVLPGHNRVIQLNEQRELFDGVLSDSELNWQGSLLLVASSPQVATQSFTFAAIAPDAYIELFTSGSTGQPKRVIKPVRLLDREAELLAERLGARLAGSRVVGSVLPQHLYGLTFRVFLPMALGLPLHAAMLWYVEQFAALSHQHRYIFISSPAFLKRLDTQLSPPPVQVLLSAGGELPWQDVQHTASWLRVWPDEIYGSTETGVIAWRYREQEQRRWRPFPGMQFQAEDD",
       "dna_sequence": "CGCCCTGATGACACGCCCATTGCGTGGCTGGACGAAAGCACCTGGACGCTGAGCGATTTGCGTCACGATGTCGCGCAACTTATCTGCCGCTTGCAGCAACAGCCAGGTGAACGCTGGGCGCTGTGCTTTGAGAACAGCTATCTGTTTATCGTTGCCCTGCTCGCCACGCTACACGCCGGAAAAACACCGGTGCTTCCGGGGCATAACCGCGTTATCCAGCTTAATGAGCAACGTGAACTTTTTGATGGTGTGCTTAGCGACAGCGAACTTAACTGGCAAGGTTCATTGCTGTTGGTAGCAAGCTCCCCACAAGTCGCGACACAATCATTCACCTTTGCCGCTATAGCGCCTGACGCTTATATCGAGCTGTTTACCTCTGGTTCCACAGGGCAGCCGAAGCGGGTGATTAAACCTGTTCGTTTGTTGGACCGTGAAGCAGAACTGCTGGCTGAACGATTAGGTGCACGTCTTGCCGGAAGTCGTGTCGTCGGTTCCGTATTGCCGCAGCATTTGTACGGCCTGACTTTTCGCGTTTTCCTGCCCATGGCGCTGGGATTACCGCTCCATGCCGCCATGCTCTGGTATGTCGAACAGTTTGCCGCGTTGAGTCATCAGCATCGCTATATCTTCATCAGCAGTCCGGCATTTTTGAAGCGTCTGGATACACAGCTTTCCCCGCCCCCCGTTCAGGTGCTTCTTTCTGCTGGTGGTGAGCTACCGTGGCAGGACGTACAACACACCGCGAGCTGGCTGCGCGTCTGGCCTGATGAAATCTACGGCAGCACGGAAACCGGCGTCATCGCCTGGCGTTACCGCGAACAAGAGCAACGCCGCTGGCGGCCCTTTCCAGGTATGCAGTTCCAGGCCGAAGATGAT",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg1_3655",
     "sequence": "MTEQQTVYQEVSALLVKLFEIDPQDIKPEARLYEDLELDSIDAVDMIVHLQKKTGKKIKPEEFKAVRTVQDVVEAVERLLQEA",
     "domains": [
      {
       "type": "PP-binding",
       "start": 9,
       "end": 76,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "EVSALLVKLFEIDPQDIKPEARLYEDLELDSIDAVDMIVHLQKKTGKKIKPEEFKAVRTVQDVVEAV",
       "dna_sequence": "GAAGTCTCAGCTCTGCTGGTTAAGCTGTTTGAAATCGATCCGCAAGACATCAAACCTGAAGCGCGCCTGTACGAAGATTTGGAGCTGGACAGTATCGACGCCGTTGACATGATTGTGCACCTGCAAAAGAAAACCGGTAAGAAAATCAAGCCGGAAGAGTTTAAAGCAGTGCGTACAGTCCAGGATGTCGTCGAGGCTGTA",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg1_3656",
     "sequence": "MQALYLEIKNLIISTLNLDELSPDDIETEAPLFGDGLGLDSIDALELGLAVKNEYGVVLSAESEEMRQHFFSVATLASFIAAQRA",
     "domains": [
      {
       "type": "PP-binding",
       "start": 7,
       "end": 81,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "IKNLIISTLNLDELSPDDIETEAPLFGDGLGLDSIDALELGLAVKNEYGVVLSAESEEMRQHFFSVATLASFIA",
       "dna_sequence": "ATCAAAAACCTCATTATCTCTACTCTCAATCTGGATGAGCTTTCACCAGATGATATCGAAACCGAAGCGCCGTTGTTTGGTGATGGTTTAGGGCTGGACTCTATCGATGCCCTGGAACTGGGGCTGGCAGTGAAAAATGAATATGGCGTTGTACTTTCTGCGGAAAGTGAAGAGATGCGTCAGCACTTTTTCTCCGTCGCCACTCTGGCCTCTTTCATTGCT",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": []
    }
   ]
  }
 }
};
var resultsData = {
 "r1c1": {
  "antismash.modules.tfbs_finder": [
   {
    "name": "ZuR",
    "start": 323646,
    "end": 323661,
    "confidence": "medium",
    "score": 21.495566637366238,
    "presequence": "TAA",
    "sequence": "TGCTTCTCATTTTCA",
    "postsequence": "TTG",
    "target": "TGAANNTCATTTTCA",
    "strand": 1,
    "matches": [
     true,
     true,
     false,
     false,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true
    ],
    "left": {
     "name": "ctg1_307",
     "location": 323616,
     "strand": -1
    },
    "contained_by_left": false,
    "right": {
     "name": "ctg1_308",
     "location": 323804,
     "strand": 1
    }
   },
   {
    "name": "ZuR",
    "start": 323761,
    "end": 323776,
    "confidence": "medium",
    "score": 21.004737449782187,
    "presequence": "AAA",
    "sequence": "TGATAATCATTATTA",
    "postsequence": "AAG",
    "target": "TGAANNTCATTTTCA",
    "strand": 1,
    "matches": [
     true,
     true,
     true,
     false,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     false,
     true,
     false,
     true
    ],
    "left": {
     "name": "ctg1_307",
     "location": 323616,
     "strand": -1
    },
    "contained_by_left": false,
    "right": {
     "name": "ctg1_308",
     "location": 323804,
     "strand": 1
    }
   },
   {
    "name": "NrtR",
    "start": 303516,
    "end": 303537,
    "confidence": "weak",
    "score": 22.186266955648406,
    "presequence": "TCT",
    "sequence": "TGTTCGTCAAATTGACGATGC",
    "postsequence": "CGG",
    "target": "TTNTNGTCRNNNTGACGATTA",
    "strand": 1,
    "matches": [
     true,
     false,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     false,
     false
    ],
    "left": {
     "name": "ctg1_292",
     "location": 303419,
     "strand": -1
    },
    "contained_by_left": false,
    "right": {
     "name": "ctg1_293",
     "location": 303522,
     "strand": -1
    }
   },
   {
    "name": "HypR",
    "start": 305057,
    "end": 305068,
    "confidence": "weak",
    "score": 20.419814980314158,
    "presequence": "TGA",
    "sequence": "GTCACATTGCA",
    "postsequence": "TCC",
    "target": "GTGACATKGCA",
    "strand": -1,
    "matches": [
     true,
     true,
     false,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true
    ],
    "left": {
     "name": "ctg1_293",
     "location": 305043,
     "strand": -1
    },
    "contained_by_left": false,
    "right": {
     "name": "ctg1_294",
     "location": 305393,
     "strand": -1
    }
   },
   {
    "name": "ZuR",
    "start": 323755,
    "end": 323770,
    "confidence": "weak",
    "score": 20.4057613667494,
    "presequence": "AAA",
    "sequence": "TATAAATGATAATCA",
    "postsequence": "TTA",
    "target": "TGAAAATGANNTTCA",
    "strand": -1,
    "matches": [
     true,
     false,
     false,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     false,
     true,
     true,
     true
    ],
    "left": {
     "name": "ctg1_307",
     "location": 323616,
     "strand": -1
    },
    "contained_by_left": false,
    "right": {
     "name": "ctg1_308",
     "location": 323804,
     "strand": 1
    }
   },
   {
    "name": "AfsR",
    "start": 346019,
    "end": 346031,
    "confidence": "medium",
    "score": 19.283765867148958,
    "presequence": "ATG",
    "sequence": "GGAAAGGAACGC",
    "postsequence": "AGA",
    "target": "GTAAATGAACGC",
    "strand": 1,
    "matches": [
     true,
     false,
     true,
     true,
     true,
     false,
     true,
     true,
     true,
     true,
     true,
     true
    ],
    "left": {
     "name": "ctg1_331",
     "location": 345978,
     "strand": 1
    },
    "contained_by_left": true,
    "right": {
     "name": "ctg1_331",
     "location": 346767,
     "strand": 1
    }
   }
  ],
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "C",
        "description": "Condensation_Starter",
        "modifier": false,
        "special": false,
        "cds": "ctg1_301",
        "css": "jsdomain-condensation",
        "inactive": false,
        "start": 2,
        "terminalDocking": ""
       },
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "ctg1_301",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 461,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PCP",
        "modifier": false,
        "special": false,
        "cds": "ctg1_301",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 976,
        "terminalDocking": ""
       },
       {
        "name": "TE",
        "description": "Thioesterase",
        "modifier": false,
        "special": false,
        "cds": "ctg1_301",
        "css": "jsdomain-terminal",
        "inactive": false,
        "start": 1066,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "Ser"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg1_281": {
     "functions": [
      {
       "description": "PF00881",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1159:dihydropteridine reductase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_282": {
     "functions": [
      {
       "description": "SMCOG1198:hypothetical protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_283": {
     "functions": [
      {
       "description": "SMCOG1253:putative lipoprotein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_284": {
     "functions": [
      {
       "description": "SMCOG1165:carboxylate-amine ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_285": {
     "functions": []
    },
    "ctg1_286": {
     "functions": []
    },
    "ctg1_287": {
     "functions": [
      {
       "description": "adh_short",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "adh_short_C2",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1001:short-chain dehydrogenase/reductase SDR ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_288": {
     "functions": [
      {
       "description": "adh_short",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1001:short-chain dehydrogenase/reductase SDR ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_289": {
     "functions": [
      {
       "description": "SMCOG1113:inner-membrane translocator ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_290": {
     "functions": [
      {
       "description": "SMCOG1000:ABC transporter ATP-binding protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_291": {
     "functions": []
    },
    "ctg1_292": {
     "functions": [
      {
       "description": "SMCOG1205:ABC transporter, carbohydrate uptake ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_293": {
     "functions": [
      {
       "description": "SMCOG1210:glycerol kinase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_294": {
     "functions": []
    },
    "ctg1_295": {
     "functions": [
      {
       "description": "DXP_synthase_N",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "TPP_enzyme_C",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1204:transketolase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_296": {
     "functions": [
      {
       "description": "SMCOG1110:1-deoxy-D-xylulose-5-phosphate synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_297": {
     "functions": [
      {
       "description": "SMCOG1060:4'-phosphopantetheinyl transferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_298": {
     "functions": [
      {
       "description": "SMCOG1082:TonB-dependent siderophore receptor family ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_299": {
     "functions": [
      {
       "description": "SMCOG1098:enterobactin/ferric enterobactin esterase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_300": {
     "functions": [
      {
       "description": "SMCOG1009:mbtH-like protein ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_301": {
     "functions": [
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Condensation",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Condensation",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1127:condensation domain-containing protein ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_302": {
     "functions": [
      {
       "description": "SMCOG1254:ferric enterobactin transport protein FepE ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_303": {
     "functions": [
      {
       "description": "SMCOG1000:ABC transporter ATP-binding protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_304": {
     "functions": [
      {
       "description": "SMCOG1011:transport system permease protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_305": {
     "functions": [
      {
       "description": "SMCOG1011:transport system permease protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_306": {
     "functions": [
      {
       "description": "SMCOG1020:major facilitator transporter ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_307": {
     "functions": [
      {
       "description": "SMCOG1033:iron compound ABC transporter, periplasmic ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_308": {
     "functions": [
      {
       "description": "EntC",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1018:isochorismate synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_309": {
     "functions": [
      {
       "description": "AMP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_310": {
     "functions": [
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1027:isochorismatase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_311": {
     "functions": [
      {
       "description": "EntA",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "adh_short_C2",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1001:short-chain dehydrogenase/reductase SDR ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_312": {
     "functions": [
      {
       "description": "SMCOG1144:thioesterase superfamily protein ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_313": {
     "functions": [
      {
       "description": "SMCOG1185:carbon starvation protein A ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_314": {
     "functions": [
      {
       "description": "SMCOG1211:hypothetical protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_315": {
     "functions": [
      {
       "description": "Fe-ADH",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1181:dehydrogenase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_316": {
     "functions": [
      {
       "description": "Aminotran_1_2",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "DegT_DnrJ_EryC1",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1019:aminotransferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_317": {
     "functions": [
      {
       "description": "SMCOG1232:hypothetical protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_318": {
     "functions": [
      {
       "description": "SMCOG1221:hypothetical protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_319": {
     "functions": [
      {
       "description": "SMCOG1125:LysR family transcriptional regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_320": {
     "functions": [
      {
       "description": "SMCOG1233:disulfide isomerase/thiol-disulfide oxidase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_321": {
     "functions": [
      {
       "description": "SMCOG1196:alkyl hydroperoxide reductase/ Thiol specific ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_322": {
     "functions": [
      {
       "description": "Pyr_redox_2",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1176:alkyl hydroperoxide reductase subunit ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_323": {
     "functions": []
    },
    "ctg1_324": {
     "functions": []
    },
    "ctg1_325": {
     "functions": []
    },
    "ctg1_326": {
     "functions": []
    },
    "ctg1_327": {
     "functions": []
    },
    "ctg1_328": {
     "functions": []
    },
    "ctg1_329": {
     "functions": [
      {
       "description": "SMCOG1255:cold-shock DNA-binding domain protein ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_330": {
     "functions": []
    },
    "ctg1_331": {
     "functions": [
      {
       "description": "SMCOG1294:Nitrilase/cyanide hydratase and apolipoprotein ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_332": {
     "functions": []
    },
    "ctg1_333": {
     "functions": [
      {
       "description": "PF04055",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    }
   }
  }
 },
 "r1c2": {
  "antismash.modules.tfbs_finder": [],
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg1_1696": {
     "functions": []
    },
    "ctg1_1697": {
     "functions": [
      {
       "description": "SMCOG1132:DNA-binding protein HU 1 ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_1698": {
     "functions": []
    },
    "ctg1_1699": {
     "functions": []
    },
    "ctg1_1700": {
     "functions": []
    },
    "ctg1_1701": {
     "functions": [
      {
       "description": "Aminotran_5",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg1_1702": {
     "functions": []
    },
    "ctg1_1703": {
     "functions": [
      {
       "description": "YcaO",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg1_1704": {
     "functions": []
    },
    "ctg1_1705": {
     "functions": []
    },
    "ctg1_1706": {
     "functions": [
      {
       "description": "PF04055",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Fer4_12",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg1_1707": {
     "functions": [
      {
       "description": "SMCOG1038:phenylalanine-specific permease ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_1708": {
     "functions": [
      {
       "description": "SMCOG1169:sugar transport protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_1709": {
     "functions": []
    },
    "ctg1_1710": {
     "functions": []
    },
    "ctg1_1711": {
     "functions": []
    },
    "ctg1_1712": {
     "functions": []
    }
   }
  }
 },
 "r1c3": {
  "antismash.modules.tfbs_finder": [
   {
    "name": "ZuR",
    "start": 3941731,
    "end": 3941746,
    "confidence": "medium",
    "score": 20.67047351896721,
    "presequence": "CGT",
    "sequence": "TGAATATAATTTTCC",
    "postsequence": "TGA",
    "target": "TGAANNTCATTTTCA",
    "strand": 1,
    "matches": [
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     false,
     true,
     true,
     true,
     true,
     true,
     true,
     false
    ],
    "left": {
     "name": "ctg1_3638",
     "location": 3941292,
     "strand": -1
    },
    "contained_by_left": true,
    "right": {
     "name": "ctg1_3638",
     "location": 3941766,
     "strand": -1
    }
   },
   {
    "name": "DmdR1",
    "start": 3928388,
    "end": 3928407,
    "confidence": "weak",
    "score": 23.607240402920304,
    "presequence": "TTG",
    "sequence": "TCAGATTATGTTCGCCTTC",
    "postsequence": "GCC",
    "target": "TTAGGTTAGGCTCACCTWA",
    "strand": 1,
    "matches": [
     true,
     false,
     true,
     true,
     false,
     true,
     true,
     true,
     false,
     true,
     false,
     true,
     true,
     false,
     true,
     true,
     true,
     true,
     false
    ],
    "left": null,
    "contained_by_left": false,
    "right": {
     "name": "ctg1_3629",
     "location": 3930138,
     "strand": -1
    }
   },
   {
    "name": "ZuR",
    "start": 3928933,
    "end": 3928948,
    "confidence": "weak",
    "score": 20.44912176020834,
    "presequence": "GGC",
    "sequence": "TGAAAATGAAATACC",
    "postsequence": "CCG",
    "target": "TGAAAATGANNTTCA",
    "strand": -1,
    "matches": [
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     true,
     false,
     true,
     false
    ],
    "left": null,
    "contained_by_left": false,
    "right": {
     "name": "ctg1_3629",
     "location": 3930138,
     "strand": -1
    }
   },
   {
    "name": "ZuR",
    "start": 3931538,
    "end": 3931553,
    "confidence": "weak",
    "score": 20.083504578529244,
    "presequence": "ATG",
    "sequence": "TGATAGTCATATTCT",
    "postsequence": "TTT",
    "target": "TGAANNTCATTTTCA",
    "strand": 1,
    "matches": [
     true,
     true,
     true,
     false,
     true,
     true,
     true,
     true,
     true,
     true,
     false,
     true,
     true,
     true,
     false
    ],
    "left": {
     "name": "ctg1_3629",
     "location": 3931191,
     "strand": -1
    },
    "contained_by_left": false,
    "right": {
     "name": "ctg1_3630",
     "location": 3931923,
     "strand": 1
    }
   }
  ],
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg1_3629": {
     "functions": []
    },
    "ctg1_3630": {
     "functions": [
      {
       "description": "SMCOG1029:RND family efflux transporter MFP subunit ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3631": {
     "functions": [
      {
       "description": "SMCOG1000:ABC transporter ATP-binding protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3632": {
     "functions": [
      {
       "description": "SMCOG1065:ABC-2 type transporter ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3633": {
     "functions": []
    },
    "ctg1_3634": {
     "functions": []
    },
    "ctg1_3635": {
     "functions": [
      {
       "description": "SMCOG1210:glycerol kinase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3636": {
     "functions": []
    },
    "ctg1_3637": {
     "functions": []
    },
    "ctg1_3638": {
     "functions": []
    },
    "ctg1_3639": {
     "functions": [
      {
       "description": "SMCOG1136:GntR family transcriptional regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3640": {
     "functions": []
    },
    "ctg1_3641": {
     "functions": []
    },
    "ctg1_3642": {
     "functions": [
      {
       "description": "SMCOG1012:4'-phosphopantetheinyl transferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3643": {
     "functions": [
      {
       "description": "APE_KS1",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1022:Beta-ketoacyl synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3644": {
     "functions": [
      {
       "description": "adh_short",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1001:short-chain dehydrogenase/reductase SDR ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3645": {
     "functions": []
    },
    "ctg1_3646": {
     "functions": [
      {
       "description": "APE_KS2",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1022:Beta-ketoacyl synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3647": {
     "functions": []
    },
    "ctg1_3648": {
     "functions": []
    },
    "ctg1_3649": {
     "functions": []
    },
    "ctg1_3650": {
     "functions": []
    },
    "ctg1_3651": {
     "functions": [
      {
       "description": "Glycos_transf_2",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1123:polyprenol-monophosphomannose synthase ppm1 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3652": {
     "functions": []
    },
    "ctg1_3653": {
     "functions": [
      {
       "description": "AMP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3654": {
     "functions": []
    },
    "ctg1_3655": {
     "functions": [
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg1_3656": {
     "functions": [
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg1_3657": {
     "functions": [
      {
       "description": "SMCOG1141:acyltransferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3658": {
     "functions": []
    },
    "ctg1_3659": {
     "functions": [
      {
       "description": "SMCOG1042:O-methyltransferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3660": {
     "functions": []
    },
    "ctg1_3661": {
     "functions": []
    },
    "ctg1_3662": {
     "functions": [
      {
       "description": "SMCOG1020:major facilitator transporter ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3663": {
     "functions": []
    },
    "ctg1_3664": {
     "functions": []
    },
    "ctg1_3665": {
     "functions": []
    },
    "ctg1_3666": {
     "functions": []
    },
    "ctg1_3667": {
     "functions": [
      {
       "description": "SMCOG1037:heavy metal translocating P-type ATPase ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg1_3668": {
     "functions": []
    }
   }
  }
 }
};
